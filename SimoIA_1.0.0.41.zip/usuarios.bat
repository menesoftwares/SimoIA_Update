@echo off
rem Atalho para o cadastro de usuarios (ferramentas\usuarios.js).
rem No PowerShell:  .\usuarios listar      No Prompt (cmd):  usuarios listar
rem Ajuda com todos os comandos:  .\usuarios ajuda
node "%~dp0ferramentas\usuarios.js" %*
