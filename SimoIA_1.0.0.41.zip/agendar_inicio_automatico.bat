@echo off
rem Agenda o AgenteIA para iniciar sozinho quando o Windows ligar (mesmo sem ninguem entrar),
rem rodando com o SEU usuario do Windows (onde esta salva a conexao "probus" do SQLcl).
rem Tambem libera a porta 3000 no firewall para a rede interna.
rem >>> Clique com o botao direito neste arquivo e escolha "Executar como administrador". <<<

net session >nul 2>&1
if not %errorlevel%==0 (
  echo Este arquivo precisa ser executado como Administrador.
  echo Clique com o botao direito nele e escolha "Executar como administrador".
  pause
  exit /b 1
)

echo.
echo Usuario do Windows que vai rodar o AgenteIA: %USERDOMAIN%\%USERNAME%
echo Digite a SENHA desse usuario do Windows quando for pedida (nao aparece na tela).
echo.
schtasks /create /f /tn AgenteIA /sc onstart /delay 0001:00 /rl limited ^
  /ru "%USERDOMAIN%\%USERNAME%" /rp * ^
  /tr "wscript.exe \"C:\AgenteIA\iniciar_oculto.vbs\""
if not %errorlevel%==0 (
  echo.
  echo Nao foi possivel criar a tarefa. Confira a senha e tente de novo.
  pause
  exit /b 1
)

netsh advfirewall firewall delete rule name="AgenteIA" >nul 2>&1
netsh advfirewall firewall add rule name="AgenteIA" dir=in action=allow protocol=TCP localport=3000 profile=private,domain >nul
echo Firewall: porta 3000 liberada para a rede interna.

echo.
echo Pronto. O AgenteIA vai iniciar sozinho 1 minuto depois que o Windows ligar.
echo Para iniciar agora:   iniciar_servico.bat
echo Para parar:           parar_servico.bat
echo Para desfazer:        schtasks /delete /tn AgenteIA /f
