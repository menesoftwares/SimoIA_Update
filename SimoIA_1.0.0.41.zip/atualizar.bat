@echo off
rem ===========================================================================
rem  Atualizador do SimoIA. Clique com o botao direito > "Executar como administrador".
rem  Mostra as etapas na tela e pausa no fim. NAO toca em dados\ nem config\.
rem  Dica: NAO clique dentro desta janela preta enquanto ela roda (o Windows pausa
rem  o processo ate voce clicar/apertar de novo). Se parecer travado, aperte Enter.
rem ===========================================================================
net session >nul 2>&1
if not %errorlevel%==0 goto semadmin
call "%~dp0_atualizar_core.bat"
echo.
pause
exit /b

:semadmin
echo Este arquivo precisa ser executado como Administrador.
echo Clique com o botao direito nele e escolha "Executar como administrador".
echo.
pause
exit /b 1
