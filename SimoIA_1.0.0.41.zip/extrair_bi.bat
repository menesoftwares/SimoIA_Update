@echo off
rem Atalho para extrair um BI do banco (ferramentas\extrair_bi.js). Grava em tmp\bi_<w_id>\
rem No PowerShell:  .\extrair_bi 15272      No Prompt (cmd):  extrair_bi 15272
node "%~dp0ferramentas\extrair_bi.js" %*
