/* SimoIA - codigo gerado, nao editar */
"use strict";const n=require("fs"),_=require("path"),m=[{id:"2026-11-02_01_coletor_pendentes",descricao:"Coletor: SQL das notas a conferir e parametros (mostrar e data inicial)",up(e){e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("pendentes","Notas a conferir (lista da tela inicial do Coletor): sem nenhuma leitura ativa, emitidas a partir da data do par\xE2metro",`select x.id_transacao, x.empresa, x.especie_docto, x.nr_docto, to_char(x.dt_emissao, 'dd/mm/yyyy') dt_emissao,
       x.codigo, x.nome, x.fantasia, x.tr_nome, count(*) itens
  from (#DOCUMENTOS#) x
 where x.dt_emissao >= to_date(#DESDE#, 'dd/mm/yyyy')
   and not exists (select 1
                     from wonder.simo_conferencia_doctos c
                    where c.w_id_transacao = x.id_transacao
                      and c.cancelado = 'N'
                      and c.eliminado = 'N')
 group by x.id_transacao, x.empresa, x.especie_docto, x.nr_docto, x.dt_emissao, x.codigo, x.nome, x.fantasia, x.tr_nome
 order by x.dt_emissao, x.nr_docto`,'#DOCUMENTOS# = o SQL "documentos" (uma linha por item); #DESDE# = data do par\xE2metro "Notas a conferir a partir de" (Gest\xE3o \u203A Coletor \u203A Ajustes). Manter as colunas ID_TRANSACAO, NR_DOCTO, DT_EMISSAO, CODIGO, NOME, FANTASIA, TR_NOME e ITENS. As notas em coleta (reservadas) saem da lista no servidor.'),e.prepare("insert or ignore into sistema_config (chave, valor, alterado_por) values ('coletor_pendentes', '1', 'inicial')").run(),e.prepare("insert or ignore into sistema_config (chave, valor, alterado_por) values ('coletor_pendentes_desde', date('now','localtime'), 'inicial')").run()}},{id:"2026-11-02_02_versoes_instaladas",descricao:"Tabela versoes_instaladas (versao, anterior, data em que subiu pela primeira vez)",up(e){e.exec(`create table if not exists versoes_instaladas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        versao TEXT NOT NULL,
        anterior TEXT,
        instalada_em TEXT NOT NULL DEFAULT (datetime('now','localtime'))
      )`)}},{id:"2026-11-03_01_coletor_finalizacao",descricao:"Coletor: SQLs finalizar, reabrir e abertas; conferidos com DT_CONFERENCIA e USUARIO_CONFERENCIA",up(e){const t=e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')");t.run("finalizar","Finaliza a confer\xEAncia da nota (preenche DT_CONFERENCIA e USUARIO_CONFERENCIA nas leituras ativas)",`update wonder.simo_conferencia_doctos
   set dt_conferencia = sysdate, usuario_conferencia = #USUARIO#
 where w_id_transacao = #W_ID_TRANSACAO#
   and cancelado = 'N'
   and eliminado = 'N'`,'Bot\xE3o "Finalizar" do Coletor (s\xF3 com tudo conferido). O servidor junta num bloco com commit.'),t.run("reabrir","Reabre a confer\xEAncia da nota (apaga DT_CONFERENCIA e USUARIO_CONFERENCIA)",`update wonder.simo_conferencia_doctos
   set dt_conferencia = null, usuario_conferencia = null
 where w_id_transacao = #W_ID_TRANSACAO#
   and dt_conferencia is not null`,"Vai junto de cancelar leitura, excluir item, abandonar, liberar e de abrir de novo uma nota finalizada. #USUARIO# tamb\xE9m pode ser usado."),t.run("abertas","Notas em confer\xEAncia pelo banco (leitura ativa sem DT_CONFERENCIA), para as que est\xE3o sem reserva no Coletor",`select x.id_transacao, x.empresa, x.especie_docto, x.nr_docto, to_char(x.dt_emissao, 'dd/mm/yyyy') dt_emissao,
       x.codigo, x.nome, x.fantasia, x.tr_nome, count(*) itens,
       to_char(c.ultima, 'dd/mm/yyyy hh24:mi:ss') ultima_leitura, c.usuario, c.tipo_coleta, c.leituras
  from (#DOCUMENTOS#) x,
       (select w_id_transacao, max(dt_criacao) ultima, count(*) leituras,
               max(usuario_criacao) keep (dense_rank last order by dt_criacao, w_id) usuario,
               max(tipo_coleta) keep (dense_rank last order by dt_criacao, w_id) tipo_coleta
          from wonder.simo_conferencia_doctos
         where cancelado = 'N'
           and eliminado = 'N'
           and dt_conferencia is null
         group by w_id_transacao) c
 where c.w_id_transacao = x.id_transacao
 group by x.id_transacao, x.empresa, x.especie_docto, x.nr_docto, x.dt_emissao, x.codigo, x.nome, x.fantasia, x.tr_nome,
          c.ultima, c.usuario, c.tipo_coleta, c.leituras
 order by c.ultima desc`,'#DOCUMENTOS# = o SQL "documentos". Manter as colunas ID_TRANSACAO, NR_DOCTO, DT_EMISSAO, FANTASIA, NOME, TR_NOME, ULTIMA_LEITURA, USUARIO e TIPO_COLETA. As reservadas (com conferente no Coletor) saem da lista no servidor.'),e.prepare("update coletor_sql set sql_texto = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = 'conferidos' and replace(sql_texto, char(13), '') = ?").run(`select w_id, w_id_movitens, sequencia, w_id_produto, cod_item, num_lote, bipe_checkout, qtd_checkout, qtd_conferida, observacao,
       tipo_coleta, to_char(dt_criacao, 'dd/mm/yyyy hh24:mi:ss') dt_criacao, usuario_criacao,
       to_char(dt_conferencia, 'dd/mm/yyyy hh24:mi:ss') dt_conferencia, usuario_conferencia
  from wonder.simo_conferencia_doctos
 where w_id_transacao = #W_ID_TRANSACAO#
   and cancelado = 'N'
   and eliminado = 'N'
 order by w_id desc`,"Mostrado na tela de coleta (totais por item e hist\xF3rico de leituras). TIPO_COLETA define o tipo em que a coleta continua. DT_CONFERENCIA/USUARIO_CONFERENCIA: preenchidos em todas = nota finalizada.",`select w_id, w_id_movitens, sequencia, w_id_produto, cod_item, num_lote, bipe_checkout, qtd_checkout, qtd_conferida, observacao,
       tipo_coleta, to_char(dt_criacao, 'dd/mm/yyyy hh24:mi:ss') dt_criacao, usuario_criacao
  from wonder.simo_conferencia_doctos
 where w_id_transacao = #W_ID_TRANSACAO#
   and cancelado = 'N'
   and eliminado = 'N'
 order by w_id desc`)}},{id:"2026-11-03_02_coletor_documentos_plano_cv",descricao:"Coletor: SQL documentos com wonder.plano_compravenda (tipo de documento ligado ao plano)",up(e){const t=e.prepare("select sql_texto from coletor_sql where chave = 'documentos'").get(),o=t?t.sql_texto:"";if(/plano_compravenda/i.test(o))return;const a=/(wonder\.est_produtos_emp\s+pr)([ \t]*\r?\n\s*where\b)/i,r=/(and\s+m\.empresa\s*=\s*pr\.empresa)([ \t]*\r?\n)/i;if(!a.test(o)||!r.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "documentos" do Coletor nao reconhecido; nao foi alterado. Acrescente wonder.plano_compravenda pcv, tp.w_id_plano_cv = pcv.w_id e tp.empresa = pcv.empresa na Gestao > Coletor.');return}const i=o.replace(a,`$1,
       wonder.plano_compravenda pcv$2`).replace(r,`$1
   and tp.w_id_plano_cv = pcv.w_id
   and tp.empresa = pcv.empresa$2`);e.prepare("update coletor_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'documentos'").run(i)}},{id:"2026-11-04_01_simulador_tipos_docto_plano_cv",descricao:"Simulador: SQL tipos_docto com wonder.plano_compravenda (tipo de documento ligado ao plano)",up(e){const t=e.prepare("select sql_texto from simulador_sql where chave = 'tipos_docto'").get(),o=t?t.sql_texto:"";if(/plano_compravenda/i.test(o))return;const a=/(wonder\.cml_tiposdoc\s+td)[ \t]*(\r?\n\s*where)\s+/i;if(!a.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "tipos_docto" do Simulador nao reconhecido; nao foi alterado. Acrescente wonder.plano_compravenda pcv, td.w_id_plano_cv = pcv.w_id e td.empresa = pcv.empresa na Gestao.');return}const r=o.replace(a,`$1,
       wonder.plano_compravenda pcv$2 td.w_id_plano_cv = pcv.w_id
   and td.empresa = pcv.empresa
   and `);e.prepare("update simulador_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'tipos_docto'").run(r)}},{id:"2026-11-04_02_simulador_pedidos_cod_tabpreco",descricao:"Simulador: SQLs pedidos e pedido_numero com ipv.cod_tabpreco (tabela de preco do item no pedido)",up(e){const t=/(ipv\.sequencia)([ \t]*,[ \t]*\r?\n\s*pv\.empresa\b)/i,o=/(ipv\.sequencia\s*,\s*pv\.num_carga)\b/i,a=" COD_TABPRECO (tabela de pre\xE7o do item no pedido) \xE9 opcional: sem ela, o item segue a tabela das Configura\xE7\xF5es.";for(const r of["pedidos","pedido_numero"]){const i=e.prepare("select sql_texto, observacao from simulador_sql where chave = ?").get(r);if(!i)continue;const d=i.sql_texto;if(!/cod_tabpreco/i.test(d)){if(!t.test(d)||!o.test(d)){console.log(new Date().toISOString()+' ATENCAO: SQL "'+r+'" do Simulador nao reconhecido; nao foi alterado. Acrescente ipv.cod_tabpreco no select e no group by na Gestao.');continue}const l=d.replace(t,"$1, ipv.cod_tabpreco$2").replace(o,"$1, ipv.cod_tabpreco");e.prepare("update simulador_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = ?").run(l,r)}/COD_TABPRECO/.test(i.observacao||"")||e.prepare("update simulador_sql set observacao = ? where chave = ?").run((i.observacao||"")+a,r)}}},{id:"2026-11-04_03_coletor_etiquetas",descricao:"Coletor: permissao pode_col_etiq e SQLs etiqueta_produtos e etiqueta_lotes",up(e,t){t.adicionarColuna("usuarios","pode_col_etiq","INTEGER NOT NULL DEFAULT 0");const o=e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')");o.run("etiqueta_produtos","Gerar etiqueta: produtos para escolher",`Select prod.codigo, prod.descricao, prod.unmed, prod.Peso_Liquido, prod.Peso_Bruto, prod.Volume_cubico,
       case when prod.UndAlt_Fator_Qtde = 1 then 0 else prod.Peso_Liquido/(prod.UndAlt_Fator_Qtde/1000) end peso_pct,
       prod.catproduto, prod.desc_cat, prod.fabricante, prod.desc_fab, prod.grupo, prod.desc_grupo,
       prod.grupo_1, prod.grupo_2, prod.grupo_3, prod.grupo_4, prod.grupo_5, eh_Kit
 From(
      Select pr.codigo, pr.descricao, pr.unmed, pr.Peso_Liquido, pr.Peso_Bruto, pr.Volume_cubico,
             pr.catproduto, pr.fabricante, pr.grupo,
             cat.descricao desc_cat, fab.descricao desc_fab, grp.descricao desc_grupo,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,1) as grupo_1,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,2) as grupo_2,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,3) as grupo_3,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,4) as grupo_4,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,5) as grupo_5,
             Nvl(Decode(UndAlt.Cod_Unidade, pr.UnMed, UndAlt.Cod_UndResult, UndAlt.Cod_Unidade),pr.UnMed) as UndAlt,
             Nvl(Wonder.Probus_Estoque.ObtemQtdEquiv(pr.W_Id, pr.UnMed, 1, Decode(UndAlt.Cod_Unidade, pr.UnMed, UndAlt.Cod_UndResult, UndAlt.Cod_Unidade), 'N'),1) UndAlt_Fator_Qtde,
             Nvl(Wonder.Probus_Estoque.ObtemQtdEquiv(pr.W_Id, Decode(UndAlt.Cod_Unidade, pr.UnMed, UndAlt.Cod_UndResult, UndAlt.Cod_Unidade), 1, pr.UnMed, 'N'),1) UndAlt_Fator_Valores,
             case when ee.tipo_estrutura = 'KIT' then 'S' else 'N' end eh_Kit
        From wonder.MOB_Envio_Prod ep, wonder.est_produtos pr, Wonder.EST_Produtos_Emp ee,
             wonder.est_catproduto cat, wonder.est_fabricantes fab, wonder.est_grupos grp,
             (Select e.W_Id_Produto,
                     min(e.w_id) w_id,
                     trim(substr( min( to_char(e.w_id,'FM000000000000000')||rpad(e.cod_unidade,5)   ), 16,5)) cod_unidade,
                     trim(substr( min( to_char(e.w_id,'FM000000000000000')||rpad(e.cod_undresult,5) ), 16,5)) cod_undresult
                from Wonder.Est_Prod_Und_Equiv e
               Group by e.w_id_produto
             ) UndAlt
       Where ep.w_id_produto = pr.w_id
         and pr.w_id = ee.w_id_produto
         and ee.empresa = pr.empresa --s\xF3 pega da mestre
         and pr.w_id = UndAlt.w_id_produto(+)
         and pr.w_id_cat_produto = cat.w_id(+)
         and pr.w_id_fabricante = fab.w_id(+)
         and pr.w_id_grupo = grp.w_id(+)
         and ep.w_id_vendedor in (select p.w_id from wonder.pessoas p where p.codigo in (26349, 999))
         and pr.catproduto in ('7')
         and pr.fabricante in ('2','1')
         and pr.ativo = 'S'
         and ep.disponivel = 'S'
      ) prod
 Order by prod.descricao`,"Manter as colunas CODIGO e DESCRICAO."),o.run("etiqueta_lotes","Gerar etiqueta: lotes do produto escolhido",`select epc.cod_produto, epc.cod_subproduto, el.lote, el.validade
  from wonder.est_produto_compos epc,
       wonder.est_produtos_emp pe,
       wonder.est_lotes_produto el
 where epc.w_id_subproduto = pe.w_id_produto
   and pe.tipo_estrutura = 'P' and pe.empresa = 1
   and epc.w_id_subproduto = el.w_id_produto
   and epc.empresa_m = el.empresa_m
   and pe.empresa = el.empresa
   and el.lote is not null and el.lote <> '_CTRL_LOTE_ATIVADO_APOS_'
   and epc.cod_produto = #COD_ITEM#
 order by el.lote desc`,"Manter a coluna LOTE e o marcador #COD_ITEM# (c\xF3digo do produto escolhido, j\xE1 vai entre aspas).")}},{id:"2026-11-04_04_coletor_etiqueta_kits",descricao:"Coletor: SQL etiqueta_kits (kits e componentes para a etiqueta)",up(e){e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("etiqueta_kits","Gerar etiqueta: kits e seus componentes (uma linha por componente)",`select kit.codigo, kit.descricao, kit.unmed, cast(c.Sequencia as int) seq,
       p.codigo cod_matrial, p.descricao descr_material, p.unmed unid_material, c.quantidade
from Wonder.Est_Produto_Compos c, Wonder.Est_Produtos p,
     Wonder.Est_Produtos kit, Wonder.Est_Espprodemp e, Wonder.Est_Espprodemp ekit,
     Wonder.EST_Produtos_Emp estkit, Wonder.Est_Produtos i
where c.W_Id_SubProduto = p.W_Id
  and c.w_id_produto = kit.w_id
  and kit.w_id = ekit.w_id_produto
  and kit.w_id = estkit.w_id_produto
  and p.w_id = e.w_id_produto
  and c.Hash_Produto = '-1'
  and ekit.empresa = e.empresa
  and ekit.empresa = estkit.empresa
  and estkit.tipo_estrutura = 'KIT'
  and kit.ativo = 'S'
  and i.codigo(+) = p.obs
  and e.empresa in (1)
order by cast(kit.codigo as int), cast(c.Sequencia as int)`,"Manter as colunas CODIGO, DESCRICAO, COD_MATRIAL, DESCR_MATERIAL e QUANTIDADE. Uma linha por componente: o sistema agrupa por CODIGO, na ordem do SQL.")}},{id:"2026-11-04_05_coletor_etiqueta_lotes_kit",descricao:"Coletor: SQL etiqueta_lotes_kit (lotes dos componentes do kit)",up(e){e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("etiqueta_lotes_kit","Gerar etiqueta: lotes dos componentes do kit escolhido",`select pr.codigo, el.lote, el.validade, el.qtd_estoque
  from wonder.est_produtos pr,
       wonder.est_produtos_emp pe,
       wonder.est_lotes_produto el
 where pr.w_id = pe.w_id_produto
   and pe.tipo_estrutura = 'P' and pe.empresa = 1
   and pr.w_id = el.w_id_produto
   and pr.empresa = el.empresa_m
   and pe.empresa = el.empresa
   and el.lote is not null and el.lote <> '_CTRL_LOTE_ATIVADO_APOS_' --and el.qtd_estoque
   and pr.codigo in (#COD_ITENS#)
 order by el.lote desc`,"Manter as colunas CODIGO, LOTE e VALIDADE e o marcador #COD_ITENS# (c\xF3digos dos componentes do kit, j\xE1 v\xE3o entre aspas e separados por v\xEDrgula).")}},{id:"2026-11-04_06_coletor_documentos_eh_kit",descricao:"Coletor: SQL documentos com a coluna EH_KIT",up(e){const t=e.prepare("select sql_texto from coletor_sql where chave = 'documentos'").get(),o=t?t.sql_texto:"";if(/\beh_kit\b/i.test(o))return;const a=/(mi\.unid_qtd_digitada)([ \t]*\r?\n\s*from\b)/i;if(!a.test(o)||!/wonder\.est_produtos_emp\s+pr\b/i.test(o)){console.log(new Date().toISOString()+` ATENCAO: SQL "documentos" do Coletor nao reconhecido; nao foi alterado. Acrescente a coluna: case when pr.tipo_estrutura = 'KIT' then 'S' else 'N' end eh_kit, na Gestao > Coletor.`);return}const r=o.replace(a,`$1,
       case when pr.tipo_estrutura = 'KIT' then 'S' else 'N' end eh_kit$2`);e.prepare("update coletor_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'documentos'").run(r)}},{id:"2026-11-05_01_coletor_etiqueta_sub_produto",descricao:"Coletor: SQL etiqueta_sub_produto; etiqueta_lotes_kit passa a ser etiqueta_lotes",up(e){e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("etiqueta_sub_produto","Gerar etiqueta: subprodutos do produto escolhido",`select epc.cod_produto, epc.cod_subproduto,
       (select sp.descricao from wonder.est_produtos sp where sp.w_id = epc.w_id_subproduto) desc_subproduto
  from wonder.est_produto_compos epc,
       wonder.est_produtos_emp pe
 where epc.w_id_subproduto = pe.w_id_produto
   and pe.tipo_estrutura = 'P' and pe.empresa = 1
   and epc.cod_produto = #COD_ITEM#`,"Manter as colunas COD_SUBPRODUTO e DESC_SUBPRODUTO (aparece na tela ao lado do c\xF3digo) e o marcador #COD_ITEM# (c\xF3digo do produto escolhido, j\xE1 vai entre aspas). Com 2 ou mais subprodutos, a tela pergunta qual usar."),e.prepare("select 1 from coletor_sql where chave = 'etiqueta_lotes_kit'").get()&&(e.prepare("delete from coletor_sql where chave = 'etiqueta_lotes'").run(),e.prepare("update coletor_sql set chave = 'etiqueta_lotes', descricao = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = 'etiqueta_lotes_kit'").run("Gerar etiqueta: lotes dos itens (subproduto escolhido ou componentes do kit)","Manter as colunas CODIGO, LOTE e VALIDADE e o marcador #COD_ITENS# (c\xF3digos dos itens, j\xE1 v\xE3o entre aspas e separados por v\xEDrgula)."))}},{id:"2026-11-05_02_simulador_produtos_undalt_fator_qtde",descricao:"Simulador: SQL produtos com a coluna UndAlt_Fator_Qtde",up(e){const t=e.prepare("select sql_texto from simulador_sql where chave = 'produtos'").get(),o=t?t.sql_texto:"";if(/volume_cubico\s*,\s*(prod\.)?undalt_fator_qtde\b/i.test(o))return;const a=/(prod\.Volume_cubico)(\s*,\s*case when prod\.UndAlt_Fator_Qtde\b)/i;if(!a.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "produtos" do Simulador nao reconhecido; nao foi alterado. Acrescente a coluna UndAlt_Fator_Qtde, na Gestao > Simulador.');return}e.prepare("update simulador_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'produtos'").run(o.replace(a,"$1, UndAlt_Fator_Qtde$2"))}},{id:"2026-11-05_03_coletor_etiqueta_lotes_validade",descricao:"Coletor: SQL etiqueta_lotes so com lotes na validade",up(e){const t=e.prepare("select sql_texto from coletor_sql where chave = 'etiqueta_lotes'").get(),o=t?t.sql_texto:"";if(/\bel\.validade\s*>\s*sysdate\b/i.test(o))return;const a=/([ \t]*--and el\.qtd_estoque)?(\s*\r?\n\s*and pr\.codigo in \(#COD_ITENS#\))/i;if(!a.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "etiqueta_lotes" do Coletor nao reconhecido; nao foi alterado. Acrescente a condicao: and el.validade > sysdate, na Gestao > Coletor.');return}e.prepare("update coletor_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'etiqueta_lotes'").run(o.replace(a,`
   and el.validade > sysdate$2`))}},{id:"2026-11-05_04_coletor_etiqueta_kits_sem_tabela_i",descricao:"Coletor: SQL etiqueta_kits sem a tabela Est_Produtos i",up(e){const t=e.prepare("select sql_texto from coletor_sql where chave = 'etiqueta_kits'").get(),o=t?t.sql_texto:"",a=/,\s*Wonder\.Est_Produtos\s+i\b/i,r=/\s*and\s+i\.codigo\s*\(\+\)\s*=\s*p\.obs\b/i;if(!(!a.test(o)&&!r.test(o))){if(!a.test(o)||!r.test(o)||/\bi\./i.test(o.replace(r,""))){console.log(new Date().toISOString()+' ATENCAO: SQL "etiqueta_kits" do Coletor nao reconhecido; nao foi alterado. Retire a tabela Wonder.Est_Produtos i e a condicao i.codigo(+) = p.obs, na Gestao > Coletor.');return}e.prepare("update coletor_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'etiqueta_kits'").run(o.replace(a,"").replace(r,""))}}},{id:"2026-11-05_05_coletor_etiqueta_linha_mm",descricao:"Coletor: tamanho da etiqueta em mm, pela linha de etiquetas",up(e){for(const t of["coletor_etiqueta_largura","coletor_etiqueta_altura"]){const o=e.prepare("select valor from sistema_config where chave = ?").get(t),a=o?Number(o.valor):NaN;isFinite(a)&&a>=1&&a<=30&&e.prepare("update sistema_config set valor = ? where chave = ?").run(String(Math.round(a*100)/10),t)}}},{id:"2026-11-06_01_coletor_rastreabilidade",descricao:"Coletor: permissao pode_col_rastro e SQL rastreabilidade",up(e,t){t.adicionarColuna("usuarios","pode_col_rastro","INTEGER NOT NULL DEFAULT 0"),e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("rastreabilidade","Rastreabilidade: notas em que o lote do produto foi conferido (uma linha por nota)",`select m.id_transacao, m.nr_docto, p.codigo, nvl(p.fantasia, p.nome) pessoa, sum(c.qtd_conferida) quantidade
  from wonder.simo_conferencia_doctos c,
       wonder.cml_movimento m,
       wonder.pessoas p
 where c.w_id_transacao = m.id_transacao
   and m.w_id_pessoa_filial = p.w_id
   and c.cancelado = 'N'
   and c.eliminado = 'N'
   and (c.cod_item = #COD_ITEM# or c.cod_comercial_item = #COD_ITEM#)
   and upper(c.num_lote) = upper(#NUM_LOTE#)
 group by m.id_transacao, m.nr_docto, p.codigo, p.fantasia, p.nome
 order by m.nr_docto desc, m.id_transacao desc`,"Manter as colunas ID_TRANSACAO, NR_DOCTO, CODIGO, PESSOA e QUANTIDADE e os marcadores #COD_ITEM# e #NUM_LOTE# (j\xE1 v\xE3o entre aspas). L\xEA as leituras do Coletor: nota sem leitura desse lote n\xE3o aparece.")}},{id:"2026-11-06_02_coletor_documentos_qtd_multipla",descricao:"Coletor: SQL documentos com mi.unidade e pr.qtd_multipla",up(e){const t=" pr.qtd_multipla (06/11/2026): inteira e diferente de zero, o item s\xF3 aceita quantidade inteira, mesmo com a v\xEDrgula permitida.",o=e.prepare("select sql_texto, observacao from coletor_sql where chave = 'documentos'").get();if(!o)return;const a=o.sql_texto,r=/(mi\.quantidade\s*,\s*)mi\.unid_qtd_digitada\b/i;let i=a;if(!/\bqtd_multipla\b/i.test(a)){if(!r.test(a)||!/wonder\.est_produtos_emp\s+pr\b/i.test(a)){console.log(new Date().toISOString()+' ATENCAO: SQL "documentos" do Coletor nao reconhecido; nao foi alterado. Acrescente as colunas mi.unidade e pr.qtd_multipla, na Gestao > Coletor.');return}i=a.replace(r,"$1mi.unidade, pr.qtd_multipla")}const d=String(o.observacao||"");e.prepare("update coletor_sql set sql_texto = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = 'documentos'").run(i,d.includes("pr.qtd_multipla")?d:d+t)}},{id:"2026-11-06_03_coletor_rastreabilidade_relatorio",descricao:"Coletor: SQL rastreabilidade com cidade e UF; SQL rastreabilidade_cab",up(e){e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("rastreabilidade_cab","Rastreabilidade: descri\xE7\xE3o do produto e validade do lote (cabe\xE7alho do relat\xF3rio)",`select pr.codigo, pr.descricao, to_char(el.validade, 'dd/mm/yyyy') validade
  from wonder.est_produtos pr,
       wonder.est_lotes_produto el
 where pr.w_id = el.w_id_produto(+)
   and upper(el.lote(+)) = upper(#NUM_LOTE#)
   and pr.codigo = #COD_ITEM#
 order by el.validade`,'Manter as colunas CODIGO, DESCRICAO e VALIDADE e os marcadores #COD_ITEM# e #NUM_LOTE# (j\xE1 v\xE3o entre aspas). Lote sem validade cadastrada: o relat\xF3rio mostra "n\xE3o informada".');const t=e.prepare("select sql_texto from coletor_sql where chave = 'rastreabilidade'").get(),o=t?t.sql_texto:"";if(/\bm\.cidade\b/i.test(o))return;const a=/(\bpessoa\s*,\s*)(sum\s*\(\s*c\.qtd_conferida\s*\)\s+quantidade)/i,r=/(group\s+by\s+m\.id_transacao\s*,[^\r\n]*)/i;if(!a.test(o)||!r.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "rastreabilidade" do Coletor nao reconhecido; nao foi alterado. Acrescente as colunas m.cidade e m.uf, na Gestao > Coletor.');return}e.prepare("update coletor_sql set sql_texto = ?, observacao = 'Manter as colunas ID_TRANSACAO, NR_DOCTO, CODIGO, PESSOA, CIDADE, UF e QUANTIDADE e os marcadores #COD_ITEM# e #NUM_LOTE# (j\xE1 v\xE3o entre aspas). L\xEA as leituras do Coletor: nota sem leitura desse lote n\xE3o aparece.', alterado_em = datetime('now','localtime') where chave = 'rastreabilidade'").run(o.replace(a,"$1m.cidade, m.uf, $2").replace(r,"$1, m.cidade, m.uf"))}},{id:"2026-11-06_04_coletor_sem_rastreabilidade_cab",descricao:"Coletor: retira o SQL rastreabilidade_cab",up(e){e.prepare("delete from coletor_sql where chave = 'rastreabilidade_cab'").run()}},{id:"2026-11-06_05_coletor_rastreabilidade_final",descricao:"Coletor: SQL rastreabilidade com produto, unidade e validade",up(e){e.prepare("update coletor_sql set sql_texto = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = 'rastreabilidade'").run(`select m.id_transacao, m.nr_docto, p.codigo, nvl(p.fantasia, p.nome) pessoa, m.cidade, m.uf, sum(c.qtd_conferida) quantidade,
       pr.codigo cod_produto, pr.descricao, pr.unmed, c.num_lote, to_char(el.validade, 'dd/mm/yyyy') validade
  from wonder.simo_conferencia_doctos c,
       wonder.cml_movimento m,
       wonder.cml_movitens mi,
       wonder.pessoas p,
       wonder.est_produtos pr,
       wonder.est_lotes_produto el
 where c.w_id_transacao = m.id_transacao
   and m.id_transacao = mi.id_transacao
   and c.w_id_movitens = mi.w_id
   and m.w_id_pessoa_filial = p.w_id
   and mi.w_id_produto = pr.w_id
   and pr.w_id = el.w_id_produto(+)
   and pr.empresa = el.empresa_m(+)
   and mi.empresa = el.empresa(+)
   and c.num_lote = el.num_lote(+)
   and c.cancelado = 'N' and c.eliminado = 'N'
   and m.cancelado = 'N' and m.eliminado = 'N'
   and mi.cancelado = 'N' and mi.eliminado = 'N'
   and (c.cod_item = #COD_ITEM# or c.cod_comercial_item = #COD_ITEM#)
   and upper(c.num_lote) = upper(#NUM_LOTE#)
 group by m.id_transacao, m.nr_docto, p.codigo, p.fantasia, p.nome, m.cidade, m.uf,
          pr.codigo, pr.descricao, pr.unmed, c.num_lote, el.validade
 order by m.nr_docto desc, m.id_transacao desc`,'Manter as colunas ID_TRANSACAO, NR_DOCTO, CODIGO (da pessoa), PESSOA, CIDADE, UF, QUANTIDADE, COD_PRODUTO, DESCRICAO, UNMED e VALIDADE e os marcadores #COD_ITEM# e #NUM_LOTE# (j\xE1 v\xE3o entre aspas). L\xEA as leituras do Coletor: nota sem leitura desse lote n\xE3o aparece. Lote fora do cadastro: a validade sai como "n\xE3o informada".')}},{id:"2026-11-06_06_coletor_rastreabilidade_finalizadas",descricao:"Coletor: SQL rastreabilidade so com conferencias finalizadas",up(e){const t=e.prepare("select sql_texto, observacao from coletor_sql where chave = 'rastreabilidade'").get(),o=t?t.sql_texto:"";if(/\bc\.dt_conferencia\b/i.test(o))return;const a=/(and\s+c\.cancelado\s*=\s*'N'\s+and\s+c\.eliminado\s*=\s*'N')/i;if(!a.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "rastreabilidade" do Coletor nao reconhecido; nao foi alterado. Acrescente c.dt_conferencia is not null e c.usuario_conferencia is not null, na Gestao > Coletor.');return}e.prepare("update coletor_sql set sql_texto = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = 'rastreabilidade'").run(o.replace(a,`$1
   and c.dt_conferencia is not null and c.usuario_conferencia is not null`),String(t.observacao||"").replace("L\xEA as leituras do Coletor: nota sem leitura desse lote n\xE3o aparece.","L\xEA as leituras de confer\xEAncias finalizadas no Coletor: nota sem leitura finalizada desse lote n\xE3o aparece."))}},{id:"2026-11-06_07_coletor_conferidas",descricao:"Coletor: SQL conferidas para a Manutencao",up(e){e.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("conferidas","Manuten\xE7\xE3o: notas conferidas (todas as leituras ativas finalizadas)",`select x.id_transacao, x.empresa, x.especie_docto, x.nr_docto, to_char(x.dt_emissao, 'dd/mm/yyyy') dt_emissao,
       x.codigo, x.nome, x.fantasia, x.tr_nome, count(*) itens,
       to_char(c.primeira, 'dd/mm/yyyy hh24:mi:ss') primeira_leitura, to_char(c.ultima, 'dd/mm/yyyy hh24:mi:ss') ultima_leitura,
       to_char(c.finalizada, 'dd/mm/yyyy hh24:mi:ss') dt_conferencia, c.usuario_conferencia
  from (#DOCUMENTOS#) x,
       (select w_id_transacao, min(dt_criacao) primeira, max(dt_criacao) ultima, max(dt_conferencia) finalizada,
               max(usuario_conferencia) keep (dense_rank last order by dt_conferencia) usuario_conferencia
          from wonder.simo_conferencia_doctos
         where cancelado = 'N'
           and eliminado = 'N'
         group by w_id_transacao
        having count(*) = count(dt_conferencia)) c
 where c.w_id_transacao = x.id_transacao
 group by x.id_transacao, x.empresa, x.especie_docto, x.nr_docto, x.dt_emissao, x.codigo, x.nome, x.fantasia, x.tr_nome,
          c.primeira, c.ultima, c.finalizada, c.usuario_conferencia
 order by c.finalizada desc, x.nr_docto desc`,'#DOCUMENTOS# = o SQL "documentos". Manter as colunas ID_TRANSACAO, NR_DOCTO, ESPECIE_DOCTO, DT_EMISSAO, CODIGO, NOME, FANTASIA, TR_NOME, ITENS, PRIMEIRA_LEITURA, ULTIMA_LEITURA, DT_CONFERENCIA e USUARIO_CONFERENCIA, com as datas nos formatos atuais. Os filtros da tela s\xE3o aplicados por fora, pelo servidor.')}},{id:"2026-11-07_01_sistema_logo",descricao:"Gestao: tabela das conversoes do logo principal, com o logo do projeto",up(e){e.exec(`create table if not exists sistema_logo (
  chave TEXT PRIMARY KEY,
  largura INTEGER NOT NULL,
  altura INTEGER NOT NULL,
  png BLOB NOT NULL,
  descricao TEXT,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`);const t=require("./icones"),o=e.prepare("insert or ignore into sistema_logo (chave, largura, altura, png, descricao, alterado_por) values (?, ?, ?, ?, ?, 'inicial')");for(const a of t.variantes(n.readFileSync(t.LOGO_PROJETO),{fundo:t.FUNDO_PADRAO}))o.run(a.chave,a.largura,a.altura,a.png,a.descricao);e.prepare("insert or ignore into sistema_config (chave, valor, alterado_por) values ('logo_fundo', ?, 'inicial')").run(t.corHex(t.FUNDO_PADRAO)),e.prepare("insert or ignore into sistema_config (chave, valor, alterado_por) values ('logo_arquivo', 'logo-app.png (logo do projeto)', 'inicial')").run()}},{id:"2026-11-07_02_nome_sistema",descricao:"Gestao: titulo da pagina (nome do sistema), comecando em SimoIA",up(e){e.prepare("insert or ignore into sistema_config (chave, valor, alterado_por) values ('nome_sistema', 'SimoIA', 'inicial')").run()}},{id:"2026-11-07_03_site_empresa",descricao:"Gestao: site da empresa (link do rodape), comecando em https://www.simonetto.ind.br",up(e){e.prepare("insert or ignore into sistema_config (chave, valor, alterado_por) values ('site_empresa', 'https://www.simonetto.ind.br', 'inicial')").run()}},{id:"2026-11-09_01_simulador_tributos_desconto",descricao:"Simulador: SQL tributos com aliq_icms_disp, vl_icms_disp, vl_desconto_pis e vl_desconto_cofins",up(e){const t=e.prepare("select sql_texto from simulador_sql where chave = 'tributos'").get(),o=t?t.sql_texto:"";if(!o||/\bvl_desconto_pis\b/i.test(o))return;const a=/(vl_base_cbs_ibs\s+varchar2\(\d+\)\s+path\s+'\$\.vl_base_cbs_ibs')/i,r=/(j\(r\.vl_base_cbs_ibs\))/i;if(!a.test(o)||!r.test(o)){console.log(new Date().toISOString()+' ATENCAO: SQL "tributos" do Simulador nao reconhecido; nao foi alterado. Acrescente as colunas aliq_icms_disp, vl_icms_disp, vl_desconto_pis e vl_desconto_cofins (no json_table e na saida), na Gestao > Simulador.');return}const i=o.replace(a,`$1,
             aliq_icms_disp              varchar2(40)  path '$$.aliq_icms_disp',
             vl_icms_disp                varchar2(40)  path '$$.vl_icms_disp',
             vl_desconto_pis             varchar2(40)  path '$$.vl_desconto_pis',
             vl_desconto_cofins          varchar2(40)  path '$$.vl_desconto_cofins'`).replace(r,`$1
      || ',"aliq_icms_disp":' || j(r.aliq_icms_disp) || ',"vl_icms_disp":' || j(r.vl_icms_disp)
      || ',"vl_desconto_pis":' || j(r.vl_desconto_pis) || ',"vl_desconto_cofins":' || j(r.vl_desconto_cofins)`);e.prepare("update simulador_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'tributos'").run(i)}},{id:"2026-11-09_02_simulador_cidades",descricao:"Simulador: SQL cidades e SQL clientes com p.p_w_id_cidade",up(e){e.prepare("insert or ignore into simulador_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, 1, 'inicial')").run("cidades","Cidades (wonder.sis_cidades, sem EX) para o campo Cidade das Configura\xE7\xF5es; o W_ID vai no w_id_cidade da API de tributos",`select cid.*
  from wonder.sis_cidades cid
 where cid.uf not in ('EX')
 order by cid.uf, cid.nome`,"Manter as colunas W_ID (vai no w_id_cidade da API de tributos), NOME e UF (a tela mostra as cidades da UF de venda).");const t=e.prepare("select sql_texto from simulador_sql where chave = 'clientes'").get(),o=t?t.sql_texto:"";if(!o||/\bp_w_id_cidade\b/i.test(o))return;const a=/\bp\.p_cidade\s*,\s*p\.p_uf\b/gi;if((o.match(a)||[]).length!==2){console.log(new Date().toISOString()+' ATENCAO: SQL "clientes" do Simulador nao reconhecido; nao foi alterado. Acrescente a coluna p.p_w_id_cidade (no select e no group by), na Gestao > Simulador.');return}e.prepare("update simulador_sql set sql_texto = ?, observacao = coalesce(observacao, '') || ?, alterado_em = datetime('now','localtime') where chave = 'clientes'").run(o.replace(a,"p.p_cidade, p.p_w_id_cidade, p.p_uf")," p_w_id_cidade: w_id da cidade do cadastro (campo Cidade; vai no w_id_cidade da API de tributos).")}}];function w(e){const t=a=>!!e.prepare("select 1 from sqlite_master where type = 'table' and name = ?").get(a),o=(a,r)=>e.prepare("pragma table_info("+a+")").all().some(i=>i.name===r);return{temTabela:t,temColuna:o,adicionarColuna(a,r,i){if(!t(a))throw new Error("tabela "+a+" nao existe");o(a,r)||e.exec("ALTER TABLE "+a+" ADD COLUMN "+r+" "+i)}}}function v(e){e.exec("create table if not exists schema_migracoes (id TEXT PRIMARY KEY, descricao TEXT, aplicada_em TEXT NOT NULL DEFAULT (datetime('now','localtime')))")}function f(e,t,o){o=o||m,v(e);const a=new Set(e.prepare("select id from schema_migracoes").all().map(s=>s.id)),r=o.filter(s=>!a.has(s.id));if(!r.length)return[];const i=_.join(_.dirname(t),"backups");n.mkdirSync(i,{recursive:!0});const d=_.join(i,"agenteia_antes_"+r[0].id.replace(/[^A-Za-z0-9_.-]/g,"_")+".db");n.existsSync(d)||e.exec("VACUUM INTO '"+d.replace(/'/g,"''")+"'");try{n.readdirSync(i).filter(c=>/^agenteia_antes_.*\.db$/.test(c)).map(c=>({n:c,t:n.statSync(_.join(i,c)).mtimeMs})).sort((c,u)=>u.t-c.t).slice(10).forEach(c=>n.unlinkSync(_.join(i,c.n)))}catch{}const l=w(e),p=[];for(const s of r){e.exec("BEGIN");try{s.up(e,l),e.prepare("insert into schema_migracoes (id, descricao) values (?, ?)").run(s.id,s.descricao||""),e.exec("COMMIT")}catch(c){try{e.exec("ROLLBACK")}catch{}throw new Error("Migracao "+s.id+" falhou: "+c.message+". O banco ficou como estava antes dela; copia de seguranca em "+d)}p.push(s.id),console.log(new Date().toISOString()+" Migracao aplicada: "+s.id+(s.descricao?" ("+s.descricao+")":""))}return p}module.exports={MIGRACOES:m,aplicar:f,garantirTabela:v};
