Select *
  From (
        Select ipv.id_transacao, ipv.w_id_produto, ipv.cod_item, ipv.descricao desc_item, ipv.unidade un_item, ipv.sequencia, ipv.cod_tabpreco,
               pv.empresa, pv.dt_emissao, pv.nr_docto num_pedido, pv.situacao, pv.cod_pessoa_filial cod_cliente, pv.nome nome_cliente, pv.cidade, pv.uf,
               max(ipv.bonificado) iten_bonificado,
               max(ipv.perc_desc_vlunit) perc_desc_vlunit1, max(ipv.perc_desc_vlunit1) perc_desc_vlunit2, max(ipv.perc_desc_vlunit2) perc_desc_vlunit3,
               max(descped.descped) descped,
               sum(ipv.qtd_digitada) qtd_digitada,
               sum(ipv.qtd_cancelada+(ck.qtd_canc_kit*ipv.quantidade)) qtd_cancelada,
               Sum(ipv.VL_UNIT_DIGIT)   vl_digitado,
               Sum(ipv.VL_UNITARIO)     vl_unt,
               Sum(ipv.VL_liquido - Decode('N', 'N',0, (ipv.qtd_cancelada+(ck.qtd_canc_kit*ipv.quantidade)) * wonder.util.wdivide(ipv.VL_liquido,ipv.quantidade)))  vl_bruto_iten,
               dense_rank() over (order by ipv.id_transacao desc) rn_transacao
          From wonder.cml_movimento pv, Wonder.Cml_Movitens ipv, wonder.cml_tiposdoc tp,
              (select md.id_transacao, max(md.vl_desc_prod) descped from wonder.cml_movimento md group by md.id_transacao
              ) descped,
              (select mic.id_transacao, mic.seq_item_agrupador, nvl(max(qtd_canc_kit),0) qtd_canc_kit
                 from (select mic.id_transacao, mic.seq_item_agrupador,
                              case when mic.seq_item_agrupador <> mic.sequencia then
                                        nvl(decode(sum(mic.quantidade),0,0, sum(mic.qtd_cancelada) / sum(mic.quantidade)),0)
                               end qtd_canc_kit
                         from wonder.cml_movitens mic
                        where 1=1
                        group by mic.id_transacao, mic.seq_item_agrupador, mic.sequencia
                      ) mic
                group by mic.id_transacao, mic.seq_item_agrupador
              ) ck
         Where pv.id_Transacao = ipv.id_Transacao
           and pv.w_id_tipo_docto = tp.w_id
           and ipv.seq_item_agrupador = ipv.sequencia
           and descped.id_transacao = ipv.id_transacao
           and pv.w_tp_trans='EPV'
           and tp.operacao in ('VE')
           and pv.cancelado='N' and pv.eliminado='N'
           and ipv.cancelado='N' and ipv.eliminado='N'
           and ck.id_transacao = pv.id_transacao
           and ck.seq_item_agrupador = ipv.sequencia
           and pv.cod_pessoa_filial = #COD_PESSOA#
         Group by pv.empresa, pv.dt_emissao, pv.nr_docto, pv.cod_pessoa_filial, pv.nome, pv.cidade, pv.uf, pv.situacao, ipv.id_transacao,
                  ipv.w_id_produto, ipv.cod_item, ipv.descricao, ipv.unidade, ipv.seq_item_agrupador, ipv.sequencia, pv.num_carga, ipv.cod_tabpreco
       )
 Where rn_transacao <= 5
 Order by id_transacao desc, sequencia
