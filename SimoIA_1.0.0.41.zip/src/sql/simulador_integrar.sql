declare
  -- Integra o pedido do Simulador (dono, 28/10/2026): o servidor poe no lugar do marcador o documento (cliente,
  -- vendedor, condicao de pagamento, itens com tabela, valor e os 3 descontos, parcelas). Grava de verdade: commit
  -- no fim; erro = rollback. A resposta sai em linhas "#J#" (dbms_output tem limite por linha) e o servidor junta.
  -- (nao escrever o marcador em comentario: o servidor troca a primeira ocorrencia)
  v_resp clob;
  v_pos  pls_integer := 1;
begin
  v_resp := wonder.probus_edi.Grava_JSON_as_pv_terc(#JSON#);
  commit;
  while v_pos <= nvl(dbms_lob.getlength(v_resp), 0) loop
    -- a resposta vem formatada em varias linhas: as quebras viram espaco para cada pedaco ficar numa linha "#J#"
    dbms_output.put_line('#J#' || replace(replace(dbms_lob.substr(v_resp, 3000, v_pos), chr(13), ''), chr(10), ' '));
    v_pos := v_pos + 3000;
  end loop;
exception
  when others then
    rollback;
    raise;
end;
