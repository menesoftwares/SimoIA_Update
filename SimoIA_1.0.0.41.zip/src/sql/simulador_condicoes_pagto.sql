select pagto.w_id, pagto.empresa, pagto.codigo, pagto.descricao, pagto.vista,
       pgto_p.sequencia, pgto_p.dias, pgto_p.amortizacao, pgto_p.tipo_vcto
  from wonder.cml_condpagto pagto, wonder.cml_parcelacp pgto_p
 where pagto.w_id = pgto_p.w_id_condpagto
   and pagto.ativo = 'S'
 order by pagto.descricao, pagto.codigo, pgto_p.sequencia
