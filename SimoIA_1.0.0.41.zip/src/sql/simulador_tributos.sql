declare
  -- API de tributos (dono, 28/10/2026): GetPrecoVendaFormacaoPreco, devolvendo so os campos que o Simulador usa
  -- (JSON_TABLE nativo do Oracle 19c: o CONSULTA nao precisa de grant nas rotinas pljson). Bloco PL/SQL, nao select:
  -- a rotina pode gravar sem dar ORA-14551, e o rollback no fim desfaz o que ela gravar.
  v_resp clob;
  v_sep  varchar2(1) := ' ';
  function j(p varchar2) return varchar2 is
  begin
    if p is null then return 'null'; end if;
    return '"' || replace(replace(replace(replace(p, '\', '\\'), '"', '\"'), chr(10), ' '), chr(13), ' ') || '"';
  end;
begin
  v_resp := wonder.probus_edi.GetPrecoVendaFormacaoPreco(#JSON#);
  dbms_output.put_line('{"itens":[');
  for r in (
    select *
      from json_table(v_resp, '$.itens[*]' columns (
             cod_item                    varchar2(30)  path '$.cod_produto',
             descricao                   varchar2(400) path '$.descricao',
             cst                         varchar2(10)  path '$.cst',
             vl_bruto                    varchar2(40)  path '$.vl_venda',
             perc_tributado              varchar2(40)  path '$.perc_trib_icms',
             aliq_icms                   varchar2(40)  path '$.aliq_icms',
             vl_icms                     varchar2(40)  path '$.vl_icms',
             aliq_pis                    varchar2(40)  path '$.aliq_pis',
             vl_pis                      varchar2(40)  path '$.vl_pis',
             aliq_cofins                 varchar2(40)  path '$.aliq_cofins',
             vl_cofins                   varchar2(40)  path '$.vl_cofins',
             aliq_ipi                    varchar2(40)  path '$.aliq_ipi',
             vl_ipi                      varchar2(40)  path '$.vl_ipi',
             aliq_cbs                    varchar2(40)  path '$.aliq_cbs',
             vl_cbs                      varchar2(40)  path '$.vl_cbs',
             aliq_ibs_uf                 varchar2(40)  path '$.aliq_ibs_uf',
             vl_ibs_uf                   varchar2(40)  path '$.vl_ibs_uf',
             aliq_ibs_mun                varchar2(40)  path '$.aliq_ibs_mun',
             vl_ibs_mun                  varchar2(40)  path '$.vl_ibs_mun',
             vl_is                       varchar2(40)  path '$.vl_is',
             margem_lucro_sub            varchar2(40)  path '$.margem_lucro_sub',
             perc_trib_icms_subst_trib   varchar2(40)  path '$.perc_trib_icms_subst_trib',
             aliq_icms_sub               varchar2(40)  path '$.aliq_icms_sub',
             vl_icms_sub                 varchar2(40)  path '$.vl_icms_sub',
             operacao_sujeita_icms_difal varchar2(10)  path '$.operacao_sujeita_icms_difal',
             aliq_fc_pobreza_uf_dest     varchar2(40)  path '$.aliq_fc_pobreza_uf_dest',
             vl_fc_pobreza_uf_dest       varchar2(40)  path '$.vl_fc_pobreza_uf_dest',
             -- bases (kit, 31/10/2026): o kit nao devolve as aliquotas; o % sai de valor / base
             vl_base_icms                varchar2(40)  path '$.vl_base_icms',
             vl_base_pis                 varchar2(40)  path '$.vl_base_pis',
             vl_base_cofins              varchar2(40)  path '$.vl_base_cofins',
             vl_base_cbs_ibs             varchar2(40)  path '$.vl_base_cbs_ibs',
             -- tributos como desconto (dono, 09/11/2026): ICMS desonerado e PIS/COFINS que deduzem do total do documento
             aliq_icms_disp              varchar2(40)  path '$.aliq_icms_disp',
             vl_icms_disp                varchar2(40)  path '$.vl_icms_disp',
             vl_desconto_pis             varchar2(40)  path '$.vl_desconto_pis',
             vl_desconto_cofins          varchar2(40)  path '$.vl_desconto_cofins'))
  ) loop
    dbms_output.put_line(v_sep || '{"cod_item":' || j(r.cod_item) || ',"descricao":' || j(r.descricao) || ',"cst":' || j(r.cst)
      || ',"vl_bruto":' || j(r.vl_bruto) || ',"perc_tributado":' || j(r.perc_tributado)
      || ',"aliq_icms":' || j(r.aliq_icms) || ',"vl_icms":' || j(r.vl_icms) || ',"aliq_pis":' || j(r.aliq_pis) || ',"vl_pis":' || j(r.vl_pis)
      || ',"aliq_cofins":' || j(r.aliq_cofins) || ',"vl_cofins":' || j(r.vl_cofins) || ',"aliq_ipi":' || j(r.aliq_ipi) || ',"vl_ipi":' || j(r.vl_ipi)
      || ',"aliq_cbs":' || j(r.aliq_cbs) || ',"vl_cbs":' || j(r.vl_cbs) || ',"aliq_ibs_uf":' || j(r.aliq_ibs_uf) || ',"vl_ibs_uf":' || j(r.vl_ibs_uf)
      || ',"aliq_ibs_mun":' || j(r.aliq_ibs_mun) || ',"vl_ibs_mun":' || j(r.vl_ibs_mun) || ',"vl_is":' || j(r.vl_is)
      || ',"margem_lucro_sub":' || j(r.margem_lucro_sub) || ',"perc_trib_icms_subst_trib":' || j(r.perc_trib_icms_subst_trib)
      || ',"aliq_icms_sub":' || j(r.aliq_icms_sub) || ',"vl_icms_sub":' || j(r.vl_icms_sub)
      || ',"operacao_sujeita_icms_difal":' || j(r.operacao_sujeita_icms_difal)
      || ',"aliq_fc_pobreza_uf_dest":' || j(r.aliq_fc_pobreza_uf_dest) || ',"vl_fc_pobreza_uf_dest":' || j(r.vl_fc_pobreza_uf_dest)
      || ',"vl_base_icms":' || j(r.vl_base_icms) || ',"vl_base_pis":' || j(r.vl_base_pis) || ',"vl_base_cofins":' || j(r.vl_base_cofins)
      || ',"vl_base_cbs_ibs":' || j(r.vl_base_cbs_ibs)
      || ',"aliq_icms_disp":' || j(r.aliq_icms_disp) || ',"vl_icms_disp":' || j(r.vl_icms_disp)
      || ',"vl_desconto_pis":' || j(r.vl_desconto_pis) || ',"vl_desconto_cofins":' || j(r.vl_desconto_cofins) || '}');
    v_sep := ',';
  end loop;
  dbms_output.put_line(']}');
  rollback;
exception
  when others then
    rollback;
    raise;
end;
