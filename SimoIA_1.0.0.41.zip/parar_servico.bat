@echo off
rem Para o SimoIA: encerra o servidor (node) e o vigia que o religa.
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
echo Parando o SimoIA...
schtasks /end /tn AgenteIA >nul 2>&1
schtasks /end /tn SimoIA   >nul 2>&1
rem mata quem esta na porta 3000 e o processo-pai (o vigia que religa)
if exist "%PS%" "%PS%" -NoProfile -Command "$n=(Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue).OwningProcess; if($n){$par=(Get-CimInstance Win32_Process -Filter ('ProcessId='+$n) -ErrorAction SilentlyContinue).ParentProcessId; Stop-Process -Id $n -Force -ErrorAction SilentlyContinue; if($par){Stop-Process -Id $par -Force -ErrorAction SilentlyContinue}}" >nul 2>&1
rem reforco: todo node ou cmd cujo comando contenha server.js
if exist "%PS%" "%PS%" -NoProfile -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -eq 'cmd.exe' -or $_.Name -eq 'node.exe') -and $_.CommandLine -like '*server.js*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }" >nul 2>&1
rem garantia final pelo numero do processo na porta 3000
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:":3000 .*LISTENING"') do taskkill /PID %%p /T /F >nul 2>&1
echo Parado.
