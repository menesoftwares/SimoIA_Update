@echo off
setlocal enableextensions enabledelayedexpansion
rem Miolo do atualizador (rodado pelo atualizar.bat). Simples: parar -> copiar -> iniciar.
set "DEST=C:\AgenteIA"
set "SRC=%~dp0"
if "%SRC:~-1%"=="\" set "SRC=%SRC:~0,-1%"

echo === SimoIA: atualizacao ===
if not exist "%DEST%\dados\agenteia.db" ( echo ERRO: nao achei o banco em "%DEST%". Nada foi alterado. & exit /b 1 )
rem log de cada atualizacao (dono, 02/11/2026): uma linha por etapa em logs\atualizacoes.log (a pasta logs nunca e apagada)
if not exist "%DEST%\logs" mkdir "%DEST%\logs"
set "LOGF=%DEST%\logs\atualizacoes.log"
set "DENTRO="
if /i "%SRC%"=="%DEST%" set "DENTRO=1"
call set "RESTO=%%SRC:%DEST%\=%%"
if /i not "%RESTO%"=="%SRC%" set "DENTRO=1"
if defined DENTRO echo ERRO: nao rode de dentro da pasta do sistema. Extraia o zip em OUTRA pasta e rode de la.
if defined DENTRO >>"%LOGF%" echo %DATE% %TIME% - ERRO: rodado de dentro da pasta do sistema [%SRC%]. Nada foi alterado.
if defined DENTRO exit /b 1
set "FALTA="
for %%F in ("src\server.js" "src\db.js" "vigia.bat" "VERSAO" "parar_servico.bat" "iniciar_servico.bat") do if not exist "%SRC%\%%~F" set "FALTA=%%~F !FALTA!"
if defined FALTA echo ERRO: pasta de atualizacao incompleta. Faltam: !FALTA!
if defined FALTA >>"%LOGF%" echo %DATE% %TIME% - ERRO: pacote incompleto, faltam: !FALTA! Nada foi alterado.
if defined FALTA exit /b 1

if exist "%SRC%\VERSAO"  ( set /p NOVA=<"%SRC%\VERSAO" )  else ( set "NOVA=?" )
if exist "%DEST%\VERSAO" ( set /p ATUAL=<"%DEST%\VERSAO" ) else ( set "ATUAL=?" )
echo Instalada: !ATUAL!    Nova: !NOVA!    Destino: %DEST%
>>"%LOGF%" echo.
>>"%LOGF%" echo %DATE% %TIME% - INICIO: instalada !ATUAL! - nova !NOVA! - pacote em [%SRC%] - usuario %USERNAME%
echo O banco (dados\) e as configuracoes (config\) NAO serao apagados.
echo.

echo [1/4] Parando o servico...
call "%SRC%\parar_servico.bat"

echo [2/4] Backup do codigo antigo...
set "BKP=%DEST%\backup_codigo"
if not exist "%BKP%" mkdir "%BKP%"
rem nome com a versao que sai (dono, 02/11/2026): 1.0.0.25 vira anterior_versao25; se ja existir, _2, _3...
set "VNUM=!ATUAL!"
for %%V in ("!ATUAL:.=" "!") do set "VNUM=%%~V"
if "!ATUAL!"=="?" set "VNUM=desconhecida"
set "BKPDIR=%BKP%\anterior_versao!VNUM!"
set "BKPBASE=!BKPDIR!"
for /L %%N in (2,1,99) do if exist "!BKPDIR!" set "BKPDIR=!BKPBASE!_%%N"
mkdir "%BKPDIR%" >nul 2>&1
for %%D in (src public ferramentas) do if exist "%DEST%\%%D" robocopy "%DEST%\%%D" "%BKPDIR%\%%D" /E /R:1 /W:1 /NFL /NDL /NJH /NJS /NP >nul
echo       backup em: %BKPDIR%
>>"%LOGF%" echo %DATE% %TIME% - backup do codigo anterior em [%BKPDIR%]
rem so os 5 backups mais recentes (dono, 02/11/2026): pela data de criacao, o novo conta entre os 5; os outros saem
for /f "skip=5 delims=" %%B in ('dir /b /ad /o-d /tc "%BKP%\anterior_*" 2^>nul') do (
  rd /s /q "%BKP%\%%B"
  >>"%LOGF%" echo %DATE% %TIME% - backup antigo apagado: [%BKP%\%%B]
)

echo [3/4] Limpando e copiando o codigo novo...
for /d %%D in ("%DEST%\*") do (
  set "MANTER="
  for %%K in (dados config externos logs tmp backup_codigo) do if /i "%%~nxD"=="%%K" set "MANTER=1"
  if not defined MANTER rmdir /s /q "%%D"
)
del /q "%DEST%\*" >nul 2>&1
robocopy "%SRC%" "%DEST%" /E /R:1 /W:1 /XF atualizar.bat _atualizar_core.bat /NFL /NDL /NJH /NJS /NP >nul
set "RC=%errorlevel%"
if not exist "%DEST%\logs" mkdir "%DEST%\logs"
if not exist "%DEST%\tmp" mkdir "%DEST%\tmp"
if %RC% geq 8 echo ERRO: a copia falhou. Codigo robocopy %RC%. Backup em %BKPDIR%
if %RC% geq 8 >>"%LOGF%" echo %DATE% %TIME% - ERRO: a copia falhou, robocopy %RC%. Backup em [%BKPDIR%]
if %RC% geq 8 exit /b 1
set "FALTA2="
for %%F in ("src\server.js" "src\db.js" "vigia.bat" "VERSAO") do if not exist "%DEST%\%%~F" set "FALTA2=%%~F !FALTA2!"
if defined FALTA2 echo ERRO: copia incompleta. Faltam: !FALTA2!  Backup em %BKPDIR%
if defined FALTA2 >>"%LOGF%" echo %DATE% %TIME% - ERRO: copia incompleta, faltam: !FALTA2! Backup em [%BKPDIR%]
if defined FALTA2 exit /b 1
echo       copiado.
>>"%LOGF%" echo %DATE% %TIME% - codigo novo copiado

echo [4/4] Iniciando o servico...
rem espera a porta 3000 liberar (o parar pode levar 1-2s para soltar a porta)
set /a W=0
:wait_free
netstat -ano | findstr /r /c:":3000 .*LISTENING" >nul
if not %errorlevel%==0 goto port_free
set /a W+=1
if %W% geq 15 goto port_free
ping -n 2 127.0.0.1 >nul
goto wait_free
:port_free
rem inicia o servidor SEM janela (via vbs oculto). sem o guard do iniciar_servico, que barrava apos o parar
if not exist "%DEST%\logs" mkdir "%DEST%\logs"
if exist "%DEST%\iniciar_oculto.vbs" ( wscript.exe "%DEST%\iniciar_oculto.vbs" ) else ( start "SimoIA" /min "%DEST%\vigia.bat" )
rem espera subir (ate ~24s)
set /a W=0
:wait_up
ping -n 3 127.0.0.1 >nul
netstat -ano | findstr /r /c:":3000 .*LISTENING" >nul
if %errorlevel%==0 goto is_up
set /a W+=1
if %W% lss 12 goto wait_up
echo.
echo === Codigo atualizado para a versao !NOVA!. O servico ainda nao respondeu. ===
echo Abra http://localhost:3000. Se nao abrir, rode:  cd /d %DEST%   e depois:  node src\server.js
echo Backup do codigo anterior: %BKPDIR%
>>"%LOGF%" echo %DATE% %TIME% - FIM: codigo atualizado para !NOVA!, mas o servico NAO respondeu na porta 3000. Ver logs\servidor_saida.log
echo Log da atualizacao: %LOGF%
exit /b 0
:is_up
echo.
echo === Atualizado para a versao !NOVA!. Servico NO AR. Acesse http://localhost:3000 ===
echo Backup do codigo anterior: %BKPDIR%
>>"%LOGF%" echo %DATE% %TIME% - FIM: atualizado de !ATUAL! para !NOVA!, servico NO AR
echo Log da atualizacao: %LOGF%
exit /b 0
