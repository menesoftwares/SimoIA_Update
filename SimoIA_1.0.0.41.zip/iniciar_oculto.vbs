' Inicia o SimoIA SEM janela (janela oculta, estilo 0) e sem esperar.
' Roda o vigia.bat (que religa o servidor se cair) a partir da pasta deste arquivo.
Set sh  = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName)
sh.CurrentDirectory = base
sh.Run """" & base & "\vigia.bat""", 0, False
