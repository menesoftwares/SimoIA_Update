@echo off
rem Inicia o SimoIA escondido (sem janela). Religa sozinho se cair.
cd /d "%~dp0"
netstat -ano | findstr /r /c:":3000 .*LISTENING" >nul
if %errorlevel%==0 goto jaroda
if not exist "%~dp0iniciar_oculto.vbs" goto semvbs
if not exist "%~dp0vigia.bat" goto semvbs
if not exist logs mkdir logs
if not exist tmp mkdir tmp
wscript.exe "%~dp0iniciar_oculto.vbs"
echo SimoIA iniciando (sem janela). Em alguns segundos: http://localhost:3000
goto fim
:jaroda
echo O SimoIA ja esta rodando: http://localhost:3000
goto fim
:semvbs
echo ERRO: falta iniciar_oculto.vbs ou vigia.bat nesta pasta. Instalacao incompleta.
:fim
