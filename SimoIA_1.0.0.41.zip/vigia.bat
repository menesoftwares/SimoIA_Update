@echo off
rem Mantem o SimoIA no ar: roda o servidor e o reinicia se cair. Sem janela extra quando
rem iniciado minimizado ou pela tarefa agendada. Roda a partir da propria pasta.
cd /d "%~dp0"
if not exist logs mkdir logs
:loop
node src\server.js >> logs\servidor_saida.log 2>&1
ping -n 6 127.0.0.1 >nul
goto loop
