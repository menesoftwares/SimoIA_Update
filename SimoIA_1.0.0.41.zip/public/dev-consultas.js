/*
 * Atalho de diagnostico (dono, 05/11/2026): Ctrl + Alt + Shift + Q mostra os SQLs em andamento e os ultimos que terminaram.
 * So para o usuario desenv: para os demais, a rota responde 404 e o atalho nao faz nada.
 */
(function () {
  'use strict';
  let caixa = null, timer = null, assinatura = '';
  const abertos = new Set(), fechados = new Set();

  const token = () => { try { return sessionStorage.getItem('token') || localStorage.getItem('simoia_token') || ''; } catch (e) { return ''; } };
  async function ler() {
    const r = await fetch('/api/dev/consultas', { headers: { Authorization: 'Bearer ' + token() } });
    return r.ok ? r.json() : null;
  }
  const el = (tag, css, texto) => {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (texto != null) e.textContent = texto;
    return e;
  };
  const tempo = (ms) => { const s = Math.round(ms / 1000); return s < 60 ? s + ' s' : Math.floor(s / 60) + ' min ' + (s % 60) + ' s'; };
  const situacao = (c) => (c.situacao === 'fila' ? 'Na fila há ' : 'Rodando há ') + tempo(c.ms) + (c.situacao === 'fila' ? '' : ' (' + tempo(c.ms_fila) + ' na fila)');

  async function copiar(texto, botao) {
    let ok = false;
    try { await navigator.clipboard.writeText(texto); ok = true; } catch (e) {
      const t = el('textarea', 'position:fixed;opacity:0');
      t.value = texto;
      document.body.appendChild(t);
      t.select();
      try { ok = document.execCommand('copy'); } catch (x) { /* sem permissao */ }
      t.remove();
    }
    botao.textContent = ok ? 'Copiado' : 'Não copiou';
    setTimeout(() => { botao.textContent = 'Copiar'; }, 1500);
  }

  function cartao(c, ativo) {
    const d = el('details', 'border:1px solid #33444F;border-radius:8px;padding:8px 10px;margin-top:8px;background:#16222C');
    d.open = ativo ? !fechados.has(c.id) : abertos.has(c.id);
    d.addEventListener('toggle', () => {
      (d.open ? abertos : fechados).add(c.id);
      (d.open ? fechados : abertos).delete(c.id);
    });
    const topo = el('summary', 'cursor:pointer;font-weight:700;overflow-wrap:anywhere', c.nome);
    const info = el('div', 'font-weight:400;font-size:12px;color:#9DAEB9;margin-top:2px');
    info.dataset.consulta = c.id;
    info.textContent = (ativo ? situacao(c) : 'Terminou em ' + tempo(c.ms) + ' (' + c.quando + ')' + (c.erro ? ' · com erro' : '')) + ' · ' + (c.usuario || 'sistema') + ' · ' + c.conexao;
    topo.appendChild(info);
    d.appendChild(topo);
    if (c.erro) d.appendChild(el('div', 'color:#F0A08C;font-size:12px;margin-top:6px;white-space:pre-wrap;overflow-wrap:anywhere', c.erro));
    const botao = el('button', 'margin-top:8px;padding:4px 10px;border:1px solid #33444F;border-radius:6px;background:#0E161C;color:#7CC4E8;font:inherit;font-size:12px;cursor:pointer', 'Copiar');
    botao.type = 'button';
    botao.addEventListener('click', () => copiar(c.sql, botao));
    d.appendChild(botao);
    d.appendChild(el('pre', 'margin:8px 0 0;padding:8px;max-height:40vh;overflow:auto;background:#0E161C;border-radius:6px;font:12px/1.45 ui-monospace,Menlo,Consolas,monospace;white-space:pre', c.sql));
    return d;
  }
  function desenhar(d) {
    // lista igual: atualiza so os tempos, sem perder a rolagem nem a selecao de texto
    const nova = d.ativos.map((c) => c.id + c.situacao).concat(d.recentes.map((c) => c.id)).join(',');
    if (nova === assinatura) {
      for (const c of d.ativos) {
        const i = caixa.querySelector('[data-consulta="' + c.id + '"]');
        if (i) i.textContent = situacao(c) + ' · ' + (c.usuario || 'sistema') + ' · ' + c.conexao;
      }
      return;
    }
    assinatura = nova;
    const corpo = caixa.querySelector('[data-corpo]');
    const rolagem = corpo.scrollTop;
    corpo.textContent = '';
    corpo.appendChild(el('div', 'font-weight:700;margin-top:4px', 'Em andamento (' + d.ativos.length + ')'));
    if (!d.ativos.length) corpo.appendChild(el('div', 'color:#9DAEB9;font-size:13px;margin-top:4px', 'Nenhum SQL rodando agora.'));
    d.ativos.forEach((c) => corpo.appendChild(cartao(c, true)));
    corpo.appendChild(el('div', 'font-weight:700;margin-top:14px', 'Últimos que terminaram (' + d.recentes.length + ')'));
    d.recentes.forEach((c) => corpo.appendChild(cartao(c, false)));
    corpo.scrollTop = rolagem;
  }
  function fechar() {
    clearInterval(timer);
    timer = null;
    if (caixa) caixa.remove();
    caixa = null;
    assinatura = '';
  }
  async function abrir() {
    let d = null;
    try { d = await ler(); } catch (e) { /* sem resposta: nao abre */ }
    if (!d || caixa) return; // outro usuario: 404, o atalho nao faz nada
    caixa = el('div', 'position:fixed;inset:0;z-index:100000;background:rgba(0,0,0,.55);display:flex;align-items:center;justify-content:center;padding:16px;font:14px/1.4 system-ui,"Segoe UI",sans-serif;color:#E4EBEF');
    caixa.id = 'dev-consultas';
    caixa.setAttribute('role', 'dialog');
    caixa.setAttribute('aria-modal', 'true');
    caixa.setAttribute('aria-label', 'SQLs em andamento');
    const painel = el('div', 'width:100%;max-width:900px;max-height:100%;display:flex;flex-direction:column;background:#0E161C;border:1px solid #33444F;border-radius:12px;padding:14px;box-sizing:border-box');
    const cab = el('div', 'display:flex;align-items:center;justify-content:space-between;gap:10px');
    cab.appendChild(el('strong', 'font-size:16px', 'SQLs em andamento'));
    const x = el('button', 'padding:4px 10px;border:1px solid #33444F;border-radius:6px;background:#16222C;color:#E4EBEF;font:inherit;cursor:pointer', 'Fechar (Esc)');
    x.type = 'button';
    x.addEventListener('click', fechar);
    cab.appendChild(x);
    painel.appendChild(cab);
    const corpo = el('div', 'overflow:auto;margin-top:8px');
    corpo.dataset.corpo = '1';
    painel.appendChild(corpo);
    caixa.appendChild(painel);
    caixa.addEventListener('click', (e) => { if (e.target === caixa) fechar(); });
    document.body.appendChild(caixa);
    desenhar(d);
    timer = setInterval(async () => {
      let n = null;
      try { n = await ler(); } catch (e) { return; }
      if (!caixa) return;
      if (n) desenhar(n); else fechar(); // sessao encerrada
    }, 1000);
  }
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && caixa) { e.preventDefault(); e.stopPropagation(); fechar(); return; }
    if (e.ctrlKey && e.altKey && e.shiftKey && e.code === 'KeyQ') {
      e.preventDefault();
      e.stopPropagation();
      if (caixa) fechar(); else abrir();
    }
  }, true);
})();
