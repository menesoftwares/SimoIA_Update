/*
 * Service worker do AgenteIA (app instalavel / PWA).
 * Faz so o necessario para o navegador oferecer "Instalar app": NAO guarda dados no aparelho
 * (relatorios, respostas e login vem sempre do servidor). Sem conexao, mostra uma pagina simples.
 */
const VERSAO = 'agenteia-sw-1';

self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));

const SEM_CONEXAO = '<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">' +
  '<meta name="viewport" content="width=device-width, initial-scale=1"><title>__NOME_SISTEMA__</title>' +
  '<style>body{font-family:"Segoe UI",system-ui,sans-serif;background:#EEF2F4;color:#16222C;display:grid;place-items:center;min-height:90vh;margin:0;padding:20px;text-align:center}' +
  'h1{font-size:1.4rem;margin:0 0 8px}p{color:#556673;margin:0 0 16px}button{font:inherit;font-weight:600;border:0;border-radius:8px;padding:10px 18px;background:#0E5A78;color:#fff;cursor:pointer}' +
  '@media (prefers-color-scheme: dark){body{background:#0E161C;color:#E4EBEF}p{color:#9DAEB9}}</style></head><body><div>' +
  '<h1>Sem conex\u00e3o com o __NOME_SISTEMA__</h1><p>Verifique a internet (ou a rede da empresa) e tente de novo.</p>' +
  '<button onclick="location.reload()">Tentar de novo</button></div></body></html>';

self.addEventListener('fetch', (e) => {
  // so a abertura das paginas passa por aqui; dados (/api), icones etc. vao direto pela rede
  if (e.request.mode !== 'navigate') return;
  e.respondWith(fetch(e.request).catch(() => new Response(SEM_CONEXAO, { headers: { 'Content-Type': 'text/html; charset=utf-8' } })));
});
