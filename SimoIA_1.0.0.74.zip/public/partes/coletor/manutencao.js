/*@parte Coletor: manutenção e conferidas (ver e imprimir). Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- manutencao (dono, 02/11/2026): so consulta — em conferencia (todos os conferentes) e a conferir (a partir da
   * data do parametro da Gestao, mesmo com "Notas a conferir" desligada na tela inicial) ---------- */
  let manutPedido = 0;
  let manutFiltro = null; // ultima pesquisa feita: depois de liberar uma nota, repete esta, mesmo com os campos ja alterados
  // abre a tela sem pesquisar (dono, 06/11/2026): as listas so aparecem depois do botao Pesquisar
  function manutAbrir() {
    manutPedido++;
    manutFiltro = null;
    $('manut-result').hidden = true;
    manutVerFechar();
    $('manut-pesquisar').disabled = false;
    mensagem($('manut-msg'), '', 'info');
    mostrarEtapa('manut');
    irAoTopo();
  }
  $('manut-filtro').addEventListener('submit', (e) => {
    e.preventDefault();
    const ini = $('manut-ini').value, fim = $('manut-fim').value, cini = $('manut-cini').value, cfim = $('manut-cfim').value, status = $('manut-status').value, nf = $('manut-nf').value.replace(/\s+/g, '');
    if (ini && fim && ini > fim) { mensagem($('manut-msg'), 'A emissão inicial não pode ser depois da emissão final.', 'erro'); return; }
    if (cini && cfim && cini > cfim) { mensagem($('manut-msg'), 'A coleta inicial não pode ser depois da coleta final.', 'erro'); return; }
    if (nf && !/^\d{1,12}$/.test(nf)) { mensagem($('manut-msg'), 'Digite só os números da NF-e.', 'erro'); return; }
    manutFiltro = { ini, fim, nf, cini, cfim, status };
    $('manut-result').hidden = true;
    carregarManut();
  });
  async function carregarManut() {
    if (!manutFiltro) return;
    const pedido = ++manutPedido;
    $('manut-pesquisar').disabled = true;
    mensagem($('manut-msg'), 'Pesquisando…', 'info');
    try {
      const d = await api('/api/coletor/manutencao?' + new URLSearchParams(manutFiltro));
      if (pedido !== manutPedido || $('etapa-manut').hidden) return;
      if (!d.ok) { mensagem($('manut-msg'), d.mensagem || 'Não foi possível carregar a manutenção.', 'erro'); return; }
      mensagem($('manut-msg'), '', 'info');
      $('manut-result').hidden = false;
      const em = d.em_conferencia || [], pend = d.pendentes || [], conf = d.conferidas || [];
      // Status: so aparece o balao pedido
      $('manut-em-cartao').hidden = !!manutFiltro.status && manutFiltro.status !== 'em';
      $('manut-pend-cartao').hidden = !!manutFiltro.status && manutFiltro.status !== 'pend';
      $('manut-conf-cartao').hidden = !!manutFiltro.status && manutFiltro.status !== 'conf';
      const faixa = (d.desde ? ' a partir de ' + d.desde : '') + (d.ate ? ' até ' + d.ate : '');
      $('manut-em-n').textContent = '(' + em.length + ')';
      $('manut-em-nota').textContent = (d.erro_abertas ? 'Não foi possível ler do banco as notas sem conferente: ' + d.erro_abertas + ' ' : '') +
        (em.length ? 'Coletas iniciadas e ainda não finalizadas, de todos os conferentes. O uso mais recente fica em cima.' +
        (em.some((r) => r.sem_reserva) ? ' "Sem conferente": tem leituras e não foi finalizada, mas ninguém está com ela.' : '') +
        (em.some((r) => r.coletando) ? ' "Coletando agora": o conferente está na tela da coleta, e só dá para liberar depois que ele sair.' : '') : d.filtrado ? 'Nenhuma nota em conferência nesta pesquisa.' : 'Nenhuma nota em conferência agora.');
      $('manut-em').innerHTML = em.map((r) => '<div class="manut-item"><div class="manut-linha"><div class="doc-cab">' +
        '<div class="nf">NF ' + esc(r.nr_docto || r.id_transacao) + ' <span class="selo">' + (r.tipo === 'produto' ? 'Por produto' : r.tipo === 'cega' ? 'Coleta cega' : 'Tipo a escolher') + '</span></div>' +
        (r.cliente ? '<div class="det">' + esc(r.cliente) + '</div>' : '') +
        (r.transportadora ? '<div class="det">Transp.: ' + esc(r.transportadora) + '</div>' : '') +
        // sem reserva (dono, 03/11/2026): nao finalizada no banco e sem conferente agora; mostra quem leu por ultimo
        (r.sem_reserva ? '<div class="det"><span class="selo">sem conferente</span>' + (r.conferente ? ' · última leitura por <strong>' + esc(r.conferente) + '</strong>' : '') + '</div>' +
          '<div class="det">Não finalizada' + (r.ultimo_uso ? ' · última leitura ' + esc(r.ultimo_uso) : '') + '</div>'
        : '<div class="det"><strong>' + esc(r.conferente || r.usuario) + '</strong>' + (r.aparelho ? ' · ' + esc(r.aparelho) : '') +
          (r.coletando ? ' · <span class="selo coletando">coletando agora</span>' : '') + '</div>' +
        '<div class="det">Iniciada em ' + esc(r.iniciado_em) + (r.ultimo_uso ? ' · último uso ' + esc(r.ultimo_uso) : '') + '</div>') +
        // bipados x total: preenchido depois (andamento vem numa segunda ida ao banco, para a lista abrir rapido)
        '<div class="manut-and" data-andamento="' + esc(r.id_transacao) + '">Bipados: …</div></div>' +
        // conferente dentro da coleta agora: Liberar travado ate ele sair (dono, 02/11/2026; o servidor confere de novo)
        '<button type="button" class="btn-sec btn-abandonar" data-liberar="' + esc(r.id_transacao) + '" data-nf="' + esc(r.nr_docto || r.id_transacao) + '" data-conf="' + esc(r.sem_reserva ? '' : r.conferente || r.usuario) + '"' +
          (r.coletando ? ' disabled title="' + esc(r.conferente || r.usuario) + ' está na coleta agora. Libere depois que sair (toque em Pesquisar)."' : '') + '>Liberar</button>' +
        '</div></div>').join('');
      if (em.length) carregarAndamento(pedido);
      $('manut-pend-n').textContent = d.erro_pendentes ? '' : '(' + pend.length + ')';
      $('manut-pend-nota').textContent = d.erro_pendentes ? 'Não foi possível carregar as notas a conferir: ' + d.erro_pendentes
        : d.pend_sem_coleta ? 'Nota a conferir ainda não tem coleta: ela não entra em pesquisa por data de coleta.'
        : pend.length ? (faixa ? 'Emitidas' + faixa + ', sem' : 'Sem') + ' nenhuma leitura e sem coleta em andamento.' + (d.pend_limite ? ' Mostrando só as primeiras 300: refine a pesquisa.' : '')
        : 'Nenhuma nota a conferir' + (faixa ? ' emitida' + faixa : '') + (manutFiltro.nf ? ' com o número ' + manutFiltro.nf : '') + '.';
      $('manut-pend').innerHTML = pend.map((r) => '<div class="manut-item"><div class="doc-cab">' +
        '<div class="nf">NF ' + esc(r.nr_docto || r.id_transacao) + (r.especie ? ' <span class="selo">' + esc(r.especie) + '</span>' : '') + '</div>' +
        (r.cliente ? '<div class="det">' + esc(r.cliente) + '</div>' : '') +
        (r.transportadora ? '<div class="det">Transp.: ' + esc(r.transportadora) + '</div>' : '') +
        '<div class="det">Emissão ' + esc(r.dt_emissao || '') + (r.itens ? ' · ' + r.itens + (r.itens === 1 ? ' item' : ' itens') : '') + '</div></div></div>').join('');
      $('manut-conf-n').textContent = d.erro_conferidas ? '' : '(' + conf.length + ')';
      $('manut-conf-nota').textContent = d.erro_conferidas ? 'Não foi possível carregar as notas conferidas: ' + d.erro_conferidas
        : conf.length ? 'Conferências finalizadas, a mais recente em cima.' + (d.conf_limite ? ' Mostrando só as últimas ' + conf.length + ': refine a pesquisa.' : '')
        : d.filtrado ? 'Nenhuma nota conferida nesta pesquisa.' : 'Nenhuma nota conferida.';
      $('manut-conf').innerHTML = conf.map((r) => '<div class="manut-item"><div class="doc-cab">' +
        '<div class="nf">NF ' + esc(r.nr_docto || r.id_transacao) + (r.especie ? ' <span class="selo">' + esc(r.especie) + '</span>' : '') + '</div>' +
        (r.cliente ? '<div class="det">' + esc(r.cliente) + '</div>' : '') +
        (r.transportadora ? '<div class="det">Transp.: ' + esc(r.transportadora) + '</div>' : '') +
        '<div class="det">Emissão ' + esc(r.dt_emissao || '') + (r.itens ? ' · ' + r.itens + (r.itens === 1 ? ' item' : ' itens') : '') + '</div>' +
        '<div class="det">Coleta ' + esc(r.primeira_leitura || '') + (r.ultima_leitura && r.ultima_leitura !== r.primeira_leitura ? ' até ' + esc(r.ultima_leitura) : '') + '</div>' +
        '<div class="det">Finalizada em ' + esc(r.finalizada_em || '') + (r.conferente ? ' por <strong>' + esc(r.conferente) + '</strong>' : '') + '</div></div>' +
        // Ver e Imprimir (dono, 15/11/2026): dados do documento e as coletas
        '<div class="manut-conf-acoes"><button type="button" class="btn-sec" data-ver="' + esc(r.id_transacao) + '">Ver</button>' +
        '<button type="button" class="btn-sec" data-imprimir="' + esc(r.id_transacao) + '">Imprimir</button>' +
        // Excluir (dono, 24/11/2026): elimina as leituras e a nota volta para coletar
        '<button type="button" class="btn-sec btn-abandonar" data-excluir="' + esc(r.id_transacao) + '" data-nf="' + esc(r.nr_docto || r.id_transacao) + '">Excluir</button></div></div>').join('');
    } catch (e) {
      if (e.message !== 'sessao' && pedido === manutPedido) mensagem($('manut-msg'), 'Não foi possível falar com o servidor.', 'erro');
    } finally { if (pedido === manutPedido) $('manut-pesquisar').disabled = false; }
  }
  // bipados x total de cada nota em conferencia (dono, 02/11/2026)
  async function carregarAndamento(pedido) {
    try {
      const d = await api('/api/coletor/manutencao/andamento');
      if (pedido !== manutPedido || $('etapa-manut').hidden) return;
      document.querySelectorAll('#manut-em [data-andamento]').forEach((el) => {
        const a = d.ok && d.andamento ? d.andamento[el.dataset.andamento] : null;
        if (!d.ok) { el.textContent = 'Bipados: não foi possível ler agora.'; return; }
        if (!a) { el.textContent = 'Bipados: 0'; return; }
        const pct = a.total ? Math.min(100, Math.round(a.bipados / a.total * 100)) : 0;
        el.innerHTML = 'Bipados: ' + fmtQtd(a.bipados) + ' de ' + fmtQtd(a.total) + (a.total ? ' (' + pct + '%)' : '') +
          ' · ' + a.leituras + (a.leituras === 1 ? ' leitura' : ' leituras') + '<div class="barra"><span style="width:' + pct + '%"></span></div>';
      });
    } catch (e) { /* fica o "…"; o Pesquisar tenta de novo */ }
  }
  // Liberar (dono, 02/11/2026): igual ao da Gestao — cancela todos os bipes da nota e tira da coleta; comeca do zero
  $('manut-em').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-liberar]');
    if (!b) return;
    if (!(await perguntar({ titulo: 'Liberar NF ' + b.dataset.nf, perigo: true, sim: 'Liberar', nao: 'Voltar',
      texto: 'Liberar a NF ' + b.dataset.nf + (b.dataset.conf ? ', que está em conferência com ' + b.dataset.conf : ', que está em conferência sem conferente') + '?\nTodos os bipes dela serão cancelados e a conferência começa do zero.' }))) return;
    b.disabled = true;
    carregando('Liberando nota', 'Cancelando os bipes da NF ' + b.dataset.nf + '…');
    try {
      const d = await api('/api/coletor/manutencao/liberar', { id_transacao: b.dataset.liberar });
      fecharCarregando();
      if (!d.ok) { mensagem($('manut-msg'), d.mensagem || 'Não foi possível liberar a nota.', 'erro'); b.disabled = false; return; }
      // bipes desta nota que ficaram guardados neste aparelho tambem saem (nao voltam a ser gravados depois)
      try { localStorage.removeItem(chaveFila(b.dataset.liberar)); } catch (x) { /* ignora */ }
      await carregarManut();
      mensagem($('manut-msg'), d.mensagem || 'Nota liberada.', 'ok');
    } catch (x) {
      fecharCarregando();
      if (x.message !== 'sessao') mensagem($('manut-msg'), 'Não foi possível falar com o servidor.', 'erro');
      b.disabled = false;
    }
  });
  $('manut-abrir').addEventListener('click', manutAbrir);

  /* ---------- conferidas: Ver e Imprimir (dono, 15/11/2026) — dados do documento e as coletas (leituras ativas) ---------- */
  let manutVerDados = null; // ultima nota aberta no Ver: o Imprimir de dentro usa esta
  async function manutColetas(id) {
    carregando('Buscando as coletas', 'Lendo a nota e as coletas no banco…');
    try {
      const d = await api('/api/coletor/manutencao/coletas?' + new URLSearchParams({ id }));
      fecharCarregando();
      if (!d.ok) { avisar(d.mensagem || 'Não foi possível buscar as coletas.'); return null; }
      return d;
    } catch (x) {
      fecharCarregando();
      if (x.message !== 'sessao') avisar('Não foi possível falar com o servidor.');
      return null;
    }
  }
  const manutQtd = (c) => fmtQtd(c.quantidade) + (c.unidade ? ' ' + c.unidade : '');
  // linhas de dados do documento: [rotulo, valor], so as preenchidas
  const manutDadosDoc = (d) => [
    ['Documento', 'NF ' + d.documento.nr_docto + (d.documento.especie ? ' (' + d.documento.especie + ')' : '')],
    ['Empresa', d.documento.empresa], ['Emissão', d.documento.dt_emissao], ['Chave', d.documento.chave],
    ['Cliente', d.documento.cliente], ['Transportadora', d.documento.transportadora],
    ['Itens', d.documento.itens + (d.documento.itens === 1 ? ' item' : ' itens') + ' · ' + fmtQtd(d.documento.quantidade) + ' no total'],
    ['Coleta', d.primeira + (d.ultima && d.ultima !== d.primeira ? ' até ' + d.ultima : '')],
    ['Finalizada', d.finalizada_em ? d.finalizada_em + (d.finalizada_por ? ' por ' + d.finalizada_por : '') : 'não']
  ].filter((l) => l[1]);
  function manutVerFechar() {
    $('manut-ver').hidden = true;
    manutVerDados = null;
    $('manut-filtro').hidden = false;
    if (manutFiltro) $('manut-result').hidden = false;
  }
  function manutVerMostrar(d) {
    manutVerDados = d;
    $('manut-ver-titulo').textContent = 'Coletas da NF ' + d.documento.nr_docto;
    $('manut-ver-dados').innerHTML = manutDadosDoc(d).slice(1).map((l) => '<div class="det"><strong>' + esc(l[0]) + ':</strong> ' + esc(l[1]) + '</div>').join('');
    $('manut-ver-n').textContent = '(' + d.coletas.length + ')';
    $('manut-ver-lista').innerHTML = d.coletas.length ? d.coletas.map((c) => '<div class="manut-item manut-leitura"><div>' +
      '<strong>' + esc(c.cod_item) + '</strong>' + (c.descricao ? ' · ' + esc(c.descricao) : '') +
      '<div class="sub">' + esc(c.quando) + ' · ' + esc(c.conferente) + (c.num_lote ? ' · lote ' + esc(c.num_lote) : '') + (c.tipo ? ' · ' + esc(c.tipo) : '') + (c.digitado ? ' · digitado' : '') + '</div></div>' +
      '<div class="qtd">' + esc(manutQtd(c)) + '</div></div>').join('') : '<p class="nota">Nenhuma coleta ativa nesta nota.</p>';
    $('manut-filtro').hidden = true;
    $('manut-result').hidden = true;
    $('manut-ver').hidden = false;
    mensagem($('manut-msg'), '', 'info');
    irAoTopo();
  }
  // Imprimir: A4 com os dados do documento e as coletas
  function manutFimImpressao() {
    if (!document.body.classList.contains('manut-imprimindo')) return;
    document.body.classList.remove('manut-imprimindo');
    const st = $('manut-pagina');
    if (st) st.remove();
    $('manut-impressao').innerHTML = '';
  }
  window.addEventListener('afterprint', manutFimImpressao);
  function manutImprimir(d) {
    const agora = new Date();
    $('manut-impressao').innerHTML = '<h1>Conferência da NF ' + esc(d.documento.nr_docto) + '</h1><p class="sub">__NOME_SISTEMA__</p>' +
      '<dl class="dados">' + manutDadosDoc(d).map((l) => '<dt>' + esc(l[0]) + '</dt><dd>' + esc(l[1]) + '</dd>').join('') + '</dl>' +
      '<h2>Coletas (' + d.coletas.length + ')</h2>' +
      (d.coletas.length ? '<table><thead><tr><th>Data e hora</th><th>Seq.</th><th>Produto</th><th>Lote</th><th class="num">Quantidade</th><th>Conferente</th><th>Tipo</th></tr></thead><tbody>' +
        d.coletas.map((c) => '<tr><td>' + esc(c.quando) + '</td><td>' + esc(c.sequencia) + '</td><td>' + esc(c.cod_item + (c.descricao ? ' - ' + c.descricao : '')) + '</td><td>' + esc(c.num_lote) + '</td>' +
          '<td class="num">' + esc(manutQtd(c)) + '</td><td>' + esc(c.conferente) + '</td><td>' + esc([c.tipo, c.digitado ? 'digitado' : ''].filter(Boolean).join(', ')) + '</td></tr>').join('') + '</tbody></table>'
        : '<p>Nenhuma coleta ativa nesta nota.</p>') +
      '<p class="rodape">Relatório gerado pelo __NOME_SISTEMA__ em ' + esc(agora.toLocaleDateString('pt-BR') + ' às ' + agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })) + '.</p>';
    const st = document.createElement('style');
    st.id = 'manut-pagina';
    st.textContent = '@media print { @page { size: A4; margin: 12mm 11mm 14mm; } }';
    document.head.appendChild(st);
    document.body.classList.add('manut-imprimindo');
    window.print();
  }
  $('manut-conf').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-ver], [data-imprimir]');
    if (!b) return;
    b.disabled = true;
    const d = await manutColetas(b.dataset.ver || b.dataset.imprimir);
    b.disabled = false;
    if (!d || $('etapa-manut').hidden) return;
    if (b.dataset.ver) manutVerMostrar(d); else manutImprimir(d);
  });
  // Excluir (dono, 24/11/2026): a conferencia finalizada e eliminada (ELIMINADO = S) e a nota volta para coletar, do zero
  $('manut-conf').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-excluir]');
    if (!b) return;
    if (!(await perguntar({ titulo: 'Excluir conferência da NF ' + b.dataset.nf, perigo: true, sim: 'Excluir', nao: 'Voltar',
      texto: 'Excluir a conferência da NF ' + b.dataset.nf + '?\nTodas as leituras dela serão eliminadas e a nota volta para coletar, do zero.' }))) return;
    b.disabled = true;
    carregando('Excluindo conferência', 'Eliminando as leituras da NF ' + b.dataset.nf + '…');
    try {
      const d = await api('/api/coletor/manutencao/eliminar', { id_transacao: b.dataset.excluir, nf: b.dataset.nf });
      fecharCarregando();
      if (!d.ok) { mensagem($('manut-msg'), d.mensagem || 'Não foi possível excluir a conferência.', 'erro'); b.disabled = false; irAoTopo(); return; }
      // bipes desta nota que ficaram guardados neste aparelho tambem saem (nao voltam a ser gravados depois)
      try { localStorage.removeItem(chaveFila(b.dataset.excluir)); } catch (x) { /* ignora */ }
      await carregarManut();
      mensagem($('manut-msg'), d.mensagem || 'Conferência excluída.', 'ok');
      irAoTopo();
    } catch (x) {
      fecharCarregando();
      if (x.message !== 'sessao') mensagem($('manut-msg'), 'Não foi possível falar com o servidor.', 'erro');
      b.disabled = false;
    }
  });
  $('manut-ver-voltar').addEventListener('click', () => { manutVerFechar(); irAoTopo(); });
  $('manut-ver-imprimir').addEventListener('click', () => { if (manutVerDados) manutImprimir(manutVerDados); });

