/*@parte Coletor: documento, tipo, coletas iniciadas e notas a conferir. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- 1) documento ---------- */
  async function buscarDocumento(filtro) {
    const msg = $('doc-msg');
    msg.hidden = true;
    $('doc-lista').innerHTML = '';
    $('doc-buscar').disabled = true;
    // popup "Pesquisando" na hora (dono, 31/10/2026); os avisos da busca tambem vem em popup, nao embaixo do campo
    carregando('Pesquisando', filtro.id ? 'Abrindo a nota…' : 'Buscando a nota ' + String(filtro.q || '').slice(0, 44) + '…');
    try {
      const d = await api('/api/coletor/documento?' + (filtro.id ? 'id=' + encodeURIComponent(filtro.id) : 'q=' + encodeURIComponent(filtro.q)));
      // em coleta por outro usuario (ou por este em outro aparelho): o servidor nao deixa abrir
      if (!d.ok) { vibrar(200); await avisar(d.mensagem || 'Não foi possível buscar o documento.', d.bloqueado ? 'Nota em coleta' : 'Não foi possível abrir'); $('doc-q').focus(); return false; }
      const docs = d.documentos || [];
      if (!docs.length) { vibrar(200); await avisar(d.mensagem || 'Documento não encontrado.', 'Nota não encontrada'); $('doc-q').focus(); return false; }
      if (docs.length > 1) {
        fecharCarregando();
        // mesmo numero em mais de um documento: escolher (os em coleta por outro ficam travados, com o aviso)
        mensagem(msg, docs.length + ' documentos com esse número. Escolha:', 'info');
        $('doc-lista').innerHTML = docs.map((x) => '<button type="button" class="btn-sec" data-id="' + esc(x.id_transacao) + '"' + (x.em_coleta ? ' disabled' : '') + '><div class="doc-cab">' +
          cabecalho(Object.assign({}, x, { itens: null })) + '<div class="det">' + x.n_itens + ' itens' + (x.minha ? ' · sua coleta iniciada' : '') + '</div>' +
          (x.em_coleta ? '<div class="det"><strong>' + esc(x.em_coleta) + '</strong></div>' : '') + '</div></button>').join('');
        return false;
      }
      msg.hidden = true;
      // popup ao selecionar a nota (dono, 31/10/2026): confere os dados antes de abrir; "Cancelar" nao reserva nada
      const x = docs[0], conf = d.conferidos || [];
      const total = x.itens.reduce((a, i) => a + (i.quantidade || 0), 0);
      const tipoTxt = (t) => (t === 'produto' ? 'por produto' : 'cega');
      // finalizada (DT_CONFERENCIA no banco; dono, 03/11/2026): conferir de novo reabre a nota
      const fin = d.finalizada;
      const sit = fin ? 'Conferência FINALIZADA' + (fin.usuario ? ' por ' + fin.usuario : '') + (fin.em ? ' em ' + fin.em : '') + '.\nReabrir deixa a nota em conferência de novo (deixa de estar finalizada).'
        : d.reserva ? 'Sua coleta em andamento (' + tipoTxt(d.reserva.tipo) + ').'
        : d.tipo_anterior ? 'Já tem ' + conf.length + (conf.length === 1 ? ' leitura' : ' leituras') + ': continua na coleta ' + tipoTxt(d.tipo_anterior) + '.'
        : 'Nenhuma leitura ainda.';
      const abrir = (filtro.direto && !fin) || await perguntar({ titulo: 'NF ' + x.nr_docto + (x.especie ? ' (' + x.especie + ')' : ''), sim: fin ? 'Reabrir' : 'Conferir', nao: 'Cancelar',
        texto: 'Cliente: ' + x.cliente.codigo + ' - ' + (x.cliente.fantasia || x.cliente.nome) + '\nEmissão: ' + (x.dt_emissao || '') +
          (x.transportadora && x.transportadora.nome ? '\nTransportadora: ' + x.transportadora.nome : '') +
          '\n' + x.itens.length + (x.itens.length === 1 ? ' item' : ' itens') + ' · ' + fmtQtd(total) + ' no total' + '\n\n' + sit });
      if (!abrir) { $('doc-q').value = ''; $('doc-q').focus(); return false; }
      abrirDocumento(docs[0], d.conferidos || []);
      // coleta ja iniciada por este usuario neste aparelho: continua direto, no mesmo tipo
      // finalizada: passa pelo servidor para reabrir (mesmo com reserva antiga), no tipo em que comecou
      if (fin) await iniciarTipo((d.reserva && d.reserva.tipo) || d.tipo_anterior || tipoPadrao, true);
      else if (d.reserva && (d.reserva.tipo === 'cega' || d.reserva.tipo === 'produto')) { tipo = d.reserva.tipo; iniciarColeta(); }
      // nota com leituras de antes (coleta finalizada ou liberada): continua no tipo em que comecou, sem perguntar
      else if (d.tipo_anterior === 'cega' || d.tipo_anterior === 'produto') await iniciarTipo(d.tipo_anterior, true);
      // nota nova com padrao fixo na Gestao (Por produto ou Cega): ja comeca nesse tipo, sem perguntar
      else if (tipoPadrao !== 'todas') await iniciarTipo(tipoPadrao, false);
      return true;
    } catch (e) {
      if (e.message !== 'sessao') await avisar('Não foi possível falar com o servidor.', 'Sem conexão');
      return false;
    } finally { $('doc-buscar').disabled = false; fecharCarregando(); }
  }
  function abrirDocumento(d, conf) {
    doc = d; doServidor(conf); enviando = []; ordemToque.clear(); ultimoItem = null;
    fila = recuperarFila(d.id_transacao, conf); // bipes deste documento que ficaram sem gravar neste aparelho
    salvarFila();
    $('tipo-doc').innerHTML = cabecalho(d) + (conf.length ? '<div class="det"><strong>Já tem ' + conf.length + (conf.length === 1 ? ' leitura gravada' : ' leituras gravadas') + '.</strong></div>' : '');
    mostrarEtapa('tipo');
  }
  $('col-abrir').addEventListener('click', () => { mostrarEtapa('doc'); irAoTopo(); });
  $('doc-voltar').addEventListener('click', () => {
    mensagem($('doc-msg'), '', 'info');
    $('doc-lista').innerHTML = '';
    mostrarEtapa('inicio');
  });
  $('doc-buscar').addEventListener('click', () => { const q = $('doc-q').value.trim(); if (q) buscarDocumento({ q }); else $('doc-q').focus(); });
  $('doc-q').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('doc-buscar').click(); } });
  $('doc-digitar').addEventListener('click', () => abrirTeclado({ titulo: 'Número da nota', max: 12, ok: (v) => { $('doc-q').value = v; buscarDocumento({ q: v }); } }));
  $('doc-lista').addEventListener('click', (e) => { const b = e.target.closest('[data-id]'); if (b) buscarDocumento({ id: b.dataset.id }); });

  /* ---------- 2) tipo ---------- */
  // escolher o tipo reserva a nota para este usuario e aparelho (outro conferente nao pega mais). O servidor devolve o tipo
  // que vale: se a nota ja tem leituras, o tipo em que a coleta comecou (dono: "continuadas seguem no padrao que iniciou")
  async function iniciarTipo(t, continuada) {
    const botoes = document.querySelectorAll('.tipos .tipo');
    botoes.forEach((x) => { x.disabled = true; });
    try {
      const d = await api('/api/coletor/iniciar', { id_transacao: doc.id_transacao, tipo: t });
      if (!d.ok) { mensagem($('tipo-msg'), d.mensagem || 'Não foi possível iniciar a coleta.', 'erro'); vibrar(200); return; }
      $('tipo-msg').hidden = true;
      tipo = d.tipo;
      iniciarColeta();
      if (d.reaberta) mensagem($('retorno'), 'Nota reaberta: está em conferência de novo' + (d.reaberta.usuario ? ' (tinha sido finalizada por ' + d.reaberta.usuario + (d.reaberta.em ? ' em ' + d.reaberta.em : '') + ')' : '') + '. A coleta continua ' + (tipo === 'produto' ? 'por produto' : 'cega') + '.', 'info');
      else if (continuada) mensagem($('retorno'), 'Esta nota já tinha leituras: a coleta continua ' + (tipo === 'produto' ? 'por produto' : 'cega') + ', como começou.', 'info');
    } catch (x) {
      if (x.message !== 'sessao') mensagem($('tipo-msg'), 'Não foi possível falar com o servidor.', 'erro');
    } finally { botoes.forEach((x) => { x.disabled = false; }); }
  }
  document.querySelector('.tipos').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tipo]');
    if (b && !b.disabled) iniciarTipo(b.dataset.tipo, false);
  });
  $('tipo-trocar').addEventListener('click', () => { doc = null; tipo = ''; mostrarEtapa('doc'); });

  /* ---------- coletas iniciadas por este usuario ---------- */
  // o bloco aparece com qualquer das listas: reservadas (iniciadas) ou nao finalizadas sem conferente (abertas, do banco)
  let iniPedido = 0, iniN = 0, abertasN = 0;
  const mostrarIniciadas = () => { $('iniciadas-bloco').hidden = !(iniN + abertasN) || $('etapa-doc').hidden; };
  async function carregarIniciadas() {
    const pedido = ++iniPedido;
    iniN = abertasN = 0;
    $('iniciadas').innerHTML = $('iniciadas-outras').innerHTML = $('iniciadas-abertas').innerHTML = '';
    $('ini-minhas-titulo').hidden = $('ini-outras-titulo').hidden = $('ini-abertas-titulo').hidden = true;
    carregarAbertas(pedido);
    try {
      const d = await api('/api/coletor/iniciadas');
      if (pedido !== iniPedido) return;
      const lista = (d.ok && d.iniciadas) || [];
      const minhas = lista.filter((r) => r.minha), outras = lista.filter((r) => !r.minha);
      iniN = lista.length;
      mostrarIniciadas();
      $('ini-minhas-titulo').hidden = !minhas.length;
      $('ini-outras-titulo').hidden = !outras.length;
      // so as deste usuario neste aparelho podem ser retomadas; as demais aparecem travadas, com o motivo
      const cartao = (r) => '<button type="button" class="btn-sec" data-retomar="' + esc(r.id_transacao) + '"' + (r.este_aparelho ? '' : ' disabled') + '><div class="doc-cab">' +
        '<div class="nf">NF ' + esc(r.nr_docto || r.id_transacao) + ' <span class="selo">' + (r.tipo === 'produto' ? 'Por produto' : 'Coleta cega') + '</span></div>' +
        (r.cliente ? '<div class="det">' + esc(r.cliente) + '</div>' : '') +
        (r.transportadora ? '<div class="det">Transp.: ' + esc(r.transportadora) + '</div>' : '') +
        '<div class="det">' + (r.minha ? '' : '<strong>' + esc(r.conferente) + '</strong> · ') + 'iniciada em ' + esc(r.iniciado_em) +
        (r.minha && !r.este_aparelho ? ' · <strong>em outro aparelho' + (r.aparelho ? ' (' + esc(r.aparelho) + ')' : '') + '</strong>' : '') + '</div></div></button>';
      $('iniciadas').innerHTML = minhas.map(cartao).join('');
      $('iniciadas-outras').innerHTML = outras.map(cartao).join('');
    } catch (e) { /* a lista e so um atalho: sem ela, busca normal */ }
  }
  // nao finalizadas no banco (DT_CONFERENCIA vazio) e sem reserva no servidor (dono, 03/11/2026): vem do Oracle, depois
  async function carregarAbertas(pedido) {
    try {
      const d = await api('/api/coletor/abertas');
      if (pedido !== iniPedido) return;
      const lista = (d.ok && d.abertas) || [];
      abertasN = lista.length;
      mostrarIniciadas();
      $('ini-abertas-titulo').hidden = !lista.length;
      $('iniciadas-abertas').innerHTML = lista.map((r) => '<button type="button" class="btn-sec" data-retomar="' + esc(r.id_transacao) + '"><div class="doc-cab">' +
        '<div class="nf">NF ' + esc(r.nr_docto || r.id_transacao) + (r.tipo ? ' <span class="selo">' + (r.tipo === 'produto' ? 'Por produto' : 'Coleta cega') + '</span>' : '') + '</div>' +
        (r.cliente ? '<div class="det">' + esc(r.cliente) + '</div>' : '') +
        (r.transportadora ? '<div class="det">Transp.: ' + esc(r.transportadora) + '</div>' : '') +
        '<div class="det">' + r.leituras + (r.leituras === 1 ? ' leitura' : ' leituras') + ' · última ' + esc(r.ultima_leitura) + (r.conferente ? ' por <strong>' + esc(r.conferente) + '</strong>' : '') + '</div></div></button>').join('');
    } catch (e) { /* a lista e so um atalho */ }
  }
  /* ---------- notas a conferir (dono, 02/11/2026): sem leitura e sem coleta em andamento, emitidas a partir da data
   * do parametro. Tocar abre como nota bipada (pergunta "Conferir?"). ---------- */
  let pendPedido = 0;
  async function carregarPendentes() {
    const pedido = ++pendPedido;
    try {
      const d = await api('/api/coletor/pendentes');
      if (pedido !== pendPedido || $('etapa-doc').hidden) return;
      if (!d.ativo) { $('pendentes-bloco').hidden = true; return; }
      const lista = (d.ok && d.pendentes) || [];
      $('pendentes-bloco').hidden = false;
      $('pend-nota').textContent = !d.ok ? (d.mensagem || 'Não foi possível carregar as notas a conferir.')
        : lista.length ? lista.length + (lista.length === 1 ? ' nota emitida' : ' notas emitidas') + ' a partir de ' + (d.desde || '') + ', sem nenhuma leitura.'
        : 'Nenhuma nota a conferir a partir de ' + (d.desde || '') + '.';
      $('pendentes').innerHTML = lista.map((r) => '<button type="button" class="btn-sec" data-pendente="' + esc(r.id_transacao) + '"><div class="doc-cab">' +
        '<div class="nf">NF ' + esc(r.nr_docto || r.id_transacao) + (r.especie ? ' <span class="selo">' + esc(r.especie) + '</span>' : '') + '</div>' +
        (r.cliente ? '<div class="det">' + esc(r.cliente) + '</div>' : '') +
        (r.transportadora ? '<div class="det">Transp.: ' + esc(r.transportadora) + '</div>' : '') +
        '<div class="det">Emissão ' + esc(r.dt_emissao || '') + (r.itens ? ' · ' + r.itens + (r.itens === 1 ? ' item' : ' itens') : '') + '</div></div></button>').join('');
    } catch (e) { /* a lista e so um atalho: sem ela, busca normal */ }
  }
  $('pendentes').addEventListener('click', (e) => { const b = e.target.closest('[data-pendente]'); if (b) buscarDocumento({ id: b.dataset.pendente }); });
  // coleta em andamento: abre direto, sem perguntar "Conferir?" (dono, 31/10/2026); nota nova bipada continua perguntando
  $('iniciadas').addEventListener('click', (e) => { const b = e.target.closest('[data-retomar]'); if (b && !b.disabled) buscarDocumento({ id: b.dataset.retomar, direto: true }); });
  // nao finalizada sem conferente: abre direto e passa a ser de quem tocou (continua no tipo em que comecou)
  $('iniciadas-abertas').addEventListener('click', (e) => { const b = e.target.closest('[data-retomar]'); if (b && !b.disabled) buscarDocumento({ id: b.dataset.retomar, direto: true }); });

