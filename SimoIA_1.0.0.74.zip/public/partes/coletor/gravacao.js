/*@parte Coletor: gravação: fila enviada em lote. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- gravacao: fila enviada em lote, sem travar os bipes ---------- */
  // pausa do envio durante um Excluir/Cancelar (dono, 02/11/2026: excluiu 2 bipes, bipou de novo na hora e ficou 3).
  // Enquanto o cancelamento vai ao banco, os bipes novos ficam so na fila; a tela ja tira as leituras canceladas da
  // conta (o bipe novo soma do zero) e nenhuma gravacao corre junto, para a resposta dela nao trazer as antigas de volta.
  let pausaEnvio = 0;
  // exclusoes/cancelamentos vao ao banco um de cada vez, na ordem dos toques (dono, 02/11/2026: dois "Excluir" seguidos
  // corriam juntos e a resposta do primeiro trazia o segundo item de volta)
  let vezDasOps = Promise.resolve();
  async function semEnvio(fn, semLimite) {
    pausaEnvio++;
    const vez = vezDasOps.then(async () => {
      // espera terminar a gravacao que ja estava a caminho (no maximo uns 20 s; no Abandonar, ate terminar)
      for (let n = 0; enviando.length && (semLimite || n < 200); n++) await new Promise((r) => setTimeout(r, 100));
      return fn();
    });
    vezDasOps = vez.catch(() => {});
    try {
      return await vez;
    } finally {
      pausaEnvio--;
      if (!pausaEnvio) { if (doc) desenhar(); enviar(); } // redesenha: sai o vermelho de "ainda gravando" se nada ficou
    }
  }
  let tentarDeNovo = null;
  let falhouEnvio = false; // a tela mostra "Não gravou… tentando de novo": some quando a gravação der certo (dono, 02/11/2026)
  async function enviar() {
    if (pausaEnvio || enviando.length || !fila.length || !doc) return;
    clearTimeout(tentarDeNovo);
    enviando = fila.splice(0);
    desenharFila();
    const lote = enviando;
    try {
      const d = await api('/api/coletor/gravar', { id_transacao: doc.id_transacao, tipo, leituras: lote.map((l) => ({ id: l.id, texto: l.texto, qtd: l.qtd, digitado: l.digitado, lote: l.lote || '', grupo: l.grupo || '' })) });
      if (!d.ok && d.bloqueado) {
        // a nota passou para outro conferente (liberada na Gestao): nao adianta tentar de novo; as leituras ficam no aparelho
        fila = lote.concat(fila); enviando = [];
        salvarFila();
        mensagem($('retorno'), (d.mensagem || 'Este documento está com outro conferente.') + ' As leituras não gravadas ficaram neste aparelho.', 'erro');
        vibrar([200, 80, 200]);
        desenhar();
        return;
      }
      if (!d.ok) throw new Error(d.mensagem || 'Não foi possível gravar.');
      enviando = [];
      if (d.conferidos) doServidor(d.conferidos);
      seguirOrdem(d.ordem);
      if (falhouEnvio) { falhouEnvio = false; mensagem($('retorno'), '✓ Leituras pendentes gravadas.', 'ok'); }
      // recusadas pelo servidor: nao foram gravadas e saem da tela; o aviso diz isso (dono, 02/11/2026)
      if (d.recusadas && d.recusadas.length) {
        mensagem($('retorno'), (d.recusadas.length === 1 ? 'Leitura não gravada: ' : d.recusadas.length + ' leituras não gravadas: ') + d.recusadas.map((r) => r.motivo).join(' '), 'erro');
        vibrar([200, 80, 200]);
      }
    } catch (e) {
      if (e.message === 'sessao') return;
      // volta para a fila e tenta de novo daqui a pouco (nada se perde)
      fila = lote.concat(fila); enviando = [];
      falhouEnvio = true;
      mensagem($('retorno'), 'Não gravou: ' + e.message + ' Tentando de novo em 5 s…', 'erro');
      tentarDeNovo = setTimeout(enviar, 5000);
    }
    salvarFila();
    desenhar();
    if (fila.length) enviar();
  }
  // a ordem dos itens e a do servidor (dono, 02/11/2026): se mudou com a pagina aberta, a tela passa a seguir a nova,
  // para o item atual da coleta por produto ser o mesmo que o servidor confere
  function seguirOrdem(ordem) {
    if (!doc || !Array.isArray(ordem) || ordem.length !== doc.itens.length) return;
    if (doc.itens.every((i, n) => String(i.w_id) === ordem[n])) return;
    const pos = new Map(ordem.map((w, n) => [w, n]));
    if (!doc.itens.every((i) => pos.has(String(i.w_id)))) return;
    doc.itens.sort((a, b) => pos.get(String(a.w_id)) - pos.get(String(b.w_id)));
  }
  function desenharFila() {
    const n = fila.length + enviando.length;
    $('fila').textContent = n ? 'Gravando ' + n + (n === 1 ? ' leitura…' : ' leituras…') : (conferidos.length ? conferidos.length + (conferidos.length === 1 ? ' leitura gravada.' : ' leituras gravadas.') : '');
    // "Gravando N leituras…" em vermelho so quando nada falta conferir (dono, 02/11/2026): explica o "Finalizar" travado
    $('fila').classList.toggle('gravando', !!doc && !faltando(somas()).length && !!(n || pausaEnvio));
  }

