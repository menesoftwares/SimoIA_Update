/*@parte Coletor: início da tela. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- inicio ---------- */
  async function iniciar() {
    try {
      const d = await api('/api/coletor/inicio');
      if (!d.ok) { mensagem($('bloqueio'), d.mensagem || 'Coletor indisponível.', 'erro'); return; }
      qtdDecimal = !!d.qtd_decimal;
      exigeLote = !!d.exige_lote;
      exigeLoteKit = !!d.exige_lote_kit;
      tipoPadrao = d.tipo_padrao === 'produto' || d.tipo_padrao === 'cega' ? d.tipo_padrao : 'todas';
      podeManut = !!d.manutencao;
      podeEtiq = !!d.etiquetas;
      podeColetor = !!d.conferencia;
      podeRastro = !!d.rastro;
      // compartilhar: so os meios liberados no cadastro do usuario, como no Simulador (dono, 06/11/2026)
      $('rastro-comp-email').hidden = !d.pode_email;
      $('rastro-comp-whats').hidden = !d.pode_whats;
      $('rastro-comp').hidden = !d.pode_email && !d.pode_whats;
      // so com um dos "Exigir lote" da conferencia ligado na Gestao (dono, 06/11/2026); o servidor confere de novo
      const rastroLiberado = exigeLote || exigeLoteKit;
      $('rastro-abrir').disabled = !rastroLiberado;
      if (!rastroLiberado) {
        $('rastro-abrir').title = 'Precisa de um dos "Exigir lote" da conferência ligado na Gestão';
        $('rastro-bloco-nota').textContent = 'Disponível com um dos "Exigir lote" da conferência ligado em Gestão › Coletor.';
      }
      if (d.etiqueta) etqCfg = d.etiqueta;
      document.querySelectorAll('.btn-camera').forEach((b) => { b.hidden = !d.permitir_camera; b.parentNode.classList.toggle('com-camera', !!d.permitir_camera); });
      // "Informar quantidade" travada na Gestao (dono, 02/11/2026): fica na tela, desligada e sem poder mudar
      // (a escolha guardada no aparelho volta quando a Gestao liberar de novo)
      if (d.informar_qtd === false) {
        const ch = $('informar-qtd');
        ch.checked = false;
        ch.disabled = true;
        ch.closest('.chave').classList.add('travada');
        ch.closest('.chave').title = 'Bloqueada na Gestão: cada leitura vale 1.';
        dicaBipe();
      }
      // padrao fixo na Gestao: so o tipo permitido aparece (para o caso de a tela de tipo ser mostrada)
      document.querySelectorAll('.tipos [data-tipo]').forEach((b) => { b.hidden = tipoPadrao !== 'todas' && b.dataset.tipo !== tipoPadrao; });
      // usuario so do Coletor (tela padrao na Gestao): nao ha SimoIA para voltar, o botao vira "Sair"
      if (d.tela_inicial === 'coletor' || d.tela_inicial === 'coletor_rastro') {
        const v = $('voltar');
        v.textContent = 'Sair';
        v.title = 'Sair do __NOME_SISTEMA__ (encerra a sessão)';
        v.setAttribute('aria-label', 'Sair do __NOME_SISTEMA__');
        v.addEventListener('click', async (e) => {
          e.preventDefault();
          if (fila.length + enviando.length && !(await perguntar({ titulo: 'Sair', texto: 'Ainda há leituras sendo gravadas. Elas ficam guardadas neste aparelho e são gravadas quando você abrir a nota de novo. Sair mesmo assim?', sim: 'Sair', nao: 'Ficar' }))) return;
          try { await fetch('/api/sair', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token } }); } catch (x) { /* sai mesmo assim */ }
          try {
            sessionStorage.removeItem('token'); sessionStorage.removeItem('usuario');
            localStorage.removeItem('simoia_token'); localStorage.removeItem('simoia_usuario');
          } catch (x) { /* ignora */ }
          location.replace('/');
        });
      }
      if (podeColetor && !d.pronto) {
        mensagem($('bloqueio'), 'O Coletor ainda não está pronto: faltam SQLs ativos na Gestão › Coletor.', 'erro');
        podeColetor = false;
      }
      // sempre abre na tela principal (dono, 31/10/2026: "nao quero que carregue automaticamente a ultima contagem")
      try { localStorage.removeItem('coletor_atual'); } catch (e) { /* ignora (chave da versao que reabria sozinha) */ }
      // 2 ou mais acessos: tela inicial com os baloes (dono, 06/11/2026). So 1: abre direto nele, sem balao e sem o
      // "Voltar" da tela (o do topo volta ao SimoIA)
      const acessos = [podeManut, podeEtiq, podeColetor, podeRastro].filter(Boolean).length;
      if (!acessos) return;
      const comBaloes = acessos > 1;
      $('manut-voltar').hidden = !comBaloes;
      $('doc-voltar').hidden = !comBaloes;
      $('rastro-voltar').hidden = !comBaloes;
      // "Coletor (rast)" na tela padrao (dono, 07/11/2026): abre direto na Rastreabilidade; com outros acessos, o Voltar
      // da tela leva aos baloes
      if (d.tela_inicial === 'coletor_rastro' && podeRastro && rastroLiberado) rastroAbrir();
      else if (comBaloes) mostrarEtapa('inicio');
      else if (podeManut) manutAbrir();
      else if (podeEtiq) { etqSoEla = true; etqAbrir(); }
      else if (podeRastro) { if (rastroLiberado) rastroAbrir(); else mostrarEtapa('inicio'); } // fechada: mostra o balao com o motivo
      else mostrarEtapa('doc');
    } catch (e) {
      if (e.message !== 'sessao') mensagem($('bloqueio'), 'Não foi possível falar com o servidor.', 'erro');
    }
  }
  iniciar();
