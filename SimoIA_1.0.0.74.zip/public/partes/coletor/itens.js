/*@parte Coletor: lista de itens, finalizar e abandonar. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- lista de itens e historico ---------- */
  function desenhar() {
    desenharFila();
    const tot = new Map(), lotes = new Map(), nLeit = new Map(), esperando = new Map();
    for (const c of conferidos) {
      const k = String(c.w_id_movitens);
      tot.set(k, (tot.get(k) || 0) + c.qtd_conferida);
      nLeit.set(k, (nLeit.get(k) || 0) + 1);
      if (c.num_lote) { if (!lotes.has(k)) lotes.set(k, new Set()); lotes.get(k).add(c.num_lote); }
    }
    for (const l of fila.concat(enviando)) {
      const k = String(l.w_id);
      esperando.set(k, (esperando.get(k) || 0) + Number(String(l.qtd).replace(',', '.')));
      if (l.lote) { if (!lotes.has(k)) lotes.set(k, new Set()); lotes.get(k).add(l.lote); }
    }
    const s = somas(), falta = faltando(s), atual = tipo === 'produto' ? falta[0] : null;
    // contador da nota: bipados x total (soma das quantidades dos itens) e quanto falta — nas duas coletas
    const totalNota = doc.itens.reduce((a, i) => a + (i.quantidade || 0), 0);
    const bipados = doc.itens.reduce((a, i) => a + Math.min(s.get(String(i.w_id)) || 0, i.quantidade || Infinity), 0);
    const restam = arred(Math.max(0, totalNota - bipados));
    // tudo conferido, mas leituras ainda indo ao banco (ou exclusao em andamento): fica vermelho ate gravar
    const gravandoFim = !falta.length && !!(fila.length + enviando.length || pausaEnvio);
    $('resumo-qtd').innerHTML = totalNota ? '<span>Bipados: <span class="num">' + fmtQtd(bipados) + '</span> de ' + fmtQtd(totalNota) + '</span>' +
      '<span class="falta' + (restam ? '' : ' zero') + '">' + (restam ? 'Faltam ' + fmtQtd(restam) : 'Nada faltando') + '</span>' : '';
    // por produto: cartao do item atual (com o bipe dentro); sem item atual = tudo conferido
    if (tipo === 'produto') {
      const feitos = doc.itens.length - falta.length;
      $('atual').classList.toggle('pronto', !atual);
      if (atual) {
        const ja = s.get(String(atual.w_id)) || 0, pct = Math.min(100, Math.round(ja / atual.quantidade * 100));
        $('atual-info').innerHTML = '<div class="rotulo">Item atual · ' + (feitos + 1) + ' de ' + doc.itens.length + '</div>' +
          '<div class="cod">' + esc(atual.cod_item) + (atual.localizacao ? ' <span class="selo">' + esc(atual.localizacao) + '</span>' : '') + '</div>' +
          (atual.descricao ? '<div class="desc">' + esc(atual.descricao) + '</div>' : '') +
          '<div class="sub">Seq. ' + esc(atual.sequencia) + (atual.cod_comercial_item && atual.cod_comercial_item !== atual.cod_item ? ' · ' + esc(atual.cod_comercial_item) : '') + '</div>' +
          '<div class="conta">' + fmtQtd(ja) + ' de ' + fmtQtd(atual.quantidade) + ' ' + esc(atual.unidade) + '</div><div class="barra"><span style="width:' + pct + '%"></span></div>';
      } else {
        $('atual-info').innerHTML = '<div class="rotulo">Coleta por produto</div><div class="conta">Todos os ' + doc.itens.length + ' itens conferidos.</div><div class="sub">Toque em "Finalizar", no topo.</div>';
      }
      $('bipe').disabled = $('manual').disabled = $('bipe-camera').disabled = !atual;
    } else $('bipe').disabled = $('manual').disabled = $('bipe-camera').disabled = false;
    // finalizar so com tudo conferido por completo (e nada esperando gravar)
    const pend = fila.length + enviando.length;
    $('col-finalizar').disabled = !!falta.length || !!pend;
    $('fin-info').classList.toggle('gravando', gravandoFim);
    $('fin-info').textContent = falta.length ? 'Para finalizar, falta' + (falta.length === 1 ? ' 1 item' : 'm ' + falta.length + ' itens') + ' conferir por completo.' : pend ? 'Espere as leituras terminarem de gravar.' : 'Todos os itens conferidos.';

    let itens = doc.itens.slice();
    if (tipo === 'cega') {
      itens = itens.filter((i) => tot.has(String(i.w_id)) || esperando.has(String(i.w_id)))
        .sort((a, b) => (ordemToque.get(b.w_id) || 0) - (ordemToque.get(a.w_id) || 0));
    } // por produto: na ordem do servidor (com localizacao primeiro: localizacao, sequencia, descricao; sem localizacao: sequencia, descricao)
    const posAtual = atual ? itens.indexOf(atual) : -1;
    $('lista').innerHTML = itens.length ? itens.map((i, n) => {
      const k = String(i.w_id), t = tot.get(k) || 0, esp = esperando.get(k) || 0;
      const ls = lotes.has(k) ? [...lotes.get(k)].join(', ') : '';
      // por produto: concluido / atual / pendente (os pendentes so ficam a mostra; o bipe e so no item atual)
      const completo = i.quantidade > 0 && arred(t + esp) >= i.quantidade;
      // cega: amarelo enquanto incompleto, verde ao completar; por produto: concluido / atual / pendente
      const situacao = tipo !== 'produto' ? (completo ? ' feito completo' : ' parcial')
        : completo ? ' feito' : i === atual ? ' atual-lista' : n > posAtual ? ' pendente' : '';
      return '<div class="item-linha"><div class="item' + situacao + (k === String(ultimoItem) && !completo ? ' recente' : '') + '" data-item="' + esc(k) + '">' +
        '<div><div class="cod">' + esc(i.cod_item) + (i.localizacao ? ' <span class="selo">' + esc(i.localizacao) + '</span>' : '') + '</div>' +
        (i.descricao ? '<div class="desc">' + esc(i.descricao) + '</div>' : '') + '<div class="sub">Seq. ' + esc(i.sequencia) + (i.cod_comercial_item && i.cod_comercial_item !== i.cod_item ? ' · ' + esc(i.cod_comercial_item) : '') +
        (ls ? ' · lote ' + esc(ls) : '') + (nLeit.get(k) ? ' · ' + nLeit.get(k) + (nLeit.get(k) === 1 ? ' leitura' : ' leituras') : '') + '</div></div>' +
        // conferido "de" esperado, nas duas coletas (dono, 31/10/2026: na cega tambem "1 de 10")
        '<div class="tot">' + (completo ? '✓ ' : '') + fmtQtd(t + esp) + '<div class="esperado">de ' + fmtQtd(i.quantidade) + ' ' + esc(i.unidade) + '</div>' +
        (esp ? '<div class="esperando">gravando</div>' : '') + '</div></div>' +
        (t || esp ? '<button type="button" class="btn-excluir" data-excluir="' + esc(k) + '" aria-label="Excluir as leituras de ' + esc(i.cod_item) + ' para reconferir">Excluir</button>' : '') + '</div>';
    }).join('') : '<div class="vazio">' + (tipo === 'cega' ? 'Nenhum item lido ainda. Bipe a etiqueta do produto.' : 'A nota não tem itens.') + '</div>';
    // historico: leituras gravadas, mais recentes em cima, com Cancelar
    $('hist-titulo').textContent = 'Leituras gravadas (' + conferidos.length + ')';
    $('hist-lista').innerHTML = conferidos.length ? conferidos.map((c) => '<div class="leitura"><div><strong>' + esc(c.cod_item) + '</strong> · ' + fmtQtd(c.qtd_conferida) +
      (c.num_lote ? ' · lote ' + esc(c.num_lote) : '') + '<div class="sub">' + esc(c.dt_criacao) + ' · ' + esc(c.usuario) + (/digitado/.test(c.observacao || '') ? ' · digitado' : '') + '</div></div>' +
      '<button type="button" class="link-cancelar" data-cancelar="' + esc(c.w_id) + '">Cancelar</button></div>').join('') : '<p class="nota">Nenhuma leitura gravada.</p>';
  }
  $('hist-lista').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-cancelar]');
    if (!b) return;
    const c = conferidos.find((x) => String(x.w_id) === b.dataset.cancelar);
    if (!c || !(await perguntar({ titulo: 'Cancelar leitura', texto: 'Cancelar a leitura de ' + c.cod_item + ' (' + fmtQtd(c.qtd_conferida) + ') de ' + c.dt_criacao + '?', sim: 'Cancelar leitura', nao: 'Voltar', perigo: true }))) return;
    b.disabled = true;
    const id = doc.id_transacao, wid = chPend(id, c.w_id);
    pendLeit.add(wid); // ja sai da conta na tela, mesmo esperando a vez
    conferidos = semPendentes(confServ);
    desenhar(); focarBipe();
    await semEnvio(async () => {
      // a resposta so vale para a tela se a nota ainda estiver aberta (o "Voltar" nao interrompe o cancelamento)
      try {
        const d = await api('/api/coletor/cancelar', { id_transacao: id, w_id: c.w_id });
        pendLeit.delete(wid);
        if (!docAberto(id)) return;
        if (!d.ok) { mensagem($('retorno'), d.mensagem || 'Não foi possível cancelar.', 'erro'); conferidos = semPendentes(confServ); return; }
        doServidor(d.conferidos);
        mensagem($('retorno'), 'Leitura de ' + c.cod_item + ' cancelada.', 'info');
      } catch (x) { pendLeit.delete(wid); if (!docAberto(id)) return; conferidos = semPendentes(confServ); if (x.message !== 'sessao') mensagem($('retorno'), 'Não foi possível falar com o servidor.', 'erro'); }
      finally { if (docAberto(id)) { desenhar(); focarBipe(); } }
    });
  });
  const codDoItem = (k) => { const it = doc.itens.find((i) => String(i.w_id) === String(k)); return it ? it.cod_item : ''; };
  // cancelamento no banco (cancelar-item); a resposta traz as leituras atualizadas
  // fim(): tira a exclusao das pendentes (antes de aplicar a resposta, que ja vem sem as leituras canceladas)
  async function cancelarNoBanco(url, corpo, msgOk, fim) {
    try {
      const d = await api(url, corpo);
      fim();
      if (!docAberto(corpo.id_transacao)) return !!d.ok; // saiu da nota: o cancelamento valeu, a tela e de outra
      if (!d.ok) { conferidos = semPendentes(confServ); mensagem($('retorno'), d.mensagem || 'Não foi possível cancelar.', 'erro'); return false; }
      doServidor(d.conferidos);
      mensagem($('retorno'), typeof msgOk === 'function' ? msgOk() : msgOk, 'info'); // funcao: montada depois da resposta
      return true;
    } catch (x) {
      fim();
      if (!docAberto(corpo.id_transacao)) return false;
      conferidos = semPendentes(confServ); // falhou: as leituras voltam para a tela
      if (x.message !== 'sessao') mensagem($('retorno'), 'Não foi possível falar com o servidor.', 'erro');
      return false;
    } finally { if (docAberto(corpo.id_transacao)) { desenhar(); focarBipe(); } }
  }
  function irAoTopo() {
    let suave = true;
    try { suave = !window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { /* ignora */ }
    window.scrollTo({ top: 0, behavior: suave ? 'smooth' : 'auto' });
  }
  // "Pode bipar o item de novo" so se ainda falta algo (dono, 02/11/2026: o item pode ja ter sido bipado de novo enquanto
  // a exclusao esperava a vez; com "Nada faltando", a frase confundia). Avaliado na hora em que a mensagem aparece.
  const msgExcluido = (cod) => 'Leituras de ' + cod + ' excluídas.' + (doc && faltando(somas()).length ? ' Pode bipar o item de novo.' : '');
  // excluir o item inteiro para reconferir (dono, 31/10/2026): tira da fila o que nao foi gravado e cancela as gravadas
  async function excluirItem(k) {
    const cod = codDoItem(k);
    const gravadas = conferidos.filter((c) => String(c.w_id_movitens) === k);
    const naFila = fila.filter((l) => String(l.w_id) === k);
    const total = gravadas.reduce((s, c) => s + c.qtd_conferida, 0) + naFila.reduce((s, l) => s + Number(String(l.qtd).replace(',', '.')), 0);
    const n = gravadas.length + naFila.length;
    if (!(await perguntar({ titulo: 'Excluir item ' + cod, texto: 'Excluir ' + (n === 1 ? 'a leitura' : 'as ' + n + ' leituras') + ' de ' + cod + ' (total ' + fmtQtd(total) + ') para reconferir o item?', sim: 'Excluir', nao: 'Voltar', perigo: true }))) return;
    // sobe ao topo do Coletor, onde aparece a mensagem do resultado (dono, 02/11/2026)
    irAoTopo();
    // so as leituras que existiam na hora do "Excluir" (dono, 02/11/2026: bipou durante a gravacao e o bipe novo
    // tambem foi excluido). Bipe feito depois do toque fica na fila e e gravado depois do cancelamento.
    const excluir = new Set(enviando.concat(fila).filter((l) => String(l.w_id) === k).map((l) => l.id));
    const id = doc.id_transacao, pk = chPend(id, k);
    // ja sai da tela no toque, mesmo esperando a vez de outra exclusao (dono, 02/11/2026)
    pendItens.add(pk);
    fila = fila.filter((l) => !excluir.has(l.id));
    salvarFila();
    ordemToque.delete(k); ordemToque.delete(Number(k));
    if (String(ultimoItem) === k) ultimoItem = null;
    conferidos = semPendentes(confServ);
    mensagem($('retorno'), 'Excluindo as leituras de ' + cod + '…', 'info');
    desenhar(); focarBipe();
    // o envio fica parado ate o banco cancelar: o que ja estava a caminho termina antes, e o que for bipado agora so
    // vai depois (e soma do zero). As exclusoes vao ao banco uma de cada vez.
    await semEnvio(async () => {
      // saiu da nota ("Voltar"): o cancelamento vai ao banco do mesmo jeito, sem mexer na tela (dono, 02/11/2026)
      if (!docAberto(id)) { await cancelarNoBanco('/api/coletor/cancelar-item', { id_transacao: id, w_id_movitens: k }, '', () => pendItens.delete(pk)); return; }
      // o que estava sendo gravado na hora do toque ja voltou (gravado = em confServ; falhou = de volta na fila)
      fila = fila.filter((l) => !excluir.has(l.id));
      salvarFila();
      if (!confServ.some((c) => String(c.w_id_movitens) === k)) {
        pendItens.delete(pk);
        mensagem($('retorno'), msgExcluido(cod), 'info'); desenhar(); focarBipe(); return;
      }
      await cancelarNoBanco('/api/coletor/cancelar-item', { id_transacao: id, w_id_movitens: k }, () => msgExcluido(cod), () => pendItens.delete(pk));
    });
  }
  // "Voltar": sai sem finalizar (a nota continua reservada e aparece em "Coletas em andamento")
  // exclusoes em andamento nao seguram o "Voltar": continuam na vez delas ate o banco cancelar (dono, 02/11/2026)
  $('col-trocar').addEventListener('click', () => {
    if (fila.length + enviando.length) { avisar('Ainda há leituras sendo gravadas. Espere terminar para voltar.'); return; }
    const nf = doc.nr_docto, excluindo = pausaEnvio;
    doc = null; tipo = ''; conferidos = []; mostrarEtapa('doc');
    if (excluindo) mensagem($('doc-msg'), 'As exclusões da NF ' + nf + ' continuam até terminar.', 'info');
  });
  // "Finalizar coleta": libera a nota (sai das coletas iniciadas); as leituras continuam gravadas
  $('col-finalizar').addEventListener('click', async () => {
    if (fila.length + enviando.length || pausaEnvio) { avisar('Ainda há leituras sendo gravadas. Espere terminar para finalizar.'); return; }
    if (!(await perguntar({ titulo: 'Finalizar coleta', texto: 'Finalizar a coleta da NF ' + doc.nr_docto + '?\nEla fica marcada como finalizada no banco e sai das coletas em andamento. As leituras continuam gravadas.', sim: 'Finalizar', nao: 'Voltar' }))) return;
    $('col-finalizar').disabled = true;
    try {
      const d = await api('/api/coletor/finalizar', { id_transacao: doc.id_transacao });
      if (!d.ok) { mensagem($('retorno'), d.mensagem || 'Não foi possível finalizar.', 'erro'); return; }
      try { localStorage.removeItem(chaveFila(doc.id_transacao)); } catch (x) { /* ignora */ }
      const nf = doc.nr_docto;
      doc = null; tipo = ''; conferidos = []; mostrarEtapa('doc');
      mensagem($('doc-msg'), 'Coleta da NF ' + nf + ' finalizada.', 'ok');
    } catch (x) {
      if (x.message !== 'sessao') mensagem($('retorno'), 'Não foi possível falar com o servidor.', 'erro');
    } finally { $('col-finalizar').disabled = false; }
  });
  // "Abandonar coleta": cancela todas as leituras da nota e libera a nota para outro conferente
  $('col-abandonar').addEventListener('click', async () => {
    const n = conferidos.length + fila.length + enviando.length;
    if (!(await perguntar({ titulo: 'Abandonar coleta', perigo: true, sim: 'Abandonar', nao: 'Voltar',
      texto: 'Abandonar a coleta da NF ' + doc.nr_docto + '?\n' + (n ? 'As ' + n + ' leituras dela serão canceladas' : 'Ela não tem leituras') + ' e a nota fica livre para outro conferente.' }))) return;
    $('col-abandonar').disabled = true;
    // popup na tela enquanto cancela (dono, 31/10/2026); some quando o servidor responder
    carregando('Abandonando coleta', n ? 'Cancelando ' + (n === 1 ? 'a leitura' : 'as ' + n + ' leituras') + ' da NF ' + doc.nr_docto + '…' : 'Liberando a NF ' + doc.nr_docto + '…');
    const id = doc.id_transacao;
    try {
      // sem resquicios (dono, 02/11/2026): o abandono vai ao banco na vez dele — depois das exclusoes em andamento e
      // da gravacao que ja estava a caminho — e nada mais e gravado enquanto isso (o envio fica parado)
      const d = await semEnvio(async () => {
        const r = await api('/api/coletor/abandonar', { id_transacao: id });
        // o que ainda nao tinha ido para o banco tambem e descartado — aqui dentro, antes de o envio ser solto
        if (r.ok) {
          fila = []; enviando = [];
          try { localStorage.removeItem(chaveFila(id)); } catch (x) { /* ignora */ }
        }
        return r;
      }, true);
      if (!d.ok) { await avisar(d.mensagem || 'Não foi possível abandonar a coleta.', 'Não foi possível abandonar'); return; }
      fecharCarregando();
      doc = null; tipo = ''; conferidos = []; mostrarEtapa('doc');
      mensagem($('doc-msg'), d.mensagem || 'Coleta abandonada.', 'ok');
    } catch (x) {
      if (x.message !== 'sessao') await avisar('Não foi possível falar com o servidor.', 'Sem conexão');
    } finally { fecharCarregando(); $('col-abandonar').disabled = false; }
  });
  window.addEventListener('beforeunload',(e) => { if (fila.length + enviando.length || pausaEnvio) { e.preventDefault(); e.returnValue = ''; } });

