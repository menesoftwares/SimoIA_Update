/*@parte Coletor: apoio, tema, popup, teclado virtual e estado. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const fmtQtd = (n) => Number(n || 0).toLocaleString('pt-BR', { maximumFractionDigits: 3 });

  /* ---------- tema: automatico / claro / escuro (mesma chave "tema" da pagina principal) ---------- */
  function marcarTema(t) { for (const b of document.querySelectorAll('#tema button')) b.setAttribute('aria-pressed', String(b.dataset.tema === t)); }
  let temaAtual = 'auto';
  try { const t = localStorage.getItem('tema'); if (t === 'claro' || t === 'escuro') temaAtual = t; } catch (e) { /* ignora */ }
  marcarTema(temaAtual);
  $('tema').addEventListener('click', (e) => {
    const b = e.target.closest('button[data-tema]');
    if (!b) return;
    const t = b.dataset.tema;
    if (t === 'auto') document.documentElement.removeAttribute('data-tema'); else document.documentElement.setAttribute('data-tema', t);
    try { if (t === 'auto') localStorage.removeItem('tema'); else localStorage.setItem('tema', t); } catch (x) { /* ignora */ }
    marcarTema(t);
  });

  async function api(url, corpo) {
    const r = await fetch(url, corpo ? { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify(corpo) }
      : { headers: { 'Authorization': 'Bearer ' + token } });
    let d = {};
    try { d = await r.json(); } catch (e) { /* ignora */ }
    if (r.status === 401) {
      try { if (d.motivo === 'outro_acesso' && d.mensagem) sessionStorage.setItem('aviso', d.mensagem); } catch (e) { /* ignora */ }
      location.href = '/'; throw new Error('sessao');
    }
    return d;
  }
  function mensagem(el, texto, tipo) { el.textContent = texto || ''; el.className = 'msg ' + (tipo || 'info'); el.hidden = !texto; }
  const vibrar = (ms) => { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (e) { /* ignora */ } };

  /* ---------- popup da propria tela (no lugar de confirm/alert do navegador) ---------- */
  let popResolver = null;
  // perguntar(...) -> Promise<boolean>; avisar(texto) -> so OK
  function perguntar(opc) {
    opc = Object.assign({ titulo: 'Confirmar', texto: '', sim: 'Confirmar', nao: 'Cancelar', perigo: false, soAviso: false }, opc);
    if (popResolver) popResolver(false);
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    $('pop-titulo').textContent = opc.titulo;
    $('pop-texto').textContent = opc.texto;
    $('pop-sim').textContent = opc.sim;
    $('pop-nao').textContent = opc.nao;
    $('pop-nao').hidden = opc.soAviso;
    $('popup').querySelector('.pop-acoes').hidden = false; // (o "carregando" esconde os botoes)
    $('popup').querySelector('.pop-acoes').classList.toggle('so-ok', opc.soAviso);
    $('pop-sim').classList.toggle('perigo', !!opc.perigo);
    $('popup').hidden = false;
    // acao perigosa: o foco fica no "Cancelar" (um Enter sem querer nao confirma)
    (opc.perigo && !opc.soAviso ? $('pop-nao') : $('pop-sim')).focus();
    return new Promise((ok) => { popResolver = ok; });
  }
  const avisar = (texto, titulo) => perguntar({ titulo: titulo || 'Atenção', texto, sim: 'OK', soAviso: true });
  // popup "carregando" (sem botoes): fica ate perguntar/avisar trocar o conteudo ou fecharCarregando()
  function carregando(titulo, texto) {
    if (popResolver) { const r = popResolver; popResolver = null; r(false); }
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    $('pop-titulo').textContent = titulo;
    $('pop-texto').innerHTML = '<span class="girando" aria-hidden="true"></span>' + esc(texto);
    $('popup').querySelector('.pop-acoes').hidden = true;
    $('popup').hidden = false;
  }
  // fecha so se o popup ainda e o "carregando" (sem botoes e sem pergunta esperando resposta)
  function fecharCarregando() {
    const emCarregando = $('popup').querySelector('.pop-acoes').hidden;
    if (!popResolver && emCarregando) $('popup').hidden = true;
  }
  function fecharPopup(resposta) {
    if (!popResolver) return;
    const r = popResolver;
    popResolver = null;
    $('popup').hidden = true;
    r(resposta);
    focarBipe();
  }
  $('pop-sim').addEventListener('click', () => fecharPopup(true));
  $('pop-nao').addEventListener('click', () => fecharPopup(false));
  $('popup').addEventListener('click', (e) => { if (e.target === $('popup')) fecharPopup(false); });
  document.addEventListener('keydown', (e) => {
    if ($('popup').hidden) return;
    if (e.key === 'Escape') { e.preventDefault(); fecharPopup(false); }
  });

  /* ---------- teclado virtual ---------- */
  let tec = null; // { valor, decimal, max, ok }
  function abrirTeclado(opc) {
    // tira o foco do campo de bipe/numero: o que for teclado vai para o teclado virtual, nao para o campo de tras
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    tec = Object.assign({ valor: '', decimal: false, max: 12 }, opc);
    $('tec-titulo').textContent = opc.titulo;
    $('tec-virgula').disabled = !tec.decimal;
    $('tec-virgula').style.visibility = tec.decimal ? '' : 'hidden';
    desenharVisor();
    $('teclado').hidden = false;
    $('tec-ok').focus();
  }
  // cancelado: avisa quem abriu (pedirTeclado devolve null e a leitura nao acontece)
  function fecharTeclado(cancelado) {
    const t = tec;
    $('teclado').hidden = true; tec = null;
    if (cancelado && t && t.aoCancelar) t.aoCancelar();
    focarBipe();
  }
  // teclado como Promise: o valor digitado, ou null se cancelar
  const pedirTeclado = (opc) => new Promise((ok) => abrirTeclado(Object.assign({}, opc, { ok, aoCancelar: () => ok(null) })));
  function desenharVisor() {
    const v = $('tec-visor');
    v.textContent = tec.valor || tec.dica || 'Digite';
    v.classList.toggle('vazio-v', !tec.valor);
  }
  function teclar(t) {
    if (!tec) return;
    if (t === 'apagar') tec.valor = tec.valor.slice(0, -1);
    else if (t === ',') { if (tec.decimal && !tec.valor.includes(',')) tec.valor = (tec.valor || '0') + ','; }
    else if (/^\d$/.test(t) && tec.valor.replace(',', '').length < tec.max) tec.valor = (tec.valor === '0' ? '' : tec.valor) + t;
    desenharVisor();
  }
  $('tec-grade').addEventListener('click', (e) => { const b = e.target.closest('[data-t]'); if (b) teclar(b.dataset.t); });
  $('tec-cancelar').addEventListener('click', () => fecharTeclado(true));
  $('tec-ok').addEventListener('click', () => {
    if (!tec) return;
    const v = tec.valor, ok = tec.ok;
    if (!v) { vibrar(80); return; }
    fecharTeclado();
    ok(v);
  });
  $('teclado').addEventListener('click', (e) => { if (e.target === $('teclado')) fecharTeclado(true); });
  document.addEventListener('keydown', (e) => {
    if (!tec) return;
    if (/^\d$/.test(e.key)) teclar(e.key);
    else if (e.key === ',' || e.key === '.') teclar(',');
    else if (e.key === 'Backspace') teclar('apagar');
    else if (e.key === 'Enter') $('tec-ok').click();
    else if (e.key === 'Escape') fecharTeclado(true);
    else return;
    e.preventDefault();
  });

  /* ---------- estado ---------- */
  let doc = null;          // { id_transacao, nr_docto, cliente, itens: [...] }
  let tipo = '';           // 'cega' | 'produto'
  let podeManut = false;    // cadastro do usuario: "Coletor (manutencao)" (dono, 02/11/2026)
  let podeEtiq = false;     // cadastro do usuario: "Coletor (etiquetas)" (dono, 04/11/2026)
  let podeColetor = false;  // cadastro do usuario: "Coletor (conferencia)", com os SQLs prontos (dono, 06/11/2026)
  let podeRastro = false;   // cadastro do usuario: "Coletor (rastro)" (dono, 06/11/2026)
  let etqCfg = { largura: 100, altura: 100, por_linha: 2, exige_lote_produto: true, exige_lote_kit: false }; // padrao (Gestao > Coletor): largura e altura da LINHA de etiquetas, em mm, e quantas por linha
  let tipoPadrao = 'todas'; // parametro da Gestao (02/11/2026): 'todas' (conferente escolhe) | 'produto' | 'cega'
  let conferidos = [];     // leituras gravadas (do banco), sem as que estao sendo excluidas/canceladas
  let confServ = [];       // a ultima lista que veio do servidor, completa
  // exclusoes confirmadas e ainda nao concluidas (dono, 02/11/2026: excluiu 2 itens seguidos e so 1 saiu da tela):
  // ficam fora da tela desde o toque, mesmo que uma resposta do servidor ainda as traga
  // a chave leva o documento ("transacao:id"): a exclusao continua mesmo depois do "Voltar" e, se a nota for aberta de
  // novo antes de terminar, os itens dela continuam fora da tela (dono, 02/11/2026)
  const pendItens = new Set(), pendLeit = new Set();
  const chPend = (id, k) => String(id) + ':' + String(k);
  const docAberto = (id) => !!doc && String(doc.id_transacao) === String(id);
  const semPendentes = (l) => { const id = doc ? doc.id_transacao : ''; return l.filter((c) => !pendItens.has(chPend(id, c.w_id_movitens)) && !pendLeit.has(chPend(id, c.w_id))); };
  const doServidor = (l) => { confServ = l || []; conferidos = semPendentes(confServ); };
  let fila = [];           // leituras ainda nao enviadas
  let enviando = [];       // leituras no envio em andamento
  let qtdDecimal = false;  // Gestao > Coletor: quantidade com virgula permitida? (padrao: so inteiras)
  let exigeLote = false;   // Gestao > Coletor: lote de produto obrigatorio? (codigo sem lote: pede o lote no teclado)
  let exigeLoteKit = false; // Gestao > Coletor: lote de kit obrigatorio? (04/11/2026)
  // chave "Informar quantidade" (guardada neste aparelho): ligada, cada bipe abre o teclado para a quantidade
  try { $('informar-qtd').checked = localStorage.getItem('coletor_informar_qtd') === '1'; } catch (e) { /* ignora */ }
  // "2*codigo" so vale com a chave ligada (dono, 02/11/2026): o texto de ajuda do campo acompanha a chave
  function dicaBipe() {
    const lig = $('informar-qtd').checked;
    $('bipe').placeholder = lig ? 'Bipe a etiqueta (ou 2*código)' : 'Bipe a etiqueta';
    $('bipe').setAttribute('aria-label', lig ? 'Etiqueta do produto; para várias, quantidade, asterisco e código, por exemplo 2*14311' : 'Etiqueta do produto');
  }
  dicaBipe();
  $('informar-qtd').addEventListener('change', () => {
    try { localStorage.setItem('coletor_informar_qtd', $('informar-qtd').checked ? '1' : '0'); } catch (e) { /* ignora */ }
    dicaBipe();
    focarBipe();
  });
  let ultimoItem = null;   // w_id do item lido por ultimo (destaque na lista)
  const ordemToque = new Map(); // w_id do item -> quando foi lido (coleta cega: mais recentes em cima)
  // codigo de cada leitura: vai na OBSERVACAO ("[k3f9a2b1]"); se a pagina recarregar no meio de um envio, a leitura que
  // ja chegou ao banco e reconhecida e sai da fila (nao grava duas vezes)
  const novoId = () => (Date.now().toString(36) + Math.random().toString(36).slice(2, 8)).slice(-12);
  // fila guardada no aparelho por documento: bipes ainda nao gravados nao se perdem se a pagina recarregar
  const chaveFila = (id) => 'coletor_fila_' + id;
  function salvarFila() {
    if (!doc) return;
    try {
      const pend = enviando.concat(fila);
      if (pend.length) localStorage.setItem(chaveFila(doc.id_transacao), JSON.stringify(pend)); else localStorage.removeItem(chaveFila(doc.id_transacao));
    } catch (e) { /* sem armazenamento: so nao guarda */ }
  }
  function recuperarFila(id, conf) {
    let pend = [];
    try { pend = JSON.parse(localStorage.getItem(chaveFila(id)) || '[]'); } catch (e) { /* ignora */ }
    if (!Array.isArray(pend)) pend = [];
    const gravadas = new Set(conf.map((c) => (/\[([a-z0-9]+)\]\s*$/.exec(c.observacao || '') || [])[1]).filter(Boolean));
    return pend.filter((l) => l && l.id && !gravadas.has(l.id));
  }

  // aviso ao servidor de que o conferente esta DENTRO da coleta (dono, 02/11/2026: a Manutencao nao libera a nota
  // enquanto ele coleta). A cada 25 s na tela de coleta; ao sair dela, avisa que saiu.
  let presencaId = null, presencaTimer = null;
  function avisarPresenca(id, ativo) {
    api('/api/coletor/presenca', { id_transacao: id, ativo }).catch(() => { /* proximo aviso tenta de novo */ });
  }
  function presenca(qual) {
    const id = qual === 'coleta' && doc ? doc.id_transacao : null;
    if (presencaId && presencaId !== id) { avisarPresenca(presencaId, false); }
    clearInterval(presencaTimer); presencaTimer = null;
    presencaId = id;
    if (id) { avisarPresenca(id, true); presencaTimer = setInterval(() => avisarPresenca(id, true), 25000); }
  }
  // fechou a pagina/aba na coleta: avisa que saiu (keepalive: o pedido vai mesmo com a pagina fechando)
  window.addEventListener('pagehide', () => {
    if (!presencaId) return;
    try { fetch('/api/coletor/presenca', { method: 'POST', keepalive: true, headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify({ id_transacao: presencaId, ativo: false }) }); } catch (e) { /* ignora */ }
  });
  // voltou para a pagina (cache do navegador) ainda na coleta: avisa de novo que esta dentro
  window.addEventListener('pageshow', (e) => { if (e.persisted && presencaId) avisarPresenca(presencaId, true); });
  function mostrarEtapa(qual) {
    presenca(qual);
    for (const e of ['doc', 'tipo', 'coleta', 'manut', 'etiq', 'rastro']) $('etapa-' + e).hidden = e !== qual;
    // tela inicial (dono, 06/11/2026): so os baloes, na ordem Manutencao, Gerar etiqueta e Coletor
    $('manut-bloco').hidden = !(qual === 'inicio' && podeManut);
    $('etq-bloco').hidden = !(qual === 'inicio' && podeEtiq);
    $('col-bloco').hidden = !(qual === 'inicio' && podeColetor);
    $('rastro-bloco').hidden = !(qual === 'inicio' && podeRastro);
    $('iniciadas-bloco').hidden = true;
    $('pendentes-bloco').hidden = true;
    if (qual === 'doc') { $('doc-q').value = ''; $('doc-q').focus(); carregarIniciadas(); carregarPendentes(); }
    if (qual === 'coleta') focarBipe();
  }
  function cabecalho(d) {
    return '<div class="nf">NF ' + esc(d.nr_docto) + ' <span class="selo">' + esc(d.especie || '') + '</span></div>' +
      '<div class="det">' + esc(d.dt_emissao || '') + ' · Empresa ' + esc(d.empresa || '') + (d.itens ? ' · ' + d.itens.length + (d.itens.length === 1 ? ' item' : ' itens') : '') + '</div>' +
      '<div class="det">Cliente: ' + esc(d.cliente.codigo) + ' - ' + esc(d.cliente.fantasia || d.cliente.nome) + '</div>' +
      (d.transportadora && d.transportadora.nome ? '<div class="det">Transportadora: ' + esc(d.transportadora.nome) + '</div>' : '');
  }

