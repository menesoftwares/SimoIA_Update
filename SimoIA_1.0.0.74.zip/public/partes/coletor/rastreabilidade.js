/*@parte Coletor: rastreabilidade. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- rastreabilidade (dono, 06/11/2026): so pesquisa com produto e lote preenchidos ---------- */
  let rastroPedido = 0;
  let rastroUlt = null; // ultima pesquisa com resultado: Imprimir e Compartilhar usam esta, mesmo com os campos ja alterados
  const rastroQtd = (l) => fmtQtd(l.quantidade) + (l.unidade ? ' ' + l.unidade : ''); // quantidade com a unidade do item
  const rastroAcoes = () => {
    const tem = !!(rastroUlt && rastroUlt.linhas.length);
    $('rastro-imprimir').disabled = !tem;
    $('rastro-comp-abrir').disabled = !tem;
    if (!tem) rastroFecharMenu();
  };
  const rastroBotao = () => { $('rastro-pesquisar').disabled = !($('rastro-produto').value.trim() && $('rastro-lote').value.trim()); };
  // produto ao digitar (dono, 14/11/2026): lista de produtos da etiqueta; o lote e digitado (sem carregar os lotes do item)
  let rastroProdutos = null;   // lista lida do servidor (uma vez por abertura do Coletor)
  let rastroProdCarregando = null;
  let rastroProd = null;       // produto escolhido na lista: { codigo, descricao }
  const rastroCodigo = () => rastroProd ? rastroProd.codigo : $('rastro-produto').value.trim();
  async function rastroCarregarProdutos() {
    if (rastroProdutos) return rastroProdutos;
    if (!rastroProdCarregando) {
      rastroProdCarregando = (async () => {
        let d;
        try { d = await api('/api/coletor/rastreabilidade/produtos'); }
        catch (e) { d = { ok: false, mensagem: e.message === 'sessao' ? '' : 'Não foi possível falar com o servidor.' }; }
        rastroProdCarregando = null;
        if (!d.ok) { if (d.mensagem && !$('etapa-rastro').hidden) mensagem($('rastro-msg'), d.mensagem, 'erro'); return null; }
        rastroProdutos = d.produtos || [];
        return rastroProdutos;
      })();
    }
    return rastroProdCarregando;
  }
  function rastroBuscarProduto() {
    const bruto = $('rastro-produto').value, q = etqSemAc(bruto.trim());
    const tudo = /^\s{3,}$/.test(bruto); // 3 espacos: todos, como na etiqueta e no Simulador
    const lista = rastroProdutos;
    if (!q && !tudo) { $('rastro-prod-lista').innerHTML = ''; return; }
    if (!lista) {
      $('rastro-prod-lista').innerHTML = '<p class="nota">Carregando os produtos…</p>';
      rastroCarregarProdutos().then((l) => { if (l && !$('etapa-rastro').hidden && !rastroProd && $('rastro-produto').value === bruto) rastroBuscarProduto(); else if (!l) $('rastro-prod-lista').innerHTML = ''; });
      return;
    }
    const achados = tudo ? [...lista].sort((a, b) => a.descricao.localeCompare(b.descricao, 'pt-BR'))
      : lista.filter((p) => etqSemAc(p.codigo + ' ' + p.descricao).includes(q))
        .sort((a, b) => (etqSemAc(b.codigo) === q) - (etqSemAc(a.codigo) === q) || (etqSemAc(b.codigo).startsWith(q)) - (etqSemAc(a.codigo).startsWith(q)));
    const mostrar = tudo ? achados : achados.slice(0, 30);
    $('rastro-prod-lista').innerHTML = mostrar.map((p, i) => '<button type="button" class="btn-sec" data-rastro-prod="' + i + '">' + esc(p.codigo + (p.descricao ? ' - ' + p.descricao : '')) + '</button>').join('') +
      (achados.length ? (mostrar.length < achados.length ? '<p class="nota">Mostrando 30 de ' + achados.length + '. Digite mais para filtrar.</p>' : '') : '<p class="nota">Nenhum produto encontrado na lista. Pode pesquisar pelo código digitado.</p>');
    $('rastro-prod-lista').rastroAchados = mostrar;
  }
  function rastroEscolherProduto(p) {
    rastroProd = p;
    $('rastro-produto').value = p.codigo + (p.descricao ? ' - ' + p.descricao : '');
    $('rastro-prod-lista').innerHTML = '';
    rastroBotao();
    $('rastro-lote').focus();
  }
  // codigo digitado igual ao de um produto da lista (ex.: leitor): escolhe sozinho ao sair do campo
  function rastroProdutoDigitado() {
    if (rastroProd || !rastroProdutos) return;
    const q = $('rastro-produto').value.trim().toUpperCase();
    const p = q && rastroProdutos.find((x) => x.codigo.toUpperCase() === q);
    if (p) rastroEscolherProduto(p);
  }
  function rastroAbrir() {
    rastroPedido++;
    rastroCarregarProdutos(); // ja deixa a lista pronta para quando digitar
    rastroUlt = null;
    rastroAcoes();
    $('rastro-result').hidden = true;
    mensagem($('rastro-msg'), '', 'info');
    rastroBotao();
    mostrarEtapa('rastro');
    irAoTopo();
  }
  $('rastro-abrir').addEventListener('click', rastroAbrir);
  $('rastro-voltar').addEventListener('click', () => mostrarEtapa('inicio'));
  $('rastro-produto').addEventListener('input', () => {
    rastroProd = null;
    rastroBuscarProduto();
    rastroBotao();
  });
  $('rastro-produto').addEventListener('change', rastroProdutoDigitado);
  $('rastro-lote').addEventListener('input', rastroBotao);
  $('rastro-prod-lista').addEventListener('click', (e) => {
    const b = e.target.closest('[data-rastro-prod]');
    if (b) rastroEscolherProduto($('rastro-prod-lista').rastroAchados[Number(b.dataset.rastroProd)]);
  });

  $('rastro-filtro').addEventListener('submit', async (e) => {
    e.preventDefault();
    const produto = rastroCodigo(), lote = $('rastro-lote').value.trim();
    if (!produto || !lote) return;
    $('rastro-prod-lista').innerHTML = '';
    const pedido = ++rastroPedido;
    $('rastro-pesquisar').disabled = true;
    $('rastro-result').hidden = true;
    rastroUlt = null;
    rastroAcoes();
    mensagem($('rastro-msg'), 'Pesquisando…', 'info');
    try {
      const d = await api('/api/coletor/rastreabilidade?' + new URLSearchParams({ produto, lote }));
      if (pedido !== rastroPedido || $('etapa-rastro').hidden) return;
      if (!d.ok) { mensagem($('rastro-msg'), d.mensagem || 'Não foi possível pesquisar.', 'erro'); return; }
      mensagem($('rastro-msg'), '', 'info');
      const linhas = d.linhas || [];
      $('rastro-n').textContent = '(' + linhas.length + ')';
      $('rastro-nota').textContent = !linhas.length ? 'Nenhuma conferência finalizada deste produto com este lote.' : d.limite ? 'Mostrando só as primeiras ' + linhas.length + '.' : '';
      $('rastro-nota').hidden = !$('rastro-nota').textContent;
      $('rastro-tab').hidden = !linhas.length;
      $('rastro-cab').textContent = d.titulo || '';
      // celular: cidade e estado embaixo da pessoa, para continuar uma nota por linha
      $('rastro-linhas').innerHTML = linhas.map((l) => '<tr><td>' + esc(l.nr_docto) + '</td><td>' + esc(l.pessoa) + '<span class="so-cel">' + esc([l.cidade, l.uf].filter(Boolean).join(' - ')) + '</span></td><td class="col-local">' + esc(l.cidade) + '</td><td class="col-local">' + esc(l.uf) + '</td><td class="num">' + esc(rastroQtd(l)) + '</td></tr>').join('');
      $('rastro-result').hidden = false;
      rastroUlt = { produto, lote, titulo: d.titulo || '', limite: !!d.limite, linhas };
      rastroAcoes();
    } catch (x) {
      if (x.message !== 'sessao' && pedido === rastroPedido) mensagem($('rastro-msg'), 'Não foi possível falar com o servidor.', 'erro');
    } finally { if (pedido === rastroPedido) rastroBotao(); }
  });
  // Imprimir (dono, 06/11/2026): o relatorio da ultima pesquisa, em A4
  function rastroFimImpressao() {
    document.body.classList.remove('rastro-imprimindo');
    const st = $('rastro-pagina');
    if (st) st.remove();
    $('rastro-impressao').innerHTML = '';
  }
  window.addEventListener('afterprint', rastroFimImpressao);
  $('rastro-imprimir').addEventListener('click', () => {
    if (!rastroUlt) return;
    const agora = new Date();
    $('rastro-impressao').innerHTML = '<h1>Rastreabilidade</h1><p class="sub">__NOME_SISTEMA__</p><p class="titulo">' + esc(rastroUlt.titulo) + '</p>' +
      '<table><thead><tr><th>Número do Docto</th><th>Pessoa</th><th>Cidade</th><th>Estado</th><th class="num">Quantidade</th></tr></thead><tbody>' +
      rastroUlt.linhas.map((l) => '<tr><td>' + esc(l.nr_docto) + '</td><td>' + esc(l.pessoa) + '</td><td>' + esc(l.cidade) + '</td><td>' + esc(l.uf) + '</td><td class="num">' + esc(rastroQtd(l)) + '</td></tr>').join('') + '</tbody></table>' +
      (rastroUlt.limite ? '<p class="rodape">Mostrando só as primeiras ' + rastroUlt.linhas.length + ' notas.</p>' : '') +
      '<p class="rodape">Relatório gerado pelo __NOME_SISTEMA__ em ' + esc(agora.toLocaleDateString('pt-BR') + ' às ' + agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })) + '.</p>';
    const st = document.createElement('style');
    st.id = 'rastro-pagina';
    st.textContent = '@media print { @page { size: A4; margin: 12mm 11mm 14mm; } }';
    document.head.appendChild(st);
    document.body.classList.add('rastro-imprimindo');
    window.print();
  });
  /* Compartilhar (dono, 06/11/2026): mesmo metodo do Simulador. Permissoes pode_email / pode_whats do cadastro; o servidor gera o PDF;
   * onde o aparelho compartilha arquivos, "Enviar com anexo" abre o compartilhamento; senao, "Baixar PDF" para anexar. O envio e um
   * segundo clique: o navegador so abre o compartilhamento logo apos um clique. Cada envio fica no historico (/api/registro). */
  let rastroCanal = '', rastroArq = null;
  function rastroFecharMenu() { $('rastro-comp-menu').hidden = true; $('rastro-comp-abrir').setAttribute('aria-expanded', 'false'); }
  $('rastro-comp-abrir').addEventListener('click', () => {
    if (!rastroUlt) return;
    const abrir = $('rastro-comp-menu').hidden;
    $('rastro-comp-menu').hidden = !abrir;
    $('rastro-comp-abrir').setAttribute('aria-expanded', String(abrir));
    if (abrir) $('rastro-comp-menu').querySelector('button:not([hidden])').focus();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#rastro-comp')) rastroFecharMenu(); });
  const rastroPdfFechar = () => { $('rastro-pdf').hidden = true; $('rastro-comp-abrir').focus(); };
  const rastroRegistrar = (extra) => api('/api/registro', Object.assign({ origem: rastroCanal, texto: 'Rastreabilidade: ' + rastroUlt.titulo + ' (PDF)', mensagem: '' }, extra)).catch(() => { /* so o historico */ });
  const rastroNomePdf = () => {
    const d = new Date(), p2 = (n) => String(n).padStart(2, '0'), limpo = (s) => String(s).replace(/[^A-Za-z0-9_-]+/g, '-').slice(0, 30);
    return 'rastreabilidade-' + limpo(rastroUlt.produto) + '-' + limpo(rastroUlt.lote) + '-' + p2(d.getDate()) + p2(d.getMonth() + 1) + d.getFullYear() + '-' + p2(d.getHours()) + p2(d.getMinutes()) + '.pdf';
  };
  async function rastroGerarPdf(canal) {
    if (!rastroUlt) return;
    rastroFecharMenu();
    rastroCanal = canal; rastroArq = null;
    $('rastro-pdf-titulo').textContent = 'Enviar relatório em PDF por ' + (canal === 'email' ? 'e-mail' : 'WhatsApp');
    $('rastro-pdf-texto').innerHTML = '<span class="girando" aria-hidden="true"></span>Gerando o PDF…';
    $('rastro-pdf-botoes').hidden = true;
    $('rastro-pdf').hidden = false;
    try {
      const r = await fetch('/api/coletor/rastreabilidade/pdf', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify({ produto: rastroUlt.produto, lote: rastroUlt.lote }) });
      if (r.status === 401) { location.href = '/'; return; }
      if (!(r.headers.get('Content-Type') || '').includes('application/pdf')) {
        let d = {}; try { d = await r.json(); } catch (e) { /* sem corpo */ }
        throw new Error(d.mensagem || 'Não foi possível gerar o PDF agora.');
      }
      rastroArq = new File([await r.blob()], rastroNomePdf(), { type: 'application/pdf' });
    } catch (e) {
      rastroPdfFechar();
      mensagem($('rastro-msg'), e.message || 'Não foi possível gerar o PDF agora.', 'erro');
      return;
    }
    const podeAnexar = !!(window.isSecureContext && navigator.share && navigator.canShare && navigator.canShare({ files: [rastroArq] }));
    const app = canal === 'email' ? 'o e-mail' : 'o WhatsApp';
    $('rastro-pdf-texto').textContent = podeAnexar ? 'PDF pronto. Toque em "Enviar com anexo" e escolha ' + app + ': o PDF vai anexado.'
      : 'PDF pronto. Este aparelho não envia arquivos direto: toque em "Baixar PDF" e anexe o arquivo ' + (canal === 'email' ? 'no e-mail' : 'no WhatsApp') + '.';
    $('rastro-pdf-enviar').textContent = 'Enviar com anexo';
    delete $('rastro-pdf-enviar').dataset.soPdf;
    $('rastro-pdf-enviar').hidden = !podeAnexar;
    $('rastro-pdf-baixar').className = podeAnexar ? 'btn-sec' : 'btn';
    $('rastro-pdf-botoes').hidden = false;
    (podeAnexar ? $('rastro-pdf-enviar') : $('rastro-pdf-baixar')).focus();
  }
  $('rastro-comp-email').addEventListener('click', () => rastroGerarPdf('email'));
  $('rastro-comp-whats').addEventListener('click', () => rastroGerarPdf('whatsapp'));
  $('rastro-pdf-enviar').addEventListener('click', () => {
    if (!rastroArq) return;
    const comTexto = !$('rastro-pdf-enviar').dataset.soPdf;
    const dados = { files: [rastroArq], title: 'Rastreabilidade' };
    if (comTexto) dados.text = 'Segue o relatório de rastreabilidade em PDF.';
    let p;
    try { p = navigator.share(dados); } catch (e) { p = Promise.reject(e); }
    p.then(() => {
      rastroRegistrar();
      rastroPdfFechar();
      mensagem($('rastro-msg'), 'PDF enviado com anexo.', 'ok');
    }).catch((e) => {
      const nome = (e && e.name) || 'erro';
      if (nome === 'AbortError') return; // fechou a janela de compartilhamento sem escolher
      rastroRegistrar({ erro: nome + ': ' + ((e && e.message) || '') + (comTexto ? '' : ' | só o PDF') });
      if (comTexto) {
        $('rastro-pdf-texto').textContent = 'O aparelho recusou o envio com texto e anexo (' + nome + '). Toque em "Enviar só o PDF", ou em "Baixar PDF" para anexar.';
        $('rastro-pdf-enviar').textContent = 'Enviar só o PDF';
        $('rastro-pdf-enviar').dataset.soPdf = '1';
      } else $('rastro-pdf-texto').textContent = 'Não foi possível abrir o compartilhamento (' + nome + '): toque em "Baixar PDF" para anexar.';
    });
  });
  $('rastro-pdf-baixar').addEventListener('click', () => {
    if (!rastroArq) return;
    const url = URL.createObjectURL(rastroArq);
    const a = document.createElement('a');
    a.href = url; a.download = rastroArq.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    rastroRegistrar();
    mensagem($('rastro-msg'), 'PDF baixado (' + rastroArq.name + ').', 'ok');
  });
  $('rastro-pdf-fechar').addEventListener('click', rastroPdfFechar);
  $('manut-voltar').addEventListener('click', () => mostrarEtapa('inicio'));

