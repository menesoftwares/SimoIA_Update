/*@parte Coletor: coleta (leitura dos bipes). Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- 3) coleta ---------- */
  function iniciarColeta() {
    $('col-nf').textContent = 'NF ' + doc.nr_docto;
    $('col-cli').textContent = doc.cliente.fantasia || doc.cliente.nome || '';
    $('col-transp').textContent = doc.transportadora && doc.transportadora.nome ? 'Transp.: ' + doc.transportadora.nome : '';
    $('col-tipo').textContent = tipo === 'cega' ? 'Coleta cega' : 'Por produto';
    $('lista-titulo').textContent = tipo === 'cega' ? 'Itens lidos' : 'Itens da nota';
    // por produto: o bipe e os botoes vao para dentro do cartao do item atual; na cega ficam no topo
    $('atual').hidden = tipo !== 'produto';
    (tipo === 'produto' ? $('atual-casa') : $('topo-casa')).appendChild($('controles'));
    $('manual').textContent = 'Teclado'; // nas duas coletas (dono, 02/11/2026; antes "Digitar quantidade" / "Item manual")
    mensagem($('retorno'), '', 'info');
    for (const c of conferidos) if (!ordemToque.has(c.w_id_movitens)) ordemToque.set(c.w_id_movitens, -Number(c.w_id || 0));
    if (fila.length) mensagem($('retorno'), fila.length + (fila.length === 1 ? ' leitura deste aparelho ainda não tinha sido gravada; gravando agora.' : ' leituras deste aparelho ainda não tinham sido gravadas; gravando agora.'), 'info');
    desenhar();
    mostrarEtapa('coleta');
    enviar();
  }
  function focarBipe() { if (!$('etapa-coleta').hidden && !tec && $('popup').hidden) setTimeout(() => { if ($('popup').hidden && !tec) $('bipe').focus({ preventScroll: true }); }, 30); }
  const itemDoCodigo = (cod) => doc.itens.find((i) => i.cod_item === cod || i.cod_comercial_item === cod);
  // virgula: permitida na Gestao e o item sem QTD_MULTIPLA inteira (zero permite; dono, 06/11/2026). O servidor confere de novo.
  const virgulaOk = (item) => qtdDecimal && !(item && item.qtd_inteira);
  const msgSoInteira = (item) => 'O produto ' + item.cod_item + ' só aceita quantidade inteira.';
  const num = (v) => Number(String(v).replace(',', '.')) || 0;
  const arred = (n) => Math.round(n * 1000) / 1000;
  // total por item: gravadas + as que ainda estao na fila deste aparelho
  function somas() {
    const s = new Map();
    for (const c of conferidos) s.set(String(c.w_id_movitens), (s.get(String(c.w_id_movitens)) || 0) + num(c.qtd_conferida));
    for (const l of enviando.concat(fila)) s.set(String(l.w_id), (s.get(String(l.w_id)) || 0) + num(l.qtd));
    return s;
  }
  // itens que faltam (conferido menor que a quantidade da nota), na ordem da nota; o 1o e o item atual da coleta por produto
  const faltando = (s) => doc.itens.filter((i) => i.quantidade > 0 && arred(s.get(String(i.w_id)) || 0) < i.quantidade);

  // etiqueta com VARIOS itens (dono, 31/10/2026): "cod_item:14311|num_lote:123|cod_item:14311|num_lote:123" — cada
  // codigo (cod_item ou cod_produto) abre um item e o lote seguinte e dele; so numeros = codigo do produto (mesma regra do servidor)
  function lerEtiquetas(texto) {
    const s = String(texto || '').trim(), itens = [];
    for (const p of s.split('|')) {
      const m = /^\s*([A-Za-z_]+)\s*[:=]\s*(.*?)\s*$/.exec(p);
      if (!m) continue;
      const k = m[1].toLowerCase();
      if (k === 'cod_produto' || k === 'cod_item') itens.push({ cod: m[2].trim(), lote: '', qtd: '' });
      else if (k === 'num_lote' && itens.length) itens[itens.length - 1].lote = m[2].trim();
      // quantidade na etiqueta (dono, 02/11/2026): "cod_item:4555|num_lote:123|qtde:2"; sem qtde = 1 (ou o teclado)
      else if ((k === 'qtde' || k === 'qtd' || k === 'quantidade') && itens.length) itens[itens.length - 1].qtd = m[2].trim();
    }
    if (!itens.length && /^[A-Za-z0-9.-]{1,25}$/.test(s)) itens.push({ cod: s, lote: '', qtd: '' });
    return itens;
  }
  const erroLeitura = (m) => { mensagem($('retorno'), m, 'erro'); vibrar([200, 80, 200]); };

  // registra as leituras de uma etiqueta (um ou varios itens), todas ou nenhuma. Regras do dono (31/10/2026): o produto
  // faz parte da nota; nunca a mais que a nota; por produto, so o item atual (termina um para ir ao proximo).
  function registrarVarios(ents, qtdGeral, digitado, textoOriginal) {
    const s = somas(), aceitos = [];
    // etiqueta com varios itens (dono, 02/11/2026): por produto, vale em qualquer ordem, desde que tenha o item atual
    const atual0 = tipo === 'produto' ? faltando(s)[0] : null;
    if (tipo === 'produto' && ents.length > 1) {
      if (!atual0) return erroLeitura('Todos os itens já foram conferidos. Finalize a coleta.');
      if (!ents.some((en) => { const it = itemDoCodigo(en.cod); return it && it.w_id === atual0.w_id; })) {
        return erroLeitura('A etiqueta não tem o item atual (' + atual0.cod_item + '). Termine o ' + atual0.cod_item + ' primeiro. Nenhum item desta etiqueta foi lido.');
      }
    }
    const grupo = ents.length > 1 ? novoId() : '';
    const qtdDe = (en) => en.qtdFinal || qtdGeral; // qtde da etiqueta (ja multiplicada pelo "2*") ou a quantidade geral
    for (const en of ents) {
      const qtd = qtdDe(en);
      const item = en.cod && itemDoCodigo(en.cod);
      if (!item) return erroLeitura('Produto ' + en.cod + ' não faz parte desta nota.' + (ents.length > 1 ? ' Nenhum item desta etiqueta foi lido.' : ''));
      const ja = s.get(String(item.w_id)) || 0;
      if (tipo === 'produto' && ents.length === 1) {
        const atual = faltando(s)[0];
        if (!atual) return erroLeitura('Todos os itens já foram conferidos. Finalize a coleta.');
        if (atual.w_id !== item.w_id) return erroLeitura('Produto ' + item.cod_item + ' não é o item atual. Termine o ' + atual.cod_item + ' primeiro.');
      }
      if (!virgulaOk(item) && !Number.isInteger(num(qtd))) return erroLeitura(msgSoInteira(item) + (ents.length > 1 ? ' Nenhum item desta etiqueta foi lido.' : ''));
      if (item.quantidade > 0 && arred(ja + num(qtd)) > item.quantidade) {
        return erroLeitura('Quantidade a mais: a nota tem ' + fmtQtd(item.quantidade) + ' ' + item.unidade + ' de ' + item.cod_item + ' e já foram conferidos ' + fmtQtd(ja) + '.' +
          (ents.length > 1 ? ' Nenhum item desta etiqueta foi lido.' : ''));
      }
      s.set(String(item.w_id), ja + num(qtd));
      aceitos.push({ en, item });
    }
    aceitos.forEach(({ en, item }, n) => {
      // cada item vira uma leitura; com varios itens, o texto gravado e o pedaco da etiqueta daquele item
      const texto = ents.length > 1 ? 'cod_item:' + en.cod + (en.lote ? '|num_lote:' + en.lote : '') + (en.qtd ? '|qtde:' + en.qtd : '') : textoOriginal;
      fila.push({ id: novoId(), texto, qtd: qtdDe(en), digitado: !!digitado, w_id: item.w_id, lote: en.lote, grupo });
      ultimoItem = item.w_id;
      ordemToque.set(item.w_id, Date.now() + n); // coleta cega: o ultimo lido fica em cima
    });
    salvarFila();
    const ult = aceitos[aceitos.length - 1];
    let msg = aceitos.length > 1 ? '✓ ' + aceitos.length + ' itens lidos: ' + aceitos.map((a) => a.item.cod_item + (a.en.lote ? ' (lote ' + a.en.lote + ')' : '') + ' +' + fmtQtd(num(qtdDe(a.en)))).join(', ')
      : '✓ ' + ult.item.cod_item + (ult.item.descricao ? ' ' + ult.item.descricao : '') + (ult.en.lote ? ' · lote ' + ult.en.lote : '') + ' · +' + fmtQtd(num(qtdDe(ult.en)));
    if (tipo === 'produto' && arred(s.get(String(ult.item.w_id)) || 0) >= ult.item.quantidade) {
      const prox = faltando(somas())[0];
      msg = '✓ Item ' + ult.item.cod_item + ' completo. ' + (prox ? 'Próximo: ' + prox.cod_item + (prox.localizacao ? ' (' + prox.localizacao + ')' : '') + '.' : 'Todos os itens conferidos: finalize a coleta.');
    }
    mensagem($('retorno'), msg, 'ok');
    vibrar(40);
    desenhar();
    enviar();
  }
  // uma entrada (bipe, "2*..." ou digitada): pede o lote (codigo sem QR, se exigido) e a quantidade (chave "Informar
  // quantidade" ou digitacao manual) no teclado virtual; cancelar o teclado desiste da leitura
  async function lerEntrada(texto, opc) {
    opc = opc || {};
    const ehQR = /[:=]/.test(texto);
    const ents = lerEtiquetas(texto);
    if (!ents.length) return erroLeitura('Etiqueta não reconhecida: ' + texto);
    // quantidade da etiqueta (qtde:): numero valido, virgula so se permitida na Gestao
    for (const en of ents) {
      if (!en.qtd) continue;
      if (!/^\d+(?:[.,]\d+)?$/.test(en.qtd) || !(num(en.qtd) > 0)) return erroLeitura('Quantidade inválida na etiqueta do produto ' + en.cod + ': ' + en.qtd + '.');
      if (!qtdDecimal && /[.,]/.test(en.qtd)) return erroLeitura('Quantidade com vírgula não é permitida (etiqueta do produto ' + en.cod + ': ' + en.qtd + ').');
    }
    // checagem antecipada (dono, 02/11/2026): produto fora da nota ou, por produto, diferente do item atual da o erro
    // ja no bipe, antes de abrir o teclado do lote/quantidade — menos toques, o fluxo nao para
    for (const en of ents) {
      if (!itemDoCodigo(en.cod)) return erroLeitura('Produto ' + en.cod + ' não faz parte desta nota.' + (ents.length > 1 ? ' Nenhum item desta etiqueta foi lido.' : ''));
      // quantidade ja informada (etiqueta ou "2*"): item que so aceita inteira da o erro antes de pedir o lote
      const qInf = en.qtd || opc.qtd;
      if (qInf != null && !virgulaOk(itemDoCodigo(en.cod)) && !Number.isInteger(num(qInf))) return erroLeitura(msgSoInteira(itemDoCodigo(en.cod)) + (ents.length > 1 ? ' Nenhum item desta etiqueta foi lido.' : ''));
    }
    if (tipo === 'produto') {
      const atual = faltando(somas())[0];
      if (!atual) return erroLeitura('Todos os itens já foram conferidos. Finalize a coleta.');
      // etiqueta com varios itens: qualquer ordem, desde que tenha o item atual (dono, 02/11/2026)
      if (ents.length > 1) {
        if (!ents.some((en) => itemDoCodigo(en.cod).w_id === atual.w_id)) return erroLeitura('A etiqueta não tem o item atual (' + atual.cod_item + '). Termine o ' + atual.cod_item + ' primeiro. Nenhum item desta etiqueta foi lido.');
      } else {
        const prim = itemDoCodigo(ents[0].cod);
        if (prim.w_id !== atual.w_id) return erroLeitura('Produto ' + prim.cod_item + ' não é o item atual. Termine o ' + atual.cod_item + ' primeiro.');
      }
    }
    // kit (dono, 04/11/2026): a linha da nota e kit ou a etiqueta tem varios itens (o kit nao costuma vir na nota, so os componentes)
    const leituraDeKit = (lista) => lista.length > 1 || lista.some((en) => { const it = itemDoCodigo(en.cod); return !!(it && it.eh_kit); });
    if (leituraDeKit(ents) ? exigeLoteKit : exigeLote) {
      if (!ehQR) {
        const lote = await pedirTeclado({ titulo: 'Lote do produto ' + ents[0].cod, max: 20, dica: 'Número do lote' });
        if (lote == null) return;
        ents[0].lote = lote;
      } else if (ents.length === 1 && !ents[0].lote) {
        // QR so com o item (ex.: "cod_item:4555"), sem lote: pede o lote no teclado, como no codigo digitado (dono, 02/11/2026)
        const lote = await pedirTeclado({ titulo: 'Lote do produto ' + ents[0].cod, max: 20, dica: 'Número do lote' });
        if (lote == null) return;
        ents[0].lote = lote;
      } else {
        const sem = ents.find((x) => !x.lote);
        if (sem) return erroLeitura('A etiqueta do produto ' + sem.cod + ' está sem lote (lote obrigatório na conferência).');
      }
    }
    // etiqueta com qtde: vale a quantidade dela, sem perguntar ("2*" na frente = 2 etiquetas: multiplica)
    if (ents.some((en) => en.qtd)) {
      const vezes = opc.qtd != null ? num(opc.qtd) : 1;
      for (const en of ents) if (en.qtd) en.qtdFinal = String(arred(num(en.qtd) * vezes)).replace('.', ',');
      if (ents.every((en) => en.qtd)) return registrarVarios(ents, '1', opc.digitado, texto);
    }
    let qtd = opc.qtd;
    if (qtd == null) {
      if (opc.pedirQtd || $('informar-qtd').checked) {
        qtd = await pedirTeclado({ titulo: 'Quantidade' + (ents.length === 1 ? ' de ' + ents[0].cod : ' de cada um dos ' + ents.length + ' itens'), decimal: ents.every((en) => virgulaOk(itemDoCodigo(en.cod))), max: 9, dica: 'Quantidade' });
        if (qtd == null) return;
        if (!(num(qtd) > 0)) return erroLeitura('Quantidade inválida.');
      } else qtd = '1';
    }
    registrarVarios(ents, qtd, opc.digitado, texto);
  }
