/*@parte Coletor: leitura pela câmera. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- leitura pela camera (dono, 05/11/2026) ----------
   * Parametro "Permitir usar câmera" (Gestao > Coletor). So funciona em https (o navegador nao libera a camera em http).
   * A biblioteca so carrega ao abrir a camera. Nota: QR ou codigo de barras; bipe: so QR. O que for lido entra no campo como um bipe. */
  let camLeitor = null, camSessao = 0, camLib = null;
  const camCarregar = () => camLib || (camLib = new Promise((ok, erro) => {
    const sc = document.createElement('script');
    sc.src = '/html5-qrcode.min.js';
    sc.onload = ok;
    sc.onerror = () => { camLib = null; erro(new Error('biblioteca')); };
    document.head.appendChild(sc);
  }));
  async function camFechar() {
    camSessao++;
    const leitor = camLeitor;
    camLeitor = null;
    $('cam-janela').hidden = true;
    if (leitor) {
      try { await leitor.stop(); } catch (e) { /* ainda nao tinha comecado */ }
      try { leitor.clear(); } catch (e) { /* ignora */ }
    }
  }
  async function camAbrir(alvo) {
    if (!window.isSecureContext || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      await avisar('A câmera só funciona no endereço seguro do sistema (https). Abra o Coletor por ele.', 'Câmera indisponível');
      return;
    }
    const sessao = ++camSessao;
    $('cam-janela').hidden = false;
    let erroAbrir = null;
    try {
      await camCarregar();
      if (sessao !== camSessao) return;
      const F = Html5QrcodeSupportedFormats;
      const leitor = new Html5Qrcode('cam-video', { verbose: false, formatsToSupport: alvo === 'doc-q' ? [F.QR_CODE, F.CODE_128] : [F.QR_CODE], experimentalFeatures: { useBarCodeDetectorIfSupported: true } });
      camLeitor = leitor;
      await leitor.start({ facingMode: 'environment' }, { fps: 10 }, async (texto) => {
        if (sessao !== camSessao) return;
        await camFechar();
        vibrar(60);
        const campo = $(alvo);
        // QR do DANFE pode trazer uma URL: no campo da nota fica so a chave, quando houver
        const chave = alvo === 'doc-q' && /\d{44}/.exec(texto);
        campo.value = chave ? chave[0] : texto;
        campo.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', bubbles: true }));
      }, () => { /* quadro sem codigo: continua tentando */ });
      if (sessao !== camSessao) { try { await leitor.stop(); leitor.clear(); } catch (e) { /* ignora */ } }
    } catch (e) { erroAbrir = e; }
    if (!erroAbrir || sessao !== camSessao) return;
    await camFechar();
    const nome = String(erroAbrir.name || erroAbrir.message || erroAbrir);
    await avisar(/NotAllowed|Permission/i.test(nome) ? 'O acesso à câmera foi negado. Libere a câmera para este site nas permissões do navegador e tente de novo.'
      : erroAbrir.message === 'biblioteca' ? 'Não foi possível carregar a leitura pela câmera. Tente de novo.'
      : 'Não foi possível abrir a câmera deste aparelho.', 'Câmera indisponível');
    focarBipe();
  }
  document.querySelectorAll('.btn-camera').forEach((b) => b.addEventListener('click', () => camAbrir(b.dataset.alvo)));
  $('cam-cancelar').addEventListener('click', () => { camFechar(); focarBipe(); });
  $('bipe').addEventListener('keydown', (e) => {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const t = $('bipe').value.trim();
    $('bipe').value = '';
    if (!t) return;
    // "vezes" (dono, 31/10/2026): "2*14311" ou "3*cod_item:14311|num_lote:1234" = quantidade antes do "*" (digitada
    // no computador); vale para cada item da etiqueta
    const vezes = /^\s*(\d+(?:[.,]\d+)?)\s*\*\s*(\S.*)$/.exec(t);
    if (vezes) {
      // chave "Informar quantidade" desligada: cada leitura vale 1, sem "2*codigo" (dono, 02/11/2026; cega e por produto)
      if (!$('informar-qtd').checked) { erroLeitura('Para informar a quantidade com "*", ligue "Informar quantidade". Com a chave desligada, cada leitura vale 1.'); return; }
      if (!(Number(vezes[1].replace(',', '.')) > 0)) { erroLeitura('Quantidade inválida antes do "*".'); return; }
      if (!qtdDecimal && /[.,]/.test(vezes[1])) { erroLeitura('Quantidade com vírgula não é permitida: use só números inteiros antes do "*".'); return; }
      lerEntrada(vezes[2].trim(), { qtd: vezes[1].replace('.', ','), digitado: true });
    } else lerEntrada(t, {});
  });
  // botao "Teclado" — cega: codigo, lote se exigido, quantidade; por produto: o item atual (lote se exigido;
  // quantidade so com a chave "Informar quantidade" ligada, desligada ja entra 1; dono, 02/11/2026)
  $('manual').addEventListener('click', async () => {
    if (tipo === 'produto') {
      const it = faltando(somas())[0];
      if (!it) { mensagem($('retorno'), 'Todos os itens já foram conferidos. Finalize a coleta.', 'info'); return; }
      lerEntrada(it.cod_item, { pedirQtd: $('informar-qtd').checked, digitado: true });
      return;
    }
    const cod = await pedirTeclado({ titulo: 'Código do produto', max: 25, dica: 'Código' });
    // quantidade so com "Informar quantidade" ligada; desligada ja entra 1 (dono, 02/11/2026: igual a por produto)
    if (cod != null) lerEntrada(cod, { pedirQtd: $('informar-qtd').checked, digitado: true });
  });
  $('lista').addEventListener('click', (e) => {
    const x = e.target.closest('[data-excluir]');
    if (x) excluirItem(x.dataset.excluir);
  });
  // tocar fora dos botoes devolve o foco ao campo de bipe (o leitor "digita" nele)
  $('etapa-coleta').addEventListener('click', (e) => { if (!e.target.closest('button, input, summary, details')) focarBipe(); });

