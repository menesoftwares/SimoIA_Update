/*@parte Coletor: gerar etiqueta. Parte de coletor.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- gerar etiqueta (dono, 04/11/2026) ----------
   * Produtos: SQLs etiqueta_produtos, etiqueta_sub_produto e etiqueta_lotes (Gestao > Coletor). QR no padrao de coleta "cod_item:xxx|num_lote:yyy".
   * Kit: SQL etiqueta_kits, com o lote de cada componente pelo etiqueta_lotes. QR "cod_item:a|num_lote:1|qtde:5|cod_item:b|..."
   * numa linha so (quebra de linha no leitor valeria como Enter). Tudo lido por lerEtiquetas.
   * Tamanho e etiquetas por linha vem da Gestao > Coletor. */
  let etqSoEla = false;    // so "Coletor (etiquetas)": esta tela e a de partida, sem o Voltar para outra
  let etqModo = 'produto'; // 'produto' | 'kit'
  const etqListas = { produto: null, kit: null }; // listas lidas do servidor
  let etqProduto = null;   // produto ou kit escolhido
  let etqPedidoLotes = 0;  // resposta atrasada de outro produto nao vale
  const etqSemAc = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const etqFmt = (n) => String(n).replace('.', ',');
  let etqModuloMm = 0;     // tamanho de cada quadradinho do ultimo QR desenhado
  // opcoes do campo Lote: "numero - validade" na tela; o valor (e o QR) e so o numero
  // exigido (Gestao > Coletor): precisa selecionar; lote unico ja vem escolhido. Nao exigido: pode ficar em "Sem lote"
  const etqExige = () => !!etqCfg[etqModo === 'kit' ? 'exige_lote_kit' : 'exige_lote_produto'];
  let etqLotesProntos = false; // a resposta dos lotes ja chegou
  const etqOpcoesLote = (lotes) => (!etqExige() ? '<option value="">Sem lote</option>' : lotes.length > 1 ? '<option value="">Escolha o lote</option>' : '') +
    lotes.map((l) => '<option value="' + esc(l.lote) + '">' + esc(l.lote + (l.validade ? ' - ' + l.validade : '')) + '</option>').join('');
  // desenha uma etiqueta: medidas em mm. Largura = a da linha dividida pelas etiquetas por linha.
  // Etiqueta baixa e larga (ex.: 50 x 20 mm): QR a esquerda e texto a direita; as demais: QR em cima e texto embaixo.
  function etqSvg(et) {
    const W = etqCfg.largura / etqCfg.por_linha, H = etqCfg.altura;
    const margem = Math.min(W, H) * 0.04, deitada = W >= H * 1.5, nLinhas = et.linhas.length;
    const maiorTexto = Math.max(...et.linhas.map((t) => t.length));
    let lado, xQr, xTexto, largTexto, fonte, yTexto;
    if (deitada) {
      lado = H - 2 * margem;
      xQr = margem;
      xTexto = lado + 2 * margem;
      largTexto = W - lado - 3 * margem;
      fonte = Math.max(Math.min(H * 0.16, largTexto / (maiorTexto * 0.56), lado / (nLinhas * 1.35)), 1.2);
      yTexto = (H - fonte * 1.35 * nLinhas) / 2 + fonte;
    } else {
      largTexto = W - 2 * margem;
      // mais linhas (kit), letra menor: o texto ocupa no maximo cerca de um quarto da altura
      fonte = Math.max(Math.min(H * 0.045, W * 0.052, H * 0.26 / (nLinhas * 1.35)), 1.2);
      lado = Math.max(Math.min(largTexto, H - 2 * margem - fonte * 1.35 * nLinhas), 1);
      xQr = (W - lado) / 2;
      xTexto = W / 2;
      yTexto = margem + lado + fonte;
    }
    qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
    const qr = qrcode(0, 'M');
    qr.addData(et.qr, 'Byte');
    qr.make();
    const n = qr.getModuleCount(), modulo = lado / (n + 8); // 4 modulos de margem em volta (zona de silencio do QR)
    etqModuloMm = modulo;
    let d = '';
    for (let y = 0; y < n; y++) for (let x = 0; x < n; x++) if (qr.isDark(y, x)) d += 'M' + x + ' ' + y + 'h1v1h-1z';
    const texto = (t, y) => {
      const ajuste = t.length * fonte * 0.56 > largTexto ? ' textLength="' + largTexto + '" lengthAdjust="spacingAndGlyphs"' : '';
      return '<text x="' + xTexto + '" y="' + y + '" font-size="' + fonte + '" font-family="Arial, Helvetica, sans-serif" font-weight="700" text-anchor="' + (deitada ? 'start' : 'middle') + '" fill="#000"' + ajuste + '>' + esc(t) + '</text>';
    };
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + W + 'mm" height="' + H + 'mm" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(et.linhas.join(', ')) + '">' +
      '<rect width="' + W + '" height="' + H + '" fill="#fff"/>' +
      '<g transform="translate(' + (xQr + 4 * modulo) + ' ' + (margem + 4 * modulo) + ') scale(' + modulo + ')"><path d="' + d + '" fill="#000" shape-rendering="crispEdges"/></g>' +
      et.linhas.map((t, i) => texto(t, yTexto + fonte * 1.35 * i)).join('') + '</svg>';
  }
  const etqQtd = () => { const n = Number($('etq-qtd').value); return Number.isInteger(n) && n >= 1 && n <= 1000 ? n : 0; };
  // a etiqueta escolhida na tela: { qr, linhas, partes } ou null enquanto falta escolher
  function etqAtual() {
    if (!etqProduto || !etqLotesProntos) return null;
    if (etqModo === 'produto') {
      const lote = $('etq-lote').value;
      if (!lote && etqExige()) return null;
      return { qr: 'cod_item:' + etqProduto.codigo + (lote ? '|num_lote:' + lote : ''),
        linhas: ['Cod. Prod.: ' + etqProduto.codigo].concat(lote ? ['Num. Lote: ' + lote] : []), partes: [etqProduto.codigo, lote] };
    }
    const comps = etqProduto.componentes.map((c, i) => ({ c, lote: ($(`etq-comp-${i}`) || {}).value || '' }));
    if (!comps.length || (etqExige() && comps.some((x) => !x.lote))) return null;
    return { qr: comps.map((x) => 'cod_item:' + x.c.codigo + (x.lote ? '|num_lote:' + x.lote : '') + '|qtde:' + x.c.quantidade + '|').join(''),
      linhas: ['Cod. Kit: ' + etqProduto.codigo].concat(comps.map((x) => x.c.codigo + (x.lote ? ' Lote: ' + x.lote : '') + ' Qtde: ' + x.c.quantidade)),
      partes: comps.flatMap((x) => [x.c.codigo, x.lote, x.c.quantidade]) };
  }
  function etqDesenhar() {
    const et = etqAtual();
    $('etq-previa').innerHTML = '';
    let pronta = false;
    if (et) {
      // "|" separa os campos no padrao de coleta: no codigo ou no lote, a etiqueta seria lida errado
      if (et.partes.some((p) => /[|\r\n]/.test(p))) mensagem($('etq-msg'), 'Este código ou lote tem o caractere "|" e não pode virar etiqueta: seria lido errado na coleta.', 'erro');
      else {
        try {
          $('etq-previa').innerHTML = etqSvg(et);
          pronta = true;
          // abaixo disso, muitos leitores nao conseguem ler (impressora de 203 dpi: 1 ponto = 0,125 mm)
          mensagem($('etq-msg'), etqModuloMm < 0.375 ? 'Atenção: nesse tamanho de etiqueta o QR code fica muito pequeno e pode não ser lido. Teste antes de imprimir em quantidade.' : '', 'info');
        } catch (e) { mensagem($('etq-msg'), 'Não foi possível desenhar o QR code.', 'erro'); }
      }
    }
    $('etq-imprimir').disabled = !pronta || !etqQtd();
  }
  function etqLimparLote(texto) {
    etqPedidoLotes++;
    etqLotesProntos = false;
    $('etq-sub-campo').hidden = true;
    $('etq-sub').innerHTML = '';
    $('etq-comps').innerHTML = '';
    $('etq-lote').innerHTML = '<option value="">' + esc(texto) + '</option>';
    $('etq-lote').disabled = true;
    etqDesenhar();
  }
  function etqBuscar() {
    const q = etqSemAc($('etq-busca').value.trim());
    // 3 espacos (ou mais) no campo = pesquisa geral, como no Simulador (dono, 06/11/2026): todos, em ordem de nome e sem o limite de 30
    const tudo = /^\s{3,}$/.test($('etq-busca').value);
    if (etqProduto) { etqProduto = null; etqLimparLote('Escolha o produto primeiro'); }
    const lista = etqListas[etqModo];
    if (!lista || (!q && !tudo)) { $('etq-lista').innerHTML = ''; return; }
    const achados = tudo ? [...lista].sort((a, b) => a.descricao.localeCompare(b.descricao, 'pt-BR'))
      : lista.filter((p) => etqSemAc(p.codigo + ' ' + p.descricao).includes(q));
    $('etq-lista').innerHTML = (tudo ? achados : achados.slice(0, 30)).map((p, i) => '<button type="button" class="btn-sec" data-etq="' + i + '">' + esc(p.codigo + (p.descricao ? ' - ' + p.descricao : '')) + '</button>').join('') +
      (achados.length ? (!tudo && achados.length > 30 ? '<p class="nota">Mostrando 30 de ' + achados.length + '. Digite mais para filtrar.</p>' : '') : '<p class="nota">' + (etqModo === 'kit' ? 'Nenhum kit encontrado.' : 'Nenhum produto encontrado.') + '</p>');
    $('etq-lista').etqAchados = achados;
  }
  async function etqEscolherProduto(p) {
    etqProduto = p;
    $('etq-busca').value = p.codigo + (p.descricao ? ' - ' + p.descricao : '');
    $('etq-lista').innerHTML = '';
    mensagem($('etq-msg'), '', 'info'); // erro de outro produto nao fica na tela
    etqLimparLote('Carregando os lotes…');
    const pedido = etqPedidoLotes;
    const d = await etqLerLotes(p.codigo, '');
    if (pedido !== etqPedidoLotes) return;
    const subs = d.ok ? d.subprodutos || [] : [];
    if (subs.length < 2) { etqPreencherLotes(d); return; }
    // 2 ou mais subprodutos (dono, 05/11/2026): pergunta qual usar; os lotes so carregam depois da escolha
    $('etq-sub').innerHTML = '<option value="">Escolha o item</option>' +
      subs.map((s) => '<option value="' + esc(s.codigo) + '">' + esc(s.codigo + (s.descricao ? ' - ' + s.descricao : '')) + '</option>').join('');
    $('etq-sub-campo').hidden = false;
    etqEscolherSub();
    $('etq-sub').focus();
  }
  // resposta vazia ou fora do padrao (servidor reiniciando, rede oscilando; dono, 14/11/2026): tenta mais uma vez antes de avisar
  const etqLerLotes = (codigo, sub) => etqLerComRepeticao('/api/coletor/etiquetas/lotes?cod_item=' + encodeURIComponent(codigo) + (sub ? '&sub=' + encodeURIComponent(sub) : ''));
  async function etqLerComRepeticao(url) {
    for (let tentativa = 1; ; tentativa++) {
      let d;
      try { d = await api(url); }
      catch (e) { if (e.message === 'sessao') return { ok: false, mensagem: '' }; d = { ok: false, mensagem: 'Não foi possível falar com o servidor.' }; }
      if (d.ok || (d.mensagem && d.mensagem !== 'Não foi possível falar com o servidor.') || tentativa === 2) return d;
      await new Promise((r) => setTimeout(r, 1500));
    }
  }
  // item sem lote na lista (dono, 14/11/2026): com "Exigir lote ... na etiqueta" ligado (produto ou kit, conforme a tela), o combo
  // oferece o lote de controle do ERP, para a etiqueta poder sair. Sem exigir, fica so o "Sem lote", como antes
  const ETQ_LOTE_CTRL = '_CTRL_LOTE_ATIVADO_APOS_';
  const etqLotesOuCtrl = (lotes) => lotes.length || !etqExige() ? lotes : [{ lote: ETQ_LOTE_CTRL, validade: '' }];
  function etqPreencherLotes(d) {
    const lotes = d.ok ? etqLotesOuCtrl(d.lotes || []) : [];
    if (!lotes.length && etqExige()) {
      etqLotesProntos = false;
      $('etq-lote').innerHTML = '<option value="">' + (d.ok ? 'Nenhum lote' : 'Lotes indisponíveis') + '</option>';
      $('etq-lote').disabled = true;
      etqDesenhar();
      mensagem($('etq-msg'), d.ok ? (etqSubAberto() ? 'Este item' : 'Este produto') + ' não tem lote disponível.' : d.mensagem || 'Não foi possível ler os lotes.', d.ok ? 'info' : 'erro');
      return;
    }
    $('etq-lote').innerHTML = etqOpcoesLote(lotes);
    $('etq-lote').disabled = false;
    etqLotesProntos = true;
    if (d.ok) mensagem($('etq-msg'), '', 'info'); // deu certo: some o erro de uma tentativa anterior
    etqDesenhar();
    if (!d.ok) mensagem($('etq-msg'), d.mensagem || 'Não foi possível ler os lotes.', 'erro');
    $('etq-lote').focus();
  }
  const etqSubAberto = () => !$('etq-sub-campo').hidden;
  // item escolhido: carrega os lotes dele. Sem item e lote nao exigido, a etiqueta pode sair "Sem lote"
  async function etqEscolherSub() {
    const sub = $('etq-sub').value, pedido = ++etqPedidoLotes;
    mensagem($('etq-msg'), '', 'info');
    $('etq-lote').disabled = true;
    if (!sub) {
      etqLotesProntos = !etqExige();
      $('etq-lote').innerHTML = etqLotesProntos ? etqOpcoesLote([]) : '<option value="">Escolha o item primeiro</option>';
      etqDesenhar();
      return;
    }
    etqLotesProntos = false;
    $('etq-lote').innerHTML = '<option value="">Carregando os lotes…</option>';
    etqDesenhar();
    const d = await etqLerLotes(etqProduto.codigo, sub);
    if (pedido === etqPedidoLotes) etqPreencherLotes(d);
  }
  // Kit: abre os componentes (codigo, descricao e quantidade do SQL), cada um com o seu lote
  async function etqEscolherKit(k) {
    etqProduto = k;
    $('etq-busca').value = k.codigo + (k.descricao ? ' - ' + k.descricao : '');
    $('etq-lista').innerHTML = '';
    mensagem($('etq-msg'), '', 'info');
    etqLimparLote('');
    const pedido = etqPedidoLotes;
    $('etq-comps').innerHTML = k.componentes.map((c, i) => '<div class="etq-comp"><strong>' + esc(c.codigo) + '</strong> <span class="det">' + esc(c.descricao) + '</span>' +
      '<div class="det">Quantidade: ' + esc(c.quantidade) + (c.unidade ? ' ' + esc(c.unidade) : '') + '</div>' +
      '<label class="etq-campo">Lote<select id="etq-comp-' + i + '" data-comp disabled><option value="">Carregando os lotes…</option></select></label></div>').join('');
    const d = await etqLerComRepeticao('/api/coletor/etiquetas/lotes-kit?kit=' + encodeURIComponent(k.codigo));
    if (pedido !== etqPedidoLotes) return;
    const semLote = [];
    k.componentes.forEach((c, i) => {
      const sel = $('etq-comp-' + i), lidos = d.ok ? (d.lotes || {})[c.codigo] || [] : [];
      if (!lidos.length) semLote.push(c.codigo);
      const lotes = d.ok ? etqLotesOuCtrl(lidos) : [];
      if (!lotes.length && etqExige()) {
        sel.innerHTML = '<option value="">' + (d.ok ? 'Nenhum lote' : 'Lotes indisponíveis') + '</option>';
        return;
      }
      sel.innerHTML = etqOpcoesLote(lotes);
      sel.disabled = false;
    });
    etqLotesProntos = true;
    if (d.ok) mensagem($('etq-msg'), '', 'info');
    etqDesenhar();
    if (!d.ok) mensagem($('etq-msg'), d.mensagem || 'Não foi possível ler os lotes.', 'erro');
    else if (semLote.length && etqExige()) mensagem($('etq-msg'), (semLote.length === 1 ? 'O componente ' + semLote[0] + ' não tem' : 'Os componentes ' + semLote.join(', ') + ' não têm') + ' lote disponível: o lote fica ' + ETQ_LOTE_CTRL + '.', 'info');
  }
  async function etqAbrirForm(modo) {
    etqModo = modo;
    const kit = modo === 'kit';
    $('etq-busca-rot').textContent = kit ? 'Kit' : 'Produto';
    $('etq-lote-campo').hidden = kit;
    $('etq-opcoes').hidden = true;
    $('etq-form').hidden = false;
    $('etq-voltar').hidden = false;
    etqProduto = null;
    $('etq-busca').value = '';
    $('etq-lista').innerHTML = '';
    $('etq-qtd').value = 1; // quantidade total de etiquetas: nao depende das etiquetas por linha (dono, 04/11/2026)
    $('etq-padrao').textContent = 'Linha de ' + etqFmt(etqCfg.largura) + ' x ' + etqFmt(etqCfg.altura) + ' mm, com ' + etqCfg.por_linha + (etqCfg.por_linha === 1 ? ' etiqueta' : ' etiquetas') + ' de ' + etqFmt(Math.round(etqCfg.largura / etqCfg.por_linha * 10) / 10) + ' x ' + etqFmt(etqCfg.altura) + ' mm.';
    etqLimparLote('Escolha o produto primeiro');
    mensagem($('etq-msg'), '', 'info');
    // campo bloqueado enquanto a lista carrega (dono, 16/11/2026): sem os dados, a pesquisa nao acharia nada
    const busca = $('etq-busca');
    const liberar = (texto) => { busca.disabled = false; busca.placeholder = texto || 'Código ou nome (3 espaços: todos)'; };
    if (etqListas[modo]) { liberar(); busca.focus(); return; }
    const nome = kit ? 'os kits' : 'os produtos';
    busca.disabled = true;
    busca.placeholder = 'Aguarde: carregando ' + nome + '…';
    mensagem($('etq-msg'), 'Carregando ' + nome + '…', 'info');
    let d;
    try { d = await api('/api/coletor/etiquetas/' + (kit ? 'kits' : 'produtos')); }
    catch (e) { d = { ok: false, mensagem: e.message === 'sessao' ? '' : 'Não foi possível falar com o servidor.' }; }
    if ($('etq-form').hidden || etqModo !== modo) return;
    if (!d.ok) { busca.placeholder = 'Não foi possível carregar: volte e abra de novo'; mensagem($('etq-msg'), d.mensagem || 'Não foi possível ler ' + nome + '.', 'erro'); return; }
    etqListas[modo] = (kit ? d.kits : d.produtos) || [];
    mensagem($('etq-msg'), etqListas[modo].length ? '' : (kit ? 'Nenhum kit disponível.' : 'Nenhum produto disponível.'), 'info');
    liberar();
    busca.focus();
    etqBuscar();
  }
  function etqAbrir() {
    mostrarEtapa('etiq');
    irAoTopo();
    $('etq-opcoes').hidden = false;
    $('etq-form').hidden = true;
    $('etq-voltar').hidden = etqSoEla;
    mensagem($('etq-msg'), '', 'info');
  }
  $('etq-abrir').addEventListener('click', etqAbrir);
  $('etq-produtos').addEventListener('click', () => etqAbrirForm('produto'));
  $('etq-kits').addEventListener('click', () => etqAbrirForm('kit'));
  $('etq-comps').addEventListener('change', etqDesenhar);
  $('etq-voltar').addEventListener('click', () => {
    if (!$('etq-form').hidden) { etqPedidoLotes++; etqAbrir(); return; }
    mostrarEtapa('inicio');
  });
  $('etq-busca').addEventListener('input', etqBuscar);
  $('etq-lista').addEventListener('click', (e) => {
    const b = e.target.closest('[data-etq]');
    if (b) (etqModo === 'kit' ? etqEscolherKit : etqEscolherProduto)($('etq-lista').etqAchados[Number(b.dataset.etq)]);
  });
  $('etq-sub').addEventListener('change', etqEscolherSub);
  $('etq-lote').addEventListener('change', etqDesenhar);
  $('etq-qtd').addEventListener('input', etqDesenhar);
  // impressao: uma pagina por linha de etiquetas (bobina), do tamanho exato da linha e sem margem
  function etqFimImpressao() {
    document.body.classList.remove('etq-imprimindo');
    const st = $('etq-pagina');
    if (st) st.remove();
    $('etq-impressao').innerHTML = '';
  }
  window.addEventListener('afterprint', etqFimImpressao);
  $('etq-imprimir').addEventListener('click', () => {
    const qtd = etqQtd(), et = etqAtual();
    if (!et || !qtd) return;
    const svg = etqSvg(et);
    let html = '';
    for (let i = 0; i < qtd; i += etqCfg.por_linha) html += '<div class="etq-linha">' + svg.repeat(Math.min(etqCfg.por_linha, qtd - i)) + '</div>';
    $('etq-impressao').innerHTML = html;
    const st = document.createElement('style');
    st.id = 'etq-pagina';
    const L = etqCfg.largura + 'mm', A = etqCfg.altura + 'mm';
    st.textContent = '@media print { @page { size: ' + L + ' ' + A + '; margin: 0; } html, body { margin: 0; padding: 0; width: ' + L + '; } #etq-impressao .etq-linha { width: ' + L + '; height: ' + A + '; } }';
    document.head.appendChild(st);
    document.body.classList.add('etq-imprimindo');
    window.print();
  });

