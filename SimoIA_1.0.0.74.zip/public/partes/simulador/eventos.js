/*@parte Simulador: eventos dos campos, tributos e descontos. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- eventos ---------- */
  $('uf').innerHTML = '<option value="">—</option>' + UFS.map((u) => '<option>' + u + '</option>').join('');

  // fixo (regra do dono, 27/10/2026): ou o cliente (o cadastro dele tem tudo o que a API de tributos precisa),
  // ou UF de venda + regime da pessoa, os dois juntos. Custo sempre obrigatorio.
  // Cliente escolhido na lista: UF e regime vem do cadastro dele e ficam bloqueados; sem cliente, a pessoa escolhe.
  let paramsOk = false; // configuracoes minimas preenchidas (pessoa, tabela de preco e custo): libera os botoes de itens
  let cliente = null;  // { codigo, nome, fantasia, cnpj, cidade, uf, pais, regime, regime_cod, classif_icms, suframa, vendedores }
  const REGIMES = { simples: 'Simples', presumido: 'Lucro Presumido', real: 'Lucro Real', isento: 'Isento' };
  // classificacoes de ICMS (SQL "classif_icms"): contribuinte_icms do JSON da API vem da classificacao escolhida
  let classificacoes = [];
  const contribuinteDe = (cod) => { const c = classificacoes.find((x) => x.codigo === cod); return c ? c.contribuinte : 'S'; };
  function mostrarContribuinte() {
    $('info-contrib').textContent = $('classif').value ? 'Contribuinte de ICMS: ' + (contribuinteDe($('classif').value) === 'S' ? 'sim' : 'não') : '';
  }
  /* botao "Atualizar" das Configuracoes (dono, 31/10/2026): aparece quando alguma lista nao carregou (ex.: logo depois de
   * reiniciar o servico) e recarrega tudo sem sair da pagina. Se a simulacao anterior foi aberta com algo faltando, ela
   * e reaplicada (e nao e gravada por cima enquanto isso, para nao perder itens). */
  const falhas = new Set();
  let restaurarDepois = null; // { d, s } da simulacao anterior aberta com falha
  function marcarCarga(nome, deuCerto) {
    if (deuCerto) falhas.delete(nome); else falhas.add(nome);
    $('atualizar-tudo').hidden = !falhas.size && !restaurarDepois;
  }
  async function atualizarTudo() {
    const b = $('atualizar-tudo');
    b.disabled = true;
    processando('atualizar', 'Atualizando os dados', 'Recarregando cliente, classificações, cidades, tipos de documento, tabelas de preço, custos e produtos…');
    try {
      const antes = { tipodoc: $('tipodoc').value, tabela: $('tabela').value, custo: $('custo').value, classif: $('classif').value };
      for (const k of Object.keys(precoCache)) delete precoCache[k];
      for (const k of Object.keys(custoCache)) delete custoCache[k];
      await Promise.all([carregarProdutos(), carregarCustos(), carregarTiposDocto(), carregarTabelasPreco(), carregarClassificacoes(), carregarCidades()]);
      const volta = (id, v) => { if (v && [...$(id).options].some((o) => o.value === v)) $(id).value = v; };
      volta('tipodoc', antes.tipodoc); volta('tabela', antes.tabela); if (podeCusto) volta('custo', antes.custo); // sem a liberacao: o primeiro da lista
      if (cliente) await recarregarCliente(); // UF, Suframa, regime e classificacao de novo do cadastro (dono, 02/11/2026)
      else {
        volta('classif', antes.classif);
        if (falhas.has('clientes')) await testarClientes();
      }
      if (restaurarDepois) {
        const { d, s } = restaurarDepois;
        restaurarDepois = null;
        await restaurarDados(d, s); // completa cliente, configuracoes e itens que faltaram
      } else {
        if ($('custo').value) await aoTrocarCusto();
        if ($('tabela').value) await aoTrocarTabela();
        conferirParametros();
      }
    } finally {
      processando('atualizar');
      b.disabled = false;
      marcarCarga('nada', true);
      if (!falhas.size) $('info-produtos').textContent = $('info-produtos').textContent || infoProdutos;
    }
  }
  // cliente escolhido: busca de novo no cadastro (UF, Suframa, regime e classificacao de ICMS)
  async function recarregarCliente() {
    const cod = String(cliente.codigo);
    try {
      const r = await api('/api/simulador/clientes?q=' + encodeURIComponent(cod));
      marcarCarga('clientes', !!r.ok);
      const c = r.ok && (r.clientes || []).find((x) => String(x.codigo) === cod);
      if (c && cliente && String(cliente.codigo) === cod) { cliente = c; conferirParametros(); }
    } catch (e) { if (e.message !== 'sessao') marcarCarga('clientes', false); }
  }
  // sem cliente escolhido, mas a busca tinha falhado: ve se a lista de clientes ja responde (some o "Atualizar")
  async function testarClientes() {
    try { const r = await api('/api/simulador/clientes?q=' + encodeURIComponent('0')); marcarCarga('clientes', !!r.ok); }
    catch (e) { if (e.message !== 'sessao') marcarCarga('clientes', false); }
  }
  async function carregarClassificacoes() {
    try {
      const d = await api('/api/simulador/classif-icms');
      if (!d.ok || !d.classificacoes.length) { $('info-contrib').textContent = d.mensagem || 'Classificações indisponíveis.'; marcarCarga('classif', false); return; }
      marcarCarga('classif', true);
      $('info-contrib').textContent = '';
      classificacoes = d.classificacoes;
      // comeca vazia (como o regime): sem cliente a pessoa escolhe; com cliente vem do cadastro
      $('classif').innerHTML = '<option value="">—</option>' +
        classificacoes.map((c) => '<option value="' + esc(c.codigo) + '">' + esc(c.codigo + ' - ' + c.descricao) + '</option>').join('');
      // chegou depois do cliente (ex.: servidor recem-reiniciado; dono, 02/11/2026): confere tudo de novo, senao o
      // "Adicionar" ficava travado mesmo com a classificacao ja preenchida
      conferirParametros();
    } catch (e) {
      if (e.message !== 'sessao') { $('info-contrib').textContent = 'Classificações indisponíveis.'; marcarCarga('classif', false); }
    }
  }
  /* Cidade (dono, 09/11/2026): lista de wonder.sis_cidades (SQL "cidades"), so as da UF de venda. Com cliente, a do
   * cadastro (p_w_id_cidade; sem ela, pelo nome e pela UF) e o campo fica travado, como a UF. O w_id vai no w_id_cidade
   * da API de tributos. cidadeQuer = cidade a escolher quando a lista da UF estiver pronta (simulacao salva, pedido). */
  let cidades = null, cidErro = false, cidDesenhada = null, cidadeQuer = null;
  const normCid = (v) => String(v || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toUpperCase();
  function acharCidade(lista, q) {
    if (!q) return null;
    return (q.w_id && lista.find((c) => c.w_id === String(q.w_id))) || (q.nome && lista.find((c) => normCid(c.nome) === normCid(q.nome))) || null;
  }
  function desenharCidades() {
    const sel = $('cidade'), uf = $('uf').value;
    const lista = uf && cidades ? cidades.filter((c) => c.uf === uf) : [];
    const marca = uf + '|' + (cidades ? cidades.length : cidErro ? 'erro' : 'carregando');
    if (cidDesenhada !== marca) {
      const atual = sel.value;
      sel.innerHTML = '<option value="">' + (!uf || cidades ? '—' : cidErro ? 'Indisponível' : 'Carregando…') + '</option>' +
        lista.map((c) => '<option value="' + esc(c.w_id) + '">' + esc(c.nome) + '</option>').join('');
      sel.value = lista.some((c) => c.w_id === atual) ? atual : '';
      cidDesenhada = marca;
    }
    const alvo = cliente ? { w_id: cliente.w_id_cidade, nome: cliente.cidade } : cidadeQuer;
    if (alvo && cidades) {
      const c = acharCidade(lista, alvo);
      sel.value = c ? c.w_id : '';
      if (!cliente) cidadeQuer = null;
    }
    sel.disabled = !!cliente || !uf || !cidades;
    sel.title = cliente ? (sel.value ? 'Cidade do cadastro do cliente' : 'Cidade do cliente não encontrada na lista') : !uf ? 'Escolha a UF de venda antes' : '';
  }
  async function carregarCidades() {
    try {
      const d = await api('/api/simulador/cidades');
      if (d.ok && Array.isArray(d.cidades)) { cidades = d.cidades; cidErro = false; marcarCarga('cidades', true); }
      else { cidErro = !cidades; marcarCarga('cidades', false); }
    } catch (e) {
      if (e.message === 'sessao') return;
      cidErro = !cidades; marcarCarga('cidades', false);
    }
    conferirParametros(); // a cidade do cliente (ou a da simulacao salva) entra agora
  }
  // Suframa (chave Sim/Nao; dono, 29/10/2026): com cliente, a inscricao do cadastro; sem cliente, "Sim" manda uma
  // inscricao generica so para a API calcular como Suframa
  const SUFRAMA_GENERICA = '1111111111'; // valor pedido pelo dono (29/10/2026)
  let suframaSim = false;
  function desenharSuframa() {
    const b = $('suframa');
    b.classList.toggle('sim', suframaSim);
    b.setAttribute('aria-checked', String(suframaSim));
    b.querySelector('.chave-txt').textContent = suframaSim ? 'Sim' : 'Não';
    b.disabled = !!cliente;
    b.title = cliente ? (cliente.suframa ? 'Suframa ' + cliente.suframa + ' (cadastro do cliente)' : 'Cliente sem Suframa no cadastro') : 'Simular com Suframa (Sim) ou sem (Não)';
  }
  const suframaParaTributos = () => (cliente ? String(cliente.suframa || '').trim() : suframaSim ? SUFRAMA_GENERICA : '');
  // dados da pessoa que vao para a API de tributos: com cliente, os do cadastro (com cod_pessoa_filial);
  // sem cliente, os da tela (sem cod_pessoa_filial). Consumidor final: sempre N (regra do dono; o servidor garante).
  function pessoaParaTributos() {
    return {
      cliente: cliente ? String(cliente.codigo) : null,
      uf: $('uf').value, suframa: suframaParaTributos(), classif_icms: $('classif').value,
      contribuinte_icms: contribuinteDe($('classif').value), regime: $('regime').value,
      // campo Cidade (dono, 09/11/2026): com cliente, a do cadastro (sem esperar a lista); trocar recalcula todos os itens
      w_id_cidade: (cliente && cliente.w_id_cidade) || $('cidade').value,
      tipo_doc: $('tipodoc').value // trocar o tipo de documento recalcula os tributos de todos os itens
    };
  }

  /*
   * Tributos pela API (POST /api/simulador/tributos): uma chamada para todos os itens com Vl caixa, 0,8 s depois da
   * ultima mudanca de pessoa, itens ou Vl caixa (quantidade e descontos so recalculam na tela, com as mesmas aliquotas).
   * So itens que mudaram (ou todos, se a pessoa mudou) vao de novo para a API.
   */
  // sem tributacao inicial (dono, 29/10/2026): a API so e chamada com itens (saiu o "item inicial" / produto generico)
  let tribTimer = 0, tribPedido = 0, tribPessoa = '';
  // uma chamada por vez (pedido do dono, 28/10/2026: todos os itens num JSON so): o que mudar enquanto a API
  // responde espera a volta e segue numa chamada unica, so com os itens que ainda faltam
  let tribAndando = false, tribDeNovo = false;
  // itens recem-adicionados esperando os tributos: so entram na tabela quando a API responde (pedido do dono,
  // 28/10/2026: "informar que esta processando e adicionar na linha de itens so depois de retornar")
  let aguardando = [];
  let avisoDepois = ''; // mensagem para quando a busca terminar ("Simulacao anterior restaurada...")
  function avisoAguardando() {
    const n = aguardando.length;
    $('info-produtos').textContent = n ? 'Buscando os tributos de ' + n + (n === 1 ? ' item' : ' itens') + '… ' +
      (n === 1 ? 'Ele entra' : 'Eles entram') + ' na simulação assim que a busca terminar.' : (avisoDepois || infoProdutos);
    $('info-produtos').classList.toggle('buscando', !!n);
    if (!n) avisoDepois = '';
  }
  /* popup "processando" (dono, 28/10/2026: sempre que a API de tributos rodar com itens, e ao trocar tabela/custo).
   * Cada motivo ('restaurar', 'trib', 'preco', 'custo') liga e desliga o seu; o popup fica enquanto houver algum. */
  const processos = new Map();
  let restaurando = false; // ate os tributos da simulacao restaurada voltarem: o popup diz "Recarregando..."
  function processando(motivo, titulo, texto) {
    if (titulo) processos.set(motivo, { titulo, texto }); else processos.delete(motivo);
    const ult = [...processos.values()].pop();
    $('processando').hidden = !ult;
    if (ult) { $('processando-titulo').textContent = ult.titulo; $('processando-texto').textContent = ult.texto || ''; }
  }
  function popupTributos(n) {
    processando('trib', restaurando ? 'Recarregando a simulação anterior' : 'Atualizando os dados',
      'Calculando tributação de ' + n + (n === 1 ? ' item…' : ' itens…')); // texto do dono (28/10/2026)
  }
  // quantos itens vao para a API na proxima chamada (pessoa completa e Vl caixa novo, ou a pessoa mudou)
  function itensParaTributos() {
    const p = pessoaParaTributos();
    if (!(cliente ? p.uf : p.uf && p.regime && p.classif_icms)) return 0;
    const mudouPessoa = JSON.stringify(p) !== tribPessoa;
    return itens.concat(aguardando).filter((it) => ok(it.vl_caixa) && it.vl_caixa > 0 && (mudouPessoa || !it.trib)).length;
  }
  // passa para a tabela os itens que esperavam (todos, ou so os codigos que foram na chamada)
  function liberarAguardando(codigos) {
    const vao = codigos ? aguardando.filter((it) => codigos.has(it.codigo)) : aguardando;
    if (!vao.length) return;
    aguardando = codigos ? aguardando.filter((it) => !codigos.has(it.codigo)) : [];
    itens.push(...vao);
    avisoAguardando();
  }
  // chave "Online" do quadro Tributos (dono, 30/10/2026): ligada, os tributos sao calculados sozinhos a cada mudanca
  // (como sempre foi); desligada, os itens entram sem tributos e o calculo so roda no botao "Calcular tributos" (todos)
  // ou no botao de cada item. tribForcar = 'todos' ou um Set de codigos pedidos no botao.
  // simulacao nova (ou "Limpar simulacao") comeca com a ultima posicao usada da chave, guardada neste navegador;
  // nunca usada = Nao, desligada (dono, 31/10/2026)
  const ONLINE_CHAVE = 'sim_online';
  let tribOnline = (() => { try { return localStorage.getItem(ONLINE_CHAVE) === '1'; } catch (e) { return false; } })();
  let tribForcar = null;
  const guardarOnline = () => { try { localStorage.setItem(ONLINE_CHAVE, tribOnline ? '1' : '0'); } catch (e) { /* sem storage */ } };
  $('trib-calcular').hidden = tribOnline;
  // so busca quem ainda nao tem tributacao (dono, 31/10/2026): os impostos ficam em %, entao trocar o valor do item
  // (tabela de preco, Vl Novo) nao precisa ir a API de novo; a pessoa mudar (ou o Tipo Docto) limpa e busca tudo
  const MSG_TRIB_PEND = 'Calcule os tributos (Margem geral) antes de compartilhar, imprimir ou gerar o Excel';
  const precisaTributo = (it) => ok(it.vl_caixa) && it.vl_caixa > 0 && !it.trib;
  function agendarTributos() {
    clearTimeout(tribTimer);
    tribTimer = setTimeout(calcularTributos, 800);
    // o popup aparece ja na mudanca (sem esperar os 0,8 s), se algum item vai para a API
    const n = tribOnline ? itensParaTributos() : 0;
    if (n) popupTributos(n);
  }
  function calcularTributosDe(codigos) { tribForcar = codigos || 'todos'; tributosAgora(); }
  function tributosAgora() { clearTimeout(tribTimer); calcularTributos(); }
  async function calcularTributos() {
    if (tribAndando) { tribDeNovo = true; return; }
    tribAndando = true;
    try { await calcularTributosUmaVez(); } finally {
      tribAndando = false;
      processando('trib'); // se for de novo, a proxima chamada liga o popup antes da tela redesenhar
      if (tribDeNovo) { tribDeNovo = false; calcularTributos(); } else restaurando = false;
    }
  }
  async function calcularTributosUmaVez() {
    const p = pessoaParaTributos();
    const pessoaOk = cliente ? !!p.uf : !!(p.uf && p.regime && p.classif_icms);
    const chave = JSON.stringify(p);
    const todos = itens.concat(aguardando);
    if (chave !== tribPessoa) { for (const it of todos) { it.trib = null; it.trib_base = null; } tribPessoa = chave; }
    let enviar = todos.filter(precisaTributo);
    // offline: so o que foi pedido no botao (todos ou o item); o resto entra na tabela sem tributos
    const forcar = tribForcar;
    tribForcar = null;
    if (!tribOnline) enviar = forcar === 'todos' ? enviar : forcar ? enviar.filter((it) => forcar.has(it.codigo)) : [];
    // sem Vl caixa nao ha o que buscar: o item entra direto
    liberarAguardando(new Set(aguardando.filter((it) => !enviar.includes(it)).map((it) => it.codigo)));
    if (!pessoaOk || !enviar.length) {
      liberarAguardando();
      const falta = itens.filter(precisaTributo).length;
      $('info-trib').textContent = !pessoaOk && itens.length ? 'Escolha o cliente (ou a UF, o regime e a classificação de ICMS) para calcular os tributos.'
        : !tribOnline && falta ? 'Cálculo offline: ' + falta + (falta === 1 ? ' item está' : ' itens estão') + ' sem tributos. Clique em "Calcular tributos" (ou no botão do item).' : '';
      desenharTributos(); desenharItens();
      return;
    }
    const pedido = ++tribPedido;
    const bases = new Map(enviar.map((it) => [it.codigo, it.vl_caixa]));
    const lista = enviar.map((it) => ({ codigo: it.codigo, vl_bruto: it.vl_caixa }));
    $('info-trib').textContent = 'Calculando os tributos de ' + enviar.length + (enviar.length === 1 ? ' item' : ' itens') + '…';
    popupTributos(enviar.length);
    desenharTributos(); desenharItens(); // as aliquotas da pessoa anterior saem na hora
    let d;
    try {
      d = await api('/api/simulador/tributos', { pessoa: p, itens: lista });
    } catch (e) {
      if (e.message !== 'sessao' && pedido === tribPedido) $('info-trib').textContent = 'Não foi possível falar com o servidor para calcular os tributos.';
      liberarAguardando(new Set(bases.keys())); desenharItens(); // sem tributos, mas o item nao some
      return;
    }
    if (chave !== JSON.stringify(pessoaParaTributos())) return; // a pessoa mudou enquanto calculava: vale o calculo seguinte
    // (itens cujo Vl caixa mudou nesse meio tempo ficam de fora pela conferencia de base abaixo)
    if (!d.ok) {
      $('info-trib').textContent = d.mensagem || 'Não foi possível calcular os tributos.';
      liberarAguardando(new Set(bases.keys())); desenharItens();
      return;
    }
    const faltou = [];
    liberarAguardando(new Set(bases.keys())); // voltaram: agora entram na tabela, ja com os tributos
    for (const it of itens) {
      if (!bases.has(it.codigo)) continue;
      const t = d.itens && d.itens[it.codigo];
      // vale mesmo se o valor do item mudou enquanto a API respondia (os impostos sao %)
      if (t) { it.trib = t; it.trib_base = bases.get(it.codigo); }
      else faltou.push(it.codigo);
    }
    const avisos = d.avisos || [];
    $('info-trib').textContent = (faltou.length ? 'A API não devolveu tributos para: ' + faltou.join(', ') + '. ' : '') +
      (avisos.length ? 'Avisos do cálculo: ' + avisos.join(' / ') : '');
    desenharTributos();
    desenharItens();
  }
  function ajustarCliente() {
    for (const id of ['uf', 'regime', 'classif']) $(id).disabled = !!cliente;
    if (cliente) {
      $('uf').value = UFS.includes(cliente.uf) ? cliente.uf : '';
      $('regime').value = cliente.regime || '';
      $('classif').value = classificacoes.some((c) => c.codigo === cliente.classif_icms) ? cliente.classif_icms : '';
      suframaSim = !!String(cliente.suframa || '').trim(); // cliente com Suframa = Sim
    }
    desenharCidades(); // segue a UF (e, com cliente, o cadastro)
    desenharSuframa();
    mostrarContribuinte();
    // "Últimos 5 pedidos": com cliente e os demais dados (tabela de preco e custo; paramsOk vem de conferirParametros)
    $('ver-pedidos').disabled = !cliente || !paramsOk;
    $('ver-pedidos').title = $('ver-pedidos').disabled ? 'Escolha o cliente, o Tipo Docto, a tabela de preço e o custo antes' : '';
    $('cli-info').textContent = !cliente ? '' : [cliente.fantasia && cliente.fantasia !== cliente.nome ? cliente.fantasia : '',
      cliente.cnpj ? 'CNPJ ' + cliente.cnpj : '', [cliente.cidade, cliente.uf].filter(Boolean).join('/') + (cliente.uf === 'EX' && cliente.pais ? ' - ' + cliente.pais : ''),
      REGIMES[cliente.regime] || 'regime não informado no cadastro', cliente.suframa ? 'Suframa ' + cliente.suframa : '',
      cliente.vendedores ? 'Vendedor: ' + cliente.vendedores.split(';').join(', ') : ''].filter(Boolean).join(' · ');
  }
  function escolherCliente(c) {
    if (!c && cliente) suframaSim = false; // tirou o cliente: Suframa volta ao padrao (Nao)
    cliente = c;
    $('pessoa').value = c ? c.codigo + ' - ' + c.nome : '';
    fecharLista();
    conferirParametros();
  }
  function conferirParametros() {
    ajustarCliente();
    const falta = [];
    if (cliente) {
      if (!$('uf').value) falta.push('um cliente com UF no cadastro');
      else if (!$('regime').value) falta.push('um cliente com regime tributário no cadastro (ou deixe o cliente em branco e use UF + regime)');
      else if (!$('classif').value) falta.push(classificacoes.length ? 'um cliente com classificação de ICMS no cadastro' : 'as classificações de ICMS (ainda não carregaram: clique em "Atualizar", no canto das Configurações)');
    } else if ($('pessoa').value.trim()) falta.push('o cliente na lista (ou apague o texto e use UF + regime)');
    else {
      const semUf = !$('uf').value, semRegime = !$('regime').value, semClassif = !$('classif').value;
      if (semUf && semRegime && semClassif) falta.push('o cliente (ou a UF de venda, o regime e a classificação de ICMS da pessoa)');
      else {
        const f = [semUf ? 'a UF de venda' : '', semRegime ? 'o regime da pessoa' : '', semClassif ? 'a classificação de ICMS' + (classificacoes.length ? '' : ' (a lista ainda não carregou: clique em "Atualizar")') : ''].filter(Boolean);
        if (f.length) falta.push(f.join(', '));
      }
    }
    // tipo docto, tabela de preco e custo obrigatorios para entrar itens (dono, 28/10/2026; antes a tabela era opcional;
    // tipo docto em 29/10/2026)
    if (!$('tipodoc').value) falta.push('o tipo de documento');
    if (!$('tabela').value) falta.push('a tabela de preço');
    if (!$('custo').value) falta.push('o custo');
    $('erro-param').textContent = falta.length ? 'Para simular, escolha ' + falta.join(' e ') + '.' : '';
    // itens so entram com as configuracoes minimas (regra do dono, 27/10/2026): Adicionar, os botoes da pesquisa e
    // "Últimos 5 pedidos" ficam desabilitados ate la
    paramsOk = !falta.length;
    $('btn-adicionar').disabled = !paramsOk;
    $('btn-adicionar').title = paramsOk ? '' : 'Preencha as configurações acima antes de adicionar itens';
    // "Últimos 5 pedidos" bloqueado ate ter o cliente e os demais dados (tabela de preco e custo) (dono, 28/10/2026)
    $('ver-pedidos').disabled = !cliente || !paramsOk;
    $('ver-pedidos').title = $('ver-pedidos').disabled ? 'Escolha o cliente, o Tipo Docto, a tabela de preço e o custo antes' : '';
    // "Carregar pedido" sempre ativo (dono, 11/11/2026): o cliente, o Tipo Docto e a tabela de preco vazios vem do pedido
    if (!$('pesq-lista').hidden) atualizarCabPesquisa();
    atualizarIntegrar();
    agendarTributos(); // pessoa ou itens podem ter mudado (so vai a API o que mudou)
    desenharDespesas(); // a Regra dos parametros segue a UF de venda
    atualizarMargemSistema(); // regra do sistema segue a UF e o cliente
    return !falta.length;
  }
  ['uf', 'cidade', 'regime', 'classif', 'tipodoc', 'custo', 'tabela'].forEach((id) => $(id).addEventListener('change', conferirParametros));
  // chave Suframa: so sem cliente (com cliente segue o cadastro)
  $('suframa').addEventListener('click', () => {
    if (cliente) return;
    suframaSim = !suframaSim;
    desenharSuframa();
    conferirParametros();
  });

