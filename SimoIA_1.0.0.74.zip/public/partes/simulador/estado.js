/*@parte Simulador: funções de apoio e estado da simulação. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  const $ = (id) => document.getElementById(id);
  /* popup de confirmacao (dono, 11/11/2026: nada de confirm() do navegador). perguntar({ titulo, texto, sim, nao }) -> Promise<boolean>.
   * Esc ou Cancelar = false. O Esc fica so com ele (captura), para nao fechar junto a janela de baixo. */
  function perguntar(o) {
    return new Promise((ok) => {
      const foco = document.activeElement;
      $('pg-titulo').textContent = o.titulo || 'Confirmar';
      $('pg-texto').textContent = o.texto || '';
      $('pg-sim').textContent = o.sim || 'Sim';
      $('pg-nao').textContent = o.nao || 'Cancelar';
      $('dlg-pergunta').hidden = false;
      $('pg-sim').focus();
      const tecla = (e) => { if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); fim(false); } };
      const fim = (r) => {
        $('dlg-pergunta').hidden = true;
        $('pg-sim').onclick = $('pg-nao').onclick = null;
        document.removeEventListener('keydown', tecla, true);
        if (foco && foco.focus && document.contains(foco)) foco.focus();
        ok(r);
      };
      $('pg-sim').onclick = () => fim(true);
      $('pg-nao').onclick = () => fim(false);
      document.addEventListener('keydown', tecla, true);
    });
  }
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  // aceita "1,5", "1.5" e "1.234,5" (com virgula, o ponto e separador de milhar)
  const num = (v) => {
    const s = String(v == null ? '' : v).trim();
    if (!s) return null;
    const n = Number(s.includes(',') ? s.replace(/\./g, '').replace(',', '.') : s);
    return isFinite(n) ? n : null;
  };
  const ok = (v) => v != null && isFinite(v);
  const fmt = (v, casas) => !ok(v) ? '—' : v.toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
  const moeda = (v) => !ok(v) ? '—' : v.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  const pct = (v) => !ok(v) ? '—' : fmt(v, 2) + '%';
  // margem: verde positiva, vermelha negativa e azul claro quando fica em 0,00% (dono, 30/10/2026)
  const classeRes = (v) => !ok(v) ? '' : Math.round(v * 100) === 0 ? 'zero' : v < 0 ? 'neg' : 'pos';
  const soma = (a, b) => ok(a) ? (ok(b) ? a + b : a) : (ok(b) ? b : null);

  async function api(url, corpo) {
    const r = await fetch(url, corpo ? { method: 'POST', headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) }
      : { headers: { 'Authorization': 'Bearer ' + token } });
    let d = {};
    try { d = await r.json(); } catch (e) { /* ignora */ }
    if (r.status === 401) {
      try { if (d.motivo === 'outro_acesso' && d.mensagem) sessionStorage.setItem('aviso', d.mensagem); } catch (e) { /* ignora */ }
      location.href = '/';
      throw new Error('sessao');
    }
    return d;
  }

  /* ---------- estado da simulacao (so na tela; nada e gravado) ---------- */
  const UFS = ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO', 'EX'];
  // tributos: a aliquota vem por item da API de tributos (it.trib). Quadro Tributos (dono, 29/10/2026): uma chave
  // Sim/Nao por tributo (Nao = 0% em todos os itens); o "novo" de cada item fica na linha (+) do item (it.trib_novo)
  // ordem do quadro Tributos (dono, 28/10/2026): ICMS - ST - PIS/COFINS - IPI - IBS - CBS - IS (IS: dono, 11/11/2026)
  // novo: % geral digitado embaixo da chave (dono, 30/10/2026), so com a chave em Sim
  const tributos = ['ICMS', 'ST', 'PIS/COFINS', 'IPI', 'IBS', 'CBS', 'IS'].map((nome) => ({ id: nome.toLowerCase().replace(/\W/g, ''), nome, usar: true, novo: null }));
  let despesas = [];   // { id, nome, digitado } (nomes/ordem de simulador_despesas; valores por UF)
  let itens = [];
  let guia = 'item';
  let metaCliente = null; // % de meta do cliente (guia Gondola): calcula o valor meta de cada item
  let produtos = null; // Map codigo -> produto (lista de produtos disponiveis, do banco)

  // descontos padrao (Des. 1, 2 e 3 embaixo da pesquisa; dono, 30/10/2026): todo produto novo ja entra com eles.
  // Mudar os campos nao mexe nos itens que ja estao; a setinha aplica em todos.
  let descPadrao = [null, null, null];
  // dados do produto vem da lista de produtos disponiveis; NCM e precos virao da API de tributos e da tabela de preco
  const novoItem = (p) => ({
    codigo: p.codigo, descricao: p.descricao, grupo: p.grupo || null, gramatura: p.gramatura != null ? fmt(p.gramatura, 0) + ' g' : null,
    ncm: null, un_caixa: p.un_caixa, peso_liq: p.peso_liq, peso_bruto: p.peso_bruto, m3: p.m3, custo: custoDe(p.codigo),
    tab: null, // tabela de preco propria do item (w_id; botao ">"); null = segue a Tabela de preco das Configuracoes
    vl_tabela: precoDe(p.codigo), vl_caixa: precoDe(p.codigo), caixa_digitado: false, qtde: 1, des1: descPadrao[0], des2: descPadrao[1], des3: descPadrao[2], pct_simu: null, vl_gondola: null
  });

  // regra do item (API de tributos), em %: ICMS efetivo = aliquota x % tributado; ST = valor da API / valor enviado
  // ICMS dispensado (dono, 10/11/2026): so o vl_icms_disp > 0 da API faz o ICMS virar desconto do total
  const icmsDispensado = (t) => Number(t && t.vl_icms_disp) > 0;
  function regraItem(id, it) {
    const t = it.trib;
    if (!t) return null;
    const n = (v) => (ok(v) ? v : 0);
    // ICMS como desconto (dono, 09/11/2026): so quando a API devolve vl_icms_disp > 0 (dono, 10/11/2026: o aliq_icms_disp
    // pode vir sem valor dispensado = ICMS normal); ai vale a aliq_icms_disp e o valor deduz do total (ver descontoTrib)
    if (id === 'icms' && icmsDispensado(t) && t.aliq_icms_disp > 0) return t.aliq_icms_disp;
    if (id === 'icms') return ok(t.aliq_icms) ? t.aliq_icms * (ok(t.perc_tributado) ? t.perc_tributado : 100) / 100 : null;
    if (id === 'ipi') return t.aliq_ipi;
    if (id === 'st') return ok(t.vl_icms_sub) && t.vl_bruto > 0 ? t.vl_icms_sub / t.vl_bruto * 100 : 0;
    if (id === 'piscofins') return ok(t.aliq_pis) || ok(t.aliq_cofins) ? n(t.aliq_pis) + n(t.aliq_cofins) : null;
    // IBS/CBS (dono, 29/10/2026): com aliquota mas valor 0 na API, ainda nao soma no documento: aliquota 0 nos calculos
    const ibsCbs = (aliq, vl) => (ok(aliq) && !(Number(vl) > 0 || Number(vl) < 0) ? 0 : aliq);
    if (id === 'ibs') {
      const uf = ibsCbs(t.aliq_ibs_uf, t.vl_ibs_uf), mun = ibsCbs(t.aliq_ibs_mun, t.vl_ibs_mun);
      return ok(uf) || ok(mun) ? n(uf) + n(mun) : null;
    }
    if (id === 'cbs') return ibsCbs(t.aliq_cbs, t.vl_cbs);
    // IS (Imposto Seletivo, dono, 11/11/2026): aliq_is da API, com as mesmas regras do IBS/CBS (base, por fora, valor 0 = 0%)
    if (id === 'is') return ibsCbs(t.aliq_is, t.vl_is);
    return null;
  }
  /* tributos como desconto (dono, 09/11/2026): a aliquota e o calculo nao mudam, mas o valor deduz do total do pedido
   * (linha "Valor tributos desconto" do Pedido; "ICMS (desconto)" e "PIS/COFINS (desconto)" nos Impostos) em vez de
   * ficar incluso. ICMS: quando a API devolve vl_icms_disp > 0 (com a aliq_icms_disp). PIS/COFINS: quando devolve vl_desconto_pis e/ou
   * vl_desconto_cofins; so um dos dois: a parte dele no PIS/COFINS, pela aliquota (sem aliquotas, o PIS/COFINS todo). */
  function descontoTrib(it) {
    const t = it.trib || {};
    const n = (v) => (ok(v) ? v : 0);
    const dPis = t.vl_desconto_pis > 0, dCof = t.vl_desconto_cofins > 0;
    const soma = n(t.aliq_pis) + n(t.aliq_cofins);
    return {
      icms: icmsDispensado(t),
      piscofins: !dPis && !dCof ? 0 : soma > 0 ? ((dPis ? n(t.aliq_pis) : 0) + (dCof ? n(t.aliq_cofins) : 0)) / soma : 1
    };
  }
  // aliquota usada no item (ordem do dono, 30/10/2026): chave "Nao" = 0; com "Sim", o % digitado no item, senao o %
  // geral do quadro Tributos, senao o carregado da API. 0 digitado vale (zera o imposto); so o campo vazio passa adiante.
  function aliquota(id, it) {
    const t = tributos.find((x) => x.id === id);
    if (t && !t.usar) return 0;
    const v = it.trib_novo && it.trib_novo[id];
    if (ok(v)) return v;
    if (t && ok(t.novo)) return t.novo;
    return regraItem(id, it);
  }

  /*
   * Calculo de cada item. Conferido com a planilha (Vl CX 42,50; IPI 3,25% = 1,38; com impostos 43,88) e com os valores
   * da API de tributos (14311, R$ 200,05, RS: ICMS 24,01; PIS 2,90 + COFINS 13,38; CBS 1,44; IBS 0,16):
   * Descontos (regra do dono, 27/10/2026): o 1 sobre o Vl caixa, o 2 sobre o valor ja com o 1, o 3 sobre o valor ja com
   * o 1 e o 2 (cascata; nunca somados). Des. simu. nao e digitado: o usuario digita o Vl pct simulado, que e o preco
   * FINAL do pacote, com impostos (IPI, ST e IBS/CBS, os por fora; regra do dono, 27/10/2026). A caixa sem impostos volta
   * pela conta inversa: Vl CX = simulado x unidades / fator dos impostos por fora. Des. simu. = diferenca, em %, entre o
   * pacote com os descontos 1-3 (com impostos) e o simulado (negativo = acrescimo). Vl CX = caixa sem os impostos por fora.
   * ICMS = Vl CX x ICMS efetivo (por dentro); PIS/COFINS sobre (Vl CX - ICMS) (por dentro);
   * IBS e CBS sobre (Vl CX - ICMS - PIS/COFINS), por fora (somam ao total do documento, como o IPI; regra do dono);
   * IPI e ST por fora.
   * Margem (conferida com a planilha do dono: 14311, Vl CX 191,77, RS, custo 62,6073 da empresa 1 = 4,51%):
   * resultado = Vl CX - ICMS - PIS/COFINS (so o incluso; o descontado do total nao entra) - (soma de TODOS os parametros, inclusive "Margem" e Comissao) x Vl CX - custo;
   * margem = resultado / Vl CX. IPI, ST e IBS/CBS (por fora) nao entram. Sem custo ou sem parametros (UF): "—".
   * Como o ERP, a margem usa a linha arredondada a 2 casas: liquido (Vl CX x qtde), ICMS, PIS e COFINS (separados) (17/11/2026).
   * Geral, grupos e gramatura: soma dos resultados / soma dos Vl CX (pelos totais, nao pela media).
   */
  function calcularItem(it) {
    const q = ok(it.qtde) ? it.qtde : 0;
    const un = ok(it.un_caixa) && it.un_caixa > 0 ? it.un_caixa : null;
    let cxDesc = it.vl_caixa;
    if (ok(cxDesc)) for (const d of [it.des1, it.des2, it.des3]) if (ok(d)) cxDesc = cxDesc * (1 - d / 100);
    // impostos por fora, em % do valor sem eles: IPI e ST sobre o Vl CX; IBS/CBS/IS sobre o Vl CX sem ICMS e PIS/COFINS.
    // O simulado digitado ja os inclui (fator usado na conta inversa).
    const a = (id) => (ok(aliquota(id, it)) ? aliquota(id, it) : 0);
    const fatorFora = 1 + (a('ipi') + a('st')) / 100 + (a('ibs') + a('cbs') + a('is')) / 100 * (1 - a('icms') / 100) * (1 - a('piscofins') / 100);
    const pctDesc = ok(cxDesc) && un ? cxDesc / un : null;
    const pctDescImp = ok(pctDesc) ? pctDesc * fatorFora : null; // sugestao do campo: pacote com descontos e com impostos
    let cx = cxDesc, desSimu = null;
    if (ok(it.pct_simu) && un && ok(pctDescImp) && pctDescImp > 0) {
      cx = it.pct_simu * un / fatorFora;
      desSimu = (1 - it.pct_simu / pctDescImp) * 100;
    }
    const vez = (base, a) => (ok(base) && ok(a) ? base * a / 100 : null);
    const vIpi = vez(cx, aliquota('ipi', it));
    const vSt = vez(cx, aliquota('st', it));
    const vIcms = vez(cx, aliquota('icms', it));
    const vPisCof = ok(cx) ? vez(cx - (vIcms || 0), aliquota('piscofins', it)) : null;
    const baseIbs = ok(cx) ? cx - (vIcms || 0) - (vPisCof || 0) : null;
    const vIbs = vez(baseIbs, aliquota('ibs', it));
    const vCbs = vez(baseIbs, aliquota('cbs', it));
    const vIs = vez(baseIbs, aliquota('is', it)); // IS: mesma base e por fora, como o IBS/CBS
    const vIbsCbsIs = ok(vIbs) || ok(vCbs) || ok(vIs) ? (vIbs || 0) + (vCbs || 0) + (vIs || 0) : null;
    const cxImp = ok(cx) ? cx + (vIpi || 0) + (vSt || 0) + (vIbsCbsIs || 0) : null; // IBS/CBS/IS somam como o IPI
    const pctImp = ok(cxImp) && un ? cxImp / un : null;
    const fora = (vIpi || 0) + (vSt || 0) + (vIbsCbsIs || 0);
    // tributos como desconto (dono, 09/11/2026): saem do ICMS / PIS/COFINS incluso e deduzem do total
    const dt = descontoTrib(it);
    const vIcmsDesc = dt.icms && ok(vIcms) ? vIcms : null;
    const vPcDesc = dt.piscofins && ok(vPisCof) ? vPisCof * dt.piscofins : null;
    const vDesc = ok(vIcmsDesc) || ok(vPcDesc) ? (vIcmsDesc || 0) + (vPcDesc || 0) : null;
    // margem do item: precisa do custo e de todos os parametros (Regra da UF ou Novo)
    const pDesp = despesas.length ? despesas.map(despesaUsada) : [];
    const somaDesp = pDesp.length && pDesp.every(ok) ? pDesp.reduce((s, v) => s + v, 0) : null;
    // tributo como desconto (dono, 10/11/2026): o valor descontado do total do documento nao entra na margem
    // (so o ICMS / PIS/COFINS incluso sai do resultado)
    // valores da linha arredondados a 2 casas, como o ERP grava (dono, 17/11/2026: PV/674930 dava 7,31% aqui e 7,30% no ERP):
    // valor liquido = Vl CX x qtde; ICMS sobre ele; PIS e COFINS cada um sobre (liquido - ICMS), arredondados separados.
    // IBS/CBS/IS (dono, 17/11/2026): base = liquido - ICMS - PIS - COFINS da linha; IBS, CBS e IS arredondados cada um
    // (arredondamento normal, conferido nos 41 itens com CBS do banco; nao e para cima) e somados por item.
    const r2 = (v) => Math.round((v + (v < 0 ? -1 : 1) * Number.EPSILON) * 100) / 100;
    const qL = q > 0 ? q : 1; // sem quantidade, a linha sai pela caixa
    const base = ok(cx) ? r2(cx * qL) : null;
    const icmsL = ok(base) ? r2(base * a('icms') / 100) : 0;
    const aPis = ok(it.trib && it.trib.aliq_pis) ? it.trib.aliq_pis : 0, aCof = ok(it.trib && it.trib.aliq_cofins) ? it.trib.aliq_cofins : 0;
    const fPis = aPis + aCof > 0 ? aPis / (aPis + aCof) : null; // divide o % de PIS/COFINS usado entre PIS e COFINS
    const pisL = !ok(base) || fPis == null ? 0 : r2((base - icmsL) * a('piscofins') * fPis / 100);
    const cofL = !ok(base) ? 0 : fPis == null ? r2((base - icmsL) * a('piscofins') / 100) : r2((base - icmsL) * a('piscofins') * (1 - fPis) / 100);
    const baseCiL = ok(base) ? base - icmsL - pisL - cofL : null;
    const ibsCbsIsL = ok(vIbsCbsIs) && ok(baseCiL) ? r2(baseCiL * a('ibs') / 100) + r2(baseCiL * a('cbs') / 100) + r2(baseCiL * a('is') / 100) : null;
    const ibsCbsIsQ = ok(ibsCbsIsL) ? (q > 0 ? ibsCbsIsL : 0) : null; // valor da linha (quantidade toda)
    const difIbs = ok(ibsCbsIsQ) ? ibsCbsIsQ - vIbsCbsIs * q : 0; // ajuste do arredondamento nos totais
    let resultado = null, baseMargem = null;
    if (ok(cx) && cx > 0 && ok(it.custo) && ok(somaDesp)) {
      const t = it.trib || {};
      const descPc = !dt.piscofins ? 0 : fPis == null || dt.piscofins === 1 ? pisL + cofL : (t.vl_desconto_pis > 0 ? pisL : 0) + (t.vl_desconto_cofins > 0 ? cofL : 0);
      const resL = base - (dt.icms ? 0 : icmsL) - (pisL + cofL - descPc) - base * somaDesp / 100 - it.custo * qL;
      resultado = resL / qL; // por caixa (a margem do item = resultado / Vl CX)
      baseMargem = base / qL;
    }
    return {
      bruto: ok(it.vl_caixa) ? it.vl_caixa * q : null,
      cx, pct: ok(cx) && un ? cx / un : null, pctDesc, pctDescImp, desSimu, un,
      ipi: vIpi, st: vSt, cxImp, pctImp,
      produtos: ok(cx) ? cx * q : null,
      tributos: ok(vIpi) || ok(vSt) || ok(vIbsCbsIs) ? fora * q + difIbs : null, // IPI + ST + IBS/CBS/IS
      total: ok(cxImp) ? (cxImp - (vDesc || 0)) * q + difIbs : null,
      trib_desc: ok(vDesc) ? vDesc * q : null,
      peso_liq: ok(it.peso_liq) ? it.peso_liq * q : null,
      peso_bruto: ok(it.peso_bruto) ? it.peso_bruto * q : null,
      m3: ok(it.m3) ? it.m3 * q : null,
      caixas: q,
      custo: ok(it.custo) ? it.custo * q : null,
      icms: ok(vIcms) ? (vIcms - (vIcmsDesc || 0)) * q : null, piscofins: ok(vPisCof) ? (vPisCof - (vPcDesc || 0)) * q : null,
      icms_desc: ok(vIcmsDesc) ? vIcmsDesc * q : null, piscofins_desc: ok(vPcDesc) ? vPcDesc * q : null, ipi_total: ok(vIpi) ? vIpi * q : null,
      st_total: ok(vSt) ? vSt * q : null,
      ibscbs_cx: vIbsCbsIs, // por caixa (coluna Vl IBS/CBS/IS)
      ibscbs: ok(ibsCbsIsQ) ? ibsCbsIsQ : ok(vIbsCbsIs) ? vIbsCbsIs * q : null, // IBS + CBS + IS (linha arredondada como o ERP)
      margem: ok(resultado) ? resultado / baseMargem * 100 : null,
      resultado: ok(resultado) ? resultado * q : null, // para a margem pelos totais
      receita_margem: ok(resultado) ? baseMargem * q : null,
      // gondola (regra conferida com a planilha do dono: gondola 3,00 sobre 2,00 = 50%; meta 12% -> 2,24):
      // custo do cliente = nosso pacote com impostos; margem = (gondola - custo) / custo; valor meta = custo x (1 + meta%)
      margem_cliente: ok(it.vl_gondola) && ok(pctImp) && pctImp > 0 ? (it.vl_gondola - pctImp) / pctImp * 100 : null,
      valor_meta: ok(metaCliente) && ok(pctImp) ? pctImp * (1 + metaCliente / 100) : null
    };
  }
  // margem geral do cliente (regra do dono, 27/10/2026): pelos totais, nao pela media das margens.
  // Soma gondola x pacotes e Vl pct c/ imp. x pacotes dos itens com gondola (pacotes = quantidade x unidades por caixa)
  // e faz (gondola - custo do cliente) / custo do cliente sobre essas somas.
  function margemGeralCliente() {
    let gondola = 0, custo = 0;
    for (const it of itens) {
      const c = calcularItem(it);
      if (!ok(it.vl_gondola) || !ok(c.pctImp) || !c.un || !ok(it.qtde)) continue;
      const pacotes = it.qtde * c.un;
      gondola += it.vl_gondola * pacotes;
      custo += c.pctImp * pacotes;
    }
    return custo > 0 ? (gondola - custo) / custo * 100 : null;
  }

  function somar(lista) {
    const t = { n: lista.length, bruto: null, produtos: null, tributos: null, total: null, peso_liq: null, peso_bruto: null, m3: null, custo: null,
      icms: null, piscofins: null, icms_desc: null, piscofins_desc: null, trib_desc: null, ibscbs: null, ipi_total: null, st_total: null, resultado: null, receita_margem: null, caixas: 0, margem: null };
    for (const it of lista) {
      const c = calcularItem(it);
      for (const k of ['bruto', 'produtos', 'tributos', 'total', 'peso_liq', 'peso_bruto', 'm3', 'custo', 'icms', 'piscofins', 'icms_desc', 'piscofins_desc', 'trib_desc',
        'ibscbs', 'ipi_total', 'st_total', 'resultado', 'receita_margem']) t[k] = soma(t[k], c[k]);
      t.caixas += c.caixas;
    }
    t.desconto = ok(t.bruto) && ok(t.produtos) ? t.bruto - t.produtos : null;
    // margem pelos totais: soma dos resultados / soma dos Vl CX (itens com custo e parametros)
    t.margem = ok(t.resultado) && t.receita_margem > 0 ? t.resultado / t.receita_margem * 100 : null;
    return t;
  }

