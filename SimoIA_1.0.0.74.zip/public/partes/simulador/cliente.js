/*@parte Simulador: busca de cliente. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- busca de cliente (codigo, nome ou fantasia) ---------- */
  let cliAchados = [], cliAtivo = -1, cliTimer = 0, cliPedido = 0;
  function fecharLista() {
    $('cli-lista').hidden = true;
    $('pessoa').setAttribute('aria-expanded', 'false');
    $('pessoa').removeAttribute('aria-activedescendant');
    cliAtivo = -1;
  }
  function mostrarLista(html) {
    $('cli-lista').innerHTML = html;
    $('cli-lista').hidden = false;
    $('pessoa').setAttribute('aria-expanded', 'true');
  }
  function marcarAtivo(i) {
    const lis = $('cli-lista').querySelectorAll('li[data-i]');
    if (!lis.length) return;
    cliAtivo = (i + lis.length) % lis.length;
    lis.forEach((li, k) => li.setAttribute('aria-selected', String(k === cliAtivo)));
    $('pessoa').setAttribute('aria-activedescendant', lis[cliAtivo].id);
    lis[cliAtivo].scrollIntoView({ block: 'nearest' });
  }
  async function buscarClientes(q) {
    const pedido = ++cliPedido;
    mostrarLista('<li class="msg">Buscando…</li>');
    let d;
    try { d = await api('/api/simulador/clientes?q=' + encodeURIComponent(q)); } catch (e) {
      if (e.message !== 'sessao' && pedido === cliPedido) { mostrarLista('<li class="msg">Não foi possível falar com o servidor. Tente de novo em instantes.</li>'); marcarCarga('clientes', false); }
      return;
    }
    if (pedido !== cliPedido) return; // ja digitou outra coisa
    // falha na lista de clientes (ex.: servidor recem-reiniciado): mostra o "Atualizar" (dono, 02/11/2026)
    marcarCarga('clientes', !!d.ok);
    if (!d.ok) { mostrarLista('<li class="msg">' + esc(d.mensagem || 'Não foi possível buscar os clientes.') + '</li>'); return; }
    cliAchados = d.clientes || [];
    if (!cliAchados.length) { mostrarLista('<li class="msg">Nenhum cliente encontrado.</li>'); return; }
    mostrarLista(cliAchados.map((c, i) => '<li role="option" id="cli-op-' + i + '" data-i="' + i + '" aria-selected="false">' +
      '<span class="cli-nome">' + esc(c.codigo) + ' - ' + esc(c.nome) + '</span>' +
      '<span class="cli-det">' + esc([c.fantasia && c.fantasia !== c.nome ? c.fantasia : '', [c.cidade, c.uf].filter(Boolean).join('/'), REGIMES[c.regime] || ''].filter(Boolean).join(' · ')) + '</span></li>').join('') +
      (d.total > cliAchados.length ? '<li class="msg">Mostrando ' + cliAchados.length + ' de ' + d.total + '. Digite mais para filtrar.</li>' : ''));
    marcarAtivo(0);
  }
  $('pessoa').addEventListener('input', () => {
    // mudou o texto: o cliente escolhido deixa de valer (UF e regime voltam a ser da pessoa)
    if (cliente) { cliente = null; $('uf').value = ''; $('regime').value = ''; $('classif').value = ''; suframaSim = false; desenharSuframa(); }
    conferirParametros();
    clearTimeout(cliTimer);
    // 3 espacos = todos os clientes (o servidor entende "*")
    const q = pedeTudo($('pessoa').value) ? '*' : $('pessoa').value.trim();
    if (q !== '*' && q.length < 2 && !/^\d+$/.test(q)) { cliPedido++; fecharLista(); return; }
    cliTimer = setTimeout(() => buscarClientes(q), 250);
  });
  $('pessoa').addEventListener('keydown', (e) => {
    const aberta = !$('cli-lista').hidden;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      if (!aberta) return;
      e.preventDefault();
      marcarAtivo(cliAtivo + (e.key === 'ArrowDown' ? 1 : -1));
    } else if (e.key === 'Enter') {
      if (aberta && cliAtivo >= 0 && cliAchados[cliAtivo]) { e.preventDefault(); escolherCliente(cliAchados[cliAtivo]); }
    } else if (e.key === 'Escape') {
      if (aberta) { e.preventDefault(); fecharLista(); }
    }
  });
  // mousedown (antes do blur do campo) para a escolha valer
  $('cli-lista').addEventListener('mousedown', (e) => {
    const li = e.target.closest('li[data-i]');
    e.preventDefault();
    if (li) escolherCliente(cliAchados[Number(li.dataset.i)]);
  });
  $('pessoa').addEventListener('blur', () => setTimeout(fecharLista, 120));
  $('pessoa').addEventListener('search', () => { if (!$('pessoa').value) { cliPedido++; escolherCliente(null); } }); // "x" do campo

  // "Novo" digitado: vale na hora; vazio volta para a regra
  function percentualValido(el) {
    const v = num(el.value);
    if (el.value.trim() !== '' && (v == null || v < 0 || v > 100)) { el.setCustomValidity('Use um percentual de 0 a 100'); el.reportValidity(); return undefined; }
    el.setCustomValidity('');
    return v;
  }
  // % geral digitado embaixo da chave: vale na hora (0 zera); vazio volta para o carregado da API
  $('tributos').addEventListener('change', (e) => {
    const t = tributos.find((x) => x.id === e.target.dataset.trib);
    if (!t) return;
    const v = percentualValido(e.target);
    if (v === undefined) return;
    t.novo = v;
    desenharTributos();
    desenharItens();
  });
  // descontos padrao: os campos so guardam o padrao dos proximos produtos; a setinha aplica em todos os itens
  function desenharDescPadrao() {
    for (const el of document.querySelectorAll('[data-dpad]')) { const v = descPadrao[Number(el.dataset.dpad)]; el.value = ok(v) ? fmt(v, 2) : ''; }
  }
  document.querySelector('.desc-padrao').addEventListener('change', (e) => {
    if (!e.target.dataset.dpad) return;
    const v = percentualValido(e.target);
    if (v === undefined) return;
    descPadrao[Number(e.target.dataset.dpad)] = v;
    desenharDescPadrao();
    agendarSalvar();
  });
  // offline: calcula os tributos de todos os itens que estao sem (ou com o Vl caixa mudado)
  $('trib-calcular').addEventListener('click', () => {
    if (!itens.concat(aguardando).some(precisaTributo)) { $('info-trib').textContent = 'Todos os itens já estão com os tributos calculados.'; return; }
    calcularTributosDe('todos');
  });
  $('desc-aplicar').addEventListener('click', () => {
    const lista = itens.concat(aguardando);
    if (!lista.length) { $('info-produtos').textContent = 'Sem itens: os descontos padrão já valem para os próximos produtos.'; return; }
    for (const it of lista) { it.des1 = descPadrao[0]; it.des2 = descPadrao[1]; it.des3 = descPadrao[2]; }
    $('info-produtos').textContent = 'Descontos padrão aplicados em ' + lista.length + (lista.length === 1 ? ' item.' : ' itens.');
    desenharItens();
  });
  // chave Sim/Nao de cada tributo (vale para todos os itens)
  // chave "Online" (no quadro Tributos; no celular, junto da Margem Sistema)
  document.addEventListener('click', (e) => {
    if (!e.target.closest('[data-online]')) return;
    tribOnline = !tribOnline;
    guardarOnline();
    $('trib-calcular').hidden = tribOnline;
    desenharTributos();
    if (tribOnline) agendarTributos(); else desenharItens(); // voltou para online: calcula o que ficou pendente
    const nova = document.querySelector('[data-online]');
    if (nova) nova.focus();
  });
  $('tributos').addEventListener('click', (e) => {
    const b = e.target.closest('[data-usar]');
    const t = b && tributos.find((x) => x.id === b.dataset.usar);
    if (!t) return;
    t.usar = !t.usar;
    desenharTributos();
    desenharItens();
    const nova = document.querySelector('#tributos [data-usar="' + t.id + '"]');
    if (nova) nova.focus();
  });
  $('despesas').addEventListener('change', (e) => {
    const d = despesas.find((x) => String(x.id) === e.target.dataset.desp);
    if (!d) return;
    const v = percentualValido(e.target);
    if (v === undefined) return;
    d.digitado = v;
    desenharDespesas();
    desenharItens();
  });

  // "9806 — BALA AMENDOIM..." (escolhido na lista) vale o codigo; senao, varios codigos separados por espaco/virgula
  function codigosDigitados(txt) {
    const out = [];
    for (const parte of String(txt).split(/[,;\n]+/)) {
      const m = parte.match(/^\s*(\S+)\s+—\s/);
      if (m) out.push(m[1]); else out.push(...parte.split(/\s+/));
    }
    return out.map((c) => c.trim()).filter(Boolean);
  }
  // pode adicionar? (configuracoes minimas e lista de produtos carregada); senao avisa
  function podeAdicionar() {
    if (!conferirParametros()) { $('info-produtos').textContent = 'Preencha as configurações acima (cliente, ou UF + regime + classificação, a tabela de preço e o custo) antes de adicionar itens.'; return false; }
    if (!produtos) { $('info-produtos').textContent = 'Aguarde: a lista de produtos ainda está carregando.'; return false; }
    return true;
  }

