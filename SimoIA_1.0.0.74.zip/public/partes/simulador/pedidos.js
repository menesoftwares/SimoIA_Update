/*@parte Simulador: últimos 5 pedidos do cliente. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- ultimos 5 pedidos do cliente (28/10/2026, dono) ----------
   * So busca ao clicar (SQL "pedidos", editavel na Gestao). A grade mostra uma linha por pedido; "Usar itens deste
   * pedido" leva os itens que estao na lista de produtos: quantidade = qtd digitada, Vl Novo = valor digitado e os
   * 3 descontos do pedido. Item que ja esta na simulacao fica com os valores do pedido. Tributos numa chamada so. */
  let pedidosCli = [];
  // menu "Pedidos" (dono, 11/11/2026): abre/fecha; cada opcao fecha o menu antes de abrir a janela
  function fecharMenuPed() { $('pedmenu-menu').hidden = true; $('pedmenu-abrir').setAttribute('aria-expanded', 'false'); }
  $('pedmenu-abrir').addEventListener('click', () => {
    const abrir = $('pedmenu-menu').hidden;
    $('pedmenu-menu').hidden = !abrir;
    $('pedmenu-abrir').setAttribute('aria-expanded', String(abrir));
    if (abrir) $('pedmenu-menu').querySelector('button:not(:disabled)').focus();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#pedmenu')) fecharMenuPed(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('pedmenu-menu').hidden) { fecharMenuPed(); $('pedmenu-abrir').focus(); } });
  $('carregar-ped').addEventListener('click', fecharMenuPed);
  $('ver-pedidos').addEventListener('click', async () => {
    fecharMenuPed();
    if (!cliente) return;
    const cod = String(cliente.codigo);
    $('ped-titulo').textContent = 'Últimos 5 pedidos de ' + cliente.codigo + ' - ' + cliente.nome;
    $('ped-carregando').hidden = false; $('ped-msg').hidden = true; $('ped-tab').hidden = true;
    $('dlg-pedidos').hidden = false;
    $('ped-fechar').focus();
    let d;
    try { d = await api('/api/simulador/pedidos?cliente=' + encodeURIComponent(cod)); } catch (e) { d = { ok: false, mensagem: e.message === 'sessao' ? '' : 'Não foi possível falar com o servidor.' }; }
    if (!cliente || String(cliente.codigo) !== cod || $('dlg-pedidos').hidden) return; // trocou de cliente ou fechou
    $('ped-carregando').hidden = true;
    pedidosCli = d.ok ? d.pedidos || [] : [];
    if (!d.ok || !pedidosCli.length) {
      $('ped-msg').textContent = d.ok ? (d.mensagem || 'Este cliente não tem pedidos de venda.') : (d.mensagem || 'Não foi possível buscar os pedidos.');
      $('ped-msg').hidden = false;
      return;
    }
    $('ped-tab').innerHTML = '<thead><tr><th>Pedido</th><th>Emissão</th><th>Empresa</th><th>Situação</th><th class="num">Itens</th><th class="num">Valor</th><th class="num">Desc. pedido</th><th></th></tr></thead><tbody>' +
      pedidosCli.map((p, i) => '<tr><td>' + esc(p.numero) + '</td><td>' + esc(p.data) + '</td><td>' + esc(p.empresa) + '</td><td>' + esc(p.situacao || '') + '</td>' +
        '<td class="num">' + p.itens.length + '</td><td class="num">' + moeda(p.total) + '</td><td class="num">' + (ok(p.desconto_pedido) && p.desconto_pedido ? moeda(p.desconto_pedido) : '—') + '</td>' +
        '<td><button type="button" class="btn" data-pedido="' + i + '">Usar itens deste pedido</button></td></tr>').join('') + '</tbody>';
    if (CEL.matches) cartoes($('ped-tab')); else $('ped-tab').classList.remove('cartoes'); // celular: um card por pedido
    $('ped-tab').hidden = false;
    $('ped-tab').querySelector('button').focus();
  });
  function fecharPedidos() { $('dlg-pedidos').hidden = true; $('pedmenu-abrir').focus(); }
  $('ped-fechar').addEventListener('click', fecharPedidos);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-pedidos').hidden) fecharPedidos(); });
  $('ped-tab').addEventListener('click', (e) => {
    const b = e.target.closest('[data-pedido]');
    if (b) usarItensDoPedido(pedidosCli[Number(b.dataset.pedido)]);
  });
  // Pedido com itens na simulacao (dono, 04/11/2026): apagar os existentes ou so incrementar (quem ja esta e substituido pelos
  // dados do pedido, nunca duplica; ver usarPedido). Devolve 'apagar', 'incrementar' ou null (cancelou).
  let pmResponder = null, pmFoco = null;
  function perguntarModoPedido(p, trocaCliente) {
    const n = itens.length + aguardando.length;
    if (!n) return Promise.resolve('incrementar'); // sem itens, nao ha o que perguntar
    $('pm-texto').textContent = 'A simulação tem ' + n + (n === 1 ? ' item' : ' itens') + '. O que fazer ao usar o pedido ' + p.numero + '?';
    $('pm-cliente').hidden = !trocaCliente;
    pmFoco = document.activeElement;
    $('dlg-ped-modo').hidden = false;
    $('pm-incrementar').focus();
    return new Promise((resolve) => { pmResponder = resolve; });
  }
  function responderModoPedido(modo) {
    $('dlg-ped-modo').hidden = true;
    const r = pmResponder;
    pmResponder = null;
    if (pmFoco && pmFoco.isConnected) pmFoco.focus();
    if (r) r(modo);
  }
  $('dlg-ped-modo').addEventListener('click', (e) => {
    const b = e.target.closest('[data-modo]');
    if (b) responderModoPedido(b.dataset.modo);
    else if (e.target.id === 'pm-cancelar' || e.target === $('dlg-ped-modo')) responderModoPedido(null);
  });
  // captura: o Esc cancela so a pergunta, sem fechar a janela de pedidos que esta embaixo
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || $('dlg-ped-modo').hidden) return;
    e.stopPropagation();
    responderModoPedido(null);
  }, true);
  // "Usar itens deste pedido": confere as Configuracoes antes de perguntar, para nao apagar itens e depois nao poder adicionar
  async function usarItensDoPedido(p) {
    if (!p) return;
    if (!podeAdicionar()) { fecharPedidos(); return; }
    const modo = await perguntarModoPedido(p, false);
    if (!modo) return;
    if (modo === 'apagar') { itens = []; aguardando = []; }
    await usarPedido(p);
  }
  // tambem usado pelo "Carregar pedido" (fechar = a janela de onde veio)
  async function usarPedido(p, fechar = fecharPedidos) {
    if (!p) return;
    if (!podeAdicionar()) { fechar(); return; }
    let novos = 0, atualizados = 0;
    const fora = [], semTabela = [], semPreco = [];
    const valor = (v) => (ok(v) && v > 0 ? v : null);
    // tabela de cada item (dono, 04/11/2026): a do pedido. Fora da lista de tabelas (ex.: inativa) ou vazia: sem valor de tabela.
    // A das Configuracoes: o item segue o campo (tab null). SQL sem a coluna COD_TABPRECO (undefined): nao mexe na tabela do item.
    const tabDoPedido = (x) => {
      const w = tabelaDoCodigo(x.cod_tabpreco);
      if (!w) return TAB_INDISPONIVEL;
      return w === $('tabela').value ? null : w;
    };
    const tabs = [...new Set(p.itens.filter((x) => x.cod_tabpreco !== undefined && produtos.has(x.codigo)).map(tabDoPedido)
      .filter((t) => t && t !== TAB_INDISPONIVEL && !precoCache[t]))];
    if (tabs.length) {
      processando('preco', 'Atualizando os dados', 'Carregando os preços da tabela…');
      try {
        for (const t of tabs) {
          let carregou = false;
          try { carregou = await garantirPrecos(t); } catch (e) { /* fica sem preco */ }
          if (!carregou) marcarCarga('precos', false); // o "Atualizar" busca de novo
        }
      } finally { processando('preco'); }
    }
    for (const x of p.itens) {
      const prod = produtos.get(x.codigo);
      if (!prod) { fora.push(x.codigo); continue; }
      let it = itens.find((i) => i.codigo === x.codigo) || aguardando.find((i) => i.codigo === x.codigo);
      const novo = !it;
      if (novo) it = novoItem(prod);
      if (x.cod_tabpreco !== undefined) {
        it.tab = tabDoPedido(x);
        aplicarPreco(it);
        if (it.tab === TAB_INDISPONIVEL) semTabela.push(x.codigo);
        else if (!ok(it.vl_tabela)) semPreco.push(x.codigo);
      }
      it.qtde = valor(x.qtd) || 1;
      // Vl Novo nunca vem do pedido (dono, 30/10/2026): sempre limpo, vale o Vl tabela
      it.caixa_digitado = false; it.vl_caixa = it.vl_tabela;
      it.des1 = valor(x.des1); it.des2 = valor(x.des2); it.des3 = valor(x.des3);
      it.pct_simu = null;
      if (novo) { aguardando.push(it); novos++; } else atualizados++;
    }
    const partes = [];
    if (novos) partes.push(novos + (novos === 1 ? ' item adicionado' : ' itens adicionados'));
    if (atualizados) partes.push(atualizados + (atualizados === 1 ? ' item já estava e ficou' : ' itens já estavam e ficaram') + ' com os valores do pedido');
    if (fora.length) partes.push(fora.length + (fora.length === 1 ? ' item não está' : ' itens não estão') + ' na lista de produtos (' + fora.join(', ') + ')');
    if (semTabela.length) partes.push(semTabela.length + (semTabela.length === 1 ? ' item ficou' : ' itens ficaram') + ' sem valor de tabela porque a tabela do pedido não está mais disponível (' + semTabela.join(', ') + ')');
    if (semPreco.length) partes.push(semPreco.length + (semPreco.length === 1 ? ' item ficou' : ' itens ficaram') + ' sem preço na tabela do pedido (' + semPreco.join(', ') + ')');
    const msg = 'Pedido ' + p.numero + ' de ' + p.data + ': ' + (partes.join('; ') || 'nenhum item') + '.';
    fechar();
    avisoDepois = msg; // aparece quando os tributos voltarem
    avisoAguardando();
    if (!aguardando.length) $('info-produtos').textContent = msg;
    // tributos ja calculados depois de carregar o pedido, mesmo com a chave Online em Nao (dono, 17/11/2026;
    // vale para o "Carregar pedido" e para os "Últimos 5 pedidos"): calcula agora, sem esperar o botao
    if (conferirParametros()) calcularTributosDe('todos');
    desenharItens();
  }
