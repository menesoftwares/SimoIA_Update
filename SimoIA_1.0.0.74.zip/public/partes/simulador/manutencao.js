/*@parte Simulador: manutenção: parâmetros por UF. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- Manutencao (dono, 02/11/2026): parametros por UF de venda, que sairam da Gestao › Simulador ----------
   * Salvar grava na tabela simulador_param_uf e a tela ja passa a usar os novos (a linha Regra do quadro Parametros). */
  let mnDados = null;
  const mnNum = (v) => (v == null || v === '' || !isFinite(Number(v)) ? '' : Number(v).toLocaleString('pt-BR', { maximumFractionDigits: 4 }));
  const mnLer = (t) => { t = String(t || '').trim(); if (!t) return null; const n = Number(t.includes(',') ? t.replace(/\./g, '').replace(',', '.') : t); return isFinite(n) ? n : NaN; };
  function mnMsg(texto, tipo) { $('mn-msg').textContent = texto || ''; $('mn-msg').className = tipo || ''; $('mn-msg').hidden = !texto; }
  function mnSomar(tr) {
    let total = 0, certo = true;
    for (const i of tr.querySelectorAll('input[data-col]')) {
      if (i.dataset.col === 'comissao') continue;
      const n = mnLer(i.value);
      if (n == null || isNaN(n)) { certo = false; continue; }
      total += n;
    }
    tr.querySelector('.total').textContent = certo ? total.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%' : '—';
  }
  function mnDesenhar() {
    const cols = mnDados.colunas || [], ufs = Object.keys(mnDados.param_uf || {}).sort();
    $('mn-tab').innerHTML = '<thead><tr><th>UF</th><th>Margem total</th>' + cols.map((c) => '<th>' + esc(c.nome) + '</th>').join('') + '</tr></thead><tbody>' +
      ufs.map((uf) => '<tr data-uf="' + esc(uf) + '"><td>' + esc(uf) + '</td><td class="total"></td>' +
        cols.map((c) => '<td><input type="text" inputmode="decimal" data-col="' + esc(c.col) + '" value="' + esc(mnNum(mnDados.param_uf[uf][c.col])) + '" aria-label="' + esc(uf + ' ' + c.nome) + '"></td>').join('') + '</tr>').join('') + '</tbody>';
    for (const tr of $('mn-tab').querySelectorAll('tbody tr')) mnSomar(tr);
    $('mn-tab').hidden = false;
    $('mn-salvar').disabled = false;
  }
  async function abrirManutencao() {
    mnMsg(''); $('mn-tab').hidden = true; $('mn-salvar').disabled = true; $('mn-carregando').hidden = false;
    $('dlg-manut').hidden = false;
    $('mn-fechar').focus();
    try {
      const d = await api('/api/simulador/manutencao');
      if ($('dlg-manut').hidden) return;
      if (!d.ok) { mnMsg(d.mensagem || 'Não foi possível carregar os parâmetros.', 'erro'); return; }
      mnDados = d;
      mnDesenhar();
    } catch (e) { if (e.message !== 'sessao') mnMsg('Não foi possível falar com o servidor.', 'erro'); }
    finally { $('mn-carregando').hidden = true; }
  }
  function fecharManutencao() { $('dlg-manut').hidden = true; $('manut-sim').focus(); }
  $('manut-sim').addEventListener('click', abrirManutencao);
  $('mn-fechar').addEventListener('click', fecharManutencao);
  $('mn-tab').addEventListener('input', (e) => { const tr = e.target.closest('tr'); if (tr) mnSomar(tr); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-manut').hidden) fecharManutencao(); });
  $('mn-salvar').addEventListener('click', async () => {
    const param_uf = {};
    for (const tr of $('mn-tab').querySelectorAll('tbody tr')) {
      const linha = {};
      for (const i of tr.querySelectorAll('input[data-col]')) {
        const n = mnLer(i.value);
        if (n !== null && (isNaN(n) || n < 0 || n > 100)) { mnMsg('Valor inválido em ' + tr.dataset.uf + ' (use de 0 a 100).', 'erro'); i.focus(); return; }
        linha[i.dataset.col] = n;
      }
      param_uf[tr.dataset.uf] = linha;
    }
    $('mn-salvar').disabled = true;
    mnMsg('Salvando…');
    try {
      const d = await api('/api/simulador/manutencao', { param_uf });
      if (!d.ok) { mnMsg(d.mensagem || 'Não foi possível salvar.', 'erro'); return; }
      mnDados = d;
      mnDesenhar();
      // a simulacao aberta ja passa a usar os novos parametros (linha Regra)
      paramUf = d.param_uf || {};
      desenharDespesas(); desenharItens();
      mnMsg(d.mensagem || 'Parâmetros salvos.', 'ok');
    } catch (e) {
      if (e.message !== 'sessao') mnMsg('Não foi possível falar com o servidor.', 'erro');
    } finally { $('mn-salvar').disabled = false; }
  });

