/*@parte Simulador: Opções Simulação: salvar com nome e carregar. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- Opcoes Simulacao (dono, 11/11/2026): salvar com nome e carregar (tabela simulador_salvas, por usuario) ----------
   * Salvar: o mesmo estado da "simulacao anterior" (estadoAtual), com um nome; nome repetido pergunta se substitui.
   * Carregar: a salva vira a "simulacao anterior" e a tela recarrega abrindo ela sem perguntar (mesma restauracao). */
  // aviso amarelo (comp-status): some 12 s depois da ultima mensagem; "…" no fim = ainda trabalhando, fica
  { const st = $('comp-status'); let tm = null;
    new MutationObserver(() => { clearTimeout(tm); const t = st.textContent; if (t && !/…$/.test(t)) tm = setTimeout(() => { if (st.textContent === t) st.textContent = ''; }, 12000); })
      .observe(st, { childList: true, characterData: true, subtree: true }); }
  function fecharMenuOpsim() { $('opsim-menu').hidden = true; $('opsim-abrir').setAttribute('aria-expanded', 'false'); }
  $('opsim-abrir').addEventListener('click', () => {
    const abrir = $('opsim-menu').hidden;
    $('opsim-salvar').disabled = !itens.length || !simPronta; // sem itens nao ha o que salvar
    $('opsim-salvar').title = !itens.length ? 'Inclua produtos para salvar a simulação' : (!simPronta ? 'Aguarde a simulação terminar de carregar' : '');
    const pendTrib = itens.some(precisaTributo); // Margem geral ainda nao calculada (dono, 11/11/2026)
    for (const id of ['opsim-imprimir', 'opsim-excel', 'opsim-excel-pers']) {
      $(id).disabled = !itens.length || pendTrib;
      $(id).title = !itens.length ? 'Inclua produtos na simulação' : pendTrib ? MSG_TRIB_PEND : '';
    }
    // sem colunas montadas na Gestao, o Excel personalizado fica desabilitado
    if (!excelPers || !excelPers.colunas.length) { $('opsim-excel-pers').disabled = true; $('opsim-excel-pers').title = 'O Excel personalizado ainda não foi montado (Gestão do sistema › Simulador)'; }
    $('opsim-menu').hidden = !abrir;
    $('opsim-abrir').setAttribute('aria-expanded', String(abrir));
    if (abrir) $('opsim-menu').querySelector('button:not(:disabled)').focus();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#opsim')) fecharMenuOpsim(); });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (!$('opsim-menu').hidden) { fecharMenuOpsim(); $('opsim-abrir').focus(); }
    else if (!$('dlg-sim-salvar').hidden) fecharSalvarSim();
    else if (!$('dlg-sim-carregar').hidden) fecharCarregarSim();
  });
  let simNome = ''; // nome da simulacao salva aberta (sugerido no proximo "Salvar")
  try { simNome = sessionStorage.getItem('sim_nome') || ''; sessionStorage.removeItem('sim_nome'); } catch (e) { /* sem sugestao */ }
  const msgDlg = (id, texto) => { $(id).textContent = texto || ''; $(id).hidden = !texto; };
  function fecharSalvarSim() { $('dlg-sim-salvar').hidden = true; $('opsim-abrir').focus(); }
  $('opsim-salvar').addEventListener('click', () => {
    fecharMenuOpsim();
    $('ss-nome').value = simNome;
    msgDlg('ss-msg', '');
    $('ss-ok').disabled = false;
    $('dlg-sim-salvar').hidden = false;
    $('ss-nome').focus(); $('ss-nome').select();
  });
  $('ss-cancelar').addEventListener('click', fecharSalvarSim);
  $('ss-nome').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('ss-ok').click(); } });
  $('ss-ok').addEventListener('click', async () => {
    const nome = $('ss-nome').value.replace(/\s+/g, ' ').trim();
    if (!nome) { msgDlg('ss-msg', 'Informe um nome para a simulação.'); $('ss-nome').focus(); return; }
    $('ss-ok').disabled = true;
    try {
      const dados = estadoAtual();
      let d = await api('/api/simulador/salvas', { nome, dados });
      if (!d.ok && d.existe) {
        if (!(await perguntar({ titulo: 'Salvar simulação', texto: 'Já existe uma simulação salva com o nome "' + nome + '". Substituir?', sim: 'Substituir' }))) { $('ss-ok').disabled = false; $('ss-nome').focus(); return; }
        d = await api('/api/simulador/salvas', { nome, dados, substituir: true });
      }
      if (!d.ok) { msgDlg('ss-msg', d.mensagem || 'Não foi possível salvar a simulação.'); $('ss-ok').disabled = false; return; }
      simNome = nome;
      fecharSalvarSim();
      $('comp-status').textContent = d.mensagem || 'Simulação salva.';
    } catch (e) {
      if (e.message === 'sessao') return;
      msgDlg('ss-msg', 'Não foi possível falar com o servidor.');
      $('ss-ok').disabled = false;
    }
  });
  function fecharCarregarSim() { $('dlg-sim-carregar').hidden = true; $('opsim-abrir').focus(); }
  $('sc-fechar').addEventListener('click', fecharCarregarSim);
  async function listarSalvas() {
    $('sc-tab').hidden = true; msgDlg('sc-msg', '');
    $('sc-carregando').hidden = false;
    let d;
    try { d = await api('/api/simulador/salvas'); } catch (e) { if (e.message === 'sessao') return; d = { ok: false, mensagem: 'Não foi possível falar com o servidor.' }; }
    finally { $('sc-carregando').hidden = true; }
    if (!d.ok) { msgDlg('sc-msg', d.mensagem || 'Não foi possível ler as simulações salvas.'); return; }
    const lista = d.salvas || [];
    if (!lista.length) { msgDlg('sc-msg', 'Você ainda não tem simulações salvas. Use "Opções Simulação › Salvar".'); return; }
    const quando = (t) => t ? t.slice(8, 10) + '/' + t.slice(5, 7) + '/' + t.slice(0, 4) + ' ' + t.slice(11, 16) : '';
    $('sc-tab').innerHTML = '<thead><tr><th>Nome</th><th>Salva em</th><th></th></tr></thead><tbody>' + lista.map((x) =>
      '<tr><td>' + esc(x.nome) + '</td><td>' + esc(quando(x.salvo_em)) + '</td><td class="num">' +
      '<button type="button" class="btn" data-sc-abrir="' + x.id + '">Carregar</button> ' +
      '<button type="button" class="btn-sec" data-sc-excluir="' + x.id + '" data-nome="' + esc(x.nome) + '" aria-label="Excluir ' + esc(x.nome) + '">Excluir</button></td></tr>').join('') + '</tbody>';
    $('sc-tab').hidden = false;
    if (CEL.matches) cartoes($('sc-tab'));
  }
  $('opsim-carregar').addEventListener('click', () => {
    fecharMenuOpsim();
    $('dlg-sim-carregar').hidden = false;
    $('sc-fechar').focus();
    listarSalvas();
  });
  $('sc-tab').addEventListener('click', async (e) => {
    const x = e.target.closest('[data-sc-excluir]');
    if (x) {
      if (!(await perguntar({ titulo: 'Excluir simulação', texto: 'Excluir a simulação salva "' + x.dataset.nome + '"?', sim: 'Excluir' }))) return;
      try {
        const d = await api('/api/simulador/salvas', { excluir: Number(x.dataset.scExcluir) });
        if (!d.ok) { msgDlg('sc-msg', d.mensagem || 'Não foi possível excluir.'); return; }
      } catch (er) { if (er.message !== 'sessao') msgDlg('sc-msg', 'Não foi possível falar com o servidor.'); return; }
      listarSalvas();
      return;
    }
    const b = e.target.closest('[data-sc-abrir]');
    if (!b) return;
    if (itens.length && !(await perguntar({ titulo: 'Carregar simulação', texto: 'A simulação atual (cliente, configurações e itens) será substituída. Se quiser guardá-la, use "Salvar" antes.', sim: 'Carregar' }))) return;
    b.disabled = true;
    try {
      const d = await api('/api/simulador/salvas?id=' + encodeURIComponent(b.dataset.scAbrir));
      if (!d.ok) { msgDlg('sc-msg', d.mensagem || 'Não foi possível abrir a simulação salva.'); b.disabled = false; return; }
      // para de guardar a atual (senao a gravacao agendada sobrescreveria a que vai abrir)
      simPronta = false; clearTimeout(salvarTimer);
      const g = await api('/api/simulador/ultima', { dados: d.dados });
      if (!g.ok) { simPronta = true; msgDlg('sc-msg', g.mensagem || 'Não foi possível abrir a simulação salva.'); b.disabled = false; return; }
      try { sessionStorage.setItem('sim_abrir', '1'); sessionStorage.setItem('sim_nome', d.nome || ''); } catch (er) { /* pergunta ao abrir */ }
      location.reload();
    } catch (er) {
      if (er.message === 'sessao') return;
      simPronta = true;
      msgDlg('sc-msg', 'Não foi possível falar com o servidor.');
      b.disabled = false;
    }
  });

