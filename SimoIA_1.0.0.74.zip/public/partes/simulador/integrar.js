/*@parte Simulador: integrar pedido ou orçamento. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- integrar o pedido no sistema (28/10/2026, dono) ----------
   * So para quem tem a liberacao (Gestao › Usuarios › "Integrar pedidos"). Precisa de cliente, itens e todos com preco
   * na tabela de preco (o item vai com a tabela). Valor = Vl Novo (ou o da tabela) e os 3 descontos; desconto simulado
   * (Des. simu.) nao vai: pede para passar aos campos Des. 1/2/3. O servidor monta o JSON (vendedor do cadastro, codigo
   * da tabela, condicao e parcelas: vencimento = hoje + dias, valor = total x amortizacao) e grava. */
  let podeIntegrar = false, condicoes = null, intCondicao = null;
  // todos os motivos do "Integrar" estar travado, em linguagem simples (dono, 30/10/2026: aparecem no fim da tela)
  function motivosSemIntegrar() {
    const m = [];
    const lista = (cods) => (cods.length > 8 ? cods.slice(0, 8).join(', ') + ' e mais ' + (cods.length - 8) : cods.join(', '));
    if (!cliente) m.push('Sem cliente na simulação: escolha o cliente (só UF, regime e classificação não bastam para integrar).');
    if (!itens.length) m.push('Nenhum item na simulação.');
    if (aguardando.length) m.push('Aguarde: os tributos ainda estão sendo calculados.');
    if (!$('tipodoc').value) m.push('Escolha o Tipo Docto.');
    if (!$('tabela').value) m.push('Escolha a tabela de preço.');
    else {
      const semTab = itens.filter((it) => !ok(it.vl_tabela) || !(it.vl_tabela > 0)).map((it) => it.codigo);
      if (semTab.length) m.push((semTab.length === 1 ? 'Item ' : 'Itens ') + lista(semTab) + ' sem preço na tabela de preço. Escolha outra tabela no botão > ao lado do Vl tabela.');
    }
    // tributos pendentes (botao laranja do item; dono, 30/10/2026): nao integra sem os tributos calculados
    const pend = itens.filter(precisaTributo).map((it) => it.codigo);
    if (pend.length) m.push('Há tributos pendentes de atualização ' + (pend.length === 1 ? 'no item ' : 'nos itens ') + lista(pend) + ': clique em "Calcular tributos" (ou no botão amarelo ↻ do item).');
    const semLugar = itens.filter((it) => descontosIntegrar(it) === null).map((it) => it.codigo);
    if (semLugar.length) m.push((semLugar.length === 1 ? 'Item ' : 'Itens ') + lista(semLugar) + ' com Des. simu. e os três descontos já preenchidos: deixe um desconto vazio ou apague o valor simulado.');
    return m;
  }
  const motivoSemIntegrar = () => motivosSemIntegrar().filter((x) => !/^Item.*Des\. simu\./.test(x))[0] || '';
  /* descontos que vao no pedido (dono, 28/10/2026): Des. 1, 2 e 3 como estao; se o item tem desconto simulado
   * (Des. simu.), ele vai na 1a posicao vazia ou zero (preenchido = diferente de 0, mesmo negativo). Os descontos sao em
   * cascata, entao a posicao nao muda o preco. null = os 3 preenchidos e ha desconto simulado (a integracao trava). */
  function descontosIntegrar(it) {
    // sempre 2 casas (dono, 28/10/2026)
    const duas = (v) => Math.round(v * 100) / 100;
    const des = [it.des1, it.des2, it.des3].map((v) => (ok(v) && duas(v) !== 0 ? duas(v) : null));
    const simu = ok(it.pct_simu) ? calcularItem(it).desSimu : null;
    if (!ok(simu) || duas(simu) === 0) return des;
    const livre = des.findIndex((v) => v === null);
    if (livre < 0) return null;
    des[livre] = duas(simu);
    return des;
  }
  function atualizarIntegrar() {
    if (!podeIntegrar) return;
    const m = motivoSemIntegrar();
    // so desabilita enquanto falta algo (dono, 28/10/2026: sem frase ao lado do botao); o motivo fica na dica do
    // botao (passar o mouse), para saber o que falta
    $('integrar').disabled = !!m;
    $('integrar-dica').title = m ? 'Para integrar: ' + m : '';
    // fim da tela: a lista completa do que falta (so para quem pode integrar)
    const todos = motivosSemIntegrar();
    $('aviso-integrar').hidden = !todos.length;
    $('aviso-integrar-lista').innerHTML = todos.map((x) => '<li>' + esc(x) + '</li>').join('');
  }
  // previa das parcelas (o servidor calcula de novo do mesmo jeito)
  function parcelasPrevia(c, total) {
    const ps = [...c.parcelas].sort((a, b) => a.sequencia - b.sequencia);
    const soma = ps.reduce((s, p) => s + p.amortizacao, 0) || 100;
    let usado = 0;
    return ps.map((p, i) => {
      const d = new Date(); d.setDate(d.getDate() + p.dias);
      const v = i === ps.length - 1 ? Math.round((total - usado) * 100) / 100 : Math.round(total * p.amortizacao / soma * 100) / 100;
      usado += v;
      return { n: i + 1, venc: d.toLocaleDateString('pt-BR'), dias: p.dias, valor: v };
    });
  }
  function desenharCondicoes() {
    const q = semAc($('int-busca').value.trim());
    const lista = (condicoes || []).filter((c) => !q || semAc(c.codigo + ' ' + c.descricao).includes(q)).slice(0, 300);
    $('int-cond').innerHTML = lista.map((c) => '<option value="' + esc(c.id) + '"' + (intCondicao && intCondicao.id === c.id ? ' selected' : '') + '>' +
      esc(c.descricao + ' (' + c.codigo + ') · ' + c.parcelas.length + (c.parcelas.length === 1 ? ' parcela' : ' parcelas')) + '</option>').join('');
  }
  function desenharParcelas() {
    const t = somar(itens);
    $('int-confirmar').disabled = !intCondicao;
    $('int-parc').innerHTML = !intCondicao ? '' : '<thead><tr><th>Parcela</th><th>Dias</th><th>Vencimento</th><th class="num">Valor</th></tr></thead><tbody>' +
      parcelasPrevia(intCondicao, t.total).map((p) => '<tr><td>' + p.n + '</td><td>' + p.dias + '</td><td>' + p.venc + '</td><td class="num">' + moeda(p.valor) + '</td></tr>').join('') + '</tbody>';
  }
  let intIntegrado = false; // o ultimo envio deu certo: o "Fechar" pergunta se comeca uma nova simulacao
  function passoInt(n) { for (const i of [0, 1, 2, 3, 4]) $('int-passo' + i).hidden = i !== n; }
  // pedido (Grava_JSON_as_pv_terc) ou orcamento (Grava_JSON_as_orc_terc): escolhido no passo 0 (dono, 29/10/2026)
  let intTipo = 'pedido';
  const nomeTipo = () => (intTipo === 'orcamento' ? 'orçamento' : 'pedido');
  function resultadoInt(texto, erro) {
    intIntegrado = !erro;
    $('int-resultado').className = erro ? 'int-erro' : 'int-ok';
    $('int-resultado').textContent = texto;
    passoInt(3);
    $('int-ok').focus();
  }
  function fecharIntegrar() { $('dlg-integrar').hidden = true; intIntegrado = false; $('integrar').focus(); }
  $('integrar').addEventListener('click', async () => {
    const m = motivoSemIntegrar();
    if (m) { atualizarIntegrar(); return; }
    const t = somar(itens);
    $('int-titulo').textContent = 'Integrar';
    $('int-resumo').textContent = 'Cliente ' + cliente.codigo + ' - ' + cliente.nome + ' · ' + itens.length + (itens.length === 1 ? ' item' : ' itens') + ' · total ' + moeda(t.total) +
      ' · tabela ' + $('tabela').selectedOptions[0].text;
    $('dlg-integrar').hidden = false;
    // desconto simulado vai na 1a posicao livre (Des. 1, 2, 3); com os 3 ja preenchidos nao ha onde por: trava
    const semLugar = itens.filter((it) => descontosIntegrar(it) === null).map((it) => it.codigo);
    if (semLugar.length) {
      resultadoInt('Advertência na integração: ' + (semLugar.length === 1 ? 'o item ' : 'os itens ') + semLugar.join(', ') +
        (semLugar.length === 1 ? ' tem' : ' têm') + ' desconto simulado (Des. simu.) e os três descontos já preenchidos. Deixe um dos descontos vazio (ou zero) ou apague o valor simulado; depois integre de novo.', true);
      return;
    }
    passoInt(0);
    $('int-tipo-pedido').focus();
  });
  async function escolherTipoInt(tipo) {
    intTipo = tipo;
    $('int-titulo').textContent = 'Integrar ' + nomeTipo();
    $('int-confirmar').textContent = 'Integrar ' + nomeTipo();
    $('int-andando').textContent = 'Integrando o ' + nomeTipo() + '…';
    passoInt(1);
    $('int-busca').value = '';
    if (!condicoes) {
      $('int-cond').innerHTML = '<option>Carregando as condições…</option>';
      let d;
      try { d = await api('/api/simulador/condicoes-pagto'); } catch (e) { d = { ok: false, mensagem: 'Não foi possível falar com o servidor.' }; }
      if (!d.ok) { resultadoInt(d.mensagem || 'Não foi possível ler as condições de pagamento.', true); return; }
      condicoes = d.condicoes || [];
    }
    desenharCondicoes();
    desenharParcelas();
    $('int-busca').focus();
  }
  $('int-tipo-pedido').addEventListener('click', () => escolherTipoInt('pedido'));
  $('int-tipo-orcamento').addEventListener('click', () => escolherTipoInt('orcamento'));
  $('int-tipo-cancelar').addEventListener('click', fecharIntegrar);
  $('int-busca').addEventListener('input', desenharCondicoes);
  $('int-cond').addEventListener('change', () => { intCondicao = (condicoes || []).find((c) => c.id === $('int-cond').value) || null; desenharParcelas(); });
  $('int-cancelar').addEventListener('click', fecharIntegrar);
  $('int-ok').addEventListener('click', () => {
    if (!intIntegrado) { fecharIntegrar(); return; }
    passoInt(4); // integrado: pergunta se limpa e comeca uma nova simulacao
    $('int-nova-sim').focus();
  });
  $('int-nova-sim').addEventListener('click', () => { $('int-nova-sim').disabled = true; limparSimulacao(); }); // como o "Limpar simulacao", sem perguntar de novo
  $('int-nova-nao').addEventListener('click', fecharIntegrar);
  $('int-confirmar').addEventListener('click', async () => {
    if (!intCondicao || motivoSemIntegrar()) return;
    const t = somar(itens);
    passoInt(2);
    let d;
    try {
      d = await api('/api/simulador/integrar', {
        tipo: intTipo, tipo_doc: $('tipodoc').value, cliente: String(cliente.codigo), tabela: $('tabela').value, condicao: intCondicao.id, total: t.total,
        // tabela de cada item (dono, 02/11/2026): a propria (botao ">") ou a das Configuracoes
        itens: itens.map((it) => { const d = descontosIntegrar(it); return { codigo: it.codigo, tabela: tabelaDoItem(it), qtd: it.qtde, vl_unit: it.vl_caixa, des1: d[0], des2: d[1], des3: d[2] }; })
      });
    } catch (e) { d = { ok: false, mensagem: e.message === 'sessao' ? '' : 'Não foi possível falar com o servidor. Confira no sistema se o ' + nomeTipo() + ' entrou antes de tentar de novo.' }; }
    // confirmacao so na janela; o registro fica no log do sistema e no historico (dono, 28/10/2026)
    if (d.ok) resultadoInt(d.mensagem || ((intTipo === 'orcamento' ? 'Orçamento ' : 'Pedido ') + d.pedido + ' integrado com sucesso.'), false);
    else resultadoInt(d.mensagem || 'Não foi possível integrar o ' + nomeTipo() + '.', true);
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-integrar').hidden && $('int-passo2').hidden) fecharIntegrar(); });

