/*@parte Simulador: carregar pedido e início da tela. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- "Carregar pedido" (30/10/2026, dono) ----------
   * Digita o numero, busca (SQL "pedido_numero", editavel na Gestao) e "Carregar" poe o cliente do pedido e todos os
   * itens (quantidade, Vl Novo limpo e os 3 descontos). Com itens na simulacao, pergunta se apaga ou so incrementa (perguntarModoPedido).
   * Precisa de Tipo Docto, tabela de preco e custo escolhidos (os precos e os tributos dependem deles). */
  let pedidosNum = [];
  const REGIME_DO_COD = { SI: 'simples', LP: 'presumido', LR: 'real', IS: 'isento' };
  function abrirCarregarPedido() {
    $('cp-numero').value = '';
    $('cp-msg').hidden = true; $('cp-tab').hidden = true; $('cp-carregando').hidden = true;
    $('dlg-carregar').hidden = false;
    $('cp-numero').focus();
  }
  function fecharCarregarPedido() { $('dlg-carregar').hidden = true; $('pedmenu-abrir').focus(); }
  async function buscarPedidoNumero() {
    const num = $('cp-numero').value.trim();
    if (!/^\d{1,12}$/.test(num)) { $('cp-msg').textContent = 'Digite o número do pedido (só números).'; $('cp-msg').hidden = false; return; }
    $('cp-carregando').hidden = false; $('cp-msg').hidden = true; $('cp-tab').hidden = true;
    let d;
    try { d = await api('/api/simulador/pedido-numero?numero=' + encodeURIComponent(num)); } catch (e) { d = { ok: false, mensagem: e.message === 'sessao' ? '' : 'Não foi possível falar com o servidor.' }; }
    if ($('dlg-carregar').hidden || $('cp-numero').value.trim() !== num) return; // fechou ou trocou o numero
    $('cp-carregando').hidden = true;
    pedidosNum = d.ok ? d.pedidos || [] : [];
    if (!d.ok || !pedidosNum.length) {
      $('cp-msg').textContent = d.mensagem || (d.ok ? 'Pedido ' + num + ' não encontrado.' : 'Não foi possível buscar o pedido.');
      $('cp-msg').hidden = false;
      return;
    }
    $('cp-tab').innerHTML = '<thead><tr><th>Pedido</th><th>Emissão</th><th>Empresa</th><th>Cliente</th><th>Situação</th><th class="num">Itens</th><th class="num">Valor</th><th></th></tr></thead><tbody>' +
      pedidosNum.map((p, i) => '<tr><td>' + esc(p.numero) + '</td><td>' + esc(p.data) + '</td><td>' + esc(p.empresa) + '</td>' +
        '<td>' + esc(p.cliente ? p.cliente.codigo + ' - ' + p.cliente.nome : '—') + '</td><td>' + esc(p.situacao || '') + '</td>' +
        '<td class="num">' + p.itens.length + '</td><td class="num">' + moeda(p.total) + '</td>' +
        '<td><button type="button" class="btn" data-carregar="' + i + '">Carregar</button></td></tr>').join('') + '</tbody>';
    if (CEL.matches) cartoes($('cp-tab')); else $('cp-tab').classList.remove('cartoes');
    $('cp-tab').hidden = false;
    $('cp-tab').querySelector('button').focus();
  }
  // Carregar pedido sempre ativo (dono, 11/11/2026): o que estiver vazio nas Configuracoes vem do pedido. Tipo Docto: o do
  // pedido (SQL com COD_TIPO_DOCTO), se estiver na lista; tabela de preco: a mais usada nos itens do pedido; custo: o
  // primeiro da lista (como para quem nao escolhe custo). O que ja estiver escolhido fica.
  async function configuracoesDoPedido(p) {
    if (!$('tipodoc').value && p.tipo_doc && [...$('tipodoc').options].some((o) => o.value === p.tipo_doc)) $('tipodoc').value = p.tipo_doc;
    if (!$('tabela').value) {
      const conta = new Map();
      for (const x of p.itens) { const w = tabelaDoCodigo(x.cod_tabpreco); if (w) conta.set(w, (conta.get(w) || 0) + 1); }
      const w = [...conta.entries()].sort((a, b) => b[1] - a[1])[0];
      if (w) { $('tabela').value = w[0]; await aoTrocarTabela(); }
    }
    if (!$('custo').value) {
      const o = [...$('custo').options].find((x) => x.value && !x.disabled);
      if (o) { $('custo').value = o.value; await aoTrocarCusto(); }
    }
    conferirParametros();
  }
  async function carregarPedido(p) {
    if (!p || !p.cliente) return;
    const modo = await perguntarModoPedido(p, true);
    if (!modo) return;
    $('cp-carregando').hidden = false; $('cp-tab').hidden = true;
    if (modo === 'apagar') { itens = []; aguardando = []; }
    // cliente: o da lista de clientes (cadastro completo, com vendedor); fora da lista, os dados do cadastro vindos do pedido
    let c = null;
    try {
      const r = await api('/api/simulador/clientes?q=' + encodeURIComponent(p.cliente.codigo));
      c = r.ok && (r.clientes || []).find((x) => String(x.codigo) === String(p.cliente.codigo)) || null;
    } catch (e) { /* segue com os dados do pedido */ }
    let aviso = '';
    if (c) escolherCliente(c);
    else {
      escolherCliente(null);
      $('pessoa').value = '';
      $('uf').value = UFS.includes(p.cliente.uf) ? p.cliente.uf : '';
      cidadeQuer = p.cliente.cidade ? { nome: p.cliente.cidade } : null; // pelo nome, nas cidades da UF
      $('regime').value = REGIME_DO_COD[p.cliente.regime_cod] || '';
      $('classif').value = classificacoes.some((x) => x.codigo === p.cliente.classif_icms) ? p.cliente.classif_icms : '';
      suframaSim = !!p.cliente.suframa; desenharSuframa();
      aviso = ' O cliente ' + p.cliente.codigo + ' não está na lista de clientes do Simulador: usei a UF, o regime e a classificação do cadastro dele.';
    }
    await configuracoesDoPedido(p);
    await usarPedido(p, fecharCarregarPedido);
    if (aviso) { avisoDepois += aviso; if (!aguardando.length) $('info-produtos').textContent += aviso; }
  }
  // janela do "Copiar" do Des. simu.
  $('dlg-copiar').addEventListener('click', (e) => {
    const b = e.target.closest('[data-copiar]');
    if (b) { $('dlg-copiar').hidden = true; copiarSimu(b.dataset.copiar); return; }
    if (e.target.id === 'cop-cancelar' || e.target === $('dlg-copiar')) $('dlg-copiar').hidden = true;
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-copiar').hidden) $('dlg-copiar').hidden = true; });
  $('atualizar-tudo').addEventListener('click', atualizarTudo);
  $('carregar-ped').addEventListener('click', abrirCarregarPedido);
  $('cp-buscar').addEventListener('click', buscarPedidoNumero);
  $('cp-numero').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); buscarPedidoNumero(); } });
  $('cp-fechar').addEventListener('click', fecharCarregarPedido);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-carregar').hidden) fecharCarregarPedido(); });
  $('cp-tab').addEventListener('click', (e) => {
    const b = e.target.closest('[data-carregar]');
    if (b) carregarPedido(pedidosNum[Number(b.dataset.carregar)]);
  });
  $('comp-email').addEventListener('click', () => abrirPdf('email'));
  $('comp-whats').addEventListener('click', () => abrirPdf('whatsapp'));

  // "Margem Sistema": % minimo de resultado da regra comercial para a UF (e o cliente, se escolhido); sem regra = 0%.
  // Guarda o que ja buscou (UF|cliente) para nao ir ao servidor de novo.
  const margemSisMemo = {};
  let margemSisChave = '';
  async function atualizarMargemSistema() {
    const uf = $('uf').value, cli = cliente ? String(cliente.codigo) : '';
    const chave = uf + '|' + cli;
    if (chave === margemSisChave) return;
    margemSisChave = chave;
    if (!uf) { $('margem-sis').textContent = '—'; return; }
    if (margemSisMemo[chave] == null) {
      $('margem-sis').textContent = '…';
      try {
        const d = await api('/api/simulador/margem-sistema?uf=' + encodeURIComponent(uf) + (cli ? '&cliente=' + encodeURIComponent(cli) : ''));
        if (!d.ok) { if (margemSisChave === chave) { $('margem-sis').textContent = '—'; $('margem-sis').title = d.mensagem || ''; margemSisChave = ''; } return; }
        margemSisMemo[chave] = d.margem;
      } catch (e) {
        if (e.message !== 'sessao' && margemSisChave === chave) { $('margem-sis').textContent = '—'; margemSisChave = ''; }
        return;
      }
    }
    if (margemSisChave === chave) { $('margem-sis').textContent = pct(margemSisMemo[chave]); $('margem-sis').title = ''; }
  }

  // campos de numero: ao entrar (clique ou Tab) o valor fica todo selecionado, entao digitar substitui
  // (campo com 5, digita 6 = 6, nao 56; pedido do dono, 27/10/2026). Vale tambem para os campos redesenhados.
  // No clique, o navegador posiciona o cursor ao soltar o botao e desfaria a selecao: o primeiro "soltar" logo depois
  // de entrar no campo e ignorado.
  const ehNumero = (el) => el && el.matches && el.matches('input[inputmode="decimal"]');
  document.addEventListener('focusin', (e) => {
    const el = e.target;
    if (!ehNumero(el)) return;
    el.select();
    el.dataset.recemSelecionado = '1';
    setTimeout(() => { delete el.dataset.recemSelecionado; }, 600);
  });
  document.addEventListener('mouseup', (e) => {
    const el = e.target;
    if (ehNumero(el) && el.dataset.recemSelecionado) { e.preventDefault(); delete el.dataset.recemSelecionado; }
  });

  // campos digitados nas tabelas (guia Simulação e guia Gôndola)
  function aoMudarCampo(e) {
    if (e.target.id === 'meta-cliente') {
      const m = num(e.target.value);
      if (e.target.value.trim() !== '' && (m == null || m < 0 || m > 1000)) { e.target.setCustomValidity('Use um percentual de 0 a 1000'); e.target.reportValidity(); return; }
      metaCliente = m;
      desenharItens();
      return;
    }
    // "Novo" do tributo na linha (+) do item: vale so nesse item; vazio volta para a aliquota carregada
    if (e.target.dataset.tribitem) {
      const iT = itens[Number(e.target.dataset.i)];
      const v = percentualValido(e.target);
      if (!iT || v === undefined) return;
      iT.trib_novo = Object.assign({}, iT.trib_novo, { [e.target.dataset.tribitem]: v });
      if (v == null) delete iT.trib_novo[e.target.dataset.tribitem];
      desenharItens();
      return;
    }
    const el = e.target.closest('[data-campo]');
    if (!el) return;
    const it = itens[Number(el.dataset.i)];
    const campo = el.dataset.campo;
    const v = num(el.value);
    const ePct = /^des/.test(campo);
    const invalido = v == null || v < 0 || (ePct && v > 100);
    if (el.value.trim() !== '' && invalido) { el.setCustomValidity(ePct ? 'Use um percentual de 0 a 100' : 'Valor inválido'); el.reportValidity(); return; }
    el.setCustomValidity('');
    // Vl pct simulado: 0 ou vazio = sem simulacao (volta ao padrao)
    it[campo] = campo === 'pct_simu' && !(v > 0) ? null : v;
    // Vl caixa digitado: trocar a tabela de preco nao sobrescreve mais (vazio volta a seguir a tabela)
    if (campo === 'vl_caixa') {
      it.caixa_digitado = v != null;
      if (v == null) it.vl_caixa = it.vl_tabela;
      agendarTributos(); // so se o item ainda nao tinha tributos (os impostos ja estao em %)
    }
    desenharItens();
  }
  $('p-item').addEventListener('change', aoMudarCampo);
  $('p-gondola').addEventListener('change', aoMudarCampo);

  document.querySelector('.guias').addEventListener('click', (e) => {
    const b = e.target.closest('.guia');
    if (!b) return;
    guia = b.id.slice(2);
    for (const g of document.querySelectorAll('.guia')) g.setAttribute('aria-selected', String(g === b));
    for (const p of ['item', 'grupo', 'gramatura', 'gondola']) $('p-' + p).hidden = p !== guia;
    desenharItens();
  });

  // parametros (nomes e ordem de simulador_despesas; a Regra vem da UF). Os valores sao mantidos so pelo banco local
  // (SQLite Browser): o botao "Editar valores padrao" saiu a pedido do dono (27/10/2026).
  function aplicarDespesas(lista) {
    const antes = new Map(despesas.map((d) => [d.id, d.digitado]));
    despesas = (lista || []).filter((d) => d.ativo).map((d) => ({ id: d.id, nome: d.nome, digitado: antes.has(d.id) ? antes.get(d.id) : null }));
    desenharDespesas();
    desenharItens();
  }

  async function iniciar() {
    try {
      const d = await api('/api/simulador/inicio');
      if (!d.ok) {
        $('bloqueio').textContent = d.mensagem || 'Simulador indisponível.';
        $('bloqueio').hidden = false;
        return;
      }
      $('tela').hidden = false;
      // usuario so do Simulador (tela padrao na Gestao, 30/10/2026): nao ha SimoIA para voltar, o botao vira "Sair"
      if (d.tela_inicial === 'simulador') {
        const v = $('voltar');
        v.textContent = 'Sair';
        v.title = 'Sair do __NOME_SISTEMA__ (encerra a sessão)';
        v.setAttribute('aria-label', 'Sair do __NOME_SISTEMA__');
        v.addEventListener('click', async (e) => {
          e.preventDefault();
          try { await fetch('/api/sair', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token } }); } catch (x) { /* sai mesmo assim */ }
          try {
            sessionStorage.removeItem('token'); sessionStorage.removeItem('usuario');
            localStorage.removeItem('simoia_token'); localStorage.removeItem('simoia_usuario');
          } catch (x) { /* ignora */ }
          location.replace('/');
        });
      }
      $('aviso-demo').hidden = !d.demonstracao; // usuario de demonstracao: tudo ficticio
      $('limpar-sim').hidden = false;
      $('pedmenu').hidden = false; // "Carregar pedido" e "Últimos 5 pedidos"
      $('manut-sim').hidden = !d.manutencao; // so com "Simulador de precos (manutencao)" no cadastro
      podeCusto = !!d.pode_custo; // "Simulador de preços (permite selecionar custo)"; sem ela, o primeiro custo da lista
      excelPers = d.excel_personalizado && Array.isArray(d.excel_personalizado.colunas) ? d.excel_personalizado : null; // Gestao › Simulador
      podeIntegrar = !!d.pode_integrar; // "Integrar": liberado por usuario na Gestao
      $('integrar').hidden = !podeIntegrar;
      atualizarIntegrar();
      // compartilhar: so os meios permitidos ao usuario; sem nenhum, o botao nao aparece
      podeEmail = !!d.pode_email; podeWhats = !!d.pode_whats;
      $('comp-email').hidden = !podeEmail;
      $('comp-whats').hidden = !podeWhats;
      $('comp').hidden = !(podeEmail || podeWhats);
      desenharTributos();
      paramUf = d.param_uf || {};
      aplicarDespesas(d.despesas);
      // as listas carregam por tras enquanto a tela pergunta pela simulacao anterior; a restauracao espera por elas.
      // So depois disso a tela passa a guardar as mudancas
      const listas = Promise.all([carregarProdutos(), carregarCustos(), carregarTiposDocto(), carregarTabelasPreco(), carregarClassificacoes(), carregarCidades()]);
      await restaurarUltima(listas);
      await listas;
      simPronta = true;
    } catch (e) {
      if (e.message === 'sessao') return;
      $('bloqueio').textContent = 'Não foi possível falar com o servidor.';
      $('bloqueio').hidden = false;
    }
  }
  iniciar();
