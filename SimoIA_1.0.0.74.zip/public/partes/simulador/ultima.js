/*@parte Simulador: última simulação do usuário (guardar e restaurar). Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- ultima simulacao do usuario (pedido do dono, 28/10/2026) ----------
   * Guardada no banco local 1,5 s depois de cada mudanca; volta ao abrir o Simulador (precos, custos e tributos
   * recarregados do dia). "Limpar simulacao" apaga a guardada. */
  let simPronta = false;   // so guarda depois de carregar/restaurar (para nao gravar a tela vazia por cima)
  let salvarTimer = 0;
  function estadoAtual() {
    return {
      v: 1, cliente: cliente ? String(cliente.codigo) : null,
      uf: $('uf').value, cidade: $('cidade').value, regime: $('regime').value, classif: $('classif').value, suframa: suframaSim ? 'S' : '',
      custo: $('custo').value, tabela: $('tabela').value, tipodoc: $('tipodoc').value, meta: metaCliente,
      tu: tributos.filter((t) => !t.usar).map((t) => t.id), // chaves em "Nao"
      tg: Object.fromEntries(tributos.filter((t) => t.novo != null).map((t) => [t.id, t.novo])), // % geral
      dp: descPadrao, // descontos padrao
      on: tribOnline, // chave "Online" dos tributos
      desp: Object.fromEntries(despesas.filter((d) => d.digitado != null).map((d) => [d.id, d.digitado])),
      // itens que esperam os tributos tambem vao (senao uma gravacao no meio da busca os perderia)
      itens: itens.concat(aguardando).map((it) => ({ c: it.codigo, t: it.tab || null, q: it.qtde, cx: it.caixa_digitado ? it.vl_caixa : null, d1: it.des1, d2: it.des2, d3: it.des3, ps: it.pct_simu, g: it.vl_gondola,
        tn: it.trib_novo && Object.keys(it.trib_novo).length ? it.trib_novo : null }))
    };
  }
  function agendarSalvar() {
    // simulacao anterior aberta pela metade (falha de carga): nao grava por cima ate o "Atualizar" completar
    if (!simPronta || restaurarDepois) return;
    clearTimeout(salvarTimer);
    salvarTimer = setTimeout(() => { api('/api/simulador/ultima', { dados: estadoAtual() }).catch(() => { /* tenta na proxima mudanca */ }); }, 1500);
  }
  async function restaurarUltima(listas) {
    let d;
    try { d = await api('/api/simulador/ultima'); } catch (e) { return; }
    const s = d && d.ok && d.dados;
    if (!s || s.v !== 1) return;
    // pergunta antes (dono, 28/10/2026): abrir a anterior ou comecar uma nova. "Iniciar nova" nao apaga a guardada:
    // ela so e substituida quando a nova simulacao tiver a primeira mudanca (ou pelo "Limpar simulacao")
    const quando = d.salvo_em ? d.salvo_em.slice(8, 10) + '/' + d.salvo_em.slice(5, 7) + ' às ' + d.salvo_em.slice(11, 16) : '';
    const nItens = (s.itens || []).length;
    const resumo = [s.cliente ? 'cliente ' + s.cliente : (s.uf ? 'UF ' + s.uf : ''), nItens ? nItens + (nItens === 1 ? ' item' : ' itens') : 'sem itens'].filter(Boolean).join(', ');
    // veio do "Opcoes Simulacao › Carregar": abre sem perguntar
    let direto = false;
    try { direto = sessionStorage.getItem('sim_abrir') === '1'; sessionStorage.removeItem('sim_abrir'); } catch (e) { /* pergunta */ }
    if (!direto && !(await perguntarUltima('Você tem uma simulação salva' + (quando ? ' em ' + quando : '') + (resumo ? ' (' + resumo + ')' : '') + '. O que deseja fazer?'))) return;
    restaurando = true;
    processando('restaurar', 'Recarregando a simulação anterior', 'Carregando cliente, preços e custos…');
    try { await listas; await restaurarDados(d, s); } finally { processando('restaurar'); }
  }
  // janela "Abrir a simulacao anterior" / "Iniciar nova"; true = abrir
  function perguntarUltima(texto) {
    return new Promise((ok) => {
      $('pu-texto').textContent = texto;
      $('pergunta-ultima').hidden = false;
      $('pu-abrir').focus();
      const fim = (abrir) => { $('pergunta-ultima').hidden = true; $('pu-abrir').onclick = $('pu-nova').onclick = null; ok(abrir); };
      $('pu-abrir').onclick = () => fim(true);
      $('pu-nova').onclick = () => fim(false);
    });
  }
  async function restaurarDados(d, s) {
    // pessoa: o cliente pelo codigo (do cadastro de hoje) ou UF/regime/classificacao/Suframa
    let faltou = false; // algo da simulacao salva nao voltou por falha de carga (o "Atualizar" reaplica depois)
    if (s.cliente) {
      try {
        const r = await api('/api/simulador/clientes?q=' + encodeURIComponent(s.cliente));
        const c = r.ok && (r.clientes || []).find((x) => String(x.codigo) === String(s.cliente));
        if (c) { escolherCliente(c); marcarCarga('clientes', true); } else if (!r.ok) { faltou = true; marcarCarga('clientes', false); }
      } catch (e) { faltou = true; if (e.message !== 'sessao') marcarCarga('clientes', false); /* segue sem o cliente */ }
    } else {
      $('uf').value = s.uf || ''; cidadeQuer = s.cidade ? { w_id: s.cidade } : null; $('regime').value = s.regime || ''; $('classif').value = s.classif || ''; suframaSim = !!s.suframa; desenharSuframa();
    }
    if (s.tipodoc && [...$('tipodoc').options].some((o) => o.value === s.tipodoc)) $('tipodoc').value = s.tipodoc;
    else if (s.tipodoc && falhas.has('tipos')) faltou = true;
    if (!podeCusto) { if ($('custo').value) await aoTrocarCusto(); } // fica o primeiro da lista (carregarCustos)
    else if (s.custo && [...$('custo').options].some((o) => o.value === s.custo)) { $('custo').value = s.custo; await aoTrocarCusto(); }
    else if (s.custo && falhas.has('custos')) faltou = true;
    if (s.tabela && [...$('tabela').options].some((o) => o.value === s.tabela)) { $('tabela').value = s.tabela; await aoTrocarTabela(); }
    else if (s.tabela && falhas.has('tabelas')) faltou = true;
    if (!produtos && (s.itens || []).length) faltou = true; // sem a lista de produtos os itens nao voltam
    if (Array.isArray(s.dp)) { descPadrao = [0, 1, 2].map((k) => (ok(s.dp[k]) ? s.dp[k] : null)); desenharDescPadrao(); }
    // a simulacao aberta volta com a chave Online como estava nela (antiga, sem a informacao: fica a ultima usada)
    if (typeof s.on === 'boolean') { tribOnline = s.on; $('trib-calcular').hidden = tribOnline; }
    for (const t of tributos) {
      t.usar = !(Array.isArray(s.tu) && s.tu.includes(t.id));
      t.novo = s.tg && ok(s.tg[t.id]) ? s.tg[t.id] : null;
    }
    for (const x of despesas) x.digitado = s.desp && s.desp[x.id] != null ? s.desp[x.id] : null;
    metaCliente = s.meta != null ? s.meta : null;
    let fora = 0;
    for (const x of s.itens || []) {
      const p = produtos && produtos.get(x.c);
      if (!p) { fora++; continue; }
      if (itens.some((it) => it.codigo === x.c)) continue;
      const it = novoItem(p);
      // tabela propria do item (02/11/2026): so se ainda estiver na lista de tabelas
      if (x.t === TAB_INDISPONIVEL) { it.tab = x.t; aplicarPreco(it); } // veio de um pedido com tabela indisponivel: continua sem valor
      else if (x.t && nomeTabela(x.t)) {
        try { if (await garantirPrecos(x.t)) { it.tab = x.t; aplicarPreco(it); } else faltou = true; } catch (e) { faltou = true; }
      }
      it.qtde = x.q != null ? x.q : 1;
      if (x.cx != null) { it.vl_caixa = x.cx; it.caixa_digitado = true; }
      it.des1 = x.d1 ?? null; it.des2 = x.d2 ?? null; it.des3 = x.d3 ?? null; it.pct_simu = x.ps ?? null; it.vl_gondola = x.g ?? null;
      if (x.tn && typeof x.tn === 'object') it.trib_novo = x.tn;
      // como os itens novos: tributos de hoje pela API, todos num JSON so; entram na tabela quando ela responder
      aguardando.push(it);
    }
    if (faltou || falhas.has('precos') || falhas.has('custoprod')) restaurarDepois = { d, s };
    marcarCarga('nada', true); // mostra o "Atualizar" se ficou pendente
    const msg = 'Simulação anterior restaurada' + (d.salvo_em ? ' (salva em ' + d.salvo_em.slice(8, 10) + '/' + d.salvo_em.slice(5, 7) + ' às ' + d.salvo_em.slice(11, 16) + ')' : '') + '.' +
      (restaurarDepois ? ' Alguns dados não carregaram: clique em "Atualizar", no canto das Configurações.' :
        fora ? ' ' + fora + (fora === 1 ? ' produto não está mais disponível e ficou de fora.' : ' produtos não estão mais disponíveis e ficaram de fora.') : '');
    if (aguardando.length) avisoDepois = msg;
    desenharDespesas();
    conferirParametros(); // agenda os tributos (uma chamada com todos os itens)
    // sem esperar: o popup dos tributos entra no lugar do "Recarregando" sem piscar. Abrindo a simulacao anterior, busca
    // os tributos de todos os itens mesmo com a chave Online em Nao (dono, 09/11/2026); depois, o Nao volta a valer
    calcularTributosDe('todos');
    desenharItens();
    avisoAguardando();
    if (!aguardando.length) $('info-produtos').textContent = msg;
  }

