/*@parte Simulador: pesquisa de produtos e listas (custos, preços, cidades). Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- pesquisa de produtos: texto (codigo ou nome), grupo e gramatura; varios itens de uma vez ---------- */
  const semAc = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  const pesqSel = new Set(); // codigos marcados na lista
  // cada palavra do campo precisa aparecer no codigo, no nome, no grupo ou na gramatura ("500", "500g" ou "500 g")
  const textoBusca = (p) => semAc(p.codigo + ' ' + p.descricao + ' ' + (p.grupo || '') + (p.gramatura != null ? ' ' + p.gramatura + 'g ' + p.gramatura + ' g' : ''));
  // 3 espacos (ou mais) no campo = pesquisar tudo (dono, 30/10/2026): lista todos os produtos / clientes
  const pedeTudo = (v) => /^\s{3,}$/.test(String(v || ''));
  function pesquisados() {
    if (!produtos) return [];
    if (pedeTudo($('codigo').value)) return [...produtos.values()].sort((a, b) => a.descricao.localeCompare(b.descricao, 'pt-BR'));
    const txt = $('codigo').value.trim();
    if (!txt) return [];
    // codigo completo tambem aparece na lista, em primeiro (ajuste do dono, 28/10/2026: "14312" sumia e "1431" achava);
    // varios codigos conhecidos ("9806 14311") = a lista deles. O Enter continua adicionando direto.
    const cods = codigosDigitados(txt);
    if (cods.length > 1 && cods.every((c) => produtos.has(c))) return cods.map((c) => produtos.get(c));
    const palavras = semAc(txt).split(/\s+/).filter(Boolean);
    const exato = semAc(txt);
    return [...produtos.values()].filter((p) => { const t = textoBusca(p); return palavras.every((w) => t.includes(w)); })
      .sort((a, b) => (semAc(b.codigo) === exato) - (semAc(a.codigo) === exato) || a.descricao.localeCompare(b.descricao, 'pt-BR'));
  }
  function desenharPesquisa() {
    const txt = $('codigo').value.trim();
    const ativa = produtos && (txt || pedeTudo($('codigo').value));
    $('pesq-lista').hidden = !ativa;
    if (!ativa) return;
    const lista = pesquisados();
    const naSim = new Set(itens.map((it) => it.codigo));
    for (const c of [...pesqSel]) if (!lista.some((p) => p.codigo === c) || naSim.has(c)) pesqSel.delete(c); // so marcados visiveis
    atualizarCabPesquisa(lista, naSim);
    $('pesq-itens').innerHTML = lista.length ? lista.map((p) => {
      const ja = naSim.has(p.codigo);
      return '<label class="pesq-item' + (ja ? ' ja' : '') + '"><input type="checkbox" data-pesq="' + esc(p.codigo) + '"' + (ja ? ' disabled checked' : (pesqSel.has(p.codigo) ? ' checked' : '')) + '>' +
        '<span>' + esc(p.codigo) + '</span><span>' + esc(p.descricao) + (ja ? ' <small>(já na simulação)</small>' : '') + '</span>' +
        '<span class="so-grande"><small>' + esc(p.grupo || '') + '</small></span><span class="so-grande"><small>' + (p.gramatura != null ? esc(fmt(p.gramatura, 0)) + ' g' : '') + '</small></span></label>';
    }).join('') : '<p class="pesq-vazio">Nenhum produto com esses filtros.</p>';
  }
  // contagem, "marcar todos" e botoes da pesquisa (sem redesenhar a lista: marcar uma caixa nao volta ao topo)
  function atualizarCabPesquisa(lista, naSim) {
    lista = lista || pesquisados();
    naSim = naSim || new Set(itens.map((it) => it.codigo));
    const livres = lista.filter((p) => !naSim.has(p.codigo));
    $('pesq-total').textContent = lista.length + (lista.length === 1 ? ' produto' : ' produtos') + (lista.length > livres.length ? ' (' + (lista.length - livres.length) + ' já na simulação)' : '');
    $('pesq-marcar').checked = livres.length > 0 && livres.every((p) => pesqSel.has(p.codigo));
    $('pesq-marcar').disabled = !livres.length;
    $('pesq-add-sel').textContent = 'Adicionar selecionados (' + pesqSel.size + ')';
    $('pesq-add-sel').disabled = !pesqSel.size || !paramsOk;
    $('pesq-add-todos').textContent = 'Adicionar todos (' + livres.length + ')';
    $('pesq-add-todos').disabled = !livres.length || !paramsOk;
  }
  let pesqTimer = 0;
  $('codigo').addEventListener('input', () => { clearTimeout(pesqTimer); pesqTimer = setTimeout(desenharPesquisa, 150); });
  $('pesq-itens').addEventListener('change', (e) => {
    const c = e.target.dataset && e.target.dataset.pesq;
    if (!c) return;
    if (e.target.checked) pesqSel.add(c); else pesqSel.delete(c);
    atualizarCabPesquisa();
  });
  $('pesq-marcar').addEventListener('change', () => {
    const naSim = new Set(itens.map((it) => it.codigo));
    const marcar = $('pesq-marcar').checked;
    for (const p of pesquisados()) if (!naSim.has(p.codigo)) { if (marcar) pesqSel.add(p.codigo); else pesqSel.delete(p.codigo); }
    for (const cb of $('pesq-itens').querySelectorAll('input[data-pesq]:not(:disabled)')) cb.checked = marcar;
    atualizarCabPesquisa();
  });
  function fecharPesquisa() {
    pesqSel.clear();
    $('codigo').value = '';
    desenharPesquisa();
  }
  $('pesq-fechar').addEventListener('click', fecharPesquisa);
  $('pesq-add-sel').addEventListener('click', () => {
    if (!podeAdicionar()) return;
    adicionarCodigos([...pesqSel]);
    fecharPesquisa();
  });
  $('pesq-add-todos').addEventListener('click', async () => {
    if (!podeAdicionar()) return;
    const lista = pesquisados();
    if (lista.length > 50 && !(await perguntar({ titulo: 'Adicionar produtos', texto: 'Adicionar ' + lista.length + ' produtos à simulação?', sim: 'Adicionar' }))) return;
    adicionarCodigos(lista.map((p) => p.codigo));
    fecharPesquisa();
  });

  $('form-codigo').addEventListener('submit', (e) => {
    e.preventDefault();
    // Enter no campo tambem passa por aqui: sem as configuracoes minimas, nao adiciona
    if (!podeAdicionar()) return;
    const txt = $('codigo').value.trim();
    const codigos = codigosDigitados(txt);
    // texto que nao e so codigo: e pesquisa. Marcados na lista = adiciona os marcados; um so achado = adiciona ele
    if (!txt || !codigos.every((c) => produtos.has(c))) {
      if (pesqSel.size) { adicionarCodigos([...pesqSel]); fecharPesquisa(); return; }
      const lista = pesquisados();
      if (txt && lista.length === 1) { adicionarCodigos([lista[0].codigo]); fecharPesquisa(); return; }
      if (txt && !lista.length) adicionarCodigos(codigos); // codigo desconhecido: avisa "nao encontrado"
      else desenharPesquisa();
      return;
    }
    adicionarCodigos(codigos);
    $('codigo').value = '';
    desenharPesquisa();
    $('codigo').focus();
  });
  // adiciona os codigos a simulacao (ignora repetidos; avisa os que nao existem na lista de produtos)
  function adicionarCodigos(codigos) {
    let repetidos = 0;
    const fora = [];
    for (const c of codigos) {
      const p = produtos.get(c);
      if (!p) { fora.push(c); continue; }
      if (itens.some((it) => it.codigo === c) || aguardando.some((it) => it.codigo === c)) { repetidos++; continue; }
      aguardando.push(novoItem(p)); // entra na tabela quando os tributos voltarem (calcularTributos)
    }
    const avisos = [];
    if (fora.length) avisos.push((fora.length === 1 ? 'Código não encontrado' : 'Códigos não encontrados') + ' entre os produtos disponíveis: ' + fora.join(', ') + '.');
    if (repetidos) avisos.push((repetidos === 1 ? '1 código já estava' : repetidos + ' códigos já estavam') + ' na simulação.');
    avisoAguardando();
    if (avisos.length) $('info-produtos').textContent = avisos.join(' ') + (aguardando.length ? ' ' + $('info-produtos').textContent : '');
    conferirParametros(); // agenda os tributos
    desenharItens();
    $('codigo').focus();
  }

  // tabelas de custo (SQL "custos" da tabela simulador_sql): valor = "w_id|empresa" do plano de custo
  let custos = [];
  const custoEscolhido = () => custos.find((c) => c.w_id + '|' + c.empresa === $('custo').value) || null;

  // custo de cada produto (SQL "custo_produto") na empresa da tabela de custo escolhida; 0 = sem custo
  let custoMapa = null;          // { codigo: vl_custo_ref } da empresa escolhida
  const custoCache = {};         // empresa -> mapa (trocar de tabela e voltar nao vai ao servidor de novo)
  function custoDe(codigo) {
    const v = custoMapa ? custoMapa[codigo] : null;
    return ok(v) && v > 0 ? v : null;
  }
  async function aoTrocarCusto() {
    const c = custoEscolhido();
    custoMapa = null;
    for (const it of itens.concat(aguardando)) it.custo = null;
    $('info-custo').textContent = '';
    desenharItens(); // tira na hora o custo da tabela anterior
    if (c) {
      try {
        if (!custoCache[c.empresa]) {
          $('info-custo').textContent = 'Carregando o custo dos produtos…';
          if (itens.length || aguardando.length) processando('custo', 'Atualizando os dados', 'Carregando o custo dos produtos…');
          let d;
          try { d = await api('/api/simulador/custo-produtos?empresa=' + encodeURIComponent(c.empresa)); } finally { processando('custo'); }
          if (!d.ok) { $('info-custo').textContent = d.mensagem || 'Custo dos produtos indisponível.'; marcarCarga('custoprod', false); desenharItens(); return; }
          marcarCarga('custoprod', true);
          custoCache[c.empresa] = d.custos;
        }
        if (custoEscolhido() !== c) return; // trocou de novo enquanto carregava
        custoMapa = custoCache[c.empresa];
        for (const it of itens.concat(aguardando)) it.custo = custoDe(it.codigo);
        const sem = itens.filter((it) => !ok(it.custo)).length;
        $('info-custo').textContent = sem ? sem + (sem === 1 ? ' item sem custo' : ' itens sem custo') + ' na empresa ' + c.empresa + '.' : '';
      } catch (e) {
        if (e.message !== 'sessao') { $('info-custo').textContent = 'Não foi possível carregar o custo dos produtos.'; marcarCarga('custoprod', false); }
      }
    }
    desenharItens();
  }
  $('custo').addEventListener('change', aoTrocarCusto);

  // tabelas de preco (SQL "tabelas_preco") e o preco de cada item na tabela escolhida (SQL "precos").
  // Vl tabela = preco da tabela; Vl caixa comeca igual a ele, ate o usuario digitar outro valor.
  let precoMapa = null;
  const precoCache = {}; // w_id da tabela -> { codigo: preco }
  // tab: tabela propria do item (w_id); sem ela, a tabela das Configuracoes
  function precoDe(codigo, tab) {
    const mapa = tab ? precoCache[tab] : precoMapa;
    const v = mapa ? mapa[codigo] : null;
    return ok(v) && v > 0 ? v : null;
  }
  function aplicarPreco(it) {
    it.vl_tabela = precoDe(it.codigo, it.tab);
    if (!it.caixa_digitado) it.vl_caixa = it.vl_tabela;
  }
  const tabelaDoItem = (it) => it.tab || $('tabela').value;
  // it.tab de item de pedido cuja tabela nao esta mais na lista (dono, 04/11/2026): fica sem Vl tabela ate escolher outra no ">"
  const TAB_INDISPONIVEL = 'indisponivel';
  const tabPropria = (it) => !!it.tab && it.tab !== TAB_INDISPONIVEL;
  function nomeTabela(w) {
    const o = w ? [...$('tabela').options].find((x) => x.value === w) : null;
    return o ? o.textContent : '';
  }
  // w_id da tabela pelo codigo (cod_tabpreco), so entre as disponiveis no campo Tabela de preco; null = nao esta na lista
  function tabelaDoCodigo(cod) {
    const c = String(cod == null ? '' : cod).trim();
    const o = c ? [...$('tabela').options].find((x) => x.dataset.codigo === c) : null;
    return o ? o.value : null;
  }
  // precos de uma tabela (cache na tela); false = nao carregou
  async function garantirPrecos(tab) {
    if (precoCache[tab]) return true;
    const d = await api('/api/simulador/precos?tabela=' + encodeURIComponent(tab));
    if (!d.ok) return false;
    precoCache[tab] = d.precos;
    return true;
  }
  // tabelas proprias dos itens: carrega os precos que faltarem (ex.: depois do "Atualizar" ou ao abrir a simulacao salva)
  async function precosDasTabelasDosItens() {
    const tabs = [...new Set(itens.concat(aguardando).filter(tabPropria).map((it) => it.tab).filter((t) => !precoCache[t]))];
    for (const t of tabs) { try { await garantirPrecos(t); } catch (e) { /* fica sem preco */ } }
  }
  // "Tipo Docto" (dono, 29/10/2026): obrigatorio; o codigo vai no cod_tipo_doc da tributacao
  async function carregarTiposDocto() {
    const sel = $('tipodoc');
    try {
      const d = await api('/api/simulador/tipos-docto');
      if (!d.ok) { sel.innerHTML = '<option value="">Tipos indisponíveis</option>'; sel.title = d.mensagem || ''; marcarCarga('tipos', false); return; }
      marcarCarga('tipos', true);
      sel.innerHTML = '<option value="">Escolha o tipo de documento</option>' + d.tipos.map((t) => '<option value="' + esc(t.codigo) + '">' + esc(t.descricao) + '</option>').join('');
      sel.disabled = false;
      sel.title = '';
    } catch (e) {
      if (e.message !== 'sessao') { sel.innerHTML = '<option value="">Tipos indisponíveis</option>'; marcarCarga('tipos', false); }
    }
  }
  async function carregarTabelasPreco() {
    const sel = $('tabela');
    try {
      const d = await api('/api/simulador/tabelas-preco');
      if (!d.ok) { sel.innerHTML = '<option value="">Tabelas indisponíveis</option>'; sel.title = d.mensagem || ''; marcarCarga('tabelas', false); return; }
      marcarCarga('tabelas', true);
      // "codigo - descricao", em ordem de codigo (dono, 10/11/2026); numerico quando der (2 antes de 10), sem codigo no fim
      const cod = (t) => String(t.codigo == null ? '' : t.codigo).trim();
      const tabelas = d.tabelas.slice().sort((x, y) => (!cod(x) - !cod(y)) || cod(x).localeCompare(cod(y), 'pt-BR', { numeric: true }));
      sel.innerHTML = '<option value="">Escolha a tabela de preço</option>' + tabelas.map((t) => '<option value="' + esc(t.w_id) + '" data-codigo="' + esc(cod(t)) + '"' +
        (t.obs ? ' title="' + esc(t.obs) + '"' : '') + '>' + esc((cod(t) ? cod(t) + ' - ' : '') + t.descricao + (t.promocao ? ' · promoção' : '')) + '</option>').join('');
      sel.disabled = false;
      sel.title = '';
    } catch (e) {
      if (e.message !== 'sessao') { sel.innerHTML = '<option value="">Tabelas indisponíveis</option>'; marcarCarga('tabelas', false); }
    }
  }
  async function aoTrocarTabela() {
    const tab = $('tabela').value;
    precoMapa = null;
    for (const it of itens.concat(aguardando)) aplicarPreco(it);
    $('info-tabela').textContent = '';
    desenharItens(); // tira na hora o preco da tabela anterior
    if (!tab) return;
    try {
      if (!precoCache[tab]) {
        $('info-tabela').textContent = 'Carregando os preços…';
        if (itens.length || aguardando.length) processando('preco', 'Atualizando os dados', 'Carregando os preços da tabela…');
        let d;
        try { d = await api('/api/simulador/precos?tabela=' + encodeURIComponent(tab)); } finally { processando('preco'); }
        if (!d.ok) { $('info-tabela').textContent = d.mensagem || 'Preços indisponíveis.'; marcarCarga('precos', false); return; }
        marcarCarga('precos', true);
        precoCache[tab] = d.precos;
      }
      if ($('tabela').value !== tab) return; // trocou de novo enquanto carregava
      await precosDasTabelasDosItens();
      precoMapa = precoCache[tab];
      for (const it of itens.concat(aguardando)) aplicarPreco(it);
      const sem = itens.filter((it) => !tabPropria(it) && !ok(it.vl_tabela)).length;
      const proprios = itens.filter(tabPropria).length;
      $('info-tabela').textContent = [sem ? sem + (sem === 1 ? ' item sem preço' : ' itens sem preço') + ' nesta tabela.' : '',
        proprios ? proprios + (proprios === 1 ? ' item usa a sua própria tabela' : ' itens usam a sua própria tabela') + ' (botão > para aplicar esta em todos).' : ''].filter(Boolean).join(' ');
    } catch (e) {
      if (e.message !== 'sessao') { $('info-tabela').textContent = 'Não foi possível carregar os preços.'; marcarCarga('precos', false); }
    }
    desenharItens();
    agendarTributos(); // so vai a API quem ainda nao tem tributos (ex.: item que nao tinha preco e agora tem)
  }
  $('tabela').addEventListener('change', aoTrocarTabela);
  // ">" da Tabela de preco (dono, 02/11/2026): reaplica a tabela das Configuracoes em todos os itens; quem nao tem preco
  // nela fica sem preco (como ao trocar a tabela)
  function desenharTabelaTodos() {
    const b = $('tabela-todos');
    b.disabled = !$('tabela').value || !itens.concat(aguardando).length;
  }
  $('tabela-todos').addEventListener('click', async () => {
    const lista = itens.concat(aguardando);
    if (!$('tabela').value || !lista.length) return;
    for (const it of lista) it.tab = null;
    await aoTrocarTabela();
    const sem = itens.filter((it) => !ok(it.vl_tabela)).length;
    $('info-produtos').textContent = 'Tabela ' + nomeTabela($('tabela').value) + ' aplicada em ' + lista.length + (lista.length === 1 ? ' item' : ' itens') + '.' +
      (sem ? ' ' + sem + (sem === 1 ? ' item ficou' : ' itens ficaram') + ' sem preço.' : '');
    agendarSalvar();
  });
  // ">" do Vl tabela: janela com as tabelas que tem preco para o produto; escolher troca a tabela so deste item
  let tabItemAlvo = null;
  function fecharTabItem() {
    $('dlg-tab-item').hidden = true;
    const i = tabItemAlvo ? itens.indexOf(tabItemAlvo) : -1;
    tabItemAlvo = null;
    const b = i >= 0 && document.querySelector('#p-item [data-tabitem="' + i + '"]');
    if (b) b.focus();
  }
  async function abrirTabItem(it) {
    tabItemAlvo = it;
    const lista = $('tab-item-lista');
    $('tab-item-texto').textContent = it.codigo + ' - ' + (it.descricao || '');
    lista.innerHTML = '<p class="nota">Carregando as tabelas…</p>';
    $('dlg-tab-item').hidden = false;
    $('tab-item-fechar').focus();
    let d;
    try { d = await api('/api/simulador/precos-item?codigo=' + encodeURIComponent(it.codigo)); } catch (e) { d = { ok: false, mensagem: e.message === 'sessao' ? '' : 'Não foi possível ler as tabelas do item.' }; }
    if (tabItemAlvo !== it) return;
    if (!d.ok) { lista.innerHTML = '<p class="nota">' + esc(d.mensagem || 'Não foi possível ler as tabelas do item.') + '</p>'; return; }
    // so as tabelas que estao no campo Tabela de preco
    const precos = (d.precos || []).filter((x) => nomeTabela(x.w_id));
    if (!precos.length) { lista.innerHTML = '<p class="nota">Nenhuma tabela de preço tem preço para este produto hoje.</p>'; return; }
    const atual = tabelaDoItem(it);
    lista.innerHTML = precos.map((x) => '<button type="button" class="ti-op" data-tab="' + esc(x.w_id) + '" data-preco="' + x.preco + '"' + (x.w_id === atual ? ' aria-current="true"' : '') + '>' +
      '<span>' + esc(nomeTabela(x.w_id)) + (x.w_id === $('tabela').value ? ' <span class="nota">(a das Configurações)</span>' : '') + '</span><span class="ti-preco">' + moeda(x.preco) + '</span></button>').join('');
    const foco = lista.querySelector('[aria-current="true"]') || lista.querySelector('.ti-op');
    if (foco) foco.focus();
  }
  $('tab-item-lista').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-tab]');
    const it = tabItemAlvo;
    if (!b || !it) return;
    const tab = b.dataset.tab;
    // a tabela das Configuracoes: o item volta a segui-la; outra: fica como tabela propria do item
    it.tab = tab === $('tabela').value ? null : tab;
    // precos da tabela inteira (ficam guardados na tela); se nao vierem, vale o preco mostrado na janela
    if (it.tab) {
      try { await garantirPrecos(it.tab); } catch (x) { /* usa o da janela */ }
      if (!precoCache[it.tab]) precoCache[it.tab] = {};
      if (precoCache[it.tab][it.codigo] == null) precoCache[it.tab][it.codigo] = Number(b.dataset.preco);
    }
    aplicarPreco(it);
    $('info-produtos').textContent = 'Item ' + it.codigo + ': tabela ' + nomeTabela(tab) + (it.tab ? ' (só deste item).' : ' (a das Configurações).');
    fecharTabItem();
    desenharItens();
    agendarTributos();
  });
  $('tab-item-fechar').addEventListener('click', fecharTabItem);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-tab-item').hidden) fecharTabItem(); });
  // sem "Simulador de preços (permite selecionar custo)" no cadastro (dono, 10/11/2026): o campo Custo fica travado no primeiro
  // custo da lista (vale tambem para a simulacao salva e o "Atualizar")
  let podeCusto = true;
  let excelPers = null; // Excel personalizado: { colunas: [{ nome, campo, formato, margem }], dados_gerais } (dono, 13/11/2026)
  async function carregarCustos() {
    const sel = $('custo');
    try {
      const d = await api('/api/simulador/custos');
      if (!d.ok || !d.custos.length) {
        sel.innerHTML = '<option value="">' + esc(d.ok ? 'Nenhuma tabela de custo' : 'Custos indisponíveis') + '</option>';
        sel.title = d.mensagem || '';
        marcarCarga('custos', false);
        return;
      }
      marcarCarga('custos', true);
      custos = d.custos;
      sel.innerHTML = '<option value="">Escolha a tabela de custo</option>' +
        d.custos.map((c) => '<option value="' + esc(c.w_id + '|' + c.empresa) + '">' + esc(c.descricao + (c.empresa ? ' · Empresa ' + c.empresa : '')) + '</option>').join('');
      sel.disabled = false;
      sel.title = '';
      if (!podeCusto) {
        // a lista abre com todos os custos (dono, 10/11/2026), mas so o primeiro pode ser escolhido
        const primeiro = d.custos[0].w_id + '|' + d.custos[0].empresa;
        for (const o of sel.options) o.disabled = o.value !== primeiro;
        sel.value = primeiro;
        sel.title = 'Custo fixo no primeiro da lista: escolher outro custo precisa de liberação no cadastro do usuário.';
        await aoTrocarCusto();
        conferirParametros();
      }
    } catch (e) {
      if (e.message !== 'sessao') { sel.innerHTML = '<option value="">Custos indisponíveis</option>'; marcarCarga('custos', false); }
    }
  }

  let infoProdutos = '';
  async function carregarProdutos() {
    try {
      const d = await api('/api/simulador/produtos');
      if (!d.ok) { $('info-produtos').textContent = d.mensagem || 'Produtos indisponíveis.'; marcarCarga('produtos', false); return; }
      marcarCarga('produtos', true);
      produtos = new Map(d.produtos.map((p) => [p.codigo, p]));
      infoProdutos = d.produtos.length + ' produtos disponíveis.';
      $('info-produtos').textContent = infoProdutos;
    } catch (e) {
      if (e.message !== 'sessao') { $('info-produtos').textContent = 'Não foi possível carregar os produtos.'; marcarCarga('produtos', false); }
    }
  }
  $('limpar').addEventListener('click', async () => {
    if ((itens.length || aguardando.length) && await perguntar({ titulo: 'Tirar todos os itens', texto: 'Tirar todos os itens da simulação?', sim: 'Tirar todos' })) { itens = []; aguardando = []; avisoAguardando(); desenharItens(); }
  });

  // botao de atualizar os itens (dono, 10/11/2026): busca de novo a lista de produtos (descricao, grupo, pesos...),
  // os precos (tabela das Configuracoes e as proprias dos itens), o custo e os tributos de todos os itens.
  // Os valores digitados (Vl Novo, quantidade, descontos) ficam como estao.
  $('atualizar-itens').addEventListener('click', async () => {
    const b = $('atualizar-itens');
    const lista = itens.concat(aguardando);
    if (b.disabled) return;
    if (!lista.length) { $('info-produtos').textContent = 'Nenhum item para atualizar.'; return; }
    b.disabled = true; b.classList.add('girando');
    processando('itens', 'Atualizando os dados', 'Atualizando ' + lista.length + (lista.length === 1 ? ' item…' : ' itens…'));
    try {
      for (const k of Object.keys(precoCache)) delete precoCache[k];
      for (const k of Object.keys(custoCache)) delete custoCache[k];
      await carregarProdutos();
      for (const it of itens.concat(aguardando)) {
        const p = produtos && produtos.get(it.codigo);
        if (!p) continue;
        const n = novoItem(p);
        for (const c of ['descricao', 'grupo', 'gramatura', 'un_caixa', 'peso_liq', 'peso_bruto', 'm3']) it[c] = n[c];
      }
      if ($('custo').value) await aoTrocarCusto();
      await aoTrocarTabela();
      for (const it of itens.concat(aguardando)) { it.trib = null; it.trib_base = null; }
      calcularTributosDe('todos'); // busca de novo, mesmo com a chave Online desligada
      const total = itens.length + aguardando.length;
      $('info-produtos').textContent = total + (total === 1 ? ' item atualizado.' : ' itens atualizados.');
      agendarSalvar();
    } finally {
      processando('itens');
      b.disabled = false; b.classList.remove('girando');
    }
  });

  // topo: data de hoje por extenso ("Quarta-feira, 28 de outubro de 2026") e "Limpar simulacao" = volta ao inicio
  // (cliente, configuracoes, itens, valores digitados); pergunta antes se ja houver itens
  {
    const t = new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
    $('hoje').textContent = t.charAt(0).toUpperCase() + t.slice(1);
  }
  // apaga a simulacao guardada e recomeca (botao "Limpar simulacao" e o "Sim" depois de integrar um pedido)
  async function limparSimulacao() {
    simPronta = false; clearTimeout(salvarTimer);
    try { await api('/api/simulador/ultima', { dados: null }); } catch (e) { /* recarrega mesmo assim */ }
    location.reload();
  }
  $('limpar-sim').addEventListener('click', async () => {
    if (itens.length && !(await perguntar({ titulo: 'Limpar simulação', texto: 'Cliente, configurações, itens e valores digitados voltam ao início.', sim: 'Limpar' }))) return;
    limparSimulacao();
  });
  $('p-item').addEventListener('click', (e) => {
    const rb = e.target.closest('[data-rodape]');
    if (rb) {
      const qual = rb.dataset.rodape;
      if (desfazer[qual]) voltarRodape(qual);
      else if (qual === 'copia') abrirCopiar();
      else if (qual === 'novo') limparNovo();
      else if (qual === 'simul') limparSimul();
      return;
    }
    const c = e.target.closest('[data-calc]');
    if (c) {
      const it = itens[Number(c.dataset.calc)];
      if (!it) return;
      it.trib = null; it.trib_base = null; // forca: vai de novo para a API mesmo se ja tinha tributos
      calcularTributosDe(new Set([it.codigo]));
      return;
    }
    const tb = e.target.closest('[data-tabitem]');
    if (tb) {
      const it = itens[Number(tb.dataset.tabitem)];
      if (it) abrirTabItem(it);
      return;
    }
    const m = e.target.closest('[data-abrir]');
    if (m) {
      const it = itens[Number(m.dataset.abrir)];
      if (!it) return;
      it.aberto = !it.aberto;
      desenharItens();
      const nova = document.querySelector('#p-item [data-abrir="' + m.dataset.abrir + '"]');
      if (nova) nova.focus();
      return;
    }
    const s = e.target.closest('[data-qtd]');
    if (s) {
      // setinhas da quantidade: +1 / -1 (nunca abaixo de 0); so recalcula na tela, sem ir a API
      const it = itens[Number(s.dataset.i)];
      if (!it) return;
      it.qtde = Math.max(0, Math.round(ok(it.qtde) ? it.qtde : 0) + Number(s.dataset.qtd));
      desenharItens();
      const nova = document.querySelector('#p-item [data-qtd="' + s.dataset.qtd + '"][data-i="' + s.dataset.i + '"]');
      if (nova) nova.focus(); // mantem o foco na setinha para clicar de novo (ou usar Enter/espaco)
      return;
    }
    const b = e.target.closest('[data-tirar]');
    if (b) { itens.splice(Number(b.dataset.tirar), 1); desenharItens(); }
  });
