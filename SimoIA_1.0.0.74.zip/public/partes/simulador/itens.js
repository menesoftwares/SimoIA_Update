/*@parte Simulador: desenho dos itens, tributos e modo card do celular. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- desenho ---------- */
  const inputPct = (attr, id, v, rotulo) => '<input type="text" inputmode="decimal" ' + attr + '="' + esc(id) + '" value="' + (v == null ? '' : esc(fmt(v, 2))) + '" placeholder="—" aria-label="' + esc(rotulo) + ' novo (%)">';

  /* ---------- modo card no celular (dono, 30/10/2026; o computador nao muda) ----------
   * Ate 760px de largura as tabelas (itens, por grupo, por gramatura, gondola, Tributos e Parametros) viram cards:
   * cada linha e um card e cada celula mostra o nome da coluna (data-rot, tirado do cabecalho). */
  const CEL = matchMedia('(max-width: 760px)');
  function cartoes(tab) {
    const cab = tab.tHead && tab.tHead.rows[tab.tHead.rows.length - 1];
    const nomes = [];
    if (cab) for (const th of cab.cells) for (let k = 0; k < th.colSpan; k++) nomes.push(k ? '' : th.textContent.trim());
    for (const sec of [...tab.tBodies, tab.tFoot].filter(Boolean)) {
      for (const tr of sec.rows) {
        let col = 0;
        for (const td of tr.cells) { if (!td.hasAttribute('data-rot')) td.setAttribute('data-rot', nomes[col] || ''); col += td.colSpan; }
      }
    }
    tab.classList.add('cartoes');
  }
  // passou do computador para o celular (ou o contrario): redesenha no outro formato
  // celular: Configuracoes, Tributos e Parametros com uma setinha para recolher (dono, 30/10/2026); no computador a
  // setinha nem aparece (CSS) e o quadro fica sempre aberto
  // (30/10/2026: tambem Pedido, Impostos e Volume do resumo)
  for (const id of ['t-param', 't-trib', 't-desp', 't-pedido', 't-impostos', 't-volume']) {
    const h = $(id), sec = h.closest('.quadro');
    const nome = h.firstChild.textContent.trim(); // so o titulo (o h2 das Configuracoes tem tambem o botao Atualizar)
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'recolher'; b.setAttribute('aria-expanded', 'true'); b.setAttribute('aria-label', 'Recolher ' + nome);
    b.innerHTML = '&#9650;';
    b.addEventListener('click', () => {
      const fechado = sec.classList.toggle('recolhido');
      b.setAttribute('aria-expanded', String(!fechado));
      b.setAttribute('aria-label', (fechado ? 'Abrir ' : 'Recolher ') + nome);
    });
    h.appendChild(b);
  }
  let celAntes = CEL.matches;
  const trocouTamanho = () => { if (CEL.matches === celAntes) return; celAntes = CEL.matches; desenharTributos(); desenharDespesas(); desenharItens(); };
  CEL.addEventListener('change', trocouTamanho);
  addEventListener('resize', trocouTamanho); // alguns navegadores nao avisam a troca pelo matchMedia
  // quadro Tributos (dono, 29/10/2026): so as chaves Sim (verde) / Nao (vermelho) de cada tributo; sem a consulta
  // inicial do produto generico. A aliquota de cada item aparece no (+) da linha do item.
  function desenharTributos() {
    if (CEL.matches) { // celular: um card por tributo (nome, chave e % geral)
      $('tributos').innerHTML = '<thead><tr><th>Tributo</th><th>Usar</th><th>Novo</th></tr></thead><tbody>' + tributos.map((t) => '<tr><td class="txt"><strong>' + esc(t.nome) + '</strong></td>' +
        '<td><button type="button" role="switch" class="chave' + (t.usar ? ' sim' : '') + '" data-usar="' + esc(t.id) + '" aria-checked="' + t.usar + '" aria-label="Usar ' + esc(t.nome) + '"><span class="chave-bola"></span><span class="chave-txt">' +
        (t.usar ? 'Sim' : 'Não') + '</span></button></td>' +
        '<td class="ed' + (t.usar && t.novo != null ? ' digitado' : '') + '"><input type="text" inputmode="decimal" data-trib="' + esc(t.id) + '" value="' + (t.usar && t.novo != null ? esc(fmt(t.novo, 2)) : '') +
        '" placeholder="—" aria-label="' + esc(t.nome) + ' novo (%) para todos os itens"' + (t.usar ? '' : ' disabled') + '></td></tr>').join('') + '</tbody>';
      cartoes($('tributos'));
      // a chave "Online" fica junto da Margem Sistema no celular
      $('online-cel').hidden = false;
      $('online-cel-chave').innerHTML = chaveOnline();
      return;
    }
    $('online-cel').hidden = true;
    $('online-cel-chave').innerHTML = '';
    $('tributos').classList.remove('cartoes');
    $('tributos').innerHTML = '<thead><tr><th></th>' + tributos.map((t) => '<th>' + esc(t.nome) + '</th>').join('') + '<th class="col-online">Online</th></tr></thead><tbody>' +
      '<tr><td>Usar</td>' + tributos.map((t) => '<td><button type="button" role="switch" class="chave' + (t.usar ? ' sim' : '') + '" data-usar="' + esc(t.id) + '" aria-checked="' + t.usar +
        '" aria-label="Usar ' + esc(t.nome) + '" title="' + (t.usar ? 'Usando a alíquota de cada item' : 'Não usado: 0% em todos os itens') + '"><span class="chave-bola"></span><span class="chave-txt">' +
        (t.usar ? 'Sim' : 'Não') + '</span></button></td>').join('') + '<td class="col-online">' + chaveOnline() + '</td></tr>' +
      // % geral (vale para todos os itens sem % proprio); so com a chave em Sim
      '<tr><td>Novo</td>' + tributos.map((t) => '<td class="ed' + (t.usar && t.novo != null ? ' digitado' : '') + '"><input type="text" inputmode="decimal" data-trib="' + esc(t.id) +
        '" value="' + (t.usar && t.novo != null ? esc(fmt(t.novo, 2)) : '') + '" placeholder="—" aria-label="' + esc(t.nome) + ' novo (%) para todos os itens"' +
        (t.usar ? ' title="% para todos os itens (0 zera; vazio = o carregado da tributação; o % do item prevalece)"' : ' disabled title="Chave em Não"') + '></td>').join('') + '<td class="col-online"></td></tr></tbody>';
  }
  // chave "Online": Sim = calcula os tributos sozinho; Nao = so nos botoes "Calcular tributos" (geral e do item)
  function chaveOnline() {
    return '<button type="button" role="switch" class="chave' + (tribOnline ? ' sim' : '') + '" data-online="1" aria-checked="' + tribOnline + '" aria-label="Cálculo dos tributos online"' +
      ' title="' + (tribOnline ? 'Online: os tributos são calculados sozinhos, item a item' : 'Offline: os tributos só são calculados nos botões Calcular') + '"><span class="chave-bola"></span><span class="chave-txt">' +
      (tribOnline ? 'Sim' : 'Não') + '</span></button>';
  }
  // linha aberta pelo (+) do item: aliquota carregada da API e o campo para trocar (ex.: 0 para zerar) so nesse item
  function linhaTributosItem(it, i) {
    // tudo numa linha (dono, 29/10/2026): "ICMS 12,00% [novo]" | "ST 0,00% [novo]" | ...
    const cel = tributos.map((t) => {
      const v = it.trib_novo && it.trib_novo[t.id] != null ? it.trib_novo[t.id] : null;
      // sem % digitado no item, o campo mostra o % do topo (dono, 03/11/2026). So mostra: nao grava em trib_novo, para
      // acompanhar o topo quando ele mudar ou for apagado (o calculo em aliquota() ja segue esta mesma ordem).
      const herdado = v == null && ok(t.novo) ? t.novo : null;
      const mostrar = v != null ? v : herdado;
      return '<span class="ti-trib' + (t.usar ? '' : ' ti-off') + '"><span class="ti-nome">' + esc(t.nome) + '</span>' +
        '<span class="ti-carr" title="Alíquota carregada da tributação">' + pct(regraItem(t.id, it)) + '</span>' +
        (t.usar
          ? '<span class="ed' + (v != null ? ' digitado' : herdado != null ? ' herdado' : '') + '"><input type="text" inputmode="decimal" data-tribitem="' + esc(t.id) + '" data-i="' + i + '" value="' + (mostrar == null ? '' : esc(fmt(mostrar, 2))) +
            '" placeholder="—" title="' + (herdado != null ? 'Repassado do quadro Tributos; digite aqui um % só para este item' : '% só deste item; prevalece sobre o geral (0 zera; vazio = o geral, ou o carregado)') + '" aria-label="' + esc(t.nome) + ' novo (%) de ' + esc(it.codigo) + '"></span>'
          : '<span class="ti-nao" title="Chave Não no quadro Tributos">0,00% (Não)</span>') + '</span>';
    }).join('<span class="ti-pipe" aria-hidden="true">|</span>');
    return '<tr class="trib-item"><td></td><td class="txt" colspan="19"><div class="ti-caixa">' + cel + '<span class="ti-pipe" aria-hidden="true">|</span></div></td></tr>';
  }

  /*
   * Parametros: a "Regra" vem da UF de venda (tabela simulador_param_uf do banco local, igual a planilha do dono);
   * cada parametro casa com a coluna pelo nome ("Cont. Soc." -> cont_soc, "Comissão" -> comissao). Sem UF escolhida,
   * ou UF sem linha na tabela, "—" (nao ha mais valor padrao: a coluna percentual de simulador_despesas saiu).
   * Margem total = soma de todos os parametros menos a comissao (regra do dono), na Regra e com o "Novo".
   */
  let paramUf = {};
  const colunaDe = (nome) => String(nome || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  function regraDespesa(d) {
    const uf = $('uf').value;
    if (!uf) return null;
    const linha = paramUf[uf];
    return linha && ok(linha[colunaDe(d.nome)]) ? linha[colunaDe(d.nome)] : null;
  }
  const despesaUsada = (d) => (d.digitado != null ? d.digitado : regraDespesa(d));
  const ehComissao = (d) => colunaDe(d.nome) === 'comissao';
  function margemTotal(valor) {
    const vs = despesas.filter((d) => !ehComissao(d)).map(valor);
    return vs.length && vs.every(ok) ? vs.reduce((a, b) => a + b, 0) : null;
  }
  function desenharDespesas() {
    if (!despesas.length) { $('despesas').innerHTML = '<tbody><tr><td class="vazio">Nenhum parâmetro cadastrado.</td></tr></tbody>'; return; }
    const usado = margemTotal(despesaUsada), regra = margemTotal(regraDespesa);
    if (CEL.matches) { // celular: um card por parametro (regra da UF e o novo); a margem total em cima
      $('despesas').innerHTML = '<thead><tr><th>Parâmetro</th><th>Regra' + ($('uf').value ? ' (' + esc($('uf').value) + ')' : '') + '</th><th>Novo</th></tr></thead><tbody>' +
        '<tr><td class="txt"><strong>Margem total</strong></td><td><strong>' + pct(regra) + '</strong></td><td' + (usado !== regra ? ' class="digitado"' : '') + '><strong>' + (usado !== regra ? pct(usado) : '—') + '</strong></td></tr>' +
        despesas.map((d) => '<tr><td class="txt"><strong>' + esc(d.nome) + '</strong></td><td>' + pct(regraDespesa(d)) + '</td>' +
          '<td class="ed' + (d.digitado != null ? ' digitado' : '') + '">' + inputPct('data-desp', d.id, d.digitado, d.nome) + '</td></tr>').join('') + '</tbody>';
      cartoes($('despesas'));
      return;
    }
    $('despesas').classList.remove('cartoes');
    $('despesas').innerHTML = '<thead><tr><th></th><th>Margem total</th>' + despesas.map((d) => '<th>' + esc(d.nome) + '</th>').join('') + '</tr></thead><tbody>' +
      '<tr><td>Regra' + ($('uf').value ? ' (' + esc($('uf').value) + ')' : '') + '</td><td><strong>' + pct(regra) + '</strong></td>' +
        despesas.map((d) => '<td>' + pct(regraDespesa(d)) + '</td>').join('') + '</tr>' +
      '<tr><td>Novo</td><td' + (usado !== regra ? ' class="digitado"' : '') + '><strong>' + (usado !== regra ? pct(usado) : '—') + '</strong></td>' +
        despesas.map((d) => '<td class="ed' + (d.digitado != null ? ' digitado' : '') + '">' + inputPct('data-desp', d.id, d.digitado, d.nome) + '</td>').join('') + '</tr></tbody>';
  }

  const ed = (campo, i, v, casas, cls) => '<td class="ed"><input type="text" inputmode="decimal"' + (cls ? ' class="' + cls + '"' : '') + ' data-campo="' + campo + '" data-i="' + i + '" value="' + (ok(v) ? esc(fmt(v, casas)) : '') + '" placeholder="—"></td>';

  function tabelaItens() {
    if (!itens.length) return '<p class="vazio">Digite os códigos dos produtos acima para começar a simulação.</p>';
    const linhas = itens.map((it, i) => {
      const c = calcularItem(it);
      // o custo do item entra no calculo, mas nao aparece na tabela (pedido do dono, 27/10/2026)
      // (+): abre embaixo a linha com os tributos carregados do item (dono, 29/10/2026)
      return '<tr><td><button type="button" class="btn-mais" data-abrir="' + i + '" aria-expanded="' + !!it.aberto + '" title="' + (it.aberto ? 'Fechar' : 'Ver') + ' os tributos do item" aria-label="' +
          (it.aberto ? 'Fechar' : 'Ver') + ' os tributos de ' + esc(it.codigo) + '">' + (it.aberto ? '&minus;' : '+') + '</button></td>' +
        '<td class="txt">' + esc(it.codigo) + '</td><td class="txt desc">' + esc(it.descricao || '—') + '</td>' +
                // Vl Novo so mostra o que foi digitado; vazio ("—") = vale o Vl tabela (dono, 30/10/2026)
        // ">" (dono, 02/11/2026): escolhe a tabela de preco deste item
        '<td><span class="vl-tab">' + moeda(it.vl_tabela) + '<button type="button" class="btn-tab' + (it.tab ? ' propria' : '') + '" data-tabitem="' + i + '" title="' +
          esc(it.tab === TAB_INDISPONIVEL ? 'A tabela de preço do pedido não está mais disponível. Clique para escolher outra' : 'Tabela de preço: ' + (nomeTabela(tabelaDoItem(it)) || 'nenhuma') + (it.tab ? ' (só deste item)' : '') + '. Clique para trocar') + '" aria-label="Trocar a tabela de preço de ' + esc(it.codigo) + '">&gt;</button></span></td>' +
        ed('vl_caixa', i, it.caixa_digitado ? it.vl_caixa : null, 2, 'vl-novo') +
        // quantidade com setinhas pequenas para somar/tirar 1 (pedido do dono, 27/10/2026)
        ed('qtde', i, it.qtde, 0, 'curto').replace('</td>', '<span class="setas"><button type="button" data-qtd="1" data-i="' + i + '" title="Mais 1" aria-label="Aumentar a quantidade de ' + esc(it.codigo) + '">&#9650;</button>' +
          '<button type="button" data-qtd="-1" data-i="' + i + '" title="Menos 1" aria-label="Diminuir a quantidade de ' + esc(it.codigo) + '">&#9660;</button></span></td>') +
        '<td>' + moeda(c.cx) + '</td><td>' + moeda(c.pct) + '</td><td>' + moeda(c.ipi) + '</td><td>' + moeda(c.st) + '</td><td>' + moeda(c.ibscbs_cx) + '</td>' +
        '<td>' + moeda(c.cxImp) + '</td><td>' + moeda(c.pctImp) + '</td>' +
        ed('des1', i, it.des1, 2, 'curto') + ed('des2', i, it.des2, 2, 'curto') + ed('des3', i, it.des3, 2, 'curto') +
        // Des. simu.: calculado (diferenca entre o pacote com descontos e o Vl pct simulado), nao digitavel
        '<td title="Diferença entre o pacote com os descontos 1 a 3 (com impostos) e o Vl pct simulado">' + (ok(c.desSimu) ? pct(c.desSimu) : '—') + '</td>' +
        // Vl pct simulado: digitavel, preco final do pacote COM impostos. Comeca em 0,00 = sem simulacao (regra do dono,
        // 27/10/2026); apagar ou digitar 0 volta ao padrao. A dica mostra o pacote com descontos e impostos.
        (c.un ? '<td class="ed"><input type="text" inputmode="decimal" class="vl-simul" data-campo="pct_simu" data-i="' + i + '" value="' + (ok(it.pct_simu) ? esc(fmt(it.pct_simu, 2)) : '0,00') +
          '" title="0,00 = sem simulação. Digite o preço final do pacote, com impostos, para simular' + (ok(c.pctDescImp) ? ' (sem simular: ' + esc(fmt(c.pctDescImp, 2)) + ')' : '') + '" aria-label="Vl pct simulado de ' + esc(it.codigo) + '"></td>'
          : '<td title="Produto sem unidades por caixa: não dá para simular por pacote">—</td>') +
        '<td class="' + classeRes(c.margem) + '">' + pct(c.margem) + '</td>' +
        '<td class="acoes-item">' + (tribOnline ? '' : '<button type="button" class="btn-calc' + (precisaTributo(it) ? ' pendente' : '') + '" data-calc="' + i + '" title="' +
          (precisaTributo(it) ? 'Calcular os tributos deste item (pendente)' : 'Calcular de novo os tributos deste item') + '" aria-label="Calcular os tributos de ' + esc(it.codigo) + '">&#8635;</button>') +
          '<button type="button" class="btn-x" data-tirar="' + i + '" title="Tirar o item" aria-label="Tirar ' + esc(it.codigo) + '">&times;</button></td></tr>' +
        (it.aberto ? linhaTributosItem(it, i) : '');
    }).join('');
    const t = somar(itens);
    return '<table><thead>' +
      '<tr class="faixa"><th colspan="13">Produtos a simular</th><th colspan="6">Simulador</th><th></th></tr>' +
      '<tr><th title="Tributos do item"></th><th class="txt">Cód.</th><th class="txt">Descrição</th><th>Vl tabela</th><th>Vl Novo</th><th>Qtd</th><th>Vl CX</th><th>Vl pct</th><th>Vl IPI</th><th>Vl ST</th><th>Vl IBS/CBS/IS</th><th>Vl CX c/ imp.</th><th>Vl pct c/ imp.</th>' +
      '<th>Des. 1</th><th>Des. 2</th><th>Des. 3</th><th>Des. simu.</th><th>Vl pct simul Final</th><th>Margem</th><th></th></tr></thead>' +
      '<tbody>' + linhas + '</tbody><tfoot><tr><td class="txt" colspan="3">Geral (' + t.n + (t.n === 1 ? ' item' : ' itens') + ')</td>' +
      // rodape (dono, 31/10/2026): cada botao alterna entre a acao e "Voltar" (desfaz a ultima)
      '<td></td><td>' + botaoRodape('novo', itens.some((it) => it.caixa_digitado), 'Limpar', 'Limpar o Vl Novo digitado de todos os itens (voltam ao Vl tabela)') + '</td><td>' + fmt(t.caixas, 0) + '</td>' +
      // um total embaixo de cada imposto: IPI, ST e IBS/CBS/IS
      '<td>' + moeda(t.produtos) + '</td><td></td><td>' + moeda(t.ipi_total) + '</td><td>' + moeda(t.st_total) + '</td><td>' + moeda(t.ibscbs) + '</td>' +
      // embaixo do Des. simu.: copiar para o Des. 1, 2 ou 3; embaixo do Vl pct simul Final: voltar a copia (dono, 30/10/2026)
      '<td>' + moeda(t.total) + '</td><td colspan="4"></td>' +
      '<td>' + botaoRodape('copia', itens.some(temSimu), 'Copiar &#9654;', 'Copiar o Des. simu. para o Des. 1, 2 ou 3 e limpar o Vl pct simul Final') + '</td>' +
      '<td>' + botaoRodape('simul', itens.some((it) => ok(it.pct_simu)), 'Limpar', 'Limpar o Vl pct simul Final de todos os itens') + '</td>' +
      '<td class="' + classeRes(t.margem) + '">' + pct(t.margem) + '</td><td></td></tr></tfoot></table>';
  }

  // guia "Gôndola (cliente)": simulacao de gondola, separada da tabela principal (pedido do dono, 27/10/2026).
  // Em cima: media da margem do cliente e o % de meta (calcula o valor meta de cada item).
  function tabelaGondola() {
    const media = margemGeralCliente();
    const topo = '<div class="gondola-topo">' +
      '<div class="gondola-caixa"><div class="rot">Margem geral do cliente</div><div class="val ' + classeRes(media) + '">' + pct(media) + '</div></div>' +
      '<div class="gondola-caixa"><label class="rot" for="meta-cliente">Meta cliente (%)</label>' +
      '<input type="text" inputmode="decimal" id="meta-cliente" value="' + (ok(metaCliente) ? esc(fmt(metaCliente, 2)) : '') + '" placeholder="—"></div></div>';
    if (!itens.length) return topo + '<p class="vazio">Sem itens na simulação.</p>';
    const linhas = itens.map((it, i) => {
      const c = calcularItem(it);
      return '<tr><td class="txt">' + esc(it.codigo) + '</td><td class="txt desc">' + esc(it.descricao || '—') + '</td>' +
        '<td>' + moeda(c.pctImp) + '</td>' + ed('vl_gondola', i, it.vl_gondola, 2) +
        '<td class="' + classeRes(c.margem_cliente) + '">' + pct(c.margem_cliente) + '</td><td>' + moeda(c.valor_meta) + '</td></tr>';
    }).join('');
    return topo + '<table><thead><tr><th class="txt">Cód.</th><th class="txt">Descrição</th><th>Vl pct c/ imp.</th><th>Vl gôndola</th><th>Margem do cliente</th><th>Valor meta</th></tr></thead>' +
      '<tbody>' + linhas + '</tbody></table>' +
      '<p class="nota">Margem do cliente = (Vl gôndola − Vl pct c/ imp.) ÷ Vl pct c/ imp. Valor meta = Vl pct c/ imp. × (1 + meta). Margem geral = calculada sobre os totais (gôndola × pacotes e Vl pct c/ imp. × pacotes) dos itens com Vl gôndola.</p>';
  }

  // guias "por grupo" e "por gramatura": totais e margem agrupados
  function grupos(campo, rotulo) {
    const g = new Map();
    for (const it of itens) {
      const k = it[campo] || '(sem ' + rotulo.toLowerCase() + ')';
      if (!g.has(k)) g.set(k, []);
      g.get(k).push(it);
    }
    return [...g.entries()].sort((a, b) => a[0].localeCompare(b[0], 'pt-BR', { numeric: true }));
  }
  /* copiar o Des. simu. (dono, 30/10/2026): o botao embaixo da coluna pergunta para qual desconto (1, 2 ou 3) vai o
   * desconto simulado de cada item e depois limpa o Vl pct simul Final. Desconto vazio recebe o simulado; ja preenchido,
   * fica a soma em cascata dos dois (o preco final continua o mesmo). "Voltar" desfaz a ultima copia. */
  const temSimu = (it) => ok(it.pct_simu) && ok(calcularItem(it).desSimu);
  /* botoes do rodape da tabela de itens (dono, 31/10/2026): Vl Novo "Limpar", Des. simu. "Copiar" e Vl pct simul
   * Final "Limpar". Depois de usado, o proprio botao vira "Voltar" e desfaz (volta os valores de antes). */
  const desfazer = { novo: null, copia: null, simul: null }; // copia dos campos antes da acao, por botao
  const fotoItens = (campos) => itens.map((it) => Object.assign({ codigo: it.codigo }, ...campos.map((c) => ({ [c]: it[c] }))));
  function botaoRodape(qual, pode, rotulo, dica) {
    if (desfazer[qual]) return '<button type="button" class="btn-rodape voltar-rodape" data-rodape="' + qual + '" title="Desfazer">&#8630; Voltar</button>';
    return '<button type="button" class="btn-rodape" data-rodape="' + qual + '"' + (pode ? '' : ' disabled') + ' title="' + dica + '">' + rotulo + '</button>';
  }
  function voltarRodape(qual) {
    const foto = desfazer[qual];
    if (!foto) return;
    for (const f of foto) { const it = itens.find((x) => x.codigo === f.codigo); if (it) Object.assign(it, f, { codigo: it.codigo }); }
    desfazer[qual] = null;
    $('info-produtos').textContent = 'Desfeito.';
    if (qual === 'novo') agendarTributos(); // so busca quem ainda nao tem tributos
    desenharItens();
  }
  function limparNovo() {
    const lista = itens.filter((it) => it.caixa_digitado);
    if (!lista.length) return;
    desfazer.novo = fotoItens(['vl_caixa', 'caixa_digitado']);
    for (const it of lista) { it.caixa_digitado = false; it.vl_caixa = it.vl_tabela; }
    $('info-produtos').textContent = 'Vl Novo limpo em ' + lista.length + (lista.length === 1 ? ' item' : ' itens') + ' (vale o Vl tabela). Use "Voltar" para desfazer.';
    agendarTributos(); // so busca quem ainda nao tem tributos
    desenharItens();
  }
  function limparSimul() {
    const lista = itens.filter((it) => ok(it.pct_simu));
    if (!lista.length) return;
    desfazer.simul = fotoItens(['pct_simu']);
    for (const it of lista) it.pct_simu = null;
    $('info-produtos').textContent = 'Vl pct simul Final limpo em ' + lista.length + (lista.length === 1 ? ' item' : ' itens') + '. Use "Voltar" para desfazer.';
    desenharItens();
  }
  // janela do "Copiar": desconto que ja tem valor (diferente de 0) em algum item com simulacao aparece, mas travado
  // (dono, 31/10/2026)
  function abrirCopiar() {
    const lista = itens.filter(temSimu);
    let livre = null;
    for (const b of document.querySelectorAll('#dlg-copiar [data-copiar]')) {
      const k = b.dataset.copiar;
      const ocupados = lista.filter((it) => ok(it[k]) && it[k] !== 0).map((it) => it.codigo);
      b.disabled = ocupados.length > 0;
      b.title = ocupados.length ? 'Já tem desconto ' + (ocupados.length === 1 ? 'no item ' : 'nos itens ') + ocupados.join(', ') : '';
      if (!b.disabled && !livre) livre = b;
    }
    $('cop-nenhum').hidden = !!livre;
    $('dlg-copiar').hidden = false;
    (livre || $('cop-cancelar')).focus();
  }
  function copiarSimu(campo) {
    const lista = itens.filter(temSimu);
    if (!lista.length) return;
    desfazer.copia = fotoItens(['des1', 'des2', 'des3', 'pct_simu']);
    for (const it of lista) {
      const s = calcularItem(it).desSimu, atual = ok(it[campo]) ? it[campo] : 0;
      it[campo] = Math.round((1 - (1 - atual / 100) * (1 - s / 100)) * 10000) / 100;
      it.pct_simu = null;
    }
    $('info-produtos').textContent = 'Des. simu. copiado para o ' + campo.replace('des', 'Des. ') + ' em ' + lista.length + (lista.length === 1 ? ' item' : ' itens') + '. Use "Voltar" para desfazer.';
    desenharItens();
  }
  // linha Geral sem o "% do valor" (seria sempre 100%; dono, 30/10/2026)
  function tabelaAgrupada(campo, rotulo) {
    if (!itens.length) return '<p class="vazio">Sem itens na simulação.</p>';
    const geral = somar(itens);
    const linha = (k, t, rodape) => {
      const part = ok(t.produtos) && geral.produtos ? t.produtos / geral.produtos * 100 : null;
      return '<tr><td class="txt">' + esc(k) + '</td><td>' + t.n + '</td><td>' + fmt(t.caixas, 0) + '</td><td>' + fmt(t.peso_liq, 3) + '</td><td>' + fmt(t.peso_bruto, 3) + '</td>' +
        '<td>' + moeda(t.produtos) + '</td><td>' + (rodape ? '' : pct(part)) + '</td><td>' + moeda(t.tributos) + '</td><td>' + moeda(t.total) + '</td>' +
        '<td class="' + classeRes(t.margem) + '">' + pct(t.margem) + '</td></tr>';
    };
    return '<table><thead><tr><th class="txt">' + esc(rotulo) + '</th><th>Itens</th><th>Caixas</th><th>Peso líq.</th><th>Peso bruto</th><th>Valor produtos</th><th>% do valor</th><th>Tributos</th><th>Total</th><th>Margem</th></tr></thead>' +
      // sem a linha Geral (dono, 30/10/2026): os totais ja estao nos quadros Pedido, Impostos e Volume
      '<tbody>' + grupos(campo, rotulo).map(([k, l]) => linha(k, somar(l))).join('') + '</tbody></table>';
  }

  function desenharResumo() {
    const t = somar(itens);
    const dl = (pares) => pares.map(([r, v, f]) => '<dt' + (f ? ' class="forte"' : '') + '>' + r + '</dt><dd' + (f ? ' class="forte"' : '') + '>' + v + '</dd>').join('');
    $('r-valores').innerHTML = dl([['Valor produtos bruto', moeda(t.bruto)], ['Valor desconto', moeda(t.desconto)], ['Valor tributos', moeda(t.tributos)],
      ['Valor tributos desconto', moeda(t.trib_desc)], // ICMS e PIS/COFINS que deduzem do total (dono, 09/11/2026)
      ['Valor produtos', moeda(t.produtos)], ['Valor total pedido', moeda(t.total), true]]); // custo dos produtos nunca aparece na tela (regra do dono, 27/10/2026); so entra no calculo
    // mesma ordem das chaves do quadro Tributos (dono, 30/10/2026): ICMS - ST - PIS/COFINS - IPI - IBS/CBS/IS
    // ICMS (descontado) e PIS/COFINS (descontado) (dono, 09/11/2026): sempre na lista ("—" sem tributo como desconto)
    $('r-impostos').innerHTML = dl([['ICMS (incluso)', moeda(t.icms)], ['ICMS (descontado)', moeda(t.icms_desc)], ['ST', moeda(t.st_total)],
      ['PIS/COFINS (incluso)', moeda(t.piscofins)], ['PIS/COFINS (descontado)', moeda(t.piscofins_desc)], ['IPI', moeda(t.ipi_total)], ['IBS + CBS + IS', moeda(t.ibscbs)]]);
    $('r-volume').innerHTML = dl([['Total peso líquido', fmt(t.peso_liq, 3)], ['Total peso bruto', fmt(t.peso_bruto, 3)], ['Metragem cúbica', fmt(t.m3, 3)], ['Quantidade de caixas', fmt(t.caixas, 0)]]);
    // item sem tributos (offline): margem geral so depois do "Calcular tributos" (dono, 11/11/2026); o botao fica amarelo
    const pendTrib = itens.some(precisaTributo);
    $('trib-calcular').classList.toggle('pendente', pendTrib);
    if (pendTrib) {
      $('r-margem').className = 'margem-geral quadro';
      $('r-margem').innerHTML = '<div class="rot">Margem geral</div><div class="val">—</div><div class="sub">Calcule os tributos para ver a margem · Meta: ' + pct(metaCliente) + '</div>';
      return;
    }
    $('r-margem').className = 'margem-geral quadro ' + classeRes(t.margem);
    $('r-margem').innerHTML = '<div class="rot">Margem geral</div><div class="val">' + pct(t.margem) + '</div><div class="sub">Margem geral do cliente: ' + pct(margemGeralCliente()) + ' · Meta: ' + pct(metaCliente) + '</div>';
  }

  function desenharItens() {
    // so redesenha a guia aberta (as outras desenham ao abrir)
    if (guia === 'item') $('p-item').innerHTML = tabelaItens();
    if (guia === 'grupo') $('p-grupo').innerHTML = tabelaAgrupada('grupo', 'Grupo de produto');
    if (guia === 'gramatura') $('p-gramatura').innerHTML = tabelaAgrupada('gramatura', 'Gramatura');
    if (guia === 'gondola') $('p-gondola').innerHTML = tabelaGondola();
    if (CEL.matches) for (const t of $('p-' + guia).querySelectorAll('table')) cartoes(t); // celular: cada linha vira um card
    desenharResumo();
    desenharTributos(); // a linha "Regra" acompanha os itens
    atualizarIntegrar(); // "Integrar" depende de cliente, itens e tabela
    desenharTabelaTodos(); // ">" da Tabela de preco: so com tabela e itens
    // "Compartilhar" so com itens (dono, 28/10/2026: bloqueado como o Integrar, sem mensagem ao clicar)
    // sem a Margem geral calculada (item sem tributos) nao compartilha, imprime nem gera Excel (dono, 11/11/2026)
    $('comp-abrir').disabled = !itens.length || itens.some(precisaTributo);
    $('comp').title = itens.length && itens.some(precisaTributo) ? MSG_TRIB_PEND : '';
    if (!itens.length) fecharMenuComp();
    agendarSalvar(); // guarda a simulacao do usuario (toda mudanca passa por aqui)
  }

