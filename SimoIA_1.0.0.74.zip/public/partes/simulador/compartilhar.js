/*@parte Simulador: compartilhar: PDF, Excel e imprimir. Parte de simulador.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- compartilhar a simulacao (28/10/2026; dono: com margem, nunca o custo) ----------
   * Mesmas permissoes do SimoIA (pode_email / pode_whats); cada envio fica no historico (/api/registro, que tambem
   * confere a permissao). E-mail e WhatsApp vao em PDF (abaixo); o "Copiar texto" saiu a pedido do dono (28/10/2026). */
  let podeEmail = false, podeWhats = false;
  function registrarEnvio(origem) {
    api('/api/registro', { origem, texto: 'Simulador de preços: ' + itens.length + (itens.length === 1 ? ' item' : ' itens') + ' (PDF)', mensagem: '' }).catch(() => { /* so o historico */ });
  }
  function fecharMenuComp() { $('comp-menu').hidden = true; $('comp-abrir').setAttribute('aria-expanded', 'false'); }
  $('comp-abrir').addEventListener('click', () => {
    if (!itens.length || itens.some(precisaTributo)) return; // (o botao ja fica bloqueado sem itens ou sem a Margem geral)
    const abrir = $('comp-menu').hidden;
    $('comp-menu').hidden = !abrir;
    $('comp-abrir').setAttribute('aria-expanded', String(abrir));
    if (abrir) $('comp-menu').querySelector('button:not([hidden])').focus();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#comp')) fecharMenuComp(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('comp-menu').hidden) { fecharMenuComp(); $('comp-abrir').focus(); } });
  /* E-mail e WhatsApp em PDF (28/10/2026, dono: "relatorio em PDF"; com ou sem margens escolhido na hora).
   * O servidor monta o PDF com os valores da tela (nunca o custo). Onde o aparelho compartilha arquivos (celular,
   * Windows), "Enviar PDF" abre o compartilhamento com o PDF anexado; senao, o PDF e baixado e o WhatsApp/e-mail
   * abre para anexar. O "Enviar" e um segundo clique: o navegador so abre o compartilhamento logo apos um clique. */
  let pdfCanal = '', pdfArquivo = null, pdfMargens = true;
  function dadosPdf(margens) {
    const t = somar(itens);
    const pessoa = cliente ? cliente.codigo + ' - ' + cliente.nome + (cliente.uf ? ' (' + cliente.uf + ')' : '')
      : ($('uf').value ? 'UF ' + $('uf').value + (REGIMES[$('regime').value] ? ' · ' + REGIMES[$('regime').value] : '') : '');
    return {
      margens, data: $('hoje').textContent, pessoa, tabela: ($('tabela').value ? $('tabela').selectedOptions[0].text : '') + (itens.some(tabPropria) ? ' (alguns itens com outra tabela)' : ''),
      itens: itens.map((it) => { const c = calcularItem(it); return { codigo: it.codigo, descricao: it.descricao, caixas: c.caixas, cx_imp: c.cxImp, pct_imp: c.pctImp, total: c.total, margem: margens ? c.margem : null }; }),
      totais: { produtos: t.produtos, ipi: t.ipi_total, st: t.st_total, ibscbs: t.ibscbs, trib_desc: t.trib_desc, total: t.total, caixas: t.caixas, peso_liq: t.peso_liq, peso_bruto: t.peso_bruto, m3: t.m3, margem: margens ? t.margem : null },
      grupos: margens ? grupos('grupo', 'Grupo').map(([k, l]) => ({ nome: k, margem: somar(l).margem })) : []
    };
  }
  function passoPdf(n) { for (const i of [1, 2, 3]) $('pdf-passo' + i).hidden = i !== n; }
  // canal: 'email' / 'whatsapp' (Compartilhar) ou 'imprimir' / 'excel' (Opcoes Simulacao, dono 11/11/2026): a mesma
  // janela pergunta com ou sem margens
  function abrirPdf(canal) {
    fecharMenuComp(); fecharMenuOpsim();
    if (itens.some(precisaTributo)) { $('comp-status').textContent = MSG_TRIB_PEND; return; } // Margem geral ainda nao calculada
    pdfCanal = canal; pdfArquivo = null;
    const excel = canal === 'excel' || canal === 'excel_pers';
    $('pdf-titulo').textContent = canal === 'excel_pers' ? 'Gerar Excel personalizado' : excel ? 'Gerar Excel da simulação' : canal === 'imprimir' ? 'Imprimir relatório da simulação' : 'Enviar simulação em PDF por ' + (canal === 'email' ? 'e-mail' : 'WhatsApp');
    $('pdf-pergunta').textContent = excel ? 'O Excel deve mostrar as margens?' : 'O relatório deve mostrar as margens?';
    $('pdf-gerar').textContent = excel ? 'Gerar Excel' : canal === 'imprimir' ? 'Gerar relatório' : 'Gerar PDF';
    $('pdf-gerando').textContent = excel ? 'Gerando o Excel…' : 'Gerando o PDF…';
    passoPdf(1);
    $('dlg-pdf').hidden = false;
    $('pdf-gerar').focus();
  }
  function fecharPdf() { $('dlg-pdf').hidden = true; (pdfCanal === 'imprimir' || pdfCanal === 'excel' || pdfCanal === 'excel_pers' ? $('opsim-abrir') : $('comp-abrir')).focus(); }
  $('opsim-imprimir').addEventListener('click', () => { if (itens.length) abrirPdf('imprimir'); });
  $('opsim-excel').addEventListener('click', () => { if (itens.length) abrirPdf('excel'); });
  // Excel personalizado: so pergunta com/sem margens se alguma coluna for de margem
  $('opsim-excel-pers').addEventListener('click', () => {
    if (!itens.length || !excelPers || !excelPers.colunas.length) return;
    if (excelPers.colunas.some((c) => c.margem)) { abrirPdf('excel_pers'); return; }
    fecharMenuOpsim();
    if (itens.some(precisaTributo)) { $('comp-status').textContent = MSG_TRIB_PEND; return; }
    pdfCanal = 'excel_pers';
    gerarExcel(false, true);
  });
  /* valor de cada campo do Excel personalizado (as chaves sao as de SIM_EXCEL_CAMPOS no server.js) */
  function valorExcel(campo, it, c) {
    const q = c.caixas || 0;
    const porCx = (v) => (ok(v) && q ? v / q : null);
    const aliq = (id) => { const v = aliquota(id, it); return ok(v) ? v : null; };
    switch (campo) {
      case 'codigo': return it.codigo;
      case 'descricao': return it.descricao || '';
      case 'grupo': return it.grupo || '';
      case 'gramatura': return it.gramatura || '';
      case 'un_caixa': return c.un;
      case 'tabela': return nomeTabela(tabelaDoItem(it)) || '';
      case 'peso_liq': return it.peso_liq;
      case 'peso_bruto': return it.peso_bruto;
      case 'm3': return it.m3;
      case 'vl_tabela': return it.vl_tabela;
      case 'vl_novo': return it.caixa_digitado ? it.vl_caixa : null;
      case 'qtde': return it.qtde;
      case 'vl_cx': return c.cx;
      case 'vl_pct': return c.pct;
      case 'des1': return it.des1;
      case 'des2': return it.des2;
      case 'des3': return it.des3;
      case 'des_simu': return c.desSimu;
      case 'pct_simu': return it.pct_simu;
      case 'vl_cx_imp': return c.cxImp;
      case 'vl_pct_imp': return c.pctImp;
      case 'aliq_icms': return aliq('icms');
      case 'aliq_piscofins': return aliq('piscofins');
      case 'aliq_ipi': return aliq('ipi');
      case 'aliq_st': return aliq('st');
      case 'aliq_ibs': return aliq('ibs');
      case 'aliq_cbs': return aliq('cbs');
      case 'aliq_is': return aliq('is');
      case 'vl_icms': return porCx(c.icms);
      case 'vl_piscofins': return porCx(c.piscofins);
      case 'vl_ipi': return c.ipi;
      case 'vl_st': return c.st;
      case 'vl_ibscbs': return c.ibscbs_cx;
      case 'tot_bruto': return c.bruto;
      case 'tot_produtos': return c.produtos;
      case 'tot_tributos': return c.tributos;
      case 'tot_total': return c.total;
      case 'tot_icms': return c.icms;
      case 'tot_piscofins': return c.piscofins;
      case 'tot_ipi': return c.ipi_total;
      case 'tot_st': return c.st_total;
      case 'tot_ibscbs': return c.ibscbs;
      case 'tot_peso_liq': return c.peso_liq;
      case 'tot_peso_bruto': return c.peso_bruto;
      case 'tot_m3': return c.m3;
      case 'vl_gondola': return it.vl_gondola;
      case 'margem': return c.margem;
      case 'margem_cliente': return c.margem_cliente;
      case 'valor_meta': return c.valor_meta;
      default: return null;
    }
  }
  function dadosExcelPers(margens) {
    const cols = excelPers.colunas.filter((c) => margens || !c.margem);
    const linhas = itens.map((it) => {
      const c = calcularItem(it);
      return cols.map((k) => { const v = valorExcel(k.campo, it, c); return v == null || (typeof v === 'number' && !isFinite(v)) ? '' : v; });
    });
    const base = excelPers.dados_gerais ? dadosExcel(margens) : null; // titulo, subtitulo e dados gerais do Excel normal
    return { personalizado: true, titulo: base ? base.titulo : '', subtitulo: base ? base.subtitulo : '', info: base ? base.info : [],
      colunas: cols.map((k) => ({ nome: k.nome, formato: k.formato || 'texto' })), linhas, margens };
  }
  /* Excel (dono, 11/11/2026): dados gerais (pessoa, configuracoes e totais do Pedido/Impostos/Volume) e os itens linha a
   * linha, com os mesmos valores da tela. O custo nunca vai; as margens so com "Com margens". */
  function dadosExcel(margens) {
    const t = somar(itens);
    const pend = itens.some(precisaTributo);
    const txt = (id) => ($(id).value ? $(id).selectedOptions[0].text : '');
    const pessoa = cliente ? cliente.codigo + ' - ' + cliente.nome + (cliente.uf ? ' (' + cliente.uf + ')' : '')
      : ($('uf').value ? 'UF ' + $('uf').value + (REGIMES[$('regime').value] ? ' · ' + REGIMES[$('regime').value] : '') : '');
    const info = [['Data', $('hoje').textContent], ['Cliente', pessoa], ['Tipo Docto', txt('tipodoc')],
      ['Tabela de preço', txt('tabela') + (itens.some(tabPropria) ? ' (alguns itens com outra tabela)' : '')],
      ['Valor produtos bruto', t.bruto, 'moeda'], ['Valor desconto', t.desconto, 'moeda'], ['Valor tributos', t.tributos, 'moeda'],
      ['Valor tributos desconto', t.trib_desc, 'moeda'], ['Valor produtos', t.produtos, 'moeda'], ['Valor total pedido', t.total, 'moeda'],
      ['ICMS (incluso)', t.icms, 'moeda'], ['ICMS (descontado)', t.icms_desc, 'moeda'], ['ST', t.st_total, 'moeda'],
      ['PIS/COFINS (incluso)', t.piscofins, 'moeda'], ['PIS/COFINS (descontado)', t.piscofins_desc, 'moeda'], ['IPI', t.ipi_total, 'moeda'],
      ['IBS + CBS + IS', t.ibscbs, 'moeda'], ['Total peso líquido', t.peso_liq, 'numero'], ['Total peso bruto', t.peso_bruto, 'numero'],
      ['Metragem cúbica', t.m3, 'numero'], ['Quantidade de caixas', t.caixas, 'inteiro']];
    if (margens) info.push(['Margem geral', pend ? 'Calcule os tributos' : t.margem, 'percentual2'], ['Meta do cliente', metaCliente, 'percentual2']);
    if (pend) info.push(['Atenção', 'Há itens sem tributos calculados']);
    const colunas = [['Cód.'], ['Descrição'], ['Grupo'], ['Gramatura'], ['Tabela de preço'], ['Vl tabela', 'moeda'], ['Vl Novo', 'moeda'], ['Qtd', 'inteiro'],
      ['Vl CX', 'moeda'], ['Vl pct', 'moeda'], ['Vl ICMS', 'moeda'], ['Vl PIS/COFINS', 'moeda'], ['Vl IPI', 'moeda'], ['Vl ST', 'moeda'], ['Vl IBS/CBS/IS', 'moeda'],
      ['Vl CX c/ imp.', 'moeda'], ['Vl pct c/ imp.', 'moeda'], ['Des. 1', 'percentual2'], ['Des. 2', 'percentual2'], ['Des. 3', 'percentual2'],
      ['Des. simu.', 'percentual2'], ['Vl pct simul Final', 'moeda'], ['Total', 'moeda']].concat(margens ? [['Margem', 'percentual2']] : [])
      .map(([nome, formato]) => ({ nome, formato: formato || 'texto' }));
    const linhas = itens.map((it) => {
      const c = calcularItem(it), q = c.caixas || 0;
      const porCx = (v) => (ok(v) && q ? v / q : null); // ICMS e PIS/COFINS por caixa, como as outras colunas de imposto
      const l = [it.codigo, it.descricao || '', it.grupo || '', it.gramatura || '', nomeTabela(tabelaDoItem(it)) || '', it.vl_tabela, it.caixa_digitado ? it.vl_caixa : null, it.qtde,
        c.cx, c.pct, porCx(c.icms), porCx(c.piscofins), c.ipi, c.st, c.ibscbs_cx, c.cxImp, c.pctImp, it.des1, it.des2, it.des3, c.desSimu, it.pct_simu, c.total];
      if (margens) l.push(c.margem);
      return l.map((v) => (v == null || (typeof v === 'number' && !isFinite(v)) ? '' : v));
    });
    return { titulo: 'Simulação de preços', subtitulo: (margens ? 'Com margens' : 'Sem margens') + ' · gerado em ' + new Date().toLocaleString('pt-BR'), info: info.map((x) => [x[0], x[1] == null ? '' : x[1], x[2]]), colunas, linhas, margens };
  }
  function baixarArquivo(arquivo) {
    const url = URL.createObjectURL(arquivo);
    const a = document.createElement('a');
    a.href = url; a.download = arquivo.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  async function gerarExcel(margens, personalizado) {
    passoPdf(2);
    if (personalizado) $('comp-status').textContent = 'Gerando o Excel personalizado…';
    try {
      const corpo = personalizado ? dadosExcelPers(margens) : dadosExcel(margens);
      if (!corpo.colunas.length) throw new Error('O Excel personalizado só tem colunas de margem: escolha "Com margens".');
      const r = await fetch('/api/simulador/excel', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify(corpo) });
      if (r.status === 401) { location.href = '/'; return; }
      if (!(r.headers.get('Content-Type') || '').includes('spreadsheetml')) {
        let d = {}; try { d = await r.json(); } catch (e) { /* sem corpo */ }
        throw new Error(d.mensagem || 'Não foi possível gerar o Excel agora.');
      }
      const arq = new File([await r.blob()], nomePdf().replace(/\.pdf$/, personalizado ? '-personalizado.xlsx' : '.xlsx'), { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      baixarArquivo(arq);
      $('comp-status').textContent = 'Excel baixado (' + arq.name + ').';
    } catch (e) {
      $('comp-status').textContent = e.message || 'Não foi possível gerar o Excel agora.';
    }
    fecharPdf();
  }
  // imprimir (dono, 11/11/2026): o PDF abre num quadro escondido e chama a impressao; se o navegador nao deixar, abre o PDF numa aba
  function imprimirPdf() {
    if (!pdfArquivo) return;
    const url = URL.createObjectURL(pdfArquivo);
    const abrirAba = () => { if (!window.open(url, '_blank')) baixarPdf(); };
    const velho = document.getElementById('quadro-imprimir');
    if (velho) velho.remove();
    const f = document.createElement('iframe');
    f.id = 'quadro-imprimir';
    f.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
    f.onload = () => { try { f.contentWindow.focus(); f.contentWindow.print(); } catch (e) { abrirAba(); } };
    f.src = url;
    document.body.appendChild(f);
    setTimeout(() => URL.revokeObjectURL(url), 300000);
  }
  const nomePdf = () => {
    const quem = cliente ? 'cliente-' + cliente.codigo : ($('uf').value ? 'uf-' + $('uf').value : 'simulacao');
    const d = new Date(), p2 = (n) => String(n).padStart(2, '0');
    return 'simulacao-' + quem + '-' + p2(d.getDate()) + p2(d.getMonth() + 1) + d.getFullYear() + '-' + p2(d.getHours()) + p2(d.getMinutes()) + '.pdf';
  };
  $('pdf-gerar').addEventListener('click', async () => {
    pdfMargens = document.querySelector('input[name="pdf-margens"]:checked').value === 'sim';
    if (pdfCanal === 'excel' || pdfCanal === 'excel_pers') { gerarExcel(pdfMargens, pdfCanal === 'excel_pers'); return; }
    passoPdf(2);
    try {
      const r = await fetch('/api/simulador/pdf', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token, 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign(dadosPdf(pdfMargens), { imprimir: pdfCanal === 'imprimir' })) });
      if (r.status === 401) { location.href = '/'; return; }
      if (!(r.headers.get('Content-Type') || '').includes('application/pdf')) {
        let d = {}; try { d = await r.json(); } catch (e) { /* sem corpo */ }
        throw new Error(d.mensagem || 'Não foi possível gerar o PDF agora.');
      }
      pdfArquivo = new File([await r.blob()], nomePdf(), { type: 'application/pdf' });
    } catch (e) {
      passoPdf(1);
      $('comp-status').textContent = e.message || 'Não foi possível gerar o PDF agora.';
      fecharPdf();
      return;
    }
    // 28/10/2026 (dono: "da mesma forma que o anexo das pesquisas"): o principal e "Enviar com anexo", o mesmo
    // compartilhamento do aparelho do "Enviar com anexos..." das consultas (no Windows, a janela Compartilhar: escolhe
    // o WhatsApp e o PDF vai anexado). O "Abrir o WhatsApp" (link so com texto) saiu a pedido do dono; onde o aparelho
    // nao compartilha arquivos, o principal e "Baixar PDF" para anexar.
    if (pdfCanal === 'imprimir') {
      $('pdf-pronto').textContent = 'Relatório pronto (' + (pdfMargens ? 'com' : 'sem') + ' margens). Clique em "Imprimir".';
      $('pdf-enviar').textContent = 'Imprimir';
      $('pdf-enviar').hidden = false;
      $('pdf-baixar').className = 'btn-sec';
      passoPdf(3);
      $('pdf-enviar').focus();
      return;
    }
    const podeAnexar = !!(window.isSecureContext && navigator.share && navigator.canShare && navigator.canShare({ files: [pdfArquivo] }));
    const app = pdfCanal === 'email' ? 'o e-mail' : 'o WhatsApp';
    $('pdf-pronto').textContent = 'PDF pronto (' + (pdfMargens ? 'com' : 'sem') + ' margens). ' + (podeAnexar
      ? 'Clique em "Enviar com anexo" e escolha ' + app + ' na janela de compartilhamento: o PDF vai anexado.'
      : 'Este aparelho não envia arquivos direto: clique em "Baixar PDF" e anexe o arquivo ' + (pdfCanal === 'email' ? 'no e-mail' : 'no WhatsApp') + '.');
    $('pdf-enviar').textContent = 'Enviar com anexo';
    delete $('pdf-enviar').dataset.soPdf;
    $('pdf-enviar').hidden = !podeAnexar;
    $('pdf-baixar').className = podeAnexar ? 'btn-sec' : 'btn';
    passoPdf(3);
    (podeAnexar ? $('pdf-enviar') : $('pdf-baixar')).focus();
  });
  function baixarPdf() {
    const url = URL.createObjectURL(pdfArquivo);
    const a = document.createElement('a');
    a.href = url; a.download = pdfArquivo.name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
  // como o "Enviar com anexos..." das consultas: texto + arquivo; se o aparelho recusar os dois juntos, oferece so o PDF.
  // Falhas vao para o log do servidor (o motivo so aparece no navegador).
  function enviarComAnexo(comTexto) {
    if (!pdfArquivo) return;
    const dados = { files: [pdfArquivo], title: 'Simulação de preços' };
    if (comTexto) dados.text = 'Segue a simulação de preços em PDF.';
    let p;
    try { p = navigator.share(dados); } catch (e) { p = Promise.reject(e); }
    p.then(() => {
      registrarEnvio(pdfCanal);
      $('comp-status').textContent = 'PDF enviado com anexo.';
      fecharPdf();
    }).catch((e) => {
      const nome = (e && e.name) || 'erro';
      if (nome === 'AbortError') return; // fechou a janela de compartilhamento sem escolher
      api('/api/registro', { origem: pdfCanal, texto: 'Simulador de preços: PDF com anexo', erro: nome + ': ' + ((e && e.message) || '') + (comTexto ? '' : ' | só o PDF') }).catch(() => { /* so o log */ });
      if (comTexto) {
        $('pdf-pronto').textContent = 'O aparelho recusou o envio com texto e anexo (' + nome + '). Clique em "Enviar só o PDF", ou em "Baixar PDF" para anexar.';
        $('pdf-enviar').textContent = 'Enviar só o PDF';
        $('pdf-enviar').dataset.soPdf = '1';
      } else {
        $('pdf-pronto').textContent = 'Não foi possível abrir o compartilhamento (' + nome + '): clique em "Baixar PDF" para anexar.';
      }
    });
  }
  $('pdf-enviar').addEventListener('click', () => { if (pdfCanal === 'imprimir') imprimirPdf(); else enviarComAnexo(!$('pdf-enviar').dataset.soPdf); });
  $('pdf-baixar').addEventListener('click', () => {
    if (!pdfArquivo) return;
    baixarPdf();
    if (pdfCanal !== 'imprimir') registrarEnvio(pdfCanal);
    $('comp-status').textContent = 'PDF baixado (' + pdfArquivo.name + ').';
  });
  $('pdf-cancelar').addEventListener('click', fecharPdf);
  $('pdf-fechar').addEventListener('click', fecharPdf);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('dlg-pdf').hidden && $('pdf-passo2').hidden) fecharPdf(); });
