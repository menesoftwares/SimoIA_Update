/*@parte Gestão: guia Gerais: título, dados e ordem da página inicial. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- guia Gerais: titulo da pagina (dono, 07/11/2026) ---------- */
  const NOME_OK = /^[\p{L}\p{N}][\p{L}\p{N} ._()-]{0,39}$/u; // o mesmo do servidor
  function mostrarNome(d) {
    const antigo = $('nome-sistema').dataset.atual || '';
    $('nome-sistema').value = d.nome || '';
    $('nome-sistema').dataset.atual = d.nome || '';
    $('nome-quando').textContent = d.alterado_em && d.alterado_por && d.alterado_por !== 'inicial' ? 'alterado em ' + dataBr(d.alterado_em) + ' por ' + d.alterado_por : 'padrão: ' + (d.padrao || 'SimoIA');
    // esta pagina ja mostra o nome novo (titulo da aba, cabecalho e a previa da aba)
    if (antigo && d.nome && antigo !== d.nome) {
      document.title = document.title.split(antigo).join(d.nome);
      document.querySelectorAll('.cabeca .sobre').forEach((e) => { e.textContent = d.nome; });
    }
    $('logo-aba-nome').textContent = d.nome || '';
  }
  // site da empresa (dono, 07/11/2026): link do rodape da tela inicial
  function mostrarSite(d) {
    if (d.site === undefined) return;
    $('site-empresa').value = d.site || '';
    $('site-empresa').dataset.atual = d.site || '';
    $('site-quando').textContent = d.site_alterado_em && d.site_alterado_por && d.site_alterado_por !== 'inicial'
      ? 'alterado em ' + dataBr(d.site_alterado_em) + ' por ' + d.site_alterado_por : 'padrão: ' + (d.site_padrao || '');
  }
  // cidade e UF da empresa (dono, 22/11/2026)
  const UFS = ['AC', 'AL', 'AM', 'AP', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MG', 'MS', 'MT', 'PA', 'PB', 'PE', 'PI', 'PR', 'RJ', 'RN', 'RO', 'RR', 'RS', 'SC', 'SE', 'SP', 'TO'];
  const CIDADE_OK = /^[\p{L}][\p{L} '-]{0,59}$/u; // o mesmo do servidor
  $('uf-empresa').innerHTML = '<option value="">--</option>' + UFS.map((u) => '<option>' + u + '</option>').join('');
  function mostrarCidade(d) {
    if (d.cidade === undefined) return;
    $('cidade-empresa').value = d.cidade || '';
    $('uf-empresa').value = d.uf || '';
    $('cidade-quando').textContent = d.cidade_alterado_em && d.cidade_alterado_por && d.cidade_alterado_por !== 'inicial'
      ? 'alterado em ' + dataBr(d.cidade_alterado_em) + ' por ' + d.cidade_alterado_por : '';
  }
  // atualizacao automatica (dono, 12/11/2026): ligada exige a hora
  function mostrarAtuAuto(d) {
    if (d.atualizar_auto === undefined) return;
    $('atuauto-ligado').checked = !!d.atualizar_auto;
    $('atuauto-hora').value = d.atualizar_auto_hora || '';
    $('atuauto-hora').disabled = !d.atualizar_auto;
    $('atuauto-quando').textContent = d.atualizar_auto_alterado_em && d.atualizar_auto_alterado_por ? 'alterado em ' + dataBr(d.atualizar_auto_alterado_em) + ' por ' + d.atualizar_auto_alterado_por : '';
    const aqui = d.atualizar_auto_aqui || {};
    $('atuauto-info').textContent = (aqui.pode_aqui === false ? 'Atenção: ' + (aqui.motivo || 'não dá para atualizar por aqui.') + ' ' : '') +
      (d.atualizar_auto_ultima ? 'Última verificação automática: ' + d.atualizar_auto_ultima : '');
  }
  $('atuauto-ligado').addEventListener('change', () => {
    $('atuauto-hora').disabled = !$('atuauto-ligado').checked;
    if ($('atuauto-ligado').checked) { if (!$('atuauto-hora').value) $('atuauto-hora').value = '03:00'; $('atuauto-hora').focus(); }
  });
  $('atuauto-salvar').addEventListener('click', async () => {
    const ligado = $('atuauto-ligado').checked, hora = $('atuauto-hora').value;
    if (ligado && !/^([01]\d|2[0-3]):[0-5]\d$/.test(hora)) { $('atuauto-msg').textContent = 'Informe a hora da atualização automática (ex.: 03:00).'; $('atuauto-hora').focus(); return; }
    $('atuauto-salvar').disabled = true;
    try {
      const d = await api('/api/admin/gerais', { atualizar_auto: ligado, hora });
      if (d.ok) mostrarAtuAuto(d);
      $('atuauto-msg').textContent = d.mensagem || (d.ok ? 'Salvo.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('atuauto-msg').textContent = 'Não foi possível falar com o servidor.';
    } finally { $('atuauto-salvar').disabled = false; }
  });
  // ordem da pagina inicial (dono, 16/11/2026): lista com subir/descer; salva os ids na ordem da tela
  let ohRotulos = {};
  let ohOcultos = new Set();
  function desenharOrdemHome(ordem) {
    const ol = $('oh-lista');
    ol.innerHTML = '';
    ordem.forEach((id, i) => {
      const li = document.createElement('li');
      li.dataset.id = id;
      // marcado = visivel na tela inicial
      const nome = document.createElement('label'); nome.className = 'oh-nome';
      const vis = document.createElement('input'); vis.type = 'checkbox'; vis.checked = !ohOcultos.has(id); vis.title = 'Mostrar na página inicial';
      vis.addEventListener('change', () => {
        if (vis.checked) ohOcultos.delete(id); else ohOcultos.add(id);
        li.classList.toggle('oh-oculto', !vis.checked);
        $('oh-msg').textContent = 'Alterado: clique em Salvar ordem.';
      });
      nome.append(vis, document.createTextNode(ohRotulos[id] || id));
      li.classList.toggle('oh-oculto', ohOcultos.has(id));
      const sobe = document.createElement('button'); sobe.type = 'button'; sobe.textContent = '↑'; sobe.title = 'Subir'; sobe.setAttribute('aria-label', 'Subir ' + (ohRotulos[id] || id)); sobe.disabled = i === 0;
      const desce = document.createElement('button'); desce.type = 'button'; desce.textContent = '↓'; desce.title = 'Descer'; desce.setAttribute('aria-label', 'Descer ' + (ohRotulos[id] || id)); desce.disabled = i === ordem.length - 1;
      const mover = (d) => { const o = ordemHomeTela(); const j = i + d; [o[i], o[j]] = [o[j], o[i]]; desenharOrdemHome(o); ol.children[j].querySelector(d < 0 ? 'button' : 'button:last-child').focus(); $('oh-msg').textContent = 'Ordem alterada: clique em Salvar ordem.'; };
      sobe.addEventListener('click', () => mover(-1));
      desce.addEventListener('click', () => mover(1));
      li.append(nome, sobe, desce);
      ol.appendChild(li);
    });
  }
  const ordemHomeTela = () => Array.from($('oh-lista').children).map((li) => li.dataset.id);
  function mostrarOrdemHome(d) {
    if (!d.ordem_home) return;
    ohRotulos = {};
    (d.baloes_home || []).forEach((b) => { ohRotulos[b.id] = b.rotulo; });
    ohOcultos = new Set(d.ocultos_home || []);
    desenharOrdemHome(d.ordem_home);
    $('oh-quando').textContent = d.ordem_home_alterado_em && d.ordem_home_alterado_por ? 'alterado em ' + dataBr(d.ordem_home_alterado_em) + ' por ' + d.ordem_home_alterado_por : 'ordem padrão';
  }
  async function salvarOrdemHome(ordem, botao) {
    botao.disabled = true;
    try {
      const d = await api('/api/admin/gerais', { ordem_home: ordem, ocultos_home: [...ohOcultos] });
      if (d.ok) mostrarOrdemHome(d);
      $('oh-msg').textContent = d.mensagem || (d.ok ? 'Ordem salva.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('oh-msg').textContent = 'Não foi possível falar com o servidor.';
    } finally { botao.disabled = false; }
  }
  $('oh-salvar').addEventListener('click', () => salvarOrdemHome(ordemHomeTela(), $('oh-salvar')));
  $('oh-padrao').addEventListener('click', async () => {
    if (!(await perguntar({ titulo: 'Ordem da página inicial', texto: 'Voltar os balões da página inicial à ordem padrão, todos visíveis?', sim: 'Voltar ao padrão' }))) return;
    salvarOrdemHome('padrao', $('oh-padrao'));
  });
  async function carregarNome() {
    try {
      const d = await api('/api/admin/gerais');
      if (d.ok) { mostrarNome(d); mostrarSite(d); mostrarCidade(d); mostrarAtuAuto(d); mostrarOrdemHome(d); } else $('nome-msg').textContent = d.mensagem || 'Não foi possível carregar o título.';
    } catch (e) { if (e.message !== 'sessao' && e.message !== 'proibido') $('nome-msg').textContent = 'Não foi possível falar com o servidor.'; }
  }
  // dados gerais (dono, 22/11/2026): titulo, site, cidade e UF salvos juntos
  $('dg-salvar').addEventListener('click', async () => {
    const nome = $('nome-sistema').value.replace(/\s+/g, ' ').trim();
    if (!NOME_OK.test(nome)) { $('nome-msg').textContent = 'Título inválido: use de 1 a 40 caracteres, começando com letra ou número (letras, números, espaço e . - _ ( ) ).'; $('nome-sistema').focus(); return; }
    let site = $('site-empresa').value.trim();
    if (site && !/^https?:\/\//i.test(site)) site = 'https://' + site;
    if (site && !/^https?:\/\/[A-Za-z0-9.-]+\.[A-Za-z]{2,}(:\d{1,5})?(\/[^\s"'<>`]*)?$/.test(site)) { // o mesmo do servidor
      $('nome-msg').textContent = 'Link inválido: use um endereço como https://www.empresa.com.br (ou deixe vazio para tirar o link do rodapé).'; $('site-empresa').focus(); return;
    }
    const cidade = $('cidade-empresa').value.replace(/\s+/g, ' ').trim();
    const uf = $('uf-empresa').value;
    if (cidade && !CIDADE_OK.test(cidade)) { $('nome-msg').textContent = 'Cidade inválida: use até 60 caracteres (letras, espaço, apóstrofo e hífen).'; $('cidade-empresa').focus(); return; }
    if (cidade && !uf) { $('nome-msg').textContent = 'Escolha a UF da cidade.'; $('uf-empresa').focus(); return; }
    if (!site && ($('site-empresa').dataset.atual || '') && !(await perguntar({ titulo: 'Site da empresa', texto: 'Deixar o rodapé da tela inicial sem o link do site?', sim: 'Tirar o link' }))) return;
    $('dg-salvar').disabled = true;
    try {
      const d = await api('/api/admin/gerais', { gerais: true, nome, site, cidade, uf });
      if (d.ok) { mostrarNome(d); mostrarSite(d); mostrarCidade(d); }
      $('nome-msg').textContent = d.mensagem || (d.ok ? 'Dados gerais salvos.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('nome-msg').textContent = 'Não foi possível falar com o servidor.';
    } finally { $('dg-salvar').disabled = false; }
  });
  ['nome-sistema', 'site-empresa', 'cidade-empresa'].forEach((id) => $(id).addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('dg-salvar').click(); } }));

