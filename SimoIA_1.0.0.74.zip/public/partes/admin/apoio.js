/*@parte Gestão: apoio, popup e guias principais. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  /* popup de confirmacao da tela (dono, 12/11/2026). perguntar({ titulo, texto, sim, nao }) -> Promise<boolean>; Esc ou Cancelar = false */
  function perguntar(o) {
    return new Promise((ok) => {
      const dlg = $('dlg-pergunta');
      $('pg-titulo').textContent = o.titulo || 'Confirmar';
      $('pg-texto').textContent = o.texto || '';
      $('pg-sim').textContent = o.sim || 'Sim';
      $('pg-nao').textContent = o.nao || 'Cancelar';
      let resp = false;
      dlg.addEventListener('close', () => { $('pg-sim').onclick = $('pg-nao').onclick = null; ok(resp); }, { once: true });
      $('pg-sim').onclick = () => { resp = true; dlg.close(); };
      $('pg-nao').onclick = () => dlg.close();
      dlg.showModal();
      $('pg-sim').focus();
    });
  }
  const semAcento = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();

  /* ---------- guias principais: graficos, dados do banco, usuarios (a ultima escolhida fica neste navegador) ---------- */
  const GUIAS = ['gerais', 'graficos', 'banco', 'usuarios', 'simulador', 'coletor', 'atualizacoes', 'interna'];
  function abrirGuia(g, foco) {
    if (!GUIAS.includes(g) || $('guia-' + g).hidden) g = 'graficos'; // Conf. interna: so aparece para o desenv
    for (const x of GUIAS) {
      const sel = x === g;
      $('guia-' + x).setAttribute('aria-selected', String(sel));
      $('guia-' + x).tabIndex = sel ? 0 : -1;
      $('painel-' + x).hidden = !sel;
    }
    if (foco) $('guia-' + g).focus();
    if (g === 'atualizacoes') carregarAtualizacoes();
    try { localStorage.setItem('simoia_gestao_guia', g); } catch (e) { /* sem armazenamento: so nao lembra */ }
  }
  GUIAS.forEach((g) => {
    $('guia-' + g).addEventListener('click', () => abrirGuia(g));
    // setas esquerda/direita, Home e End trocam de guia (padrao de abas acessiveis)
    $('guia-' + g).addEventListener('keydown', (e) => {
      const vis = GUIAS.filter((x) => !$('guia-' + x).hidden), n = vis.length, j = vis.indexOf(g);
      const alvo = e.key === 'ArrowRight' ? vis[(j + 1) % n] : e.key === 'ArrowLeft' ? vis[(j - 1 + n) % n] : e.key === 'Home' ? vis[0] : e.key === 'End' ? vis[n - 1] : null;
      if (alvo) { e.preventDefault(); abrirGuia(alvo, true); }
    });
  });
