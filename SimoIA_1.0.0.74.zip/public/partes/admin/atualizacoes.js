/*@parte Gestão: guia Atualizações. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- guia Atualizacoes: le o docs/NOVIDADES.md e mostra um cartao por versao (a mais nova aberta) ---------- */
  // markdown simples do NOVIDADES.md: ## versao, ### assunto, "- " item, **negrito**, `codigo`, paragrafos e ---
  function mdLinha(t) {
    return esc(t).replace(/`([^`]+)`/g, '<code>$1</code>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
  }
  function mdBloco(linhas) {
    let html = '', lista = false;
    const fecharLista = () => { if (lista) { html += '</ul>'; lista = false; } };
    for (const l of linhas) {
      const t = l.trim();
      if (!t || t === '---') { fecharLista(); continue; }
      if (t.startsWith('### ')) { fecharLista(); html += '<h4>' + mdLinha(t.slice(4)) + '</h4>'; continue; }
      if (/^[-*] /.test(t)) { if (!lista) { html += '<ul>'; lista = true; } html += '<li>' + mdLinha(t.slice(2)) + '</li>'; continue; }
      fecharLista(); html += '<p>' + mdLinha(t) + '</p>';
    }
    fecharLista();
    return html;
  }
  /* atualizacao pelo sistema (dono, 09/11/2026): o servidor le o versao.json do repositorio de atualizacoes (GitHub)
   * e compara com a versao instalada. "Atualizar agora" baixa, confere e instala (o servico para e volta sozinho);
   * esta pagina espera a versao nova responder em /api/saude e recarrega. */
  let atuInfo = null, atuEsperando = false;
  async function carregarDisponivel(forcar) {
    if (atuEsperando) return;
    const caixa = $('atu-disp');
    caixa.className = 'atu-disp';
    caixa.innerHTML = '<p class="nota">Procurando atualizações…</p>';
    let d;
    try { d = await api('/api/admin/atualizacao' + (forcar ? '?forcar=1' : '')); } catch (e) {
      if (e.message !== 'sessao') caixa.innerHTML = '<p class="nota">Não foi possível consultar as atualizações.</p>' + botoesDisp(false);
      return;
    }
    atuInfo = d;
    if (!d.ok) { caixa.innerHTML = '<p class="nota">' + esc(d.mensagem || 'Não foi possível consultar as atualizações.') + '</p>' + botoesDisp(false); return; }
    if (!d.nova) {
      caixa.innerHTML = '<h3>O sistema está atualizado</h3><p class="nota">Versão instalada ' + esc(d.instalada) + '. A mais nova publicada é a ' + esc(d.versao) +
        (d.data ? ' (' + esc(d.data) + ')' : '') + '.</p>' + botoesDisp(false);
      return;
    }
    caixa.className = 'atu-disp nova';
    caixa.innerHTML = '<h3>Nova versão disponível: ' + esc(d.versao) + (d.data ? ' <span class="atu-inst">' + esc(d.data) + '</span>' : '') + '</h3>' +
      '<p class="nota">Instalada: ' + esc(d.instalada) + '. Ao atualizar, o sistema fica fora do ar por cerca de 1 minuto para todos os usuários e volta sozinho. ' +
      'O banco e as configurações não são alterados, e o código atual fica guardado para voltar atrás.</p>' +
      (d.novidades ? '<div class="atu-corpo">' + mdBloco(d.novidades.split('\n')) + '</div>' : '') +
      (d.pode_aqui ? '' : '<p class="nota"><strong>' + esc(d.motivo || 'Não dá para atualizar por aqui.') + '</strong></p>') +
      (d.andando ? '<p class="nota"><strong>Já há uma atualização em andamento.</strong></p>' : '') +
      botoesDisp(true, !d.pode_aqui || d.andando);
  }
  function botoesDisp(comAtualizar, bloqueado) {
    return '<div class="atu-disp-acoes">' + (comAtualizar ? '<button type="button" class="btn" id="atu-aplicar"' + (bloqueado ? ' disabled' : '') + '>Atualizar agora</button>' : '') +
      '<button type="button" class="btn-sec" id="atu-verificar">Verificar de novo</button></div>';
  }
  $('atu-disp').addEventListener('click', async (e) => {
    if (e.target.id === 'atu-verificar') return carregarDisponivel(true);
    if (e.target.id !== 'atu-aplicar' || !atuInfo || !atuInfo.nova) return;
    const v = atuInfo.versao;
    if (!(await perguntar({ titulo: 'Atualizar o sistema', sim: 'Atualizar agora',
      texto: 'Atualizar o sistema para a versão ' + v + ' agora?\n\nO sistema fica fora do ar por cerca de 1 minuto para todos os usuários (o que estiver sendo feito nesse momento pode se perder) e volta sozinho.' }))) return;
    const caixa = $('atu-disp');
    e.target.disabled = true;
    caixa.querySelector('.atu-disp-acoes').insertAdjacentHTML('beforeend', '<span class="nota">Baixando e conferindo o pacote…</span>');
    let d;
    try { d = await api('/api/admin/atualizacao', { versao: v }); } catch (err) {
      if (err.message !== 'sessao') { caixa.insertAdjacentHTML('beforeend', '<p class="nota"><strong>Não foi possível falar com o servidor.</strong></p>'); e.target.disabled = false; }
      return;
    }
    if (!d.ok) { caixa.insertAdjacentHTML('beforeend', '<p class="nota"><strong>Não atualizou: ' + esc(d.mensagem || 'erro') + '</strong></p>'); e.target.disabled = false; return; }
    atuEsperando = true;
    caixa.innerHTML = '<h3>Atualizando para a versão ' + esc(v) + '…</h3><p class="nota" id="atu-espera">' + esc(d.mensagem) + ' Esta página recarrega sozinha quando o sistema voltar.</p>';
    // espera a versao nova responder (ate 5 min)
    const ate = Date.now() + 5 * 60 * 1000;
    const tentar = async () => {
      try {
        const r = await fetch('/api/saude', { cache: 'no-store' });
        const j = await r.json();
        if (j && j.versao === v) { $('atu-espera').textContent = 'Pronto: versão ' + v + ' no ar. Recarregando…'; setTimeout(() => location.reload(), 1500); return; }
      } catch (err) { /* fora do ar: ainda atualizando */ }
      if (Date.now() > ate) {
        $('atu-espera').innerHTML = 'O sistema ainda não voltou na versão ' + esc(v) + '. Confira no servidor o arquivo <code>C:\\AgenteIA\\logs\\atualizacao_ultima.log</code> ' +
          '(e o <code>logs\\atualizacoes.log</code>). Se precisar, rode o <code>iniciar_servico.bat</code>.';
        atuEsperando = false;
        return;
      }
      setTimeout(tentar, 4000);
    };
    setTimeout(tentar, 8000);
  });
  /* "Instalada em" de cada versao (dono, 13/11/2026): data e quem atualizou (usuario, automatico ou atualizar.bat). Versao
   * pulada (ex.: da 46 direto para a 48) nao sobe sozinha: aparece como instalada junto com a versao que a trouxe. */
  const cmpVersao = (a, b) => {
    const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) { const x = pa[i] || 0, y = pb[i] || 0; if (x !== y) return x < y ? -1 : 1; }
    return 0;
  };
  function atuInstalada(nv, d) {
    const hist = Array.isArray(d.historico) ? d.historico : [];
    const quem = (r) => (r.por ? ' por ' + esc(r.por) : '');
    const r = hist.find((x) => x.versao === nv);
    if (r) return '<span class="atu-inst">Instalada em ' + esc(dataBr(r.instalada_em)) + quem(r) + '</span>';
    if (d.instaladas && d.instaladas[nv]) return '<span class="atu-inst">Instalada em ' + esc(dataBr(d.instaladas[nv])) + '</span>';
    const junto = hist.find((x) => x.anterior && cmpVersao(x.anterior, nv) < 0 && cmpVersao(x.versao, nv) > 0);
    if (junto) return '<span class="atu-inst">Instalada junto com a ' + esc(junto.versao) + ' em ' + esc(dataBr(junto.instalada_em)) + quem(junto) + '</span>';
    return '';
  }
  let atuCarregada = false;
  async function carregarAtualizacoes() {
    carregarDisponivel(false); // a cada abertura da guia (o servidor guarda 5 min)
    if (atuCarregada) return;
    const caixa = $('atu-lista');
    try {
      const d = await api('/api/admin/atualizacoes');
      $('atu-versao').textContent = d.versao || '?';
      const partes = String(d.texto || '').replace(/\r/g, '').split(/^## /m).slice(1); // o que vem antes do 1o "## " e o cabecalho do arquivo
      if (!partes.length) { caixa.innerHTML = '<div class="vazio">Nenhuma atualização registrada.</div>'; return; }
      caixa.innerHTML = partes.map((p, i) => {
        const linhas = p.split('\n');
        const titulo = linhas.shift();
        const rc = /\bRC\b/.test(titulo) ? '<span class="selo atu-selo">nova</span>' : '';
        // data em que esta versao subiu neste servidor (tabela versoes_instaladas; 02/11/2026)
        const nv = (/^(\d+(?:\.\d+)+)/.exec(titulo) || [])[1];
        const inst = nv ? atuInstalada(nv, d) : '';
        return '<details class="atu-versao"' + (i === 0 ? ' open' : '') + '><summary>Versão ' + mdLinha(titulo.replace(/\s*\(RC[^)]*\)/, '')) + rc + inst + '</summary>' +
          '<div class="atu-corpo">' + mdBloco(linhas) + '</div></details>';
      }).join('');
      atuCarregada = true;
    } catch (e) {
      caixa.innerHTML = '<p class="nota">Não foi possível carregar as atualizações' + (e && e.message ? ': ' + esc(e.message) : '') + '.</p>';
    }
  }
  let guiaGuardada = null;
  try { guiaGuardada = localStorage.getItem('simoia_gestao_guia'); } catch (e) { /* ignora */ }
  abrirGuia(guiaGuardada || 'graficos');
  const dataBr = (dh) => { const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(String(dh || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] + ' ' + m[4] + ':' + m[5] : ''; };

  let dados = { usuarios: [], bis: [], eu: '' };
  let editando = null; // null = novo; senao o usuario

  function aviso(texto, tipo) {
    const a = $('aviso');
    a.textContent = texto; a.className = 'aviso ' + (tipo || 'ok'); a.hidden = !texto;
    if (texto && tipo !== 'erro') setTimeout(() => { if (a.textContent === texto) a.hidden = true; }, 6000);
  }

  async function api(url, corpo) {
    const r = await fetch(url, corpo ? {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify(corpo)
    } : { headers: { 'Authorization': 'Bearer ' + token } });
    let d = {};
    try { d = await r.json(); } catch (e) { /* ignora */ }
    if (r.status === 401) {
      // sessão caiu (ex.: entrou em outro equipamento): leva o aviso para a tela de login
      try { if (d.motivo === 'outro_acesso' && d.mensagem) sessionStorage.setItem('aviso', d.mensagem); } catch (e) { /* ignora */ }
      location.href = '/'; throw new Error('sessao');
    }
    if (r.status === 403) { $('conteudo').hidden = true; aviso(d.mensagem || 'Só usuários master podem gerenciar usuários.', 'erro'); throw new Error('proibido'); }
    return d;
  }

