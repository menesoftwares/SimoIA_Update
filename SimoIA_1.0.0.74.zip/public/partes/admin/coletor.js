/*@parte Gestão: guia Coletor: ajustes. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- guia Coletor: ajustes (31/10/2026) ---------- */
  function mostrarColetor(d) {
    $('col-decimal').checked = !!d.qtd_decimal;
    $('col-lote').checked = !!d.exige_lote;
    $('col-lote-kit').checked = !!d.exige_lote_kit;
    if (d.etiqueta) { $('col-etq-lote-produto').checked = d.etiqueta.exige_lote_produto !== false; $('col-etq-lote-kit').checked = !!d.etiqueta.exige_lote_kit; }
    $('col-tipo-padrao').value = d.tipo_padrao || 'todas';
    $('col-informar-qtd').checked = d.informar_qtd !== false;
    $('col-permitir-camera').checked = !!d.permitir_camera;
    $('col-pendentes').checked = d.pendentes !== false;
    $('col-pendentes-desde').value = d.pendentes_desde || '';
    $('col-pendentes-desde').disabled = !$('col-pendentes').checked;
    if (d.etiqueta) { $('col-etq-largura').value = d.etiqueta.largura; $('col-etq-altura').value = d.etiqueta.altura; $('col-etq-por-linha').value = d.etiqueta.por_linha; }
    $('col-ajuste-quando').textContent = d.alterado_em ? 'alterado em ' + dataBr(d.alterado_em) + (d.alterado_por ? ' por ' + d.alterado_por : '') : 'padrão: só inteiras';
  }
  async function carregarColetor() {
    try {
      const d = await api('/api/admin/coletor');
      if (d.ok) mostrarColetor(d); else $('col-msg').textContent = d.mensagem || 'Não foi possível carregar os ajustes do Coletor.';
    } catch (e) { if (e.message !== 'sessao' && e.message !== 'proibido') $('col-msg').textContent = 'Não foi possível falar com o servidor.'; }
  }
  $('col-pendentes').addEventListener('change', () => { $('col-pendentes-desde').disabled = !$('col-pendentes').checked; });
  $('col-salvar').addEventListener('click', async () => {
    if ($('col-pendentes').checked && !$('col-pendentes-desde').value) { $('col-msg').textContent = 'Escolha a data em "Notas a conferir a partir de".'; $('col-pendentes-desde').focus(); return; }
    $('col-salvar').disabled = true;
    try {
      const d = await api('/api/admin/coletor', { qtd_decimal: $('col-decimal').checked, exige_lote: $('col-lote').checked, exige_lote_kit: $('col-lote-kit').checked,
        etiqueta_exige_lote_produto: $('col-etq-lote-produto').checked, etiqueta_exige_lote_kit: $('col-etq-lote-kit').checked, tipo_padrao: $('col-tipo-padrao').value, informar_qtd: $('col-informar-qtd').checked, permitir_camera: $('col-permitir-camera').checked,
        pendentes: $('col-pendentes').checked, pendentes_desde: $('col-pendentes-desde').value || undefined,
        etiqueta_largura: $('col-etq-largura').value, etiqueta_altura: $('col-etq-altura').value, etiqueta_por_linha: $('col-etq-por-linha').value });
      if (d.ok) mostrarColetor(d);
      $('col-msg').textContent = d.mensagem || (d.ok ? 'Ajustes salvos.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('col-msg').textContent = 'Não foi possível falar com o servidor.';
    } finally { $('col-salvar').disabled = false; }
  });

  async function carregar() {
    try {
      const d = await api('/api/admin/usuarios');
      if (!d.ok) { aviso(d.mensagem || 'Não foi possível carregar os usuários.', 'erro'); return; }
      dados = d;
      $('conteudo').hidden = false;
      desenhar();
      carregarUso();
      carregarPessoas();
      carregarServico();
      carregarConexoes();
      carregarSimulador();
      carregarSqls('coletor');
      carregarColetor();
      carregarLogo();
      carregarNome();
      carregarInterna();
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') aviso('Não foi possível falar com o servidor.', 'erro');
    }
  }

  const nomeBi = (w) => { const b = dados.bis.find((x) => x.wid === w); return b ? b.rotulo : 'BI ' + w; };

  function desenhar() {
    const filtro = semAcento($('busca').value.trim());
    const dig = filtro.replace(/\D/g, '');
    const us = dados.usuarios.filter((u) => {
      if (!filtro) return true;
      // nome, usuario, e-mail ou celular (no celular, so os numeros digitados)
      return semAcento([u.usuario, u.nome, u.email, u.celular_fmt].join(' ')).includes(filtro) ||
        (dig.length >= 3 && String(u.celular || '').includes(dig));
    });
    const ativos = dados.usuarios.filter((u) => u.ativo).length;
    const masters = dados.usuarios.filter((u) => u.master).length;
    $('resumo').textContent = dados.usuarios.length + (dados.usuarios.length === 1 ? ' usuário' : ' usuários') + ' · ' + ativos + ' ativos · ' + masters + ' master' +
      (filtro ? ' · mostrando ' + us.length : '');
    const lista = $('lista');
    if (!us.length) { lista.innerHTML = '<div class="vazio">' + (filtro ? 'Nenhum usuário encontrado para essa busca.' : 'Nenhum usuário cadastrado.') + '</div>'; return; }
    lista.innerHTML = us.map((u) => {
      const selos = [];
      if (u.master) selos.push('<span class="selo">Master</span>');
      if (u.conectado) selos.push('<span class="selo on">Conectado</span>');
      if (!u.ativo) selos.push('<span class="selo alerta">' + (u.bloqueado_em ? 'Bloqueado por senha errada' : 'Bloqueado') + '</span>');
      if (!u.tem_senha) selos.push('<span class="selo alerta">Sem senha</span>');
      if (u.tela_inicial === 'simulador') selos.push('<span class="selo">Só Simulador</span>');
      if (u.tela_inicial === 'coletor') selos.push('<span class="selo">Só Coletor (conf)</span>');
      if (u.tela_inicial === 'coletor_rastro') selos.push('<span class="selo">Só Coletor (rast)</span>');
      const bio = u.biometria || [];
      if (bio.length) selos.push('<span class="selo">Digital / rosto</span>');
      if (u.usuario.toLowerCase() === String(dados.eu).toLowerCase()) selos.push('<span class="selo">Você</span>');
      const comp = [u.pode_email ? 'E-mail' : null, u.pode_whats ? 'WhatsApp' : null].filter(Boolean).join(' e ') || 'não compartilha';
      const rel = u.demonstracao ? 'todos com dados fictícios (demonstração)' : u.sempre_tudo ? 'todos (desenv)' : (u.bis.length ? u.bis.map(nomeBi).join('; ') : 'nenhum');
      return '<div class="usuario' + (u.ativo ? '' : ' inativo') + '">' +
        '<div><div class="u-nome">' + esc(u.nome || u.usuario) + '</div><div class="u-login">' + esc(u.usuario) + '</div><div class="selos">' + selos.join('') + '</div></div>' +
        '<div class="u-contato"><div><strong>E-mail:</strong> ' + (u.email ? esc(u.email) : '—') + '</div><div><strong>Celular:</strong> ' + (u.celular_fmt ? esc(u.celular_fmt) : '—') + '</div>' +
        '<div><strong>Compartilha:</strong> ' + esc(comp) + '</div>' +
        '<div><strong>Simulador:</strong> ' + (u.sempre_tudo ? 'sim (desenv)' : u.pode_simulador ? 'sim' : 'não') + (u.pode_integrar ? ' · integra pedidos' : '') + (u.pode_sim_manut || u.sempre_tudo ? ' · manutenção' : '') + (u.pode_sim_custo || u.sempre_tudo ? ' · escolhe o custo' : '') + '</div>' +
        '<div><strong>Coletor:</strong> ' + (u.sempre_tudo ? 'sim (desenv)' : u.pode_coletor ? 'sim' : 'não') + (u.pode_col_manut || u.sempre_tudo ? ' · manutenção' : '') + (u.pode_col_etiq || u.sempre_tudo ? ' · etiquetas' : '') + (u.pode_col_rastro || u.sempre_tudo ? ' · rastro' : '') + '</div></div>' +
        '<div class="u-acesso"><div><strong>Relatórios:</strong> ' + esc(rel) + '</div><div><strong>Último acesso:</strong> ' + (u.ultimo_login ? esc(dataBr(u.ultimo_login)) : 'nunca') + '</div>' +
          (u.conectado ? '<div><strong>Conectado:</strong> ' + esc(u.conectado.aparelho || 'navegador') + (u.conectado.ip ? ' (' + esc(u.conectado.ip) + ')' : '') +
            (u.conectado.uso ? ', uso ' + esc(u.conectado.uso) : '') + (u.conectado.sessoes > 1 ? ' · ' + u.conectado.sessoes + ' sessões' : '') + '</div>' : '') +
          (u.bloqueado_em ? '<div><strong>Bloqueado em:</strong> ' + esc(dataBr(u.bloqueado_em)) + ' (senha errada)</div>' : '') +
          // digital/rosto: em quais aparelhos esta ativa (e botao para remover, ex.: celular perdido)
          (!u.biometria_permitida ? '<div><strong>Digital / rosto:</strong> não permitido (entra só com senha)</div>'
            : bio.length ? '<div><strong>Digital / rosto:</strong> ' + bio.map((c) => esc(c.aparelho) + ' (desde ' + esc(dataBr(c.criado)) +
              (c.ultimo_uso ? ', último uso ' + esc(dataBr(c.ultimo_uso)) : '') + ')').join('; ') +
              ' <button class="link-acao" type="button" data-bio-remover="' + esc(u.usuario) + '"' + (u.protegido ? ' disabled title="Só o próprio usuário altera"' : '') + '>Remover</button></div>' : '') + '</div>' +
        // desenv visto por outro master (dono, 02/11/2026): so o proprio altera; aqui fica so consulta (Log)
        '<div class="acoes"><button class="btn-sec" type="button" data-editar="' + esc(u.usuario) + '"' + (u.protegido ? ' disabled title="Só o próprio usuário altera o cadastro dele"' : '') + '>Editar</button>' +
        '<button class="btn-sec" type="button" data-log="' + esc(u.usuario) + '">Log</button>' +
        '<button class="btn-sec" type="button" data-senha="' + esc(u.usuario) + '"' + (u.senha_protegida || u.protegido ? ' disabled title="Só o próprio usuário troca esta senha"' : '') + '>Senha</button>' +
        '<button class="btn-perigo" type="button" data-logoff="' + esc(u.usuario) + '"' + (u.protegido ? ' disabled title="Só o próprio usuário"' : u.conectado ? '' : ' disabled title="Não está conectado"') + '>Logoff</button></div>' +
        '</div>';
    }).join('');
  }

  // remove a digital/rosto de um usuario (todos os aparelhos): ele volta a entrar com a senha e pode ativar de novo
  async function removerBiometria(usuario) {
    if (!(await perguntar({ titulo: 'Remover digital/rosto', texto: 'Remover a entrada por digital/rosto de "' + usuario + '" em todos os aparelhos?\n\nEle continua entrando com a senha e pode ativar de novo.', sim: 'Remover' }))) return;
    try {
      const d = await api('/api/admin/biometria-remover', { usuario });
      aviso(d.mensagem || (d.ok ? 'Removida.' : 'Não foi possível remover.'), d.ok ? 'ok' : 'erro');
      if (d.ok) carregar();
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') aviso('Não foi possível falar com o servidor.', 'erro');
    }
  }

