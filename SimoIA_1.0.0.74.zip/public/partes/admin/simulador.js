/*@parte Gestão: guia Simulador: Excel personalizado. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- guia Simulador: so os SQLs (os parametros por UF foram para a Manutencao do Simulador, 02/11/2026) ---------- */
  function carregarSimulador() { carregarSqls('simulador'); carregarExcelSim(); }
  /* ---------- guia Simulador: Excel personalizado (dono, 13/11/2026) ---------- */
  let sxCampos = [], sxCols = [];
  const sxLetra = (i) => (i < 26 ? String.fromCharCode(65 + i) : String.fromCharCode(64 + Math.floor(i / 26)) + String.fromCharCode(65 + (i % 26)));
  function sxOpcoes(sel) {
    const grupos = [];
    for (const c of sxCampos) { let g = grupos.find((x) => x.nome === c.grupo); if (!g) grupos.push(g = { nome: c.grupo, itens: [] }); g.itens.push(c); }
    return '<option value="">Escolha o campo…</option>' + grupos.map((g) => '<optgroup label="' + esc(g.nome) + '">' +
      g.itens.map((c) => '<option value="' + esc(c.chave) + '"' + (c.chave === sel ? ' selected' : '') + '>' + esc(c.rotulo) + '</option>').join('') + '</optgroup>').join('');
  }
  function sxDesenhar() {
    const n = sxCols.length;
    $('sx-tab').innerHTML = '<thead><tr><th>Coluna</th><th>Nome no cabeçalho</th><th>Campo do Simulador</th><th></th></tr></thead><tbody>' + (n ? sxCols.map((c, i) =>
      '<tr><td>' + sxLetra(i) + '1</td>' +
      '<td><input type="text" maxlength="60" data-sx-nome="' + i + '" value="' + esc(c.nome) + '" aria-label="Nome da coluna ' + sxLetra(i) + '"></td>' +
      '<td><select data-sx-campo="' + i + '" aria-label="Campo da coluna ' + sxLetra(i) + '">' + sxOpcoes(c.campo) + '</select></td>' +
      '<td class="sx-acoes"><button type="button" data-sx-mover="' + i + ',-1"' + (i ? '' : ' disabled') + ' aria-label="Subir coluna ' + sxLetra(i) + '">↑</button>' +
      '<button type="button" data-sx-mover="' + i + ',1"' + (i < n - 1 ? '' : ' disabled') + ' aria-label="Descer coluna ' + sxLetra(i) + '">↓</button>' +
      '<button type="button" data-sx-tirar="' + i + '" aria-label="Remover coluna ' + sxLetra(i) + '">✕</button></td></tr>').join('')
      : '<tr><td colspan="4" class="nota">Nenhuma coluna ainda. Clique em "+ Adicionar coluna".</td></tr>') + '</tbody>';
  }
  async function carregarExcelSim() {
    try {
      const d = await api('/api/admin/simulador-excel');
      if (!d.ok) return;
      sxMostrar(d);
    } catch (e) { if (e.message !== 'sessao' && e.message !== 'proibido') $('sx-msg').textContent = 'Não foi possível carregar o Excel personalizado.'; }
  }
  function sxMostrar(d) {
    sxCampos = d.campos || [];
    sxCols = ((d.layout && d.layout.colunas) || []).map((c) => ({ nome: c.nome, campo: c.campo }));
    $('sx-gerais').checked = !!(d.layout && d.layout.dados_gerais);
    $('sx-quando').textContent = d.alterado_em ? 'alterado em ' + dataBr(d.alterado_em) + ' por ' + d.alterado_por : '';
    sxDesenhar();
  }
  $('sx-tab').addEventListener('input', (e) => {
    const i = e.target.dataset.sxNome;
    if (i != null) sxCols[i].nome = e.target.value;
  });
  $('sx-tab').addEventListener('change', (e) => {
    const i = e.target.dataset.sxCampo;
    if (i == null) return;
    const antes = sxCampos.find((c) => c.chave === sxCols[i].campo);
    const novo = sxCampos.find((c) => c.chave === e.target.value);
    sxCols[i].campo = e.target.value;
    // nome vazio (ou o nome padrao do campo anterior): sugere o nome do campo escolhido
    if (novo && (!sxCols[i].nome.trim() || (antes && sxCols[i].nome === antes.rotulo))) {
      sxCols[i].nome = novo.rotulo;
      const inp = $('sx-tab').querySelector('[data-sx-nome="' + i + '"]');
      if (inp) inp.value = novo.rotulo;
    }
  });
  $('sx-tab').addEventListener('click', (e) => {
    const m = e.target.closest('[data-sx-mover]'), t = e.target.closest('[data-sx-tirar]');
    if (m) {
      const [i, d] = m.dataset.sxMover.split(',').map(Number);
      [sxCols[i], sxCols[i + d]] = [sxCols[i + d], sxCols[i]];
      sxDesenhar();
      const b = $('sx-tab').querySelector('[data-sx-mover="' + (i + d) + ',' + d + '"]');
      if (b && !b.disabled) b.focus();
    } else if (t) {
      sxCols.splice(Number(t.dataset.sxTirar), 1);
      sxDesenhar();
    }
  });
  $('sx-add').addEventListener('click', () => {
    if (sxCols.length >= 60) { $('sx-msg').textContent = 'No máximo 60 colunas.'; return; }
    sxCols.push({ nome: '', campo: '' });
    sxDesenhar();
    const sel = $('sx-tab').querySelector('[data-sx-campo="' + (sxCols.length - 1) + '"]');
    if (sel) sel.focus();
  });
  $('sx-salvar').addEventListener('click', async () => {
    for (let i = 0; i < sxCols.length; i++) {
      if (!sxCols[i].campo) { $('sx-msg').textContent = 'Coluna ' + sxLetra(i) + ': escolha o campo.'; $('sx-tab').querySelector('[data-sx-campo="' + i + '"]').focus(); return; }
      if (!sxCols[i].nome.trim()) { $('sx-msg').textContent = 'Coluna ' + sxLetra(i) + ': informe o nome.'; $('sx-tab').querySelector('[data-sx-nome="' + i + '"]').focus(); return; }
    }
    $('sx-salvar').disabled = true;
    try {
      const d = await api('/api/admin/simulador-excel', { colunas: sxCols, dados_gerais: $('sx-gerais').checked });
      if (d.ok) sxMostrar(d);
      $('sx-msg').textContent = d.mensagem || (d.ok ? 'Salvo.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('sx-msg').textContent = 'Não foi possível falar com o servidor.';
    } finally { $('sx-salvar').disabled = false; }
  });

