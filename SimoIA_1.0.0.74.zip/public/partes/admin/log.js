/*@parte Gestão: logoff, senha de usuário, log, ranking e acessos. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- logoff: derruba as sessões do usuário (ele vê o aviso na tela) ---------- */
  /* ---------- trocar a senha de um usuário (master); a do desenv só ele mesmo ---------- */
  let senhaDe = null;
  function abrirSenha(usuario) {
    const u = dados.usuarios.find((x) => x.usuario === usuario);
    if (!u || u.senha_protegida) return;
    senhaDe = usuario;
    $('sn-titulo').textContent = 'Trocar a senha de ' + (u.nome || usuario);
    $('sn-nova').value = ''; $('sn-repete').value = ''; $('sn-erro').textContent = '';
    $('sn-nota').textContent = usuario.toLowerCase() === String(dados.eu).toLowerCase()
      ? 'Esta é a sua senha. Suas outras sessões abertas serão encerradas; esta continua.'
      : 'As sessões abertas de ' + usuario + ' serão encerradas: ele entra de novo com a senha nova.';
    $('dlg-senha').showModal();
    $('sn-nova').focus();
  }
  $('sn-cancelar').addEventListener('click', () => $('dlg-senha').close());
  $('sn-fechar').addEventListener('click', () => $('dlg-senha').close());
  $('sn-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const nova = $('sn-nova').value, repete = $('sn-repete').value;
    if (nova.length < 4) { $('sn-erro').textContent = 'A senha precisa ter pelo menos 4 caracteres.'; $('sn-nova').focus(); return; }
    if (nova !== repete) { $('sn-erro').textContent = 'As duas senhas não são iguais.'; $('sn-repete').focus(); return; }
    const btn = $('sn-salvar');
    btn.disabled = true;
    try {
      const d = await api('/api/admin/senha', { usuario: senhaDe, senha: nova });
      if (!d.ok) { $('sn-erro').textContent = d.mensagem || 'Não foi possível trocar a senha.'; return; }
      $('dlg-senha').close();
      aviso(d.mensagem || 'Senha alterada.', 'ok');
      carregar();
    } catch (err) {
      if (err.message !== 'sessao' && err.message !== 'proibido') $('sn-erro').textContent = 'Não foi possível falar com o servidor.';
    } finally {
      btn.disabled = false;
    }
  });

  async function fazerLogoff(usuario) {
    const u = dados.usuarios.find((x) => x.usuario === usuario);
    const eu = usuario.toLowerCase() === String(dados.eu).toLowerCase();
    const onde = u && u.conectado ? ' (' + (u.conectado.aparelho || 'navegador') + (u.conectado.ip ? ', IP ' + u.conectado.ip : '') + ')' : '';
    if (!(await perguntar({ titulo: eu ? 'Encerrar outras sessões' : 'Fazer logoff', texto: eu ? 'Encerrar as suas OUTRAS sessões abertas? Esta aqui continua.' : 'Fazer logoff de "' + usuario + '"' + onde + '? A sessão dele será encerrada agora e ele verá o aviso na tela.', sim: eu ? 'Encerrar' : 'Fazer logoff' }))) return;
    try {
      const d = await api('/api/admin/logoff', { usuario });
      aviso(d.mensagem || (d.ok ? 'Logoff feito.' : 'Não foi possível fazer o logoff.'), d.ok ? 'ok' : 'erro');
      await carregar();
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') aviso('Não foi possível falar com o servidor.', 'erro');
    }
  }

  /* ---------- log: últimas 50 pesquisas do usuário ---------- */
  const TIPOS_LOG = { pergunta: 'Pergunta', formulario: 'Consulta montada', excel: 'Excel', email: 'E-mail', whatsapp: 'WhatsApp',
    compartilhar: 'Compartilhar', gestao: 'Gestão', sugestao: 'Sugestão aceita' };
  const SITUACOES_LOG = { ok: 'ok', erro: 'erro', esclarecer: 'pediu esclarecimento', vazio: 'sem dados' };
  const EVENTOS_LOG = { login: ['Entrou', ''], sair: ['Saiu', ''], falha: ['Senha errada', 'alerta'], bloqueado: ['Bloqueado 5 min (IP)', 'alerta'],
    inativado: ['INATIVADO por senha errada', 'alerta'], falha_bloqueado: ['Tentou entrar bloqueado', 'alerta'], derrubada: ['Derrubada (outro acesso)', 'alerta'],
    logoff_admin: ['Logoff pelo administrador', 'alerta'], senha: ['Trocou a senha', ''], senha_falha: ['Troca: senha atual errada', 'alerta'],
    senha_admin: ['Senha trocada pelo administrador', 'alerta'], login_biometria: ['Entrou (digital/rosto)', ''], falha_biometria: ['Digital/rosto recusada', 'alerta'],
    biometria_ativada: ['Ativou digital/rosto', ''], biometria_removida: ['Desativou digital/rosto', ''],
    senha_email_pedido: ['Pediu link de nova senha (e-mail)', ''], senha_email: ['Criou nova senha pelo link do e-mail', 'alerta'] };
  let logAtual = null;
  function desenharLog(aba) {
    $('aba-pesq').setAttribute('aria-selected', String(aba === 'pesq'));
    $('aba-aces').setAttribute('aria-selected', String(aba === 'aces'));
    $('aba-apre').setAttribute('aria-selected', String(aba === 'apre'));
    const d = logAtual;
    if (!d) return;
    if (aba === 'apre') { desenharAprendizado(d.usuario); return; }
    if (aba === 'pesq') {
      const itens = d.itens || [];
      $('log-resumo').className = 'nota';
      $('log-resumo').textContent = itens.length ? 'Últimas ' + itens.length + ' pesquisas e ações de ' + d.usuario + ', da mais recente para a mais antiga.' : d.usuario + ' ainda não fez nenhuma pesquisa.';
      $('log-lista').innerHTML = itens.map((x) => {
        const sit = SITUACOES_LOG[x.situacao] || x.situacao || '';
        const tempo = x.tempo_ms ? (x.tempo_ms / 1000).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' s' : '';
        return '<div class="log-item"><div class="log-texto"><span class="log-tipo">' + esc(TIPOS_LOG[x.origem] || x.origem || '') + '</span>' + esc(x.texto || '—') + '</div>' +
          '<div class="log-info">' + esc(dataBr(x.data_hora)) + (sit ? ' · ' + (x.situacao === 'erro' ? '<span class="erro">erro</span>' : esc(sit)) : '') + (tempo ? ' · ' + esc(tempo) : '') + '</div></div>';
      }).join('');
      return;
    }
    // acessos + bloqueios por senha errada (com quem desbloqueou), numa lista só, do mais recente para o mais antigo
    const bl = d.bloqueios || [];
    const ac = d.acessos || [];
    $('log-resumo').className = bl.some((b) => !b.desbloqueado_em) ? 'nota alerta' : 'nota';
    $('log-resumo').textContent = (bl.length ? bl.length + (bl.length === 1 ? ' bloqueio' : ' bloqueios') + ' por senha errada. ' : 'Nenhum bloqueio por senha errada. ') +
      'Últimos ' + ac.length + ' acessos, do mais recente para o mais antigo.';
    // "2026-10-12 16:22:05" -> "12/10/2026 16:22:05" (com segundos: vários eventos no mesmo minuto)
    const dataSeg = (dh) => { const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):?(\d{2})?/.exec(String(dh || '')); return m ? m[3] + '/' + m[2] + '/' + m[1] + ' ' + m[4] + ':' + m[5] + ':' + (m[6] || '00') : ''; };
    // "Mozilla/5.0 (Windows NT 10.0...) ... Chrome/..." -> "Chrome no Windows" (o texto já curto, como "Edge no Windows", fica igual)
    const aparelho = (ua) => {
      ua = String(ua || '');
      if (!/Mozilla\//.test(ua)) return ua.slice(0, 90);
      const nav = /Edg\//.test(ua) ? 'Edge' : /OPR\/|Opera/.test(ua) ? 'Opera' : /Firefox\//.test(ua) ? 'Firefox' : /Chrome\//.test(ua) ? 'Chrome' : /Safari\//.test(ua) ? 'Safari' : 'navegador';
      const so = /Windows/.test(ua) ? 'Windows' : /Android/.test(ua) ? 'Android' : /iPhone/.test(ua) ? 'iPhone' : /iPad/.test(ua) ? 'iPad' : /Mac OS X|Macintosh/.test(ua) ? 'Mac' : /Linux/.test(ua) ? 'Linux' : '';
      return nav + (so ? ' no ' + so : '');
    };
    const itens = bl.map((b) => ({ quando: String(b.data_hora || ''), ordem: 1, html: '<div class="log-item"><div class="log-texto"><span class="log-tipo alerta">Bloqueio</span>Inativado após ' + esc(b.tentativas) +
      ' tentativas com senha errada</div><div class="log-info">' + esc(dataSeg(b.data_hora)) + (b.aparelho ? ' · ' + esc(b.aparelho) : '') + (b.ip ? ' · IP ' + esc(b.ip) : '') +
      ' · ' + (b.desbloqueado_em ? 'desbloqueado em ' + esc(dataBr(b.desbloqueado_em)) + ' por ' + esc(b.desbloqueado_por || '?') : '<span class="erro">ainda bloqueado</span>') + '</div></div>' }))
      .concat(ac.map((x, i) => {
        const ev = EVENTOS_LOG[x.evento] || [x.evento, ''];
        return { quando: String(x.data_hora || ''), ordem: 0, id: x.id || -i, html: '<div class="log-item"><div class="log-texto"><span class="log-tipo ' + ev[1] + '">' + esc(ev[0]) + '</span>' + esc(x.ip ? 'IP ' + x.ip : '') + '</div>' +
          '<div class="log-info">' + esc(dataSeg(x.data_hora)) + (x.navegador ? ' · ' + esc(aparelho(x.navegador)) : '') + '</div></div>' };
      }))
      // mais recente primeiro; no mesmo segundo, o bloqueio antes do acesso que o causou, e o acesso mais novo antes
      .sort((a, b) => (a.quando < b.quando ? 1 : a.quando > b.quando ? -1 : (b.ordem - a.ordem) || ((b.id || 0) - (a.id || 0))));
    $('log-lista').innerHTML = itens.map((x) => x.html).join('') || '<p class="nota">Nenhum acesso registrado.</p>';
  }
  $('aba-pesq').addEventListener('click', () => desenharLog('pesq'));
  $('aba-aces').addEventListener('click', () => desenharLog('aces'));
  $('aba-apre').addEventListener('click', () => desenharLog('apre'));
  // o que o app aprendeu do jeito da pessoa pesquisar: costumes por relatório e palavras ligadas a cada relatório
  const TIPOS_COSTUME = { agrupar: 'Separa', metrica: 'Medida', periodo: 'Período', filtro: 'Filtro' };
  async function desenharAprendizado(usuario) {
    $('log-resumo').className = 'nota';
    $('log-resumo').textContent = 'Carregando…';
    $('log-lista').innerHTML = '';
    let d;
    try { d = await api('/api/admin/aprendizado?usuario=' + encodeURIComponent(usuario)); } catch (e) { $('log-resumo').textContent = 'Não foi possível falar com o servidor.'; return; }
    if ($('aba-apre').getAttribute('aria-selected') !== 'true') return; // trocou de aba enquanto carregava
    if (!d.ok) { $('log-resumo').textContent = d.mensagem || 'Não foi possível carregar.'; return; }
    const rels = d.relatorios || [];
    $('log-resumo').textContent = rels.length
      ? 'O que o app aprendeu de ' + usuario + ' (o mais recente pesa mais). Com 5 pesquisas num relatório, ele passa a sugerir os costumes que a pergunta não trouxer.'
      : usuario + ' ainda não tem pesquisas suficientes para o app aprender.';
    let html = rels.map((r) => '<div class="log-item"><div class="log-texto"><strong>' + esc(r.rotulo) + '</strong> · ' + esc(r.pesquisas) + (r.pesquisas === 1 ? ' pesquisa' : ' pesquisas') + '</div>' +
      (r.costumes.length ? r.costumes.map((c) => '<div class="log-info"><span class="log-tipo">' + esc(TIPOS_COSTUME[c.tipo] || c.tipo) + '</span>' + esc(c.descricao) +
        ' · ' + esc(c.vezes) + 'x (' + esc(c.parte) + '%)' + (c.sugerida ? ' · sugerido ' + esc(c.sugerida) + 'x, aceito ' + esc(c.aceita) + 'x' : '') + '</div>').join('')
        : '<div class="log-info">Ainda sem costumes (precisa repetir 2 vezes ou mais).</div>') + '</div>').join('');
    const ts = d.termos || [];
    if (ts.length) {
      html += '<div class="log-item"><div class="log-texto"><strong>Palavras aprendidas</strong> (para entender perguntas que não dizem o assunto)</div><div class="log-info">' +
        ts.map((t) => esc(t.termo) + ' → ' + esc(t.assunto) + ' (' + esc(t.vezes) + 'x)').join(' · ') + '</div></div>';
    }
    if (rels.length || ts.length) html += '<div class="log-item"><button class="btn-sec" type="button" id="esquecer">Esquecer o que foi aprendido</button></div>';
    $('log-lista').innerHTML = html;
    const b = $('esquecer');
    if (b) b.addEventListener('click', async () => {
      if (!(await perguntar({ titulo: 'Apagar aprendizado', texto: 'Apagar tudo o que o app aprendeu de "' + usuario + '"?\n\nO histórico de pesquisas fica. O app volta a aprender com as próximas pesquisas.', sim: 'Apagar' }))) return;
      try {
        const r = await api('/api/admin/esquecer', { usuario });
        $('log-resumo').textContent = r.mensagem || '';
        if (r.ok) $('log-lista').innerHTML = '';
      } catch (e) { $('log-resumo').textContent = 'Não foi possível falar com o servidor.'; }
    });
  }
  async function abrirLog(usuario) {
    const u = dados.usuarios.find((x) => x.usuario === usuario);
    $('log-titulo').textContent = 'Log de ' + (u && u.nome ? u.nome : usuario);
    $('log-resumo').textContent = 'Carregando…';
    $('log-lista').innerHTML = '';
    logAtual = null;
    $('dlg-log').showModal();
    try {
      const d = await api('/api/admin/log?usuario=' + encodeURIComponent(usuario));
      if (!d.ok) { $('log-resumo').textContent = d.mensagem || 'Não foi possível carregar o log.'; return; }
      logAtual = d;
      desenharLog(u && u.bloqueado_em ? 'aces' : 'pesq'); // bloqueado: abre direto em acessos e bloqueios
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('log-resumo').textContent = 'Não foi possível falar com o servidor.';
    }
  }
  $('log-fechar').addEventListener('click', () => $('dlg-log').close());
  $('log-ok').addEventListener('click', () => $('dlg-log').close());

  // usuarios fora da conta dos graficos (config "gestao_ignorar"; padrao: desenv)
  const semContar = (d) => (d && d.ignorados && d.ignorados.length ? ' Sem contar: ' + d.ignorados.join(', ') + '.' : '');

  /* ---------- ranking dos relatórios (BIs) mais acessados ---------- */
  async function carregarUso() {
    const dias = $('uso-dias').value;
    $('uso-resumo').textContent = 'Carregando…';
    try {
      const d = await api('/api/admin/uso?dias=' + encodeURIComponent(dias));
      if (!d.ok) { $('uso-resumo').textContent = d.mensagem || 'Não foi possível carregar o uso dos relatórios.'; return; }
      const itens = d.itens || [];
      const periodo = $('uso-dias').selectedOptions[0].textContent.toLowerCase();
      $('uso-resumo').textContent = (d.total ? d.total.toLocaleString('pt-BR') + (d.total === 1 ? ' pesquisa' : ' pesquisas') + ' com resposta (' + periodo + '), por relatório.' :
        'Nenhuma pesquisa com resposta (' + periodo + ').') + semContar(d);
      const max = Math.max(1, ...itens.map((x) => x.total));
      let pos = 0;
      $('uso-barras').innerHTML = itens.map((x) => {
        if (x.total) pos++;
        const pct = x.pct.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%';
        const ult = x.ultimo ? 'último uso ' + dataBr(x.ultimo) : 'sem uso no período';
        return '<div class="uso-linha' + (x.total ? '' : ' zero') + '" title="' + esc(x.rotulo + ' — ' + ult) + '">' +
          '<div class="uso-pos">' + (x.total ? pos + 'º' : '—') + '</div>' +
          '<div class="uso-nome">' + esc(x.rotulo) + (x.modulo ? '<small>' + esc(x.modulo) + '</small>' : '') + '</div>' +
          '<div class="uso-trilho"><div class="uso-barra" style="width:' + (x.total / max * 100).toFixed(1) + '%"></div></div>' +
          '<div class="uso-num"><strong>' + x.total.toLocaleString('pt-BR') + '</strong>' + (x.total ? ' · ' + pct : '') +
          '<small>' + (x.total ? x.usuarios + (x.usuarios === 1 ? ' usuário' : ' usuários') + ' · ' + ult : ult) + '</small></div></div>';
      }).join('') || '<p class="nota">Nenhum relatório cadastrado.</p>';
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('uso-resumo').textContent = 'Não foi possível falar com o servidor.';
    }
  }
  $('uso-dias').addEventListener('change', carregarUso);

  /* ---------- acessos por pessoa (pesquisas ou entradas), barras horizontais ---------- */
  let pesDados = null;
  async function carregarPessoas() {
    $('pes-resumo').textContent = 'Carregando…';
    try {
      const d = await api('/api/admin/uso-pessoas?dias=' + encodeURIComponent($('pes-dias').value));
      if (!d.ok) { $('pes-resumo').textContent = d.mensagem || 'Não foi possível carregar os acessos por pessoa.'; return; }
      pesDados = d;
      desenharPessoas();
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('pes-resumo').textContent = 'Não foi possível falar com o servidor.';
    }
  }
  function desenharPessoas() {
    if (!pesDados) return;
    const med = $('pes-medida').value; // pesquisas | entradas
    const periodo = $('pes-dias').selectedOptions[0].textContent.toLowerCase();
    const itens = (pesDados.itens || []).slice().sort((a, b) => (b[med] - a[med]) || String(a.nome).localeCompare(String(b.nome)));
    const total = itens.reduce((a, x) => a + x[med], 0);
    const pessoas = itens.filter((x) => x[med] > 0).length;
    const nomeMed = med === 'pesquisas' ? ['pesquisa', 'pesquisas'] : ['entrada', 'entradas'];
    $('pes-resumo').textContent = (total
      ? total.toLocaleString('pt-BR') + ' ' + nomeMed[total === 1 ? 0 : 1] + (med === 'pesquisas' ? ' com resposta' : ' no sistema') + ' (' + periodo + '), de ' + pessoas + (pessoas === 1 ? ' pessoa.' : ' pessoas.')
      : 'Nenhuma ' + nomeMed[0] + ' (' + periodo + ').') + semContar(pesDados);
    const max = Math.max(1, ...itens.map((x) => x[med]));
    let pos = 0;
    $('pes-barras').innerHTML = itens.map((x) => {
      const v = x[med];
      if (v) pos++;
      const pct = total ? (v / total * 100).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%' : '';
      const ultimo = med === 'pesquisas' ? x.ultima_pesquisa : x.ultima_entrada;
      const ult = ultimo ? (med === 'pesquisas' ? 'última pesquisa ' : 'última entrada ') + dataBr(ultimo) : (med === 'pesquisas' ? 'sem pesquisa no período' : 'sem entrada no período');
      // o outro numero ao lado (pesquisas mostra entradas e relatorios; entradas mostra pesquisas)
      const outro = med === 'pesquisas'
        ? x.entradas + (x.entradas === 1 ? ' entrada' : ' entradas') + (x.relatorios ? ' · ' + x.relatorios + (x.relatorios === 1 ? ' relatório' : ' relatórios') : '')
        : x.pesquisas + (x.pesquisas === 1 ? ' pesquisa' : ' pesquisas');
      const selo = x.excluido ? ' (excluído)' : !x.ativo ? ' (bloqueado)' : '';
      return '<div class="uso-linha' + (v ? '' : ' zero') + '" title="' + esc(x.nome + ' — ' + ult) + '">' +
        '<div class="uso-pos">' + (v ? pos + 'º' : '—') + '</div>' +
        '<div class="uso-nome">' + esc(x.nome) + '<small>' + esc(x.usuario + selo) + '</small></div>' +
        '<div class="uso-trilho"><div class="uso-barra" style="width:' + (v / max * 100).toFixed(1) + '%"></div></div>' +
        '<div class="uso-num"><strong>' + v.toLocaleString('pt-BR') + '</strong>' + (v ? ' · ' + pct : '') +
        '<small>' + esc(outro) + ' · ' + esc(ult) + '</small></div></div>';
    }).join('') || '<p class="nota">Nenhum usuário cadastrado.</p>';
  }
  $('pes-dias').addEventListener('change', carregarPessoas);
  $('pes-medida').addEventListener('change', desenharPessoas);

  carregar();
