/*@parte Gestão: serviço e conexões com o banco. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- serviço: situação e reiniciar ---------- */
  let servicoDesde = null;
  /* ---------- conexoes com o banco (28/10/2026): todo master troca (dono, 13/11/2026); o usuario do pedido, so o desenv ---------- */
  let conPodeEditar = false, upPodeEditar = false;
  async function carregarConexoes() {
    try {
      const d = await api('/api/admin/conexoes');
      if (!d.ok) { $('con-nota').textContent = d.mensagem || 'Não foi possível carregar as conexões.'; return; }
      conPodeEditar = !!d.pode_editar;
      upPodeEditar = !!d.pode_editar_usuario_pedido;
      $('con-nota').textContent = 'Nome da conexão salva no SQLcl deste servidor que cada parte do __NOME_SISTEMA__ usa. ' + (conPodeEditar
        ? '"Testar e aplicar" confere a conexão no banco e, dando certo, passa a usá-la na hora, sem reiniciar.'
        : 'Só usuários master podem trocar; aqui é só visualização.') + (d.disponiveis && d.disponiveis.length ? ' Conexões salvas: ' + d.disponiveis.join(', ') + '.' : '');
      $('con-sugestoes').innerHTML = (d.disponiveis || []).map((n) => '<option value="' + esc(n) + '"></option>').join('');
      $('con-lista').innerHTML = (d.conexoes || []).map((c) => '<div class="con-linha"><label for="con-' + esc(c.qual) + '">' + esc(c.rotulo) + '</label>' +
        '<input type="text" id="con-' + esc(c.qual) + '" value="' + esc(c.atual) + '" list="con-sugestoes" maxlength="60" autocomplete="off" spellcheck="false"' + (conPodeEditar ? '' : ' readonly') + '>' +
        (conPodeEditar ? '<button class="btn" type="button" data-con="' + esc(c.qual) + '">Testar e aplicar</button>' : '') +
        '<span class="quando">' + (c.alterado_em ? 'alterada em ' + esc(dataBr(c.alterado_em)) + (c.alterado_por ? ' por ' + esc(c.alterado_por) : '') : 'padrão do config.json') + '</span></div>').join('') +
        // usuario que vai no pedido integrado pelo Simulador (w_usuario; 28/10/2026)
        (d.usuario_pedido ? '<div class="con-linha"><label for="con-usuario-pedido">Usuário do pedido</label>' +
          '<input type="text" id="con-usuario-pedido" value="' + esc(d.usuario_pedido.valor) + '" maxlength="30" autocomplete="off" spellcheck="false"' + (upPodeEditar ? '' : ' readonly') + '>' +
          (upPodeEditar ? '<button class="btn" type="button" id="con-salvar-usuario">Salvar</button>' : '') +
          '<span class="quando">' + (d.usuario_pedido.alterado_em ? 'alterado em ' + esc(dataBr(d.usuario_pedido.alterado_em)) + (d.usuario_pedido.alterado_por ? ' por ' + esc(d.usuario_pedido.alterado_por) : '') : 'padrão') +
          ' · vai como "w_usuario" nos pedidos integrados pelo Simulador</span></div>' : '');
    } catch (e) { if (e.message !== 'sessao' && e.message !== 'proibido') $('con-nota').textContent = 'Não foi possível falar com o servidor.'; }
  }
  $('con-lista').addEventListener('click', async (e) => {
    if (e.target.closest('#con-salvar-usuario')) { salvarUsuarioPedido(); return; }
    const b = e.target.closest('[data-con]');
    if (!b) return;
    const qual = b.dataset.con, nome = $('con-' + qual).value.trim();
    const msg = $('con-msg');
    const rotulo = (b.parentElement.querySelector('label') || {}).textContent || qual;
    if (!(await perguntar({ titulo: 'Trocar a conexão', texto: 'Testar a conexão "' + nome + '" e, se der certo, passar a usá-la em ' + rotulo + ' agora?', sim: 'Testar e usar' }))) return;
    b.disabled = true; b.textContent = 'Testando…';
    msg.hidden = false; msg.className = 'aviso'; msg.textContent = 'Testando a conexão "' + nome + '" no banco…';
    try {
      const d = await api('/api/admin/conexoes', { qual, nome });
      msg.className = 'aviso ' + (d.ok ? 'ok' : 'erro');
      msg.textContent = d.mensagem || (d.ok ? 'Conexão trocada.' : 'Não foi possível trocar a conexão.');
      if (d.ok) carregarConexoes();
    } catch (er) {
      if (er.message !== 'sessao' && er.message !== 'proibido') { msg.className = 'aviso erro'; msg.textContent = 'Não foi possível falar com o servidor.'; }
    } finally { b.disabled = false; b.textContent = 'Testar e aplicar'; }
  });
  $('con-lista').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && e.target.matches('input')) { const b = e.target.parentElement.querySelector('[data-con], #con-salvar-usuario'); if (b) { e.preventDefault(); b.click(); } }
  });
  // usuario do pedido integrado (w_usuario): so grava, nao testa no banco
  async function salvarUsuarioPedido() {
    const msg = $('con-msg'), b = $('con-salvar-usuario'), valor = $('con-usuario-pedido').value.trim();
    b.disabled = true;
    msg.hidden = false;
    try {
      const d = await api('/api/admin/usuario-pedido', { valor });
      msg.className = 'aviso ' + (d.ok ? 'ok' : 'erro');
      msg.textContent = d.mensagem || (d.ok ? 'Usuário do pedido salvo.' : 'Não foi possível salvar.');
      if (d.ok) carregarConexoes();
    } catch (er) {
      if (er.message !== 'sessao' && er.message !== 'proibido') { msg.className = 'aviso erro'; msg.textContent = 'Não foi possível falar com o servidor.'; }
    } finally { b.disabled = false; }
  }

  async function carregarServico() {
    try {
      const d = await api('/api/admin/servico');
      if (!d.ok) return;
      servicoDesde = d.desde_ms;
      const info = $('serv-info');
      if (!info.classList.contains('ok')) info.className = 'serv-info';
      info.textContent = (d.versao ? 'Versão ' + d.versao + ' · ' : '') + 'No ar desde ' + d.desde + ' · ' + d.conectados + (d.conectados === 1 ? ' usuário conectado' : ' usuários conectados') +
        ' · memória ' + d.memoria_mb + ' MB · Node ' + d.node;
      const cc = d.cache_compras || { clientes: 0 };
      $('cache-info').textContent = 'Cache de clientes: ' + (cc.clientes ? cc.clientes.toLocaleString('pt-BR') + (cc.clientes === 1 ? ' cliente' : ' clientes') +
        (cc.ultima ? ' · última atualização ' + dataBr(cc.ultima) : '') : 'vazio');
      $('limpar-cache').disabled = !cc.clientes;
    } catch (e) { /* sessao/proibido ja tratados */ }
  }
  $('limpar-cache').addEventListener('click', async () => {
    if (!(await perguntar({ titulo: 'Limpar cache de clientes', texto: 'Limpar o cache de clientes (primeira e última compra de cada cliente)?\n\nAs próximas perguntas de "primeira compra" vão buscar de novo no histórico do banco (a primeira vez fica mais demorada).', sim: 'Limpar' }))) return;
    const btn = $('limpar-cache');
    btn.disabled = true;
    try {
      const d = await api('/api/admin/limpar-cache-compras', {});
      aviso(d.mensagem || (d.ok ? 'Cache limpo.' : 'Não foi possível limpar.'), d.ok ? 'ok' : 'erro');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') aviso('Não foi possível falar com o servidor.', 'erro');
    }
    carregarServico();
  });
  const esperar = (ms) => new Promise((ok) => setTimeout(ok, ms));
  $('reiniciar').addEventListener('click', async () => {
    if (!(await perguntar({ titulo: 'Reiniciar o serviço', texto: 'Reiniciar o serviço do __NOME_SISTEMA__ agora?\n\nLeva cerca de 10 segundos. Ninguém é deslogado, mas uma pesquisa que estiver rodando neste momento será interrompida.', sim: 'Reiniciar' }))) return;
    const btn = $('reiniciar');
    const info = $('serv-info');
    btn.disabled = true;
    info.className = 'serv-info';
    info.textContent = 'Reiniciando o serviço…';
    const antes = servicoDesde;
    try { await api('/api/admin/reiniciar', {}); } catch (e) { /* a conexao pode cair no meio: segue conferindo */ }
    // confere a cada 2 s se o servidor voltou (com um novo "no ar desde"), por até 1 minuto
    for (let i = 0; i < 30; i++) {
      await esperar(2000);
      try {
        const d = await api('/api/admin/servico');
        if (d.ok && d.desde_ms !== antes) {
          info.className = 'serv-info ok';
          info.textContent = 'Serviço reiniciado. No ar desde ' + d.desde + '.';
          servicoDesde = d.desde_ms;
          btn.disabled = false;
          setTimeout(() => { info.className = 'serv-info'; carregarServico(); }, 6000);
          return;
        }
      } catch (e) { info.textContent = 'Reiniciando o serviço… aguardando o servidor voltar.'; }
    }
    info.className = 'serv-info erro';
    info.textContent = 'O serviço não voltou em 1 minuto. No servidor, rode iniciar_servico.bat (se ele foi iniciado à mão, por um terminal, o reinício automático não acontece).';
    btn.disabled = false;
  });

