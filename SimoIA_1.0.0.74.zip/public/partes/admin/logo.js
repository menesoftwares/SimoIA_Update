/*@parte Gestão: guia Gerais: logo principal. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- guia Gerais: logo principal (dono, 07/11/2026) ---------- */
  // a imagem escolhida vira PNG aqui (canvas: aceita PNG, JPG, WebP, SVG, GIF); o servidor corta a margem transparente
  // e gera as conversoes nos tamanhos das telas
  const LOGO_LADO_MAX = 1600; // imagem enviada: no maximo 1600 px no lado maior (o servidor guarda a base com ate 1024)
  let logoPng = '', logoNome = '';
  function mostrarLogo(d) {
    const v = encodeURIComponent(d.versao || Date.now());
    $('logo-ver-principal').src = '/logo.png?v=' + v;
    $('logo-ver-principal-escuro').src = '/logo.png?v=' + v;
    $('logo-ver-192').src = '/icone-192.png?v=' + v;
    $('logo-ver-mask').src = '/icone-maskable-512.png?v=' + v;
    $('logo-ver-apple').src = '/apple-touch-icon.png?v=' + v;
    $('logo-ver-fav').src = '/favicon-32.png?v=' + v;
    // o icone da aba desta pagina tambem troca na hora
    document.querySelectorAll('link[rel="icon"]').forEach((l) => { l.href = l.href.replace(/\?v=.*$/, '') + '?v=' + v; });
    if (d.fundo) $('logo-fundo').value = d.fundo.toLowerCase();
    $('logo-info').textContent = (d.padrao ? 'Em uso: logo do projeto' : 'Em uso: ' + (d.arquivo || 'logo enviado')) +
      (d.alterado_em && d.alterado_por && d.alterado_por !== 'inicial' ? ' · alterado em ' + dataBr(d.alterado_em) + ' por ' + d.alterado_por : '') + '.';
    $('logo-restaurar').disabled = !!d.padrao;
    const kb = (b) => (b / 1024).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' KB';
    $('logo-tab').innerHTML = '<thead><tr><th>Conversão</th><th>Uso</th><th>Tamanho (px)</th><th>Arquivo</th></tr></thead><tbody>' +
      (d.variantes || []).map((x) => '<tr><td>' + esc(x.chave) + '</td><td>' + esc(x.descricao || '') + '</td><td class="quando">' + x.largura + ' × ' + x.altura + '</td><td class="quando">' + kb(x.bytes || 0) + '</td></tr>').join('') + '</tbody>';
  }
  async function carregarLogo() {
    try {
      const d = await api('/api/admin/logo');
      if (d.ok) mostrarLogo(d); else $('logo-msg').textContent = d.mensagem || 'Não foi possível carregar o logo.';
    } catch (e) { if (e.message !== 'sessao' && e.message !== 'proibido') $('logo-msg').textContent = 'Não foi possível falar com o servidor.'; }
  }
  // abre a imagem no navegador e devolve { png (data URL), largura, altura, origem: [w, h] }
  function converterLogo(arquivo) {
    return new Promise((ok, erro) => {
      const url = URL.createObjectURL(arquivo);
      const img = new Image();
      img.onload = () => {
        try {
          const svg = /svg/i.test(arquivo.type) || /\.svg$/i.test(arquivo.name);
          let w = img.naturalWidth || 0, h = img.naturalHeight || 0;
          if (!w || !h) { w = 1024; h = 1024; } // SVG sem tamanho
          // SVG e vetor: desenha grande (nitido em qualquer tamanho); as demais so diminuem
          const esc = svg ? 1024 / Math.max(w, h) : Math.min(1, LOGO_LADO_MAX / Math.max(w, h));
          const cw = Math.max(1, Math.round(w * esc)), ch = Math.max(1, Math.round(h * esc));
          const c = document.createElement('canvas');
          c.width = cw; c.height = ch;
          const g = c.getContext('2d');
          g.imageSmoothingQuality = 'high';
          g.drawImage(img, 0, 0, cw, ch);
          ok({ png: c.toDataURL('image/png'), largura: cw, altura: ch, origem: [img.naturalWidth || w, img.naturalHeight || h] });
        } catch (e) { erro(new Error('Não foi possível ler esta imagem.')); }
        finally { URL.revokeObjectURL(url); }
      };
      img.onerror = () => { URL.revokeObjectURL(url); erro(new Error('Não foi possível abrir esta imagem. Use PNG, JPG, WebP ou SVG.')); };
      img.src = url;
    });
  }
  $('logo-arquivo').addEventListener('change', async () => {
    const f = $('logo-arquivo').files[0];
    logoPng = ''; logoNome = '';
    $('logo-enviar').disabled = true;
    $('logo-previa').hidden = true;
    $('logo-msg').textContent = '';
    if (!f) return;
    if (!/^image\//.test(f.type) && !/\.(png|jpe?g|webp|svg|gif)$/i.test(f.name)) { $('logo-msg').textContent = 'Escolha uma imagem (PNG, JPG, WebP ou SVG).'; return; }
    if (f.size > 15 * 1024 * 1024) { $('logo-msg').textContent = 'Imagem grande demais: escolha uma de até 15 MB.'; return; }
    try {
      const r = await converterLogo(f);
      if (r.png.length * 0.75 > 8 * 1024 * 1024) { $('logo-msg').textContent = 'A imagem convertida passou de 8 MB: use uma imagem menor.'; return; }
      logoPng = r.png; logoNome = f.name;
      $('logo-previa-img').src = r.png;
      const pequeno = Math.min(r.origem[0], r.origem[1]) < 256 && !/svg/i.test(f.type);
      $('logo-previa-info').textContent = f.name + ' · ' + r.origem[0] + ' × ' + r.origem[1] + ' px' + (pequeno ? ' · imagem pequena: pode ficar sem nitidez nos ícones grandes.' : '');
      $('logo-previa').hidden = false;
      $('logo-enviar').disabled = false;
    } catch (e) { $('logo-msg').textContent = e.message; }
  });
  async function logoAcao(corpo, botao, confirmar) {
    if (confirmar && !(await perguntar({ titulo: 'Logo principal', texto: confirmar }))) return;
    botao.disabled = true;
    $('logo-msg').textContent = corpo.acao === 'enviar' ? 'Gerando as conversões…' : 'Salvando…';
    try {
      const d = await api('/api/admin/logo', corpo);
      if (d.ok) {
        mostrarLogo(d);
        if (corpo.acao === 'enviar') { logoPng = ''; $('logo-arquivo').value = ''; $('logo-previa').hidden = true; }
      }
      $('logo-msg').textContent = d.mensagem || (d.ok ? 'Salvo.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $('logo-msg').textContent = 'Não foi possível falar com o servidor.';
    } finally { botao.disabled = corpo.acao === 'enviar' ? !logoPng : false; if (corpo.acao === 'restaurar') carregarLogo(); }
  }
  $('logo-enviar').addEventListener('click', () => { if (logoPng) logoAcao({ acao: 'enviar', png: logoPng, arquivo: logoNome, fundo: $('logo-fundo').value }, $('logo-enviar'), 'Trocar o logo de todo o sistema por esta imagem?'); });
  $('logo-salvar-fundo').addEventListener('click', () => logoAcao({ acao: 'fundo', fundo: $('logo-fundo').value }, $('logo-salvar-fundo')));
  $('logo-restaurar').addEventListener('click', () => logoAcao({ acao: 'restaurar' }, $('logo-restaurar'), 'Voltar ao logo do projeto (Simo) em todo o sistema? Os ícones voltam com o fundo roxo do logo.'));

