/*@parte Gestão: guia Conf. interna (só o desenv). Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- guia Conf. interna (dono, 13/11/2026): so o desenv; o servidor responde 404 para os demais ---------- */
  const PORTA_PADRAO = { starttls: 587, ssl: 465, nenhuma: 25 };
  function smtpDaTela() {
    return { host: $('ci-host').value.trim(), porta: Number($('ci-porta').value), seguranca: $('ci-seguranca').value, usuario: $('ci-usuario').value.trim(),
      senha: $('ci-senha').value, remetente: $('ci-remetente').value.trim(), nome_remetente: $('ci-nome').value.trim(), url_sistema: $('ci-url').value.trim() };
  }
  function mostrarInterna(d) {
    const sm = d.smtp || {}, av = d.avisos || {};
    $('ci-host').value = sm.host || '';
    $('ci-seguranca').value = sm.seguranca || 'starttls';
    $('ci-porta').value = sm.porta || PORTA_PADRAO[$('ci-seguranca').value];
    $('ci-usuario').value = sm.usuario || '';
    $('ci-senha').value = '';
    $('ci-senha').placeholder = sm.tem_senha ? '•••••••• (salva; digite só para trocar)' : '';
    $('ci-remetente').value = sm.remetente || '';
    $('ci-nome').value = sm.nome_remetente || '';
    $('ci-url').value = sm.url_sistema || '';
    $('ci-url').placeholder = sm.url_padrao ? sm.url_padrao + ' (padrão)' : 'https://app.empresa.com.br';
    $('ci-senha-info').innerHTML = sm.senha_ilegivel ? '<strong>A senha salva foi gravada em outro servidor e não pode ser lida aqui: digite a senha de novo e salve.</strong>' : '';
    $('ci-smtp-quando').textContent = sm.alterado_em ? 'alterado em ' + dataBr(sm.alterado_em) + ' por ' + sm.alterado_por : 'ainda não configurado';
    $('ci-av-ligado').checked = !!av.ligado;
    $('ci-destinos').value = av.destinos || '';
    $('ci-intervalo').value = av.intervalo_min || 5;
    $('ci-av-quando').textContent = av.alterado_em ? 'alterado em ' + dataBr(av.alterado_em) + ' por ' + av.alterado_por : '';
    if (!$('ci-teste-para').value) $('ci-teste-para').value = (av.destinos || '').split(',')[0].trim();
    let grupo = '';
    $('ci-eventos').innerHTML = (d.eventos || []).map((e) => {
      const cab = e.grupo !== grupo ? '<h4>' + esc(e.grupo) + '</h4>' : '';
      grupo = e.grupo;
      return cab + '<label class="marca"><input type="checkbox" data-evento="' + esc(e.chave) + '"' + (av.eventos && av.eventos[e.chave] ? ' checked' : '') + '> ' + esc(e.rotulo) + '</label>';
    }).join('');
    const bk = d.backup || {};
    $('ci-bk-ligado').checked = !!bk.ligado;
    $('ci-bk-hora').value = bk.hora || '';
    $('ci-bk-hora').disabled = !bk.ligado;
    $('ci-bk-destinos').value = bk.destinos || '';
    $('ci-bk-quando').textContent = bk.alterado_em ? 'alterado em ' + dataBr(bk.alterado_em) + ' por ' + bk.alterado_por : '';
    $('ci-bk-ultima').textContent = bk.ultima ? 'Último envio: ' + bk.ultima : 'Nenhuma cópia enviada ainda.';
    // aprendizado das pesquisas (dono, 27/11/2026)
    const ap = d.aprendizado || {};
    $('ci-ap-ligado').checked = ap.ligado !== false;
    const pe = ap.pendentes || {};
    $('ci-ap-info').textContent = [
      'Vai para: ' + (ap.para || '(configure o e-mail do sistema acima)') + ', uma vez por dia depois das ' + (ap.hora_email || 7) + ' h, só quando houver algo para avaliar. O assunto leva o título da página.',
      'Última revisão: ' + (ap.ultima_revisao || 'ainda não rodou (roda 2 min depois de iniciar e a cada ' + (ap.intervalo_min || 60) + ' min)') + '.',
      'Aguardando o próximo envio: ' + (pe.total || 0) + ' (não entendidas ' + (pe.nao_entendidas || 0) + ', refeitas ' + (pe.refeitas || 0) + ', com erro ' + (pe.erros || 0) + '). Frases aprendidas sozinho: ' + (ap.aprendidas || 0) + '.',
      ap.email_ultimo ? 'Último envio: ' + ap.email_ultimo.quando + ' para ' + ap.email_ultimo.para + ' (' + ap.email_ultimo.itens + ').' : 'Nenhuma lista enviada ainda.'
    ].join(' ');
    const cons = d.conexoes || [];
    $('ci-con-tab').innerHTML = '<tr><th>Módulo</th><th>Conexão</th><th>Situação</th><th>Último teste</th></tr>' + cons.map((c) =>
      '<tr><td>' + esc(c.rotulo) + '</td><td><code>' + esc(c.nome) + '</code></td><td>' +
      (c.estado === 'ok' ? '<span class="selo on">no ar</span>' : c.estado === 'caiu' ? '<span class="selo alerta">fora do ar desde ' + esc(c.desde) + '</span>' :
        c.falhas ? '<span class="selo alerta">falhou ' + c.falhas + 'x</span>' : '<span class="selo">ainda não testada</span>') +
      (c.erro ? '<br><small>' + esc(c.erro) + '</small>' : '') + '</td><td class="quando">' + esc(c.testado || '—') + '</td></tr>').join('');
    const lg = d.log || [];
    $('ci-limpar-log').disabled = !lg.length;
    $('ci-log-tab').innerHTML = lg.length ? '<tr><th>Quando</th><th>Assunto</th><th>Para</th><th>Resultado</th></tr>' + lg.map((l) =>
      '<tr><td class="quando">' + esc(dataBr(l.quando)) + '</td><td>' + esc(l.assunto || l.evento) + '</td><td>' + esc(l.para || '') + '</td><td>' +
      (l.ok ? '<span class="selo on">enviado</span>' : '<span class="selo alerta">não enviado</span><br><small>' + esc(l.erro || '') + '</small>') + '</td></tr>').join('')
      : '<tr><td class="nota">Nenhum e-mail enviado ainda.</td></tr>';
  }
  async function carregarInterna() {
    let r;
    try { r = await fetch('/api/admin/conf-interna', { headers: { 'Authorization': 'Bearer ' + token } }); } catch (e) { return; }
    if (!r.ok) return; // nao e o desenv: a guia continua escondida
    let d = {};
    try { d = await r.json(); } catch (e) { return; }
    if (!d.ok) return;
    $('guia-interna').hidden = false;
    mostrarInterna(d);
    if (guiaGuardada === 'interna' && $('painel-interna').hidden) abrirGuia('interna');
  }
  async function interna(corpo, botao, saida) {
    botao.disabled = true;
    const texto0 = botao.textContent;
    if (corpo.acao === 'teste') botao.textContent = 'Enviando…';
    if (corpo.acao === 'testar_conexoes') botao.textContent = 'Testando…';
    if (corpo.acao === 'backup_agora') botao.textContent = 'Enviando…';
    if (corpo.acao === 'aprendizado_agora') botao.textContent = 'Revisando…';
    $(saida).textContent = '';
    try {
      const d = await api('/api/admin/conf-interna', corpo);
      if (d.ok) mostrarInterna(d);
      $(saida).textContent = d.mensagem || (d.ok ? 'Salvo.' : 'Não foi possível salvar.');
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') $(saida).textContent = 'Não foi possível falar com o servidor.';
    } finally { botao.disabled = false; botao.textContent = texto0; }
  }
  $('ci-seguranca').addEventListener('change', () => { $('ci-porta').value = PORTA_PADRAO[$('ci-seguranca').value]; });
  $('ci-smtp-salvar').addEventListener('click', () => {
    const c = smtpDaTela();
    if (!c.host) { $('ci-smtp-msg').textContent = 'Informe o servidor SMTP.'; $('ci-host').focus(); return; }
    if (!c.remetente) { $('ci-smtp-msg').textContent = 'Informe o e-mail do remetente.'; $('ci-remetente').focus(); return; }
    interna(Object.assign({ acao: 'smtp' }, c), $('ci-smtp-salvar'), 'ci-smtp-msg');
  });
  $('ci-teste').addEventListener('click', () => {
    const para = $('ci-teste-para').value.trim();
    if (!para) { $('ci-smtp-msg').textContent = 'Informe para qual e-mail enviar o teste.'; $('ci-teste-para').focus(); return; }
    interna({ acao: 'teste', para, smtp: smtpDaTela() }, $('ci-teste'), 'ci-smtp-msg');
  });
  $('ci-av-salvar').addEventListener('click', () => {
    const eventos = {};
    document.querySelectorAll('#ci-eventos input[data-evento]').forEach((x) => { eventos[x.dataset.evento] = x.checked; });
    interna({ acao: 'avisos', ligado: $('ci-av-ligado').checked, destinos: $('ci-destinos').value, intervalo_min: Number($('ci-intervalo').value), eventos },
      $('ci-av-salvar'), 'ci-av-msg');
  });
  $('ci-limpar-log').addEventListener('click', async () => {
    if (!(await perguntar({ titulo: 'Limpar log de e-mails', texto: 'Apagar a lista dos últimos e-mails enviados?\n\nOs avisos continuam funcionando; o registro no log do servidor não é apagado.', sim: 'Limpar' }))) return;
    interna({ acao: 'limpar_log' }, $('ci-limpar-log'), 'ci-av-msg');
  });
  // copia do banco por e-mail (dono, 14/11/2026)
  $('ci-bk-ligado').addEventListener('change', () => {
    $('ci-bk-hora').disabled = !$('ci-bk-ligado').checked;
    if ($('ci-bk-ligado').checked) { if (!$('ci-bk-hora').value) $('ci-bk-hora').value = '23:00'; $('ci-bk-hora').focus(); }
  });
  $('ci-bk-salvar').addEventListener('click', () => {
    const ligado = $('ci-bk-ligado').checked, hora = $('ci-bk-hora').value, destinos = $('ci-bk-destinos').value.trim();
    if (ligado && !hora) { $('ci-bk-msg').textContent = 'Informe o horário do envio.'; $('ci-bk-hora').focus(); return; }
    if (ligado && !destinos) { $('ci-bk-msg').textContent = 'Informe ao menos um e-mail que recebe a cópia.'; $('ci-bk-destinos').focus(); return; }
    interna({ acao: 'backup', ligado, hora, destinos }, $('ci-bk-salvar'), 'ci-bk-msg');
  });
  $('ci-bk-agora').addEventListener('click', async () => {
    if (!(await perguntar({ titulo: 'Enviar cópia do banco', texto: 'Enviar agora a cópia do banco para os e-mails salvos?\n\nPode levar alguns minutos, conforme o tamanho do banco e a internet.', sim: 'Enviar' }))) return;
    interna({ acao: 'backup_agora' }, $('ci-bk-agora'), 'ci-bk-msg');
  });
  $('ci-ap-salvar').addEventListener('click', () => interna({ acao: 'aprendizado', ligado: $('ci-ap-ligado').checked }, $('ci-ap-salvar'), 'ci-ap-msg'));
  $('ci-ap-agora').addEventListener('click', () => interna({ acao: 'aprendizado_agora' }, $('ci-ap-agora'), 'ci-ap-msg'));
  $('ci-testar-con').addEventListener('click', () => interna({ acao: 'testar_conexoes' }, $('ci-testar-con'), 'ci-av-msg'));

