/*@parte Gestão: SQLs do Simulador e do Coletor. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- SQLs do Simulador (28/10/2026) e do Coletor (31/10/2026): todo master ve no mini editor; so o desenv altera ---------- */
  // cada guia tem a sua lista; o mini editor (#dlg-sql) e o mesmo e grava no grupo do SQL aberto
  const GRUPOS_SQL = {
    simulador: { rotulo: 'Simulador', tab: 'sqls-tab', nota: 'sqls-nota', sqls: [], podeEditar: false },
    coletor: { rotulo: 'Coletor', tab: 'col-sqls-tab', nota: 'col-sqls-nota', sqls: [], podeEditar: false }
  };
  let sqlPodeEditar = false, sqlAberto = null, sqlGrupo = 'simulador';
  async function carregarSqls(grupo) {
    const g = GRUPOS_SQL[grupo];
    try {
      const d = await api('/api/admin/' + grupo + '/sqls');
      if (!d.ok) { $(g.nota).textContent = d.mensagem || 'Não foi possível carregar os SQLs.'; return; }
      g.sqls = d.sqls || [];
      g.podeEditar = !!d.pode_editar;
      desenharSqls(grupo);
    } catch (e) { if (e.message !== 'sessao' && e.message !== 'proibido') $(g.nota).textContent = 'Não foi possível falar com o servidor.'; }
  }
  function desenharSqls(grupo) {
    const g = GRUPOS_SQL[grupo];
    $(g.nota).textContent = 'Consultas que o ' + g.rotulo + ' roda no banco. ' + (g.podeEditar ? 'Clique em "Editar" para alterar; vale a partir da próxima consulta.' : 'Só o usuário desenv pode alterar; aqui é só visualização.');
    $(g.tab).innerHTML = '<thead><tr><th>Chave</th><th>Para que serve</th><th>Situação</th><th>Alterado</th><th></th></tr></thead><tbody>' +
      g.sqls.map((x, i) => '<tr><td>' + esc(x.chave) + '</td><td>' + esc(x.descricao || '') + '</td>' +
        '<td' + (x.ativo ? '' : ' class="inativo"') + '>' + (x.ativo ? 'Ativo' : 'Inativo') + '</td>' +
        '<td class="quando">' + esc(dataBr(x.alterado_em)) + (x.alterado_por ? '<br>' + esc(x.alterado_por === 'inicial' ? 'original' : x.alterado_por) : '') + '</td>' +
        '<td><button class="btn-sec" type="button" data-sql="' + i + '">' + (g.podeEditar ? 'Editar' : 'Ver') + '</button></td></tr>').join('') + '</tbody>';
  }
  for (const [grupo, g] of Object.entries(GRUPOS_SQL)) {
    $(g.tab).addEventListener('click', (e) => {
      const b = e.target.closest('[data-sql]');
      if (b) abrirSql(g.sqls[Number(b.dataset.sql)], grupo);
    });
  }
  function abrirSql(x, grupo) {
    if (!x) return;
    sqlAberto = x;
    sqlGrupo = grupo;
    sqlPodeEditar = GRUPOS_SQL[grupo].podeEditar;
    $('sqle-titulo').textContent = 'SQL "' + x.chave + '"';
    $('sqle-desc').textContent = x.descricao || '';
    $('sqle-obs').textContent = x.observacao ? 'Observação: ' + x.observacao : '';
    const t = $('sqle-texto');
    t.value = x.sql_texto || '';
    t.readOnly = !sqlPodeEditar;
    $('sqle-ativo').checked = !!x.ativo;
    $('sqle-ativo').disabled = !sqlPodeEditar;
    $('sqle-salvar').hidden = !sqlPodeEditar;
    $('sqle-info').textContent = (sqlPodeEditar ? '' : 'Somente leitura: só o usuário desenv altera os SQLs. ') +
      'Marcadores como #JSON#, #UF# e #COD_PESSOA# são trocados pelo servidor e precisam continuar no texto.' +
      (x.alterado_em ? ' Última alteração: ' + dataBr(x.alterado_em) + (x.alterado_por ? ' (' + (x.alterado_por === 'inicial' ? 'original' : x.alterado_por) + ')' : '') + '.' : '');
    $('sqle-msg').hidden = true;
    atualizarLinhas();
    $('dlg-sql').showModal();
    t.scrollTop = 0; t.scrollLeft = 0; $('sqle-linhas').scrollTop = 0;
    t.focus(); t.setSelectionRange(0, 0);
    mostrarPosicao();
  }
  // numeros de linha ao lado do texto (acompanham a rolagem)
  function atualizarLinhas() {
    const n = $('sqle-texto').value.split('\n').length;
    let s = '';
    for (let i = 1; i <= n; i++) s += i + '\n';
    $('sqle-linhas').textContent = s;
  }
  function mostrarPosicao() {
    const t = $('sqle-texto');
    const antes = t.value.slice(0, t.selectionStart).split('\n');
    $('sqle-pos').textContent = 'Linha ' + antes.length + ', coluna ' + (antes[antes.length - 1].length + 1) + ' · ' + t.value.length + ' caracteres';
  }
  $('sqle-texto').addEventListener('input', () => { atualizarLinhas(); mostrarPosicao(); });
  $('sqle-texto').addEventListener('scroll', () => { $('sqle-linhas').scrollTop = $('sqle-texto').scrollTop; });
  for (const ev of ['keyup', 'click', 'select']) $('sqle-texto').addEventListener(ev, mostrarPosicao);
  $('sqle-texto').addEventListener('keydown', (e) => {
    const t = e.target;
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); if (sqlPodeEditar) salvarSql(); return; }
    if (e.key === 'Tab' && !t.readOnly && !e.ctrlKey && !e.altKey) {
      // Tab = 2 espacos (Shift+Tab tira ate 2 do inicio da linha); Esc fecha a janela como de costume
      e.preventDefault();
      const ini = t.selectionStart, fim = t.selectionEnd;
      if (e.shiftKey) {
        const lin = t.value.lastIndexOf('\n', ini - 1) + 1;
        const tira = (t.value.slice(lin, lin + 2).match(/^ {1,2}/) || [''])[0].length;
        if (tira) t.setRangeText('', lin, lin + tira, 'preserve');
      } else t.setRangeText('  ', ini, fim, 'end');
      t.dispatchEvent(new Event('input'));
    }
  });
  async function fecharSql() {
    const mudou = sqlAberto && sqlPodeEditar && ($('sqle-texto').value !== (sqlAberto.sql_texto || '') || $('sqle-ativo').checked !== !!sqlAberto.ativo);
    if (mudou && !(await perguntar({ titulo: 'Alterações não salvas', texto: 'Fechar sem salvar as alterações deste SQL?', sim: 'Fechar sem salvar' }))) return;
    $('dlg-sql').close();
  }
  $('sqle-x').addEventListener('click', fecharSql);
  $('sqle-fechar').addEventListener('click', fecharSql);
  $('dlg-sql').addEventListener('cancel', (e) => { e.preventDefault(); fecharSql(); });
  async function salvarSql() {
    if (!sqlAberto || !sqlPodeEditar) return;
    const msg = $('sqle-msg');
    const g = GRUPOS_SQL[sqlGrupo];
    if (!$('sqle-ativo').checked && sqlAberto.ativo && !(await perguntar({ titulo: 'Inativar SQL', texto: 'Inativar o SQL "' + sqlAberto.chave + '"? A parte do ' + g.rotulo + ' que usa ele para de funcionar.', sim: 'Inativar' }))) return;
    $('sqle-salvar').disabled = true;
    try {
      const d = await api('/api/admin/' + sqlGrupo + '/sql', { chave: sqlAberto.chave, sql_texto: $('sqle-texto').value, ativo: $('sqle-ativo').checked });
      msg.hidden = false;
      msg.className = 'aviso ' + (d.ok ? 'ok' : 'erro');
      msg.textContent = d.mensagem || (d.ok ? 'SQL salvo.' : 'Não foi possível salvar.');
      if (d.ok && d.sql) {
        const i = g.sqls.findIndex((x) => x.chave === d.sql.chave);
        if (i >= 0) g.sqls[i] = d.sql;
        sqlAberto = d.sql;
        $('sqle-texto').value = d.sql.sql_texto; atualizarLinhas(); mostrarPosicao();
        desenharSqls(sqlGrupo);
      }
    } catch (e) {
      if (e.message !== 'sessao' && e.message !== 'proibido') { msg.hidden = false; msg.className = 'aviso erro'; msg.textContent = 'Não foi possível falar com o servidor.'; }
    } finally { $('sqle-salvar').disabled = false; }
  }
  $('sqle-salvar').addEventListener('click', salvarSql);
