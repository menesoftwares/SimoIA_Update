/*@parte Gestão: lista e janela de edição de usuários. Parte de admin.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- janela de edicao ---------- */
  function montarBis(marcados) {
    const porModulo = {};
    dados.bis.forEach((b) => { (porModulo[b.modulo] = porModulo[b.modulo] || []).push(b); });
    $('f-bis').innerHTML = Object.keys(porModulo).map((m, i) => {
      const itens = porModulo[m];
      return '<div class="modulo"><label class="marca modulo-cab"><input type="checkbox" data-modulo="' + i + '"> ' + esc(m) + ' (todos)</label><div class="bis">' +
        itens.map((b) => '<label class="marca"><input type="checkbox" data-wid="' + b.wid + '" data-mod="' + i + '"' + (marcados.includes(b.wid) ? ' checked' : '') + '> ' +
          esc(b.rotulo) + '</label>').join('') + '</div></div>';
    }).join('') || '<p class="nota">Nenhum relatório cadastrado no config.json.</p>';
    sincronizarModulos();
  }
  // "todos do modulo": marcado se todos os BIs dele estao marcados; meio-marcado se so alguns
  function sincronizarModulos() {
    $('f-bis').querySelectorAll('input[data-modulo]').forEach((cab) => {
      const filhos = [...$('f-bis').querySelectorAll('input[data-mod="' + cab.dataset.modulo + '"]')];
      const n = filhos.filter((f) => f.checked).length;
      cab.checked = n === filhos.length && n > 0;
      cab.indeterminate = n > 0 && n < filhos.length;
    });
  }
  $('f-bis').addEventListener('change', (e) => {
    const t = e.target;
    if (t.dataset.modulo != null) $('f-bis').querySelectorAll('input[data-mod="' + t.dataset.modulo + '"]').forEach((f) => { f.checked = t.checked; });
    sincronizarModulos();
  });

  function ajustarMaster() {
    $('nota-master').hidden = !$('f-master').checked;
    ajustarTela();
  }
  $('f-master').addEventListener('change', ajustarMaster);
  // tela padrao: nao vale para master nem para o desenv; "Simulador"/"Coletor" ja liberam a ferramenta (caixa marcada e travada)
  function ajustarTela() {
    const sel = $('f-tela-inicial');
    const naoVale = $('f-master').checked || sel.dataset.tudo === '1';
    if (naoVale) sel.value = '';
    sel.disabled = naoVale;
    $('nota-tela').textContent = naoVale
      ? 'Usuário master (e o desenv) sempre abre o __NOME_SISTEMA__: a tela padrão não vale para ele.'
      : 'Com "Simulador" ou "Coletor", o usuário entra direto na ferramenta e só acessa ela: o botão Voltar vira Sair. "Coletor (rast)" abre direto na Rastreabilidade.';
    for (const [tela, caixa] of [['simulador', 'f-pode-simulador'], ['coletor', 'f-pode-coletor'], ['coletor_rastro', 'f-pode-col-rastro']]) {
      const so = sel.value === tela;
      if (so) $(caixa).checked = true;
      if (sel.dataset.tudo !== '1') $(caixa).disabled = so;
    }
    travarSimManut();
  }
  // o master nao libera mais o Simulador sozinho: marcar/desmarcar master nao muda a trava
  // trocou a tela padrao (dono, 07/11/2026): Coletor desmarca as caixas do Simulador e Simulador desmarca as do Coletor
  const CAIXAS_SIM = ['f-pode-simulador', 'f-pode-sim-manut', 'f-pode-sim-custo', 'f-pode-integrar'];
  const CAIXAS_COL = ['f-pode-coletor', 'f-pode-col-manut', 'f-pode-col-etiq', 'f-pode-col-rastro'];
  $('f-tela-inicial').addEventListener('change', () => {
    const v = $('f-tela-inicial').value;
    const limpar = v === 'simulador' ? CAIXAS_COL : (v === 'coletor' || v === 'coletor_rastro') ? CAIXAS_SIM : [];
    if ($('f-tela-inicial').dataset.tudo !== '1') for (const id of limpar) $(id).checked = false;
    ajustarTela();
  });
  // "Simulador de precos (manutencao)" so com acesso ao Simulador (dono, 02/11/2026): sem ele, desmarcada e travada.
  // Vale para master tambem (segue as liberacoes). "Coletor (manutencao)" pode ficar sozinha (abre direto a manutencao do Coletor).
  function travarSimManut() {
    if ($('f-tela-inicial').dataset.tudo === '1') return; // desenv: tudo marcado e travado
    const temSim = $('f-pode-simulador').checked || $('f-tela-inicial').value === 'simulador';
    if (!temSim) $('f-pode-sim-manut').checked = false;
    $('f-pode-sim-manut').disabled = !temSim;
    $('m-sim-manut').title = temSim ? '' : 'Marque "Simulador de preços" para liberar a manutenção do Simulador.';
    if (!temSim) $('f-pode-sim-custo').checked = false;
    $('f-pode-sim-custo').disabled = !temSim;
    $('m-sim-custo').title = temSim ? '' : 'Marque "Simulador de preços" para liberar a escolha do custo.';
  }
  $('f-pode-simulador').addEventListener('change', travarSimManut);

  function abrir(u) {
    editando = u || null;
    const eu = !!u && u.usuario.toLowerCase() === String(dados.eu).toLowerCase();
    $('dlg-titulo').textContent = u ? 'Editar usuário' : 'Novo usuário';
    $('f-usuario').value = u ? u.usuario : '';
    $('f-usuario').readOnly = !!u;
    $('f-nome').value = u ? (u.nome || '') : '';
    $('f-email').value = u ? (u.email || '') : '';
    $('f-celular').value = u ? (u.celular_fmt || '') : '';
    $('f-cod-pessoa-erp').value = u ? (u.cod_pessoa_erp || '') : '';
    $('f-perfil-erp').value = (u && u.perfil_erp) || 'administrativo';
    $('f-senha').value = '';
    $('l-senha').textContent = u ? 'Nova senha' : 'Senha';
    $('a-senha').textContent = u ? 'Deixe em branco para manter a senha atual. Se trocar, a pessoa precisa entrar de novo.' : 'Pelo menos 4 caracteres.';
    // senha protegida (desenv): so ele mesmo troca
    $('f-senha').disabled = !!(u && u.senha_protegida);
    if (u && u.senha_protegida) $('a-senha').textContent = 'A senha deste usuário só pode ser trocada por ele mesmo.';
    $('f-ativo').checked = u ? u.ativo : true;
    $('f-master').checked = u ? u.master : false;
    $('f-ativo').disabled = eu; $('f-master').disabled = eu;
    $('m-ativo').classList.toggle('desligado', eu); $('m-master').classList.toggle('desligado', eu);
    $('nota-eu').hidden = !eu;
    // bloqueado por senha errada: explica como desbloquear
    $('nota-bloqueio').hidden = !(u && u.bloqueado_em);
    if (u && u.bloqueado_em) $('nota-bloqueio').textContent = 'Bloqueado em ' + dataBr(u.bloqueado_em) + ' por excesso de senhas erradas. Para desbloquear, marque "Ativo" e salve (se precisar, defina uma nova senha).';
    // usuario novo: compartilhar e ferramentas sempre desmarcados (regra do dono, 31/10/2026; vale para toda caixa nova)
    $('f-pode-email').checked = !!(u && u.pode_email);
    $('f-pode-whats').checked = !!(u && u.pode_whats);
    $('f-pode-simulador').checked = !!(u && u.pode_simulador);
    $('f-pode-integrar').checked = !!(u && u.pode_integrar);
    $('f-pode-coletor').checked = !!(u && u.pode_coletor);
    $('f-pode-col-manut').checked = !!(u && u.pode_col_manut);
    $('f-pode-col-etiq').checked = !!(u && u.pode_col_etiq);
    $('f-pode-col-rastro').checked = !!(u && u.pode_col_rastro);
    $('f-pode-sim-manut').checked = !!(u && u.pode_sim_manut);
    $('f-pode-sim-custo').checked = !!(u && u.pode_sim_custo);
    // digital/rosto: padrao sim; proibido pelo config.json (desenv) = desmarcada e travada
    const bioBloq = !!(u && u.bio_bloqueada);
    $('f-pode-biometria').checked = !bioBloq && !!(u && u.pode_biometria !== false);
    $('f-pode-biometria').disabled = bioBloq;
    $('nota-biometria').hidden = !bioBloq;
    // desenv: tudo liberado sempre (dono, 28/10/2026); as caixas ficam marcadas e travadas
    const tudo = !!(u && u.sempre_tudo);
    for (const id of ['f-pode-email', 'f-pode-whats', 'f-pode-simulador', 'f-pode-integrar', 'f-pode-coletor', 'f-pode-col-manut', 'f-pode-col-etiq', 'f-pode-col-rastro', 'f-pode-sim-manut', 'f-pode-sim-custo']) {
      if (tudo) $(id).checked = true;
      $(id).disabled = tudo;
    }
    $('nota-tudo').hidden = !tudo;
    $('f-tela-inicial').value = (u && u.tela_inicial) || '';
    $('f-tela-inicial').dataset.tudo = tudo ? '1' : '';
    montarBis(u ? u.bis : []);
    // demonstracao (consulta): pesquisa em todos com dados ficticios, sem relatorio para liberar
    const demo = !!(u && u.demonstracao);
    $('nota-demo').hidden = !demo;
    if (demo) $('f-bis').innerHTML = '';
    ajustarMaster();
    $('excluir').hidden = !u || eu;
    $('dlg-erro').textContent = '';
    $('dlg').showModal();
    (u ? $('f-nome') : $('f-usuario')).focus();
  }
  const fechar = () => $('dlg').close();
  $('dlg-fechar').addEventListener('click', fechar);
  $('cancelar').addEventListener('click', fechar);
  $('novo').addEventListener('click', () => abrir(null));
  $('lista').addEventListener('click', (e) => {
    const lo = e.target.closest('[data-logoff]');
    if (lo) { fazerLogoff(lo.dataset.logoff); return; }
    const sn = e.target.closest('[data-senha]');
    if (sn) { abrirSenha(sn.dataset.senha); return; }
    const br = e.target.closest('[data-bio-remover]');
    if (br) { removerBiometria(br.dataset.bioRemover); return; }
    const lg = e.target.closest('[data-log]');
    if (lg) { abrirLog(lg.dataset.log); return; }
    const b = e.target.closest('[data-editar]');
    if (!b) return;
    const u = dados.usuarios.find((x) => x.usuario === b.dataset.editar);
    if (u) abrir(u);
  });
  $('busca').addEventListener('input', desenhar);

  $('form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const erro = $('dlg-erro');
    erro.textContent = '';
    const usuario = $('f-usuario').value.trim();
    const senha = $('f-senha').value;
    if (!usuario) { erro.textContent = 'Informe o usuário.'; $('f-usuario').focus(); return; }
    if (!editando && !/^[A-Za-z0-9._-]{2,40}$/.test(usuario)) { erro.textContent = 'Usuário inválido: use letras, números, ponto ou traço (2 a 40 caracteres).'; $('f-usuario').focus(); return; }
    if (!editando && !senha) { erro.textContent = 'Informe a senha do novo usuário.'; $('f-senha').focus(); return; }
    if (senha && senha.length < 4) { erro.textContent = 'A senha precisa ter pelo menos 4 caracteres.'; $('f-senha').focus(); return; }
    const corpo = {
      novo: !editando, usuario, nome: $('f-nome').value.trim(), email: $('f-email').value.trim(), celular: $('f-celular').value.trim(),
      cod_pessoa_erp: $('f-cod-pessoa-erp').value.trim(), perfil_erp: $('f-perfil-erp').value,
      senha: senha || undefined, ativo: $('f-ativo').checked, master: $('f-master').checked,
      pode_email: $('f-pode-email').checked, pode_whats: $('f-pode-whats').checked, pode_simulador: $('f-pode-simulador').checked,
      pode_integrar: $('f-pode-integrar').checked, pode_coletor: $('f-pode-coletor').checked, pode_col_manut: $('f-pode-col-manut').checked, pode_col_etiq: $('f-pode-col-etiq').checked, pode_col_rastro: $('f-pode-col-rastro').checked, pode_sim_manut: $('f-pode-sim-manut').checked, pode_sim_custo: $('f-pode-sim-custo').checked, pode_biometria: $('f-pode-biometria').checked, tela_inicial: $('f-tela-inicial').value,
      bis: [...$('f-bis').querySelectorAll('input[data-wid]:checked')].map((i) => Number(i.dataset.wid))
    };
    $('salvar').disabled = true;
    try {
      const d = await api('/api/admin/salvar', corpo);
      if (!d.ok) { erro.textContent = d.mensagem || 'Não foi possível salvar.'; return; }
      fechar();
      aviso(d.mensagem || 'Salvo.');
      await carregar();
    } catch (x) {
      if (x.message !== 'sessao' && x.message !== 'proibido') erro.textContent = 'Não foi possível falar com o servidor.';
    } finally {
      $('salvar').disabled = false;
    }
  });

  $('excluir').addEventListener('click', async () => {
    if (!editando) return;
    if (!(await perguntar({ titulo: 'Excluir usuário', texto: 'Excluir o usuário "' + editando.usuario + '"? Ele não poderá mais entrar. O histórico de perguntas é mantido.', sim: 'Excluir' }))) return;
    try {
      const d = await api('/api/admin/excluir', { usuario: editando.usuario });
      if (!d.ok) { $('dlg-erro').textContent = d.mensagem || 'Não foi possível excluir.'; return; }
      fechar();
      aviso(d.mensagem || 'Usuário excluído.');
      await carregar();
    } catch (x) {
      if (x.message !== 'sessao' && x.message !== 'proibido') $('dlg-erro').textContent = 'Não foi possível falar com o servidor.';
    }
  });

