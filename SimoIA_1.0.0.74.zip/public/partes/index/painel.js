/*@parte tela principal: tempo, câmbio e commodities. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- painel: tempo e câmbio (o servidor busca na web) ---------- */
  const ICONES = {
    'sol': '<circle cx="12" cy="12" r="4.5"/><path d="M12 2v2.5M12 19.5V22M2 12h2.5M19.5 12H22M4.9 4.9l1.8 1.8M17.3 17.3l1.8 1.8M4.9 19.1l1.8-1.8M17.3 6.7l1.8-1.8"/>',
    'sol-nuvem': '<circle cx="8.5" cy="8.5" r="3.5"/><path d="M8.5 1.5v1.5M1.5 8.5H3M3.6 3.6l1 1M13.4 3.6l-1 1"/><path d="M8 20h9.5a3.5 3.5 0 0 0 .4-7 5 5 0 0 0-9.6 1.2A3 3 0 0 0 8 20z"/>',
    'nuvem': '<path d="M7 19h10.5a4 4 0 0 0 .5-8 6 6 0 0 0-11.5 1.5A3.3 3.3 0 0 0 7 19z"/>',
    'chuva': '<path d="M7 15h10.5a4 4 0 0 0 .5-8 6 6 0 0 0-11.5 1.5A3.3 3.3 0 0 0 7 15z"/><path d="M8 18l-1 3M12 18l-1 3M16 18l-1 3"/>',
    'trovoada': '<path d="M7 14h10.5a4 4 0 0 0 .5-8 6 6 0 0 0-11.5 1.5A3.3 3.3 0 0 0 7 14z"/><path d="M12.5 15l-2.5 4h3l-2 4"/>',
    'neve': '<path d="M7 14h10.5a4 4 0 0 0 .5-8 6 6 0 0 0-11.5 1.5A3.3 3.3 0 0 0 7 14z"/><path d="M8 18v.01M12 18v.01M16 18v.01M10 21v.01M14 21v.01"/>'
  };
  function icone(nome) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (ICONES[nome] || ICONES.nuvem) + '</svg>';
  }
  const num = (v, casas) => Number(v).toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
  const dataBr = (iso) => iso ? iso.slice(8, 10) + '/' + iso.slice(5, 7) + '/' + iso.slice(0, 4) : '';
  function diaSemana(iso, i) {
    if (i === 0) return 'Hoje';
    const d = new Date(iso + 'T12:00:00');
    return d.toLocaleDateString('pt-BR', { weekday: 'short' }).replace('.', '') + ' ' + iso.slice(8, 10);
  }
  function hojeIso() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }

  // título do balão do tempo com a hora atual, ex.: "Tempo em Tapejara/RS - Seg. 12/10/2026 14:35"
  let tituloTempoCidade = null, tituloTempoTimer = null;
  function tituloTempo() {
    if (!tituloTempoCidade) return;
    const hoje = new Date();
    const DIAS_ABREV = ['Dom.', 'Seg.', 'Ter.', 'Qua.', 'Qui.', 'Sex.', 'Sáb.'];
    const hora = String(hoje.getHours()).padStart(2, '0') + ':' + String(hoje.getMinutes()).padStart(2, '0');
    document.getElementById('t-titulo').textContent = 'Tempo em ' + tituloTempoCidade + ' - ' + DIAS_ABREV[hoje.getDay()] + ' ' + dataBr(hojeIso()) + ' ' + hora;
  }

  function mostrarTempo(t) {
    const agora = document.getElementById('t-agora');
    if (!t) { agora.innerHTML = '<span class="cond">Previsão indisponível no momento.</span>'; return; }
    tituloTempoCidade = t.cidade;
    tituloTempo();
    if (!tituloTempoTimer) tituloTempoTimer = setInterval(tituloTempo, 15000);
    const h = t.dias[0] || {};
    agora.innerHTML = icone(t.atual.icone) +
      '<div><div class="graus">' + num(t.atual.temperatura, 0) + '°C</div>' +
      '<div class="cond">' + esc(t.atual.condicao) + ' · máx. ' + num(h.max, 0) + '° / mín. ' + num(h.min, 0) + '°' +
      (h.chuva_prob != null ? ' · chuva ' + h.chuva_prob + '%' : '') + '</div></div>';
    document.getElementById('t-semana').innerHTML = t.dias.map((d, i) =>
      '<li><span>' + esc(diaSemana(d.data, i)) + '</span>' + icone(d.icone) +
      '<span>' + esc(d.condicao) + (d.chuva_prob ? ' <span class="chuva">· ' + d.chuva_prob + '%' + (d.chuva_mm ? ', ' + num(d.chuva_mm, 1) + ' mm' : '') + '</span>' : '') + '</span>' +
      '<span class="temps">' + num(d.max, 0) + '° / ' + num(d.min, 0) + '°</span></li>').join('');
    document.getElementById('t-fonte').textContent = 'Fonte: ' + t.fonte + (t.atualizado ? ' · atualizado ' + t.atualizado.slice(11, 16) : '');
  }

  function mostrarCambio(c) {
    const caixa = document.getElementById('m-lista');
    if (!c) { caixa.innerHTML = '<span class="cond">Cotações indisponíveis no momento.</span>'; return; }
    caixa.innerHTML = c.moedas.map((m) => {
      if (m.venda == null) return '<div class="moeda"><span class="nome">' + esc(m.nome) + '</span><span>-</span></div>';
      const v = m.variacao;
      const cls = v == null ? '' : v > 0 ? 'sobe' : v < 0 ? 'desce' : '';
      const seta = v == null ? '' : v > 0 ? '▲ ' : v < 0 ? '▼ ' : '';
      return '<div class="moeda"><span class="nome">' + esc(m.nome) + '</span>' +
        '<span class="valor">R$ ' + num(m.venda, 4) + '</span>' +
        '<span class="var ' + cls + '" title="' + (c.tempo_real ? 'Variação no dia' : 'Variação sobre o dia útil anterior') + '">' + (v == null ? '' : seta + num(Math.abs(v), 2) + '%') + '</span></div>';
    }).join('');
    document.getElementById('m-titulo').textContent = c.tempo_real ? 'Câmbio comercial agora (venda)' : 'Câmbio (PTAX do Banco Central, venda)';
    const data = (c.moedas.find((m) => m.data) || {}).data;
    const quando = data ? dataBr(data) + (data.length > 10 ? ' ' + data.slice(11, 16) : '') : '';
    document.getElementById('m-fonte').textContent = 'Fonte: ' + c.fonte + (quando ? ' · cotação de ' + quando : '') + ' · atualiza a cada 10 min';
  }

  function variacaoHtml(v, titulo) {
    if (v == null || isNaN(v)) return '<span class="var"></span>';
    const cls = v > 0 ? 'sobe' : v < 0 ? 'desce' : '';
    return '<span class="var ' + cls + '" title="' + titulo + '">' + (v > 0 ? '▲ ' : v < 0 ? '▼ ' : '') + num(Math.abs(v), 2) + '%</span>';
  }
  function quandoBr(iso) {
    const d = new Date(iso);
    return isNaN(d) ? '' : d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  }

  function mostrarCommodities(k) {
    const caixa = document.getElementById('k-lista');
    if (!k) { caixa.innerHTML = '<span class="cond">Cotações indisponíveis no momento.</span>'; return; }
    caixa.innerHTML = k.itens.map((x) => {
      const c = x.cotacao;
      let h = '<div class="comm"><span class="nome">' + esc(x.nome) + ' <span class="bolsa">' + esc(x.bolsa) + (x.obs ? ' · ' + esc(x.obs) : '') + '</span></span>';
      // unidade antes do valor, ex.: "(US¢/lb) 20,77": os valores ficam alinhados à direita
      const unid = String(x.unidade || '').replace(/^\((.*)\)$/, '$1');
      h += c ? '<span class="valor" title="' + (c.quando ? 'Cotação de ' + quandoBr(c.quando) : '') + '">' + (unid ? '<span class="unid">(' + esc(unid) + ')</span> ' : '') + num(c.preco, 2) + '</span>' +
        variacaoHtml(c.variacao, 'Variação sobre o fechamento anterior') : '<span class="valor">-</span><span class="var"></span>';
      if (x.brasil) {
        const b = x.brasil;
        // indicador mensal (ex.: leite ao produtor): "em ago/2026 · +0,38% no mês"; diario: "em 16/10/2026 · +0,85% no dia"
        h += '<span class="br">Brasil (CEPEA, ' + esc(b.rotulo) + '): <strong>R$ ' + num(b.valor, b.casas || 2) + '</strong> ' + esc(b.unidade.replace(/^R\$/, '')) +
          ' em ' + (b.mensal ? esc(b.mes || '') : dataBr(b.data)) +
          (b.variacao != null && !isNaN(b.variacao) ? ' · ' + (b.variacao > 0 ? '+' : '') + num(b.variacao, 2) + (b.mensal ? '% no mês' : '% no dia') : '') + '</span>';
      }
      return h + '</div>';
    }).join('');
    const ult = k.itens.map((x) => x.cotacao && x.cotacao.quando).filter(Boolean).sort().pop();
    document.getElementById('k-fonte').textContent = 'Fonte: ' + k.fonte + (ult ? ' · última cotação ' + quandoBr(ult) : '') + ' · atualiza a cada 10 min';
  }

  async function buscarHistorico() {
    const res = document.getElementById('k-res');
    const id = document.getElementById('k-id').value;
    const de = document.getElementById('k-de').value;
    const ate = document.getElementById('k-ate').value;
    if (!de || !ate) { res.innerHTML = '<p class="msg-erro">Informe as duas datas.</p>'; return; }
    const btn = document.getElementById('k-buscar');
    btn.disabled = true;
    res.innerHTML = '<p>Buscando…</p>';
    try {
      const r = await fetch('/api/commodity?id=' + encodeURIComponent(id) + '&de=' + encodeURIComponent(de) + '&ate=' + encodeURIComponent(ate),
        { headers: { 'Authorization': 'Bearer ' + token } });
      const d = await r.json();
      if (r.status === 401 && d.sessao === false) { voltarAoPortao(); return; }
      if (!d.ok) { res.innerHTML = '<p class="msg-erro">' + esc(d.mensagem || 'Erro.') + '</p>'; return; }
      if (!d.cotacoes.length) { res.innerHTML = '<p>Sem cotações nesse período (a bolsa não abre em fins de semana e feriados).</p>'; return; }
      const s = d.resumo;
      const cls = s.variacao > 0 ? 'sobe' : s.variacao < 0 ? 'desce' : '';
      res.innerHTML = '<p><strong>' + esc(d.nome) + '</strong> (' + esc(d.bolsa) + ', ' + esc(d.unidade) + '), ' + dataBr(d.de) + ' a ' + dataBr(d.ate) +
        ' (' + d.cotacoes.length + ' pregões): média ' + num(s.media, 2) + ' · mín. ' + num(s.minimo, 2) + ' · máx. ' + num(s.maximo, 2) +
        ' · variação <span class="' + cls + '">' + (s.variacao > 0 ? '+' : '') + num(s.variacao, 2) + '%</span></p>' +
        '<div class="tabela"><table><tr><th>Data</th><th>Mínima</th><th>Máxima</th><th>Fechamento</th></tr>' +
        d.cotacoes.slice().reverse().map((x) => '<tr><td>' + dataBr(x.data) + '</td><td>' + (x.minima != null ? num(x.minima, 2) : '-') + '</td><td>' +
          (x.maxima != null ? num(x.maxima, 2) : '-') + '</td><td>' + num(x.fechamento, 2) + '</td></tr>').join('') +
        '</table></div>';
    } catch (e) {
      res.innerHTML = '<p class="msg-erro">Não foi possível buscar o histórico agora.</p>';
    } finally {
      btn.disabled = false;
    }
  }
  document.getElementById('k-buscar').addEventListener('click', buscarHistorico);

  // var: carregarPainel pode rodar antes destas linhas (sessao ja aberta)
  var painelCarregado = false;
  var painelTimer = null;
  async function carregarPainel() {
    const p = document.getElementById('painel');
    p.hidden = false;
    if (!document.getElementById('m-de').value) {
      const h = hojeIso();
      document.getElementById('m-de').value = h.slice(0, 8) + '01';
      document.getElementById('m-ate').value = h;
      document.getElementById('k-de').value = h.slice(0, 8) + '01';
      document.getElementById('k-ate').value = h;
    }
    if (!painelTimer) painelTimer = setInterval(atualizarPainel, 10 * 60 * 1000); // tempo e cambio, sem recarregar a pagina
    if (!painelCarregado) await atualizarPainel();
  }
  async function atualizarPainel() {
    if (!token) return;
    try {
      const r = await fetch('/api/painel', { headers: { 'Authorization': 'Bearer ' + token } });
      if (r.status === 401) return;
      const d = await r.json();
      // numa atualizacao automatica que falhe, mantem o que ja esta na tela
      if (d.tempo || !painelCarregado) mostrarTempo(d.tempo);
      if (d.cambio || !painelCarregado) mostrarCambio(d.cambio);
      if (d.commodities || !painelCarregado) mostrarCommodities(d.commodities);
      painelCarregado = true;
    } catch (e) {
      if (!painelCarregado) { mostrarTempo(null); mostrarCambio(null); mostrarCommodities(null); }
    }
    atualizarPainelDia();
    atualizarNoticias();
  }

