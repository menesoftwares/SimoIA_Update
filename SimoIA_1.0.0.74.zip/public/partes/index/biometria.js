/*@parte tela principal: digital / rosto, sessão e versão nova. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- digital / rosto (WebAuthn, "chave de acesso") ----------
   * A biometria é conferida pelo próprio aparelho; o servidor só recebe uma assinatura. Opcional para cada pessoa.
   * Este aparelho lembra quem ativou (localStorage "biometria" = { usuario, id, nome }), para mostrar o botão no login. */
  const b64u = {
    para: (buf) => { const u = new Uint8Array(buf); let s = ''; for (let i = 0; i < u.length; i++) s += String.fromCharCode(u[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); },
    de: (t) => { let s = String(t).replace(/-/g, '+').replace(/_/g, '/'); while (s.length % 4) s += '='; const b = atob(s); const u = new Uint8Array(b.length); for (let i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u.buffer; }
  };
  let bioSuporteP = null;
  function bioSuportado() {
    if (!bioSuporteP) {
      bioSuporteP = (window.PublicKeyCredential && window.isSecureContext && PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable)
        ? PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable().catch(() => false)
        : Promise.resolve(false);
    }
    return bioSuporteP;
  }
  function bioLocal() { try { return JSON.parse(localStorage.getItem('biometria') || 'null'); } catch (e) { return null; } }
  function bioLocalGravar(v) { try { if (v) localStorage.setItem('biometria', JSON.stringify(v)); else localStorage.removeItem('biometria'); } catch (e) { /* ignora */ } }
  const btnBio = document.getElementById('entrar-bio');
  // login: botão só se este aparelho foi ativado e o navegador suporta
  async function bioMostrarBotaoLogin() {
    const l = bioLocal();
    const ok = !!(l && l.usuario) && await bioSuportado();
    btnBio.hidden = !ok;
    document.getElementById('bio-quem').textContent = ok ? (l.nome || l.usuario) : '';
  }
  async function entrarComBiometria(confirmar) {
    const l = bioLocal();
    if (!l) return;
    ultimoMetodo = 'bio';
    btnBio.disabled = true;
    erroPortao.textContent = '';
    document.getElementById('conflito').hidden = true;
    try {
      const o = await (await fetch('/api/biometria/login-opcoes', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ usuario: l.usuario }) })).json();
      if (!o.ok) { erroPortao.textContent = o.mensagem || 'Não foi possível usar a digital/rosto agora.'; return; }
      const pk = o.publicKey;
      pk.challenge = b64u.de(pk.challenge);
      pk.allowCredentials = (pk.allowCredentials || []).map((c) => ({ type: c.type, id: b64u.de(c.id) }));
      let cred;
      try { cred = await navigator.credentials.get({ publicKey: pk }); } catch (e) {
        erroPortao.textContent = e && e.name === 'NotAllowedError' ? 'Leitura cancelada ou não reconhecida. Tente de novo ou entre com a senha.' : 'Não foi possível usar a digital/rosto (' + ((e && e.name) || 'erro') + '). Entre com a senha.';
        return;
      }
      const resp = cred.response;
      const r = await fetch('/api/biometria/entrar', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        id: cred.id, clientDataJSON: b64u.para(resp.clientDataJSON), authenticatorData: b64u.para(resp.authenticatorData),
        signature: b64u.para(resp.signature), dispositivo: idDispositivo(), confirmar: !!confirmar, manter: manterMarcado() }) });
      const d = await r.json();
      if (r.status === 409 && d.conflito) { mostrarConflito(d); return; }
      if (d.ok) { entrou(d, d.usuario); return; }
      if (r.status === 404) { bioLocalGravar(null); bioMostrarBotaoLogin(); } // desativada (na Gestão ou em outro aparelho)
      erroPortao.textContent = d.mensagem || 'Não foi possível entrar com a digital/rosto. Entre com a senha.';
    } catch (e) {
      erroPortao.textContent = 'Não foi possível falar com o servidor.';
    } finally {
      btnBio.disabled = false;
    }
  }
  btnBio.addEventListener('click', () => entrarComBiometria(false));

  // depois do login: convite para ativar (opcional) e o link "Ativar/Desativar digital / rosto" no topo
  const bioOferta = document.getElementById('bio-oferta');
  const bioStatus = document.getElementById('bio-status');
  const linkBio = document.getElementById('abrir-bio');
  let bioEu = null; // { usuario, nome } de quem está logado
  const bioAtivoAqui = () => { const l = bioLocal(); return !!(l && bioEu && String(l.usuario).toLowerCase() === String(bioEu.usuario).toLowerCase()); };
  const chaveRecusa = () => 'bio_recusa_' + String(bioEu ? bioEu.usuario : '').toLowerCase();
  async function bioOfertar(d) {
    bioEu = { usuario: d.usuario, nome: d.nome };
    bioStatus.textContent = '';
    const pode = !!d.biometria_permitida && await bioSuportado();
    linkBio.hidden = !pode;
    if (!pode) { bioOferta.hidden = true; return; }
    linkBio.textContent = bioAtivoAqui() ? 'Desativar digital / rosto' : 'Ativar digital / rosto';
    let recusou = 0;
    try { recusou = Number(localStorage.getItem(chaveRecusa())) || 0; } catch (e) { /* ignora */ }
    bioOferta.hidden = bioAtivoAqui() || Date.now() - recusou < 30 * 24 * 3600 * 1000;
  }
  async function ativarBiometria() {
    bioOferta.hidden = false;
    bioStatus.className = 'bio-status';
    bioStatus.textContent = 'Siga as instruções do aparelho (digital, rosto ou PIN)…';
    const btn = document.getElementById('bio-ativar');
    btn.disabled = true;
    try {
      const o = await (await fetch('/api/biometria/cadastro-opcoes', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: '{}' })).json();
      if (!o.ok) throw new Error(o.mensagem || 'Não foi possível ativar agora.');
      const pk = o.publicKey;
      pk.challenge = b64u.de(pk.challenge);
      pk.user.id = b64u.de(pk.user.id);
      pk.excludeCredentials = (pk.excludeCredentials || []).map((c) => ({ type: c.type, id: b64u.de(c.id) }));
      let cred;
      try { cred = await navigator.credentials.create({ publicKey: pk }); } catch (e) {
        if (e && e.name === 'InvalidStateError') { // este aparelho já tem a chave desse usuário
          bioLocalGravar({ usuario: bioEu.usuario, nome: bioEu.nome });
          throw new Error('Este aparelho já estava ativado. No próximo login, toque em "Entrar com digital / rosto".');
        }
        throw new Error(e && e.name === 'NotAllowedError' ? 'Ativação cancelada.' : 'O aparelho não permitiu (' + ((e && e.name) || 'erro') + ').');
      }
      const resp = cred.response;
      if (!resp.getPublicKey || !resp.getAuthenticatorData) throw new Error('Este navegador é antigo para isso. Atualize o navegador e tente de novo.');
      const r = await (await fetch('/api/biometria/cadastrar', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify({
        id: cred.id, clientDataJSON: b64u.para(resp.clientDataJSON), authenticatorData: b64u.para(resp.getAuthenticatorData()),
        publicKey: b64u.para(resp.getPublicKey()), alg: resp.getPublicKeyAlgorithm(), dispositivo: idDispositivo() }) })).json();
      if (!r.ok) throw new Error(r.mensagem || 'Não foi possível ativar.');
      bioLocalGravar({ usuario: r.usuario || bioEu.usuario, id: r.id, nome: bioEu.nome });
      bioStatus.textContent = r.mensagem;
      linkBio.textContent = 'Desativar digital / rosto';
      setTimeout(() => { bioOferta.hidden = true; }, 6000);
    } catch (e) {
      bioStatus.className = 'bio-status erro';
      bioStatus.textContent = e.message;
      if (bioAtivoAqui()) { linkBio.textContent = 'Desativar digital / rosto'; setTimeout(() => { bioOferta.hidden = true; }, 6000); }
    } finally {
      btn.disabled = false;
    }
  }
  document.getElementById('bio-ativar').addEventListener('click', ativarBiometria);
  document.getElementById('bio-agora-nao').addEventListener('click', () => {
    try { localStorage.setItem(chaveRecusa(), String(Date.now())); } catch (e) { /* ignora */ }
    bioOferta.hidden = true;
  });
  linkBio.addEventListener('click', async () => {
    if (!bioAtivoAqui()) { ativarBiometria(); return; }
    if (!confirm('Desativar a entrada por digital/rosto neste aparelho? Você continua entrando com a senha e pode ativar de novo depois.')) return;
    const l = bioLocal();
    try {
      const r = await (await fetch('/api/biometria/remover', { method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token }, body: JSON.stringify({ id: l && l.id ? l.id : null }) })).json();
      bioLocalGravar(null);
      linkBio.textContent = 'Ativar digital / rosto';
      alert(r.mensagem || 'Desativada.');
    } catch (e) { alert('Não foi possível falar com o servidor.'); }
  });
  bioMostrarBotaoLogin();
  document.getElementById('conflito-nao').addEventListener('click', () => {
    document.getElementById('conflito').hidden = true;
    campoSenha.value = '';
    erroPortao.textContent = 'Entrada cancelada. A outra conexão continua ativa.';
    campoUsuario.focus();
  });
  // aviso deixado por outra página (ex.: Gestão do sistema) quando a sessão caiu
  try { const av = sessionStorage.getItem('aviso'); if (av) { erroPortao.textContent = av; sessionStorage.removeItem('aviso'); } } catch (e) { /* ignora */ }

  // confere a sessão a cada 30 s e ao voltar para a aba: se caiu (outro acesso ou inatividade), avisa na hora.
  // Essa conferência não conta como uso (não renova o prazo).
  async function conferirSessao() {
    if (!token || document.hidden) return;
    try {
      const r = await fetch('/api/sessao', { headers: { 'Authorization': 'Bearer ' + token } });
      if (r.status === 401) {
        const d = await r.json().catch(() => ({}));
        if (d.sessao === false) voltarAoPortao(d.mensagem || 'Sessão expirada. Entre novamente com seu usuário e senha.');
      }
    } catch (e) { /* sem rede: tenta na próxima */ }
  }
  setInterval(conferirSessao, 30 * 1000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) conferirSessao(); });

  // Nova versão: o servidor carimba a página com a versão dela; o app instalado (que fica aberto em segundo plano)
  // confere ao voltar para a frente e a cada 10 min. Mudou: mostra a faixa "Nova versão… Atualizar" (não recarrega sozinho,
  // para não perder uma pesquisa em andamento).
  const VERSAO_PAGINA = '__VERSAO_PAGINA__';
  async function conferirVersao() {
    if (/^__/.test(VERSAO_PAGINA) || document.hidden) return; // página aberta sem o servidor (arquivo local)
    try {
      const d = await (await fetch('/api/versao', { cache: 'no-store' })).json();
      if (d && d.versao && d.versao !== VERSAO_PAGINA) document.getElementById('nova-versao').hidden = false;
    } catch (e) { /* sem rede: tenta depois */ }
  }
  document.getElementById('atualizar-app').addEventListener('click', () => location.reload());
  document.addEventListener('visibilitychange', () => { if (!document.hidden) conferirVersao(); });
  window.addEventListener('focus', conferirVersao);
  setInterval(conferirVersao, 10 * 60 * 1000);
  document.getElementById('sair').addEventListener('click', async () => {
    try { await fetch('/api/sair', { method: 'POST', headers: { 'Authorization': 'Bearer ' + token } }); } catch (e) { /* ignora */ }
    secao.hidden = true;
    voltarAoPortao();
  });

