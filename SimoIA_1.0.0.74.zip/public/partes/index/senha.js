/*@parte tela principal: trocar a própria senha. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- trocar a propria senha (usuario logado) ---------- */
  const troca = document.getElementById('troca');
  const formTroca = document.getElementById('form-troca');
  const trocaAtual = document.getElementById('troca-atual');
  const trocaNova = document.getElementById('troca-nova');
  const trocaRepete = document.getElementById('troca-repete');
  const trocaSalvar = document.getElementById('troca-salvar');
  const trocaVoltar = document.getElementById('troca-voltar');
  const trocaErro = document.getElementById('troca-erro');
  const trocaOk = document.getElementById('troca-ok');

  function abrirTroca() {
    formTroca.reset();
    try { document.getElementById('troca-usuario').value = sessionStorage.getItem('usuario') || ''; } catch (e) { /* ignora */ }
    trocaErro.textContent = '';
    trocaOk.textContent = '';
    trocaVoltar.textContent = 'Cancelar';
    trocaSalvar.hidden = false;
    app.hidden = true;
    troca.hidden = false;
    document.body.classList.add('trocando-senha');
    window.scrollTo(0, 0);
    trocaAtual.focus();
  }
  function fecharTroca() {
    formTroca.reset();
    document.body.classList.remove('trocando-senha');
    troca.hidden = true;
    app.hidden = false;
    window.scrollTo(0, 0);
  }

  async function salvarTroca(ev) {
    if (ev) ev.preventDefault();
    trocaErro.textContent = '';
    trocaOk.textContent = '';
    if (!trocaAtual.value || !trocaNova.value) { trocaErro.textContent = 'Preencha a senha atual e a nova senha.'; return; }
    if (trocaNova.value.length < 4) { trocaErro.textContent = 'A nova senha precisa ter pelo menos 4 caracteres.'; trocaNova.focus(); return; }
    if (trocaNova.value !== trocaRepete.value) { trocaErro.textContent = 'A nova senha e a repetição não conferem.'; trocaRepete.select(); return; }
    if (trocaNova.value === trocaAtual.value) { trocaErro.textContent = 'A nova senha precisa ser diferente da atual.'; trocaNova.select(); return; }
    trocaSalvar.disabled = true;
    try {
      const r = await fetch('/api/senha', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify({ atual: trocaAtual.value, nova: trocaNova.value })
      });
      const d = await r.json();
      if (d.ok) {
        formTroca.reset();
        trocaOk.textContent = d.mensagem || 'Senha alterada.';
        trocaSalvar.hidden = true;
        trocaVoltar.textContent = 'Voltar';
        trocaVoltar.focus();
      } else if (d.sessao === false) {
        voltarAoPortao();
        erroPortao.textContent = d.mensagem || 'Sessão expirada. Entre novamente.';
      } else {
        trocaErro.textContent = d.mensagem || 'Não foi possível trocar a senha.';
        if (/atual/i.test(d.mensagem || '')) trocaAtual.select();
      }
    } catch (e) {
      trocaErro.textContent = 'Não foi possível falar com o servidor.';
    }
    trocaSalvar.disabled = false;
  }

  document.getElementById('abrir-troca').addEventListener('click', abrirTroca);
  trocaVoltar.addEventListener('click', fecharTroca);
  formTroca.addEventListener('submit', salvarTroca);

