/*@parte tela principal: imagem do gráfico e botões da resposta. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- imagem (PNG) do gráfico, desenhada a partir dos dados; sempre em fundo branco ---------- */
  const CORES_IMG = ['#2a78d6', '#eb6834', '#1baf7a', '#eda100', '#e87ba4', '#008300', '#7b61c9', '#0aa5b5', '#c0392b', '#6d8a2a'];
  const nomeImagem = () => '__NOME_ARQUIVO___grafico_' + new Date().toISOString().slice(0, 16).replace(/[-:T]/g, '') + '.png';
  function imagemDoGrafico(g, pergunta) {
    const W = 900, P = 32, ESC = 2, T = 138;
    const fonte = (tam, peso) => (peso || 400) + ' ' + tam + 'px "Segoe UI", system-ui, -apple-system, Arial, sans-serif';
    const itens = g.itens.map((x, i) => ({ rotulo: String(x.rotulo), valor: Number(x.valor) || 0, cor: CORES_IMG[i % CORES_IMG.length] }));
    if (g.tipo === 'pizza' && g.outros) itens.push({ rotulo: 'Outros', valor: Number(g.outros), cor: '#a19f97' });
    const total = g.total || itens.reduce((a, x) => a + x.valor, 0);
    const comp = g.tipo === 'comparativo' && Array.isArray(g.grupos) ? g.grupos : null; // comparativo de anos: blocos por medida
    const altGraf = comp ? comp.reduce((a, b) => a + 34 + b.itens.length * 30 + 16, 0) : g.tipo === 'pizza' ? Math.max(270, itens.length * 34 + 10) : g.tipo === 'linha' ? 300 : itens.length * 32 + 8;
    const H = T + altGraf + (g.aviso ? 64 : 42);
    const cv = document.createElement('canvas');
    cv.width = W * ESC; cv.height = H * ESC;
    const c = cv.getContext('2d');
    c.scale(ESC, ESC);
    c.fillStyle = '#FFFFFF'; c.fillRect(0, 0, W, H);
    const corta = (txt, larg) => {
      txt = String(txt);
      if (c.measureText(txt).width <= larg) return txt;
      while (txt.length > 1 && c.measureText(txt + '…').width > larg) txt = txt.slice(0, -1);
      return txt + '…';
    };
    const linhaH = (y, x1, x2, cor) => { c.strokeStyle = cor; c.lineWidth = 1; c.beginPath(); c.moveTo(x1, Math.round(y) + 0.5); c.lineTo(x2, Math.round(y) + 0.5); c.stroke(); };
    // cabeçalho: marca, título do gráfico e a pergunta
    c.fillStyle = '#556673'; c.font = fonte(13, 600); c.fillText('__NOME_SISTEMA__', P, P + 10);
    c.fillStyle = '#16222C'; c.font = fonte(24, 700); c.fillText(corta(g.titulo || 'Gráfico', W - 2 * P), P, P + 44);
    c.fillStyle = '#556673'; c.font = fonte(15); c.fillText(corta(pergunta || '', W - 2 * P), P, P + 70);
    linhaH(T - 22, P, W - P, '#CBD6DC');
    if (comp) {
      const larRot = 250, xb = P + larRot + 12, xf = W - P - 210;
      const corSerie = { 1: '#2a78d6', 2: '#eb6834', 3: '#f5b399' };
      let y = T;
      comp.forEach((bl) => {
        c.fillStyle = '#16222C'; c.font = fonte(17, 700); c.fillText(corta(bl.titulo, 360), P, y + 20);
        const v = bl.variacao;
        c.textAlign = 'right'; c.font = fonte(15, 600);
        c.fillStyle = v == null ? '#556673' : v > 0.04 ? '#1F7A4D' : v < -0.04 ? '#A3321F' : '#556673';
        c.fillText(corta((v == null ? '' : v > 0.04 ? '▲ ' : v < -0.04 ? '▼ ' : '') + bl.texto, W - 2 * P - 380), W - P, y + 20);
        c.textAlign = 'left';
        y += 34;
        const max = Math.max(...bl.itens.map((x) => Math.abs(Number(x.valor) || 0)), 0) || 1;
        bl.itens.forEach((x) => {
          const val = Number(x.valor) || 0;
          c.fillStyle = '#16222C'; c.font = fonte(15); c.fillText(corta(x.rotulo, larRot), P, y + 17);
          c.fillStyle = corSerie[x.serie] || corSerie[1];
          c.fillRect(xb, y + 5, Math.max(2, Math.abs(val) / max * (xf - xb - 10)), 16);
          c.textAlign = 'right'; c.fillStyle = '#16222C'; c.fillText(fmtValor(val, bl.formato), W - P, y + 17); c.textAlign = 'left';
          y += 30;
        });
        linhaH(y + 6, P, W - P, '#E3E9ED');
        y += 16;
      });
    } else if (g.tipo === 'pizza') {
      const cx = P + 135, cy = T + altGraf / 2 - 5, R = 125, r = 72;
      let a = -Math.PI / 2;
      itens.forEach((f) => {
        const a2 = a + (total > 0 ? Math.max(f.valor, 0) / total : 0) * 2 * Math.PI;
        c.beginPath(); c.arc(cx, cy, R, a, a2); c.arc(cx, cy, r, a2, a, true); c.closePath();
        c.fillStyle = f.cor; c.fill(); c.strokeStyle = '#FFFFFF'; c.lineWidth = 2; c.stroke();
        a = a2;
      });
      c.textAlign = 'center';
      c.fillStyle = '#556673'; c.font = fonte(14); c.fillText('Total', cx, cy - 4);
      c.fillStyle = '#16222C'; c.font = fonte(18, 700); c.fillText(fmtCurto(total, g.formato), cx, cy + 20);
      c.textAlign = 'left';
      const x0 = P + 300, xv = W - P - 78, xp = W - P;
      const y0 = T + Math.max(0, (altGraf - itens.length * 34) / 2);
      itens.forEach((f, i) => {
        const y = y0 + i * 34 + 22;
        c.fillStyle = f.cor; c.fillRect(x0, y - 12, 14, 14);
        c.fillStyle = '#16222C'; c.font = fonte(16); c.fillText(corta(f.rotulo, xv - x0 - 180), x0 + 24, y);
        c.textAlign = 'right'; c.fillText(fmtValor(f.valor, g.formato), xv, y);
        c.fillStyle = '#556673'; c.fillText(pctTxt(f.valor, total), xp, y);
        c.textAlign = 'left';
        linhaH(y + 11, x0, xp, '#E3E9ED');
      });
    } else if (g.tipo === 'linha') {
      const mE = P + 80, mD = W - P - 10, mT = T + 10, mB = T + altGraf - 40;
      const vals = itens.map((x) => x.valor);
      let min = Math.min(0, ...vals), max = Math.max(...vals, 0);
      if (max === min) max = min + 1;
      const bruto = (max - min) / 4, mag = Math.pow(10, Math.floor(Math.log10(bruto)));
      const passo = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((p) => p >= bruto);
      min = Math.floor(min / passo) * passo; max = Math.ceil(max / passo) * passo;
      const X = (i) => (itens.length === 1 ? (mE + mD) / 2 : mE + i * (mD - mE) / (itens.length - 1));
      const Y = (v) => mT + (max - v) / (max - min) * (mB - mT);
      c.font = fonte(13);
      for (let v = min; v <= max + passo / 2; v += passo) {
        linhaH(Y(v), mE, mD, Math.abs(v) < passo / 1e6 ? '#c3c2b7' : '#e1e0d9');
        c.textAlign = 'right'; c.fillStyle = '#6b6a65'; c.fillText(fmtCurto(v, g.formato), mE - 8, Y(v) + 4);
      }
      c.textAlign = 'center';
      const pulo = Math.ceil(itens.length / Math.max(1, Math.floor((mD - mE) / 80)));
      itens.forEach((x, i) => {
        if (i % pulo === 0 || (i === itens.length - 1 && (itens.length - 1) % pulo >= pulo / 2)) c.fillText(corta(x.rotulo, 78), X(i), mB + 24);
      });
      c.strokeStyle = '#2a78d6'; c.lineWidth = 2.5; c.lineJoin = 'round';
      c.beginPath(); itens.forEach((x, i) => (i ? c.lineTo(X(i), Y(x.valor)) : c.moveTo(X(i), Y(x.valor)))); c.stroke();
      itens.forEach((x, i) => {
        c.beginPath(); c.arc(X(i), Y(x.valor), 4.5, 0, 2 * Math.PI);
        c.fillStyle = '#2a78d6'; c.fill(); c.strokeStyle = '#FFFFFF'; c.lineWidth = 2; c.stroke();
      });
      c.textAlign = 'left';
    } else {
      const larRot = 250, xb = P + larRot + 12, xf = W - P - 210;
      const max = Math.max(...itens.map((x) => Math.abs(x.valor)), 0) || 1;
      itens.forEach((x, i) => {
        const y = T + i * 32 + 4;
        c.fillStyle = '#16222C'; c.font = fonte(15); c.fillText(corta(x.rotulo, larRot), P, y + 17);
        c.fillStyle = x.valor < 0 ? '#556673' : '#2a78d6';
        c.fillRect(xb, y + 5, Math.max(2, Math.abs(x.valor) / max * (xf - xb - 10)), 16);
        c.textAlign = 'right';
        c.fillStyle = '#16222C'; c.fillText(fmtValor(x.valor, g.formato), W - P - (total > 0 ? 62 : 0), y + 17);
        if (total > 0) { c.fillStyle = '#556673'; c.fillText(pctTxt(x.valor, total), W - P, y + 17); }
        c.textAlign = 'left';
      });
    }
    // rodapé: aviso do gráfico e quando foi gerado
    let yf = T + altGraf + 22;
    if (g.aviso) { c.fillStyle = '#556673'; c.font = fonte(13); c.fillText(corta(g.aviso, W - 2 * P), P, yf); yf += 22; }
    const agora = new Date();
    c.fillStyle = '#8A99A4'; c.font = fonte(12);
    c.fillText('Gerado pelo __NOME_SISTEMA__ em ' + agora.toLocaleDateString('pt-BR') + ' ' + agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }), P, yf + 6);
    return new Promise((ok, falha) => cv.toBlob((b) => (b ? ok(b) : falha(new Error('sem imagem'))), 'image/png'));
  }
  // copia a imagem (página segura) ou baixa; devolve a frase para o status.
  // A imagem vai para a área de transferência como "promessa": funciona também no Safari, que exige o clique recente.
  async function entregarImagem(g, pergunta, onde) {
    if (window.isSecureContext && navigator.clipboard && window.ClipboardItem) {
      try {
        await navigator.clipboard.write([new window.ClipboardItem({ 'image/png': imagemDoGrafico(g, pergunta) })]);
        return ' A imagem do gráfico foi copiada: cole com Ctrl+V' + onde;
      } catch (e) { /* sem permissão: baixa */ }
    }
    try {
      const blob = await imagemDoGrafico(g, pergunta);
      const nome = nomeImagem();
      baixarBlob(blob, nome);
      return ' A imagem do gráfico foi baixada (' + nome + '): arraste-a' + onde;
    } catch (e) {
      return ' Não foi possível gerar a imagem do gráfico.';
    }
  }
  const ICONE_SUGESTAO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 18h6M10 22h4"/><path d="M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.2 1 2V17h6v-.3c0-.8.4-1.5 1-2A7 7 0 0 0 12 2z"/></svg>';
  const ICONE_ANEXO = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 11.5l-8.6 8.6a5 5 0 0 1-7.1-7.1l8.6-8.6a3.3 3.3 0 0 1 4.7 4.7l-8.6 8.6a1.7 1.7 0 0 1-2.4-2.4l7.9-7.9"/></svg>';
  const ICONE_COMPARTILHAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg>';
  const ICONE_WHATS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3.5 20.5l1.3-4.2A8.5 8.5 0 1 1 8 19.4z"/><path d="M9 8.5c.3 2.6 2.4 4.9 5 5.5l1-1.2 2 1-.5 1.6c-3.8.4-8.2-3.6-8-7.4L10 7l1 2z"/></svg>';
  const ICONE_OUTROS = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg>';
  // botão "Compartilhar" com o menu: E-mail, WhatsApp e (quando o aparelho permite) Outros apps
  // permissões do usuário (cadastro): se não vierem, vale "pode"
  const podeEmail = () => !opcoes || opcoes.pode_email !== false;
  const podeWhats = () => !opcoes || opcoes.pode_whats !== false;
  function botaoCompartilhar(status, pergunta, resposta, g) {
    const caixa = document.createElement('span');
    caixa.className = 'comp';
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'btn-sec';
    b.setAttribute('aria-haspopup', 'true'); b.setAttribute('aria-expanded', 'false');
    b.innerHTML = ICONE_COMPARTILHAR + 'Compartilhar';
    const menu = document.createElement('div');
    menu.className = 'menu-comp'; menu.setAttribute('role', 'menu'); menu.hidden = true;
    const opcoesComp = [];
    if (podeEmail()) opcoesComp.push(['email', ICONE_EMAIL, 'E-mail']);
    if (podeWhats()) opcoesComp.push(['whatsapp', ICONE_WHATS, 'WhatsApp']);
    // "enviar com anexos" (menu do aparelho, com gráfico e planilha) pode mandar para qualquer app: só para quem pode os dois
    const comAnexos = !!(navigator.share && navigator.canShare && window.isSecureContext && podeEmail() && podeWhats());
    if (comAnexos) opcoesComp.push(['outros', ICONE_ANEXO, 'Enviar com anexos…']);
    // os anexos são preparados quando o menu abre (uma vez por resposta), para o toque já encontrar tudo pronto
    let anexosP = null;
    const anexos = () => anexosP || (anexosP = prepararAnexos(pergunta, g));
    const fechar = () => { menu.hidden = true; b.setAttribute('aria-expanded', 'false'); };
    opcoesComp.forEach(([id, icone, rotulo]) => {
      const o = document.createElement('button');
      o.type = 'button'; o.setAttribute('role', 'menuitem');
      o.innerHTML = icone + esc(rotulo);
      o.addEventListener('click', () => { fechar(); DESTINOS[id](status, pergunta, resposta, g, anexos); });
      menu.appendChild(o);
    });
    b.addEventListener('click', (e) => {
      e.stopPropagation();
      const abrir = menu.hidden;
      document.querySelectorAll('.menu-comp').forEach((m) => { m.hidden = true; });
      menu.hidden = !abrir; b.setAttribute('aria-expanded', String(abrir));
      if (abrir) { menu.querySelector('button').focus(); if (comAnexos) anexos(); }
    });
    menu.addEventListener('keydown', (e) => { if (e.key === 'Escape') { fechar(); b.focus(); } });
    document.addEventListener('click', (e) => { if (!caixa.contains(e.target)) fechar(); });
    caixa.appendChild(b); caixa.appendChild(menu);
    return caixa;
  }
  // botões abaixo da resposta: "Baixar dados", "Enviar por e-mail" ou as opções de uma pergunta do app
  function acoesResposta(caixa, r) {
    const botoes = [];
    if (r.exportavel || r.download) {
      botoes.push({ rotulo: 'Baixar dados', acao: 'baixar' });
      if (r.grafico && r.grafico.itens && r.grafico.itens.length) {
        botoes.push({ rotulo: 'Baixar gráfico', acao: 'imagem' }); // "Copiar gráfico" removido a pedido do dono (28/10/2026)
      }
      if (podeEmail() || podeWhats()) botoes.push({ rotulo: 'Compartilhar', acao: 'compartilhar' });
    }
    (r.opcoes || []).forEach((o) => botoes.push(o));
    if (!botoes.length) return;
    const div = document.createElement('div');
    div.className = 'acoes-resp';
    const status = document.createElement('span');
    status.className = 'status'; status.setAttribute('role', 'status');
    // pergunta e resposta desta resposta (para compartilhar)
    const pergunta = titulo.textContent;
    const resposta = r.mensagem || '';
    botoes.forEach((o) => {
      if (o.acao === 'compartilhar') { div.appendChild(botaoCompartilhar(status, pergunta, resposta, r.grafico)); return; }
      const b = document.createElement('button');
      b.type = 'button'; b.className = 'btn-sec';
      b.innerHTML = (o.acao === 'baixar' || o.acao === 'imagem' ? ICONE_BAIXAR : '') + esc(o.rotulo);
      if (o.acao === 'baixar') b.addEventListener('click', () => baixarExcel(b, status));
      // "Sobre qual relatório é a pergunta?": refaz a mesma pergunta no relatório escolhido
      if (o.acao === 'assunto') b.addEventListener('click', () => {
        if (btnConsultar.disabled) return;
        campo.value = pergunta; ajustarAltura(); atualizarBotao();
        perguntar(null, o.assunto);
      });
      // sugestão de um costume da pessoa ("Ver por cliente"): roda a consulta já ajustada pelo servidor
      if (o.acao === 'consulta') {
        b.classList.add('btn-sugestao');
        b.innerHTML = ICONE_SUGESTAO + esc(o.rotulo);
        b.addEventListener('click', () => {
          if (btnConsultar.disabled) return;
          perguntar(o.consulta, null, { sugestao: o.sugestao, pergunta, titulo: pergunta + ' · ' + o.rotulo });
        });
      }
      // "Considerar quais clientes?" (cadastro): refaz a mesma pergunta com Brasil / Brasil e exterior / exterior
      if (o.acao === 'abrangencia') b.addEventListener('click', () => {
        if (btnConsultar.disabled) return;
        campo.value = pergunta; ajustarAltura(); atualizarBotao();
        perguntar(null, null, { abrangencia: o.abrangencia });
      });
      if (o.acao === 'imagem') b.addEventListener('click', () => {
        imagemDoGrafico(r.grafico, pergunta)
          .then((blob) => { const n = nomeImagem(); baixarBlob(blob, n); status.className = 'status'; status.textContent = 'Imagem do gráfico baixada: ' + n; })
          .catch(() => { status.className = 'status erro'; status.textContent = 'Não foi possível gerar a imagem do gráfico.'; });
      });
      div.appendChild(b);
    });
    div.appendChild(status);
    caixa.appendChild(div);
    if (r.download) baixarExcel(div.querySelector('.btn-sec'), status);
  }

