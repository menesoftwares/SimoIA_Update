/*@parte tela principal: formulário Montar a consulta. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- formulário de consulta ---------- */
  const btnConsultar = document.getElementById('consultar');
  const fAssunto = document.getElementById('f-assunto');
  const fMetrica = document.getElementById('f-metrica');
  const fEscopo = document.getElementById('f-escopo');
  const fPeriodo = document.getElementById('f-periodo');
  const fDe = document.getElementById('f-de');
  const fAte = document.getElementById('f-ate');
  const fAgrupar = document.getElementById('f-agrupar');
  const fLimite = document.getElementById('f-limite');
  const fFdim = document.getElementById('f-fdim');
  const fFvalor = document.getElementById('f-fvalor');
  let opcoes = null;

  function opcao(sel, valor, rotulo) {
    const o = document.createElement('option');
    o.value = valor; o.textContent = rotulo; sel.appendChild(o);
  }
  function mostrarDatas() {
    const p = fPeriodo.value === 'personalizado';
    document.getElementById('l-de').hidden = !p;
    document.getElementById('l-ate').hidden = !p;
  }
  async function carregarOpcoes() {
    carregarPainel();
    try {
      const r = await fetch('/api/opcoes', { headers: { 'Authorization': 'Bearer ' + token } });
      const d = await r.json();
      if (r.status === 401) { voltarAoPortao(); return; }
      if (!d.ok) return;
      // usuario so do Simulador ou so do Coletor (tela padrao na Gestao): vai direto para ele
      if (d.tela_inicial === 'simulador' || d.tela_inicial === 'coletor' || d.tela_inicial === 'coletor_rastro') { location.replace(d.tela_inicial === 'simulador' ? '/simulador' : '/coletor'); return; }
      mostrarRodape(d);
      bioOfertar(d);
      document.getElementById('link-gestao').hidden = !d.master;
      document.getElementById('btn-simulador').hidden = !d.pode_simulador;
      // so "Coletor (manutencao)" tambem mostra o botao: o Coletor abre direto na manutencao (dono, 02/11/2026)
      document.getElementById('btn-coletor').hidden = !(d.pode_coletor || d.pode_col_manut || d.pode_col_etiq || d.pode_col_rastro);
      if (!d.assuntos || !d.assuntos.length) {
        secao.hidden = false;
        titulo.textContent = 'Sem relatórios liberados';
        resultado.className = 'resultado erro';
        resultado.innerHTML = '<p>Seu usuário ainda não tem nenhum relatório liberado. Fale com o administrador.</p>';
        if (d.nome) quem.textContent = 'Olá, ' + d.nome;
        return;
      }
      opcoes = d;
      if (d.nome) quem.textContent = 'Olá, ' + d.nome;
      fAssunto.innerHTML = '';
      d.assuntos.forEach((x) => opcao(fAssunto, x.id, x.rotulo || x.id));
      document.getElementById('l-assunto').hidden = d.assuntos.length < 2;
      fPeriodo.innerHTML = '';
      d.periodos.forEach((p) => opcao(fPeriodo, p.id, p.rotulo));
      montarCampos(d.assuntos[0].id, true);
      // demonstracao (consulta): sem "Montar a consulta"
      document.getElementById('montar').hidden = !!d.demonstracao;
      mostrarDatas();
    } catch (e) { /* formulário fica indisponível */ }
  }
  // rodape: acesso anterior (o de agora nao conta) e modulos liberados
  function mostrarRodape(d) {
    const p = document.getElementById('rodape-sessao');
    let ult = 'Primeiro acesso';
    if (d.login_anterior) {
      const [dt, hr] = String(d.login_anterior).split(' ');
      ult = 'Último acesso: <strong>' + dataBr(dt) + (hr ? ' às ' + esc(hr.slice(0, 5)) : '') + '</strong>';
    }
    const mods = (d.modulos || []).length ? d.modulos.map(esc).join(', ') : 'nenhum';
    p.innerHTML = ult + ' · Módulos: <strong>' + mods + '</strong>';
    p.hidden = false;
  }

  // preenche as listas do formulario conforme o relatorio escolhido
  function montarCampos(assuntoId, padroes) {
    const a = opcoes.assuntos.find((x) => x.id === assuntoId) || opcoes.assuntos[0];
    fAssunto.value = a.id;
    [fMetrica, fEscopo, fAgrupar, fFdim].forEach((s) => { s.innerHTML = ''; });
    a.metricas.forEach((m) => opcao(fMetrica, m.id, m.rotulo));
    (a.escopos || []).forEach((e) => opcao(fEscopo, e.id, e.rotulo));
    document.getElementById('l-escopo').hidden = !(a.escopos || []).length;
    opcao(fAgrupar, '', 'Nada (só o total)');
    opcao(fFdim, '', 'Sem filtro');
    a.dimensoes.forEach((x) => { if (!x.so_filtro) opcao(fAgrupar, x.id, x.rotulo); opcao(fFdim, x.id, x.rotulo + (x.so_filtro ? ' (código)' : '')); });
    if (padroes) {
      fMetrica.value = a.metrica_padrao;
      if (a.escopo_padrao) fEscopo.value = a.escopo_padrao;
      fPeriodo.value = a.periodo_padrao;
    }
    mostrarDatas();
  }
  fAssunto.addEventListener('change', () => montarCampos(fAssunto.value, true));

  function preencherFormulario(c) {
    if (!opcoes) return;
    if (c.assunto && c.assunto !== fAssunto.value) montarCampos(c.assunto, false);
    fMetrica.value = c.metrica;
    if (c.escopo) fEscopo.value = c.escopo;
    fPeriodo.value = c.periodo.preset || 'personalizado';
    fDe.value = c.periodo.de || '';
    fAte.value = c.periodo.ate || '';
    fAgrupar.value = c.agrupar || '';
    const lim = c.limite ? (c.ordem === 'asc' ? -c.limite : c.limite) : '';
    fLimite.value = String(lim);
    if (fLimite.value !== String(lim)) { opcao(fLimite, String(lim), (c.ordem === 'asc' ? 'Os ' + c.limite + ' menores' : 'Os ' + c.limite + ' maiores')); fLimite.value = String(lim); }
    const f = (c.filtros || [])[0];
    fFdim.value = f ? f.dim : '';
    fFvalor.value = f ? f.valor : '';
    mostrarDatas();
  }
  function lerFormulario() {
    const lim = Number(fLimite.value || 0);
    const agrupar = fAgrupar.value || null;
    const naturais = ['mes', 'dia'];
    return {
      assunto: fAssunto.value || (opcoes ? opcoes.assuntos[0].id : undefined),
      metrica: fMetrica.value,
      escopo: fEscopo.value || undefined,
      periodo: fPeriodo.value === 'personalizado' ? { preset: 'personalizado', de: fDe.value, ate: fAte.value } : { preset: fPeriodo.value },
      agrupar,
      limite: lim ? Math.abs(lim) : null,
      ordem: lim < 0 ? 'asc' : (!lim && naturais.includes(agrupar) ? 'natural' : 'desc'),
      filtros: fFdim.value && fFvalor.value.trim() ? [{ dim: fFdim.value, valor: fFvalor.value.trim() }] : []
    };
  }
  fPeriodo.addEventListener('change', mostrarDatas);
  btnConsultar.addEventListener('click', () => {
    if (fPeriodo.value === 'personalizado' && (!fDe.value || !fAte.value)) { fDe.focus(); return; }
    perguntar(lerFormulario());
  });

