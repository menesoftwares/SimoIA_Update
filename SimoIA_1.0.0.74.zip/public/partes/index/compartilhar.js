/*@parte tela principal: Excel, e-mail e WhatsApp. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- Excel da última consulta ---------- */
  const ICONE_BAIXAR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v12M7 10l5 5 5-5M5 21h14"/></svg>';
  const ICONE_EMAIL = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/></svg>';
  // baixa um arquivo da ultima consulta: Excel (/api/exportar) ou e-mail .eml (/api/email)
  const TIPOS_ARQ = {
    excel: { url: '/api/exportar', gerando: 'Gerando o Excel…', erro: 'Não foi possível gerar o Excel.', padrao: '__NOME_ARQUIVO__.xlsx',
      ok: (n) => 'Excel baixado: ' + n },
    email: { url: '/api/email', gerando: 'Preparando o e-mail…', erro: 'Não foi possível preparar o e-mail.', padrao: '__NOME_ARQUIVO__.eml',
      ok: (n) => 'E-mail pronto: abra o arquivo ' + n + ' (na barra de downloads) para ele abrir no seu programa de e-mail, com a planilha anexa.' }
  };
  async function baixarArquivo(tipo, btn, status) {
    const T = TIPOS_ARQ[tipo];
    if (btn) btn.disabled = true;
    if (status) { status.className = 'status'; status.textContent = T.gerando; }
    try {
      const r = await fetch(T.url, { headers: { 'Authorization': 'Bearer ' + token } });
      if (!r.ok) {
        let msg = T.erro;
        try { const d = await r.json(); if (r.status === 401 && d.sessao === false) { voltarAoPortao(); return; } msg = d.mensagem || msg; } catch (e) { /* ignora */ }
        if (status) { status.className = 'status erro'; status.textContent = msg; }
        return;
      }
      const blob = await r.blob();
      const m = /filename="([^"]+)"/.exec(r.headers.get('Content-Disposition') || '');
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = m ? m[1] : T.padrao;
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(a.href), 30000);
      if (status) status.textContent = T.ok(a.download);
    } catch (e) {
      if (status) { status.className = 'status erro'; status.textContent = T.erro; }
    } finally {
      if (btn) btn.disabled = false;
    }
  }
  function baixarExcel(btn, status) { return baixarArquivo('excel', btn, status); }

  /* ---------- compartilhar: menu do sistema (Windows/celular) ou o e-mail padrão ---------- */
  const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
  function baixarBlob(blob, nome) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = nome;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 30000);
  }
  // pergunta + resposta em texto simples (sem ** e com a tabela em linhas)
  function textoParaEnvio(pergunta, resposta) {
    const linhas = String(resposta || '').replace(/\*\*(.+?)\*\*/g, '$1').split('\n')
      .filter((l) => !/^\|[\s|:-]+\|?$/.test(l.trim()))
      .map((l) => (l.trim().startsWith('|') ? l.trim().replace(/^\|\s*/, '').replace(/\s*\|$/, '').split(/\s*\|\s*/).join('  |  ') : l));
    return 'Pergunta: ' + pergunta + '\n\nResposta:\n' + linhas.join('\n');
  }
  // e-mail com a pergunta e a resposta NO CORPO (sem anexo): abre o programa de e-mail padrão na hora,
  // no computador ou no celular. O link de e-mail (mailto) tem limite de tamanho: listas longas são cortadas.
  const LIMITE_MAILTO = 1900; // caracteres da parte do corpo ja codificada (seguro para Windows e celular)
  function linhasParaEnvio(resposta) {
    const out = [];
    const linhas = String(resposta || '').replace(/\*\*(.+?)\*\*/g, '$1').split('\n');
    let cab = null;
    for (const l of linhas) {
      const t = l.trim();
      if (/^\|[\s|:-]+\|?$/.test(t)) continue; // linha |---|---|
      if (t.startsWith('|')) {
        const c = t.replace(/^\|\s*/, '').replace(/\s*\|$/, '').split(/\s*\|\s*/);
        if (!cab) { cab = c; out.push({ texto: c.join(' | '), cabecalho: true }); continue; }
        // • Produto A: 12,5 | Produzido: 100 | % retrabalho: 12,5%
        const resto = c.slice(1).map((v, i) => (i > 0 && cab[i + 1] ? cab[i + 1] + ': ' : '') + v).join(' | ');
        out.push({ texto: '• ' + c[0] + ': ' + resto, item: true });
      } else {
        cab = null;
        out.push({ texto: l });
      }
    }
    return out;
  }
  // texto para compartilhar (e-mail, WhatsApp ou outros apps), cortando a lista do fim para o começo até caber no limite
  const LIMITE_WHATS = 6000; // o link do WhatsApp aceita textos bem maiores que o do e-mail
  function textoCompartilhar(pergunta, resposta, limite, whats) {
    // no WhatsApp, **negrito** vira *negrito*; no e-mail fica texto simples
    const partes = linhasParaEnvio(whats ? String(resposta || '').replace(/\*\*(.+?)\*\*/g, '*$1*') : resposta);
    const fimLinha = whats ? '\n' : '\r\n';
    const montar = (ps, cortadas) => {
      const linhas = ps.map((p) => p.texto);
      if (cortadas) {
        // o aviso entra logo depois do ultimo item que ficou na lista
        let fim = -1;
        ps.forEach((p, k) => { if (p.item) fim = k; });
        linhas.splice(fim + 1, 0, '… e mais ' + cortadas + (cortadas === 1 ? ' linha' : ' linhas') + ' (lista completa no __NOME_SISTEMA__, em "Baixar dados").');
      }
      const cab = whats ? ['*Pergunta:* ' + pergunta, '', '*Resposta:*'] : ['Pergunta: ' + pergunta, '', 'Resposta:'];
      return cab.concat(linhas, ['', whats ? '_Enviado pelo __NOME_SISTEMA__._' : 'Enviado pelo __NOME_SISTEMA__.']).join(fimLinha);
    };
    let cortadas = 0;
    let corpo = montar(partes, 0);
    while (limite && encodeURIComponent(corpo).length > limite) {
      let i = -1;
      for (let k = partes.length - 1; k >= 0; k--) if (partes[k].item) { i = k; break; }
      if (i < 0) { corpo = corpo.slice(0, 600) + '…'; break; } // sem lista para cortar: texto curto
      partes.splice(i, 1);
      cortadas++;
      corpo = montar(partes, cortadas);
    }
    return { corpo, cortadas, assunto: '__NOME_SISTEMA__ - ' + pergunta };
  }
  // registra no historico, sem esperar a resposta do servidor
  function registrarEnvio(origem, assunto, cortadas) {
    try {
      fetch('/api/registro', { method: 'POST', keepalive: true,
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify({ origem, texto: assunto, mensagem: cortadas ? cortadas + ' linhas cortadas' : 'completo' }) });
    } catch (e) { /* ignora */ }
  }
  // falha do compartilhamento: vai para o log do servidor (o motivo só aparece no navegador)
  function registrarErroEnvio(assunto, erro) {
    try {
      fetch('/api/registro', { method: 'POST', keepalive: true,
        headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
        body: JSON.stringify({ origem: 'compartilhar', texto: assunto, erro: String(erro).slice(0, 200) }) });
    } catch (e) { /* ignora */ }
  }
  function avisoCorte(cortadas) {
    return cortadas ? ' A lista foi encurtada (' + cortadas + ' linhas ficaram de fora); use "Baixar dados" para a lista completa.' : '';
  }
  // destinos do menu Compartilhar (g = gráfico da resposta, se houver: a imagem vai junto)
  const DESTINOS = {
    email(status, pergunta, resposta, g) {
      const t = textoCompartilhar(pergunta, resposta, LIMITE_MAILTO, false);
      registrarEnvio('email', t.assunto, t.cortadas);
      window.location.href = 'mailto:?subject=' + encodeURIComponent(t.assunto) + '&body=' + encodeURIComponent(t.corpo);
      status.className = 'status';
      status.textContent = 'Abri o seu programa de e-mail com a pergunta e a resposta.' + avisoCorte(t.cortadas) +
        (g ? '' : ' Se nada abriu, confira se há um programa de e-mail padrão configurado.');
      if (g) entregarImagem(g, pergunta, ' no e-mail.').then((txt) => { status.textContent += txt; });
    },
    whatsapp(status, pergunta, resposta, g) {
      const t = textoCompartilhar(pergunta, resposta, LIMITE_WHATS, true);
      registrarEnvio('whatsapp', t.assunto, t.cortadas);
      // link oficial: abre o WhatsApp (app, WhatsApp Web ou celular) com o texto pronto; a pessoa escolhe o contato
      window.open('https://wa.me/?text=' + encodeURIComponent(t.corpo), '_blank', 'noopener');
      status.className = 'status';
      status.textContent = 'Abri o WhatsApp com a pergunta e a resposta: escolha o contato ou grupo e envie.' + avisoCorte(t.cortadas);
      if (g) entregarImagem(g, pergunta, ' na conversa.').then((txt) => { status.textContent += txt; });
    },
    // menu de compartilhar do aparelho (https), com o GRÁFICO (imagem) e a PLANILHA (Excel) anexados + o texto.
    // No celular: escolher WhatsApp, Gmail, Outlook... Os anexos vêm prontos de quando o menu abriu (anexos()).
    // O navegador só abre o menu logo depois de um toque: se os anexos demorarem, pede um novo toque.
    async outros(status, pergunta, resposta, g, anexos) {
      const t = textoCompartilhar(pergunta, resposta, 0, false);
      const avisar = (txt, erro) => { status.className = 'status' + (erro ? ' erro' : ''); status.textContent = txt; };
      const botaoNoStatus = (rotulo, acao) => {
        const b2 = document.createElement('button');
        b2.type = 'button'; b2.className = 'btn-sec'; b2.textContent = rotulo;
        b2.addEventListener('click', () => { b2.remove(); acao(); });
        status.appendChild(b2);
      };
      const novoToque = (a) => { avisar('Anexos prontos. '); botaoNoStatus('Compartilhar agora', () => enviar(a, true, true)); };
      const semPlanilha = (a) => ({ arquivos: a.arquivos.filter((f) => f.type !== XLSX_MIME),
        recusados: a.recusados.concat(a.arquivos.filter((f) => f.type === XLSX_MIME)) });
      // deToque = chamado por um toque novo ("Compartilhar agora" etc.): aí uma recusa não é mais falta de toque
      const enviar = (a, comTexto, deToque) => {
        const dados = comTexto ? { title: t.assunto, text: t.assunto + '\n\n' + t.corpo } : { title: t.assunto };
        if (a && a.arquivos.length) dados.files = a.arquivos;
        const oQue = dados.files ? dados.files.map((f) => (f.type === 'image/png' ? 'o gráfico' : 'a planilha')).join(' e ') : '';
        let p;
        try { p = navigator.share(dados); } catch (e) { p = Promise.reject(e); }
        avisar('Abrindo o compartilhamento…');
        p.then(() => {
          registrarEnvio('compartilhar', t.assunto, 0);
          avisar('Compartilhado' + (oQue ? ' com ' + oQue : '') + '.' +
            (a && a.recusados.length ? ' Este aparelho não aceita enviar a planilha por aqui: use "Baixar dados".' : ''));
        }).catch((e) => {
          const nome = (e && e.name) || 'erro';
          if (nome === 'AbortError') { avisar('Compartilhamento cancelado.'); return; } // fechou o menu sem escolher
          registrarErroEnvio(t.assunto, nome + ': ' + ((e && e.message) || '') + ' | ' + (oQue || 'só texto') + (deToque ? ' | novo toque' : ''));
          if (nome === 'NotAllowedError' && !deToque) { novoToque(a); return; } // passou do tempo do toque
          // Chrome/Edge recusam alguns tipos de arquivo (ex.: Excel): oferece mandar sem a planilha
          if (dados.files && dados.files.some((f) => f.type === XLSX_MIME)) {
            const b = semPlanilha(a);
            avisar('O aparelho recusou enviar a planilha por aqui (' + nome + '). ', true);
            botaoNoStatus(b.arquivos.length ? 'Compartilhar só com o gráfico' : 'Compartilhar só o texto', () => enviar(b, comTexto, true));
            return;
          }
          // alguns aparelhos recusam texto + arquivos juntos: oferece mandar só os anexos
          if (dados.files && comTexto) {
            avisar('O aparelho recusou o envio com texto e anexos (' + nome + '). ', true);
            botaoNoStatus('Enviar só os anexos', () => enviar(a, false, true));
            return;
          }
          avisar('Não foi possível compartilhar (' + nome + (e && e.message ? ': ' + e.message : '') + ').', true);
        });
      };
      avisar('Preparando os anexos…');
      // espera os anexos no máximo 3 s; depois disso o navegador já não abre o menu sem um novo toque
      let a = null;
      let demorou = false;
      try {
        a = await Promise.race([anexos(), new Promise((ok) => setTimeout(() => { demorou = true; ok(null); }, 3000))]);
      } catch (e) { a = null; }
      if (demorou) {
        try { a = await anexos(); } catch (e) { a = null; }
        novoToque(a);
        return;
      }
      enviar(a, true);
    }
  };
  // anexos do "Enviar com anexos": imagem do gráfico (se houver) e a planilha (Excel) da consulta.
  // Preparados quando o menu Compartilhar abre; só entram os tipos que o aparelho aceita compartilhar.
  async function prepararAnexos(pergunta, g) {
    const arquivos = [];
    if (g && g.itens && g.itens.length) {
      try { arquivos.push(new File([await imagemDoGrafico(g, pergunta)], nomeImagem(), { type: 'image/png' })); } catch (e) { /* sem imagem */ }
    }
    try {
      const r = await fetch('/api/exportar?via=anexo', { headers: { 'Authorization': 'Bearer ' + token } });
      if (r.ok) {
        const blob = await r.blob();
        const m = /filename="([^"]+)"/.exec(r.headers.get('Content-Disposition') || '');
        arquivos.push(new File([blob], m ? m[1] : '__NOME_ARQUIVO__.xlsx', { type: XLSX_MIME }));
      }
    } catch (e) { /* sem planilha */ }
    // Chrome/Edge (Windows, Android, Mac) só compartilham imagens, PDF, texto, áudio e vídeo: o canShare diz que
    // aceita o .xlsx, mas o navigator.share recusa com NotAllowedError. No iPhone (inclusive Chrome/Edge de lá) vai.
    const ua = navigator.userAgent;
    const chromium = /Chrome\/|Chromium\/|Edg\//.test(ua) && !/CriOS|EdgiOS|FxiOS/.test(ua);
    const aceitos = arquivos.filter((f) => !(chromium && f.type === XLSX_MIME) &&
      navigator.canShare && navigator.canShare({ files: [f] }));
    return { arquivos: aceitos, recusados: arquivos.filter((f) => !aceitos.includes(f)) };
  }

