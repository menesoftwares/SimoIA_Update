/*@parte tela principal: enviar a pergunta, espera e resposta. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  async function enviarPergunta(texto, consulta, assunto, extra) {
    const corpo = consulta ? { consulta } : (assunto ? { pergunta: texto, assunto } : { pergunta: texto });
    if (consulta && extra && extra.sugestao) { corpo.sugestao = extra.sugestao; corpo.pergunta = extra.pergunta || ''; }
    if (extra && extra.abrangencia) corpo.abrangencia = extra.abrangencia;
    const enviadaEm = Date.now(); // o contador "(N s)" conta desde o envio da pergunta
    const r = await fetch('/api/perguntar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + token },
      body: JSON.stringify(corpo)
    });
    let dados = await r.json();
    if (r.status === 401 && dados.sessao === false) voltarAoPortao();
    // consulta demorada (mais de 25 s): o servidor responde "aguardando" e a tela busca o resultado a cada 2 s
    if (r.status === 202 && dados.aguardando && dados.tarefa) dados = await esperarTarefa(dados.tarefa, enviadaEm);
    return dados;
  }
  // busca o resultado no servidor a cada 2 s; o contador na tela anda de 1 em 1 s, com relógio próprio
  async function esperarTarefa(id, enviadaEm) {
    const inicio = Date.now();
    const mostrar = () => {
      const seg = Math.floor((Date.now() - enviadaEm) / 1000);
      resultado.innerHTML = '<p>Buscando a resposta… ainda consultando o banco (' + seg + ' s). Esta busca é mais demorada; aguarde.</p>';
    };
    mostrar();
    const relogio = setInterval(mostrar, 1000);
    try {
      let falhas = 0;
      while (Date.now() - inicio < 9 * 60 * 1000) { // o servidor desiste em 8 min
        await new Promise((ok) => setTimeout(ok, 2000));
        try {
          const r = await fetch('/api/tarefa?id=' + encodeURIComponent(id), { headers: { 'Authorization': 'Bearer ' + token } });
          const d = await r.json();
          if (r.status === 401) { if (d.sessao === false) voltarAoPortao(); return d; }
          if (r.status === 200 && d.aguardando) { falhas = 0; continue; }
          return d;
        } catch (e) {
          if (++falhas >= 5) return { ok: false, mensagem: 'Não foi possível falar com o servidor enquanto a consulta rodava. Tente novamente em instantes.' };
        }
      }
      return { ok: false, mensagem: 'A consulta está demorando demais (mais de 9 minutos). Tente um período menor.' };
    } finally {
      clearInterval(relogio);
    }
  }

  // limpa o que ficou da sessão anterior: pergunta digitada, resposta, menus e quadros abertos
  function limparTela() {
    campo.value = '';
    ajustarAltura();
    atualizarBotao();
    titulo.textContent = '';
    resultado.className = 'resultado';
    resultado.innerHTML = '';
    secao.hidden = true;
    document.querySelectorAll('.menu-comp').forEach((m) => { m.hidden = true; });
    document.querySelectorAll('[aria-expanded="true"]').forEach((b) => b.setAttribute('aria-expanded', 'false'));
    ['montar', 't-mais', 'm-mais', 'k-mais'].forEach((id) => { const d = document.getElementById(id); if (d) d.open = false; });
  }

  function voltarAoPortao(msg) {
    const tokenAntigo = token;
    token = '';
    try { sessionStorage.removeItem('token'); sessionStorage.removeItem('usuario'); } catch (e) { /* ignora */ }
    try { localStorage.removeItem('simoia_token'); localStorage.removeItem('simoia_usuario'); } catch (e) { /* ignora */ }
    limparTela();
    document.getElementById('app').hidden = true;
    document.getElementById('topo').hidden = true;
    document.getElementById('link-gestao').hidden = true;
    document.getElementById('btn-simulador').hidden = true;
    document.getElementById('btn-coletor').hidden = true;
    document.getElementById('rodape-sessao').hidden = true;
    document.getElementById('troca').hidden = true;
    document.body.classList.remove('trocando-senha');
    document.getElementById('portao').hidden = false;
    document.getElementById('senha').value = '';
    mostrarSenha(false);
    document.getElementById('bio-oferta').hidden = true;
    bioMostrarBotaoLogin();
    document.getElementById('conflito').hidden = true;
    erroPortao.textContent = msg || '';
    // sem o motivo em mãos: pergunta ao servidor se a sessão caiu por outro acesso, para mostrar o aviso
    if (!msg && tokenAntigo) {
      fetch('/api/sessao', { headers: { 'Authorization': 'Bearer ' + tokenAntigo } })
        .then((r) => r.json()).then((d) => { if (d && d.motivo === 'outro_acesso' && !token) erroPortao.textContent = d.mensagem; })
        .catch(() => { /* ignora */ });
    }
    document.getElementById('usuario').focus();
  }

  // assunto: relatório escolhido num botão de "Sobre qual relatório é a pergunta?"
  // rola a página, suavemente, até o quadro da resposta. sempre = true: ao perguntar; false: só se o começo
  // da resposta estiver fora da tela (a pessoa pode ter rolado enquanto esperava)
  function rolarParaResposta(sempre) {
    const r = secao.getBoundingClientRect();
    const visivel = r.top >= 0 && r.top < window.innerHeight * 0.6;
    if (!sempre && visivel) return;
    const semAnimacao = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    secao.scrollIntoView({ behavior: semAnimacao ? 'auto' : 'smooth', block: 'start' });
  }

  // extra: { sugestao, pergunta, titulo } quando a consulta vem de uma sugestão de costume
  async function perguntar(consulta, assunto, extra) {
    const texto = extra && extra.titulo ? extra.titulo : consulta ? 'Consulta montada' : campo.value.trim();
    if (!texto) return;
    botao.disabled = true;
    btnConsultar.disabled = true;
    titulo.textContent = texto;
    resultado.className = 'resultado';
    resultado.innerHTML = '<p>Buscando a resposta… (pode levar alguns segundos)</p>';
    secao.hidden = false;
    rolarParaResposta(true);
    try {
      const r = await enviarPergunta(texto, consulta, assunto, extra);
      resultado.className = 'resultado' + (r.ok ? '' : ' erro');
      resultado.innerHTML = '';
      const caixa = renderizar(r.mensagem || 'Sem resposta.');
      resultado.appendChild(caixa);
      if (r.grafico) inserirGrafico(caixa, r.grafico);
      if (r.mapa) inserirMapa(caixa, r.mapa);
      acoesResposta(caixa, r);
      if (r.consulta) preencherFormulario(r.consulta);
      rolarParaResposta(false); // a resposta chegou: se o começo dela saiu da tela, volta suavemente
    } catch (e) {
      resultado.className = 'resultado erro';
      resultado.innerHTML = '<p>Não foi possível buscar a resposta. Tente novamente em instantes.</p>';
    }
    atualizarBotao();
    btnConsultar.disabled = false;
  }

