/*@parte tela principal: notícias, painel Hoje e período. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- uma linha de notícias do mercado: as manchetes mais recentes se alternam; clicar abre /noticias ---------- */
  let noticiasDestaques = [];
  let noticiasPos = 0;
  let noticiasTimer = null;
  const haQuanto = (iso) => {
    const min = Math.round((Date.now() - Date.parse(iso)) / 60000);
    if (!isFinite(min)) return '';
    if (min < 60) return 'há ' + Math.max(1, min) + ' min';
    if (min < 48 * 60) return 'há ' + Math.round(min / 60) + ' h';
    return 'há ' + Math.round(min / 1440) + ' dias';
  };
  function mostrarManchete() {
    const el = document.getElementById('n-manchete');
    const n = noticiasDestaques[noticiasPos % noticiasDestaques.length];
    if (!n) return;
    el.style.opacity = 0;
    setTimeout(() => {
      el.innerHTML = '<strong>' + esc(n.rotulo) + ':</strong> ' + esc(n.titulo) + ' <small>· ' + esc(n.fonte || '') + (n.quando ? ' · ' + haQuanto(n.quando) : '') + '</small>';
      el.title = n.titulo;
      el.style.opacity = 1;
    }, 250);
  }
  async function atualizarNoticias() {
    if (!token) return;
    const card = document.getElementById('c-noticias');
    try {
      const r = await fetch('/api/noticias', { headers: { 'Authorization': 'Bearer ' + token } });
      if (r.status === 401) return;
      const d = await r.json();
      if (!d.ok || !d.destaques || !d.destaques.length) { if (!noticiasDestaques.length) card.hidden = true; return; }
      noticiasDestaques = d.destaques;
      noticiasPos = 0;
      card.hidden = false;
      mostrarManchete();
      if (!noticiasTimer) noticiasTimer = setInterval(() => { if (document.hidden || noticiasDestaques.length < 2) return; noticiasPos++; mostrarManchete(); }, 7000);
    } catch (e) { if (!noticiasDestaques.length) card.hidden = true; }
  }

  /* ---------- painel "Hoje": números do dia (peso, valores, produção), só dos BIs liberados ---------- */
  // curto = true (quadrinhos): moeda acima de R$ 10 mil sem centavos (o valor exato fica no title)
  function fmtDia(v, formato, curto) {
    if (v == null) return '—';
    if (formato === 'moeda') {
      if (curto && Math.abs(Number(v)) >= 10000) return 'R$\u00a0' + Math.round(Number(v)).toLocaleString('pt-BR');
      return fmtValor(v, 'moeda');
    }
    if (formato === 'percentual') return Number(v).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%';
    const n = Number(v) || 0;
    const t = n.toLocaleString('pt-BR', { maximumFractionDigits: Math.abs(n) >= 100 ? 0 : 2 });
    return formato === 'kg' ? t + ' kg' : t;
  }
  // gráfico de barras compacto do painel: colunas por grupo (roteiro, grupo...), uma barra por série.
  // Cada série na sua própria escala (kg e R$ juntos); tocar/clicar numa coluna mostra os valores exatos.
  const CORES_DIA = ['#2a78d6', '#1baf7a', '#eda100'];
  function graficoDia(g) {
    if (!g || !g.grupos || !g.grupos.length) return '<p class="cond">Sem movimento hoje.</p>';
    const maxes = g.series.map((_, k) => Math.max(...g.grupos.map((x) => Math.abs(x.valores[k]) || 0), 0) || 1);
    const varias = g.series.length > 1;
    const detalhe = (x) => x.rotulo + ': ' + g.series.map((s, k) => (varias ? s.rotulo + ' ' : '') + fmtDia(x.valores[k], s.formato)).join(' · ');
    return '<div class="mg"><div class="mg-tit">' + esc(g.titulo) + '</div>' +
      '<div class="mg-colunas' + (varias ? '' : ' uma') + '">' + g.grupos.map((x) =>
        '<button type="button" class="mg-col" title="' + esc(detalhe(x)) + '" data-det="' + esc(detalhe(x)) + '"><span class="mg-barras">' +
          g.series.map((s, k) => '<span class="mg-b" style="height:' + Math.max(2, Math.abs(x.valores[k]) / maxes[k] * 100).toFixed(1) + '%;background:' + CORES_DIA[k % 3] + '"></span>').join('') +
        '</span><span class="mg-rot">' + esc(x.rotulo) + '</span></button>').join('') + '</div>' +
      (varias ? '<div class="mg-leg">' + g.series.map((s, k) => '<span><i style="background:' + CORES_DIA[k % 3] + '"></i>' + esc(s.rotulo) + '</span>').join('') +
        '<span class="mg-obs">cada cor na sua escala</span></div>' : '') +
      '<div class="mg-det" aria-live="polite">Toque numa barra para ver os valores.</div></div>';
  }
  // clique numa coluna do gráfico do painel: mostra os valores exatos dela embaixo do gráfico
  document.addEventListener('click', (e) => {
    const col = e.target.closest && e.target.closest('.mg-col');
    if (!col) return;
    const mg = col.closest('.mg');
    mg.querySelectorAll('.mg-col').forEach((c) => c.classList.toggle('sel', c === col));
    mg.querySelector('.mg-det').textContent = col.dataset.det;
  });
  var painelDiaEspera = null; // nova tentativa enquanto o servidor calcula o 1o painel do dia
  var painelDiaEmCurso = 0; // carregamentos em andamento (clique, automatico, 1o calculo)
  var painelDiaCalculando = false; // servidor ainda fazendo o 1o calculo do dia
  // forcar = botao "atualizar agora": o servidor recalcula na hora (e espera o resultado)
  async function atualizarPainelDia(forcar) {
    if (!token) return;
    if (forcar && (painelDiaEmCurso || painelDiaCalculando)) return; // ja esta carregando: ignora o clique
    const card = document.getElementById('c-dia');
    const btn = document.getElementById('d-recarregar');
    painelDiaEmCurso++;
    btn.disabled = true; btn.classList.add('girando');
    if (forcar) document.getElementById('d-fonte').textContent = 'Atualizando os números do dia…';
    try {
      const r = await fetch('/api/painel-dia' + (forcar ? '?forcar=1' : ''), { headers: { 'Authorization': 'Bearer ' + token } });
      if (r.status === 401) return;
      const d = await r.json();
      if (!d.ok) { painelDiaCalculando = false; if (!card.hidden) document.getElementById('d-fonte').textContent = d.mensagem || ''; return; }
      if (!d.blocos || !d.blocos.length) { painelDiaCalculando = false; card.hidden = true; return; } // nenhum BI do painel liberado
      card.hidden = false;
      if (d.calculando) {
        // primeiro cálculo do dia no banco: mostra os blocos e pergunta de novo em 8 s
        document.getElementById('d-blocos').innerHTML = d.blocos.map((b) => '<div class="dia-bloco"><h3>' + esc(b.titulo) + '</h3><p class="cond">Calculando os números do dia…</p></div>').join('');
        clearTimeout(painelDiaEspera);
        painelDiaEspera = setTimeout(() => atualizarPainelDia(), 8000);
        painelDiaCalculando = true; // o botao continua bloqueado ate os numeros chegarem
        return;
      }
      painelDiaCalculando = false;
      const DIAS = ['Dom.', 'Seg.', 'Ter.', 'Qua.', 'Qui.', 'Sex.', 'Sáb.'];
      const dia = new Date(d.data + 'T12:00:00');
      document.getElementById('d-titulo').textContent = (d.teste ? 'Dia ' : 'Hoje - ') + DIAS[dia.getDay()] + ' ' + dataBr(d.data) + (d.teste ? ' (data de teste)' : '');
      document.getElementById('d-blocos').innerHTML = d.blocos.map((b) => '<div class="dia-bloco"><h3>' + esc(b.titulo) + '</h3>' +
        (b.erro ? '<p class="cond">Não foi possível calcular agora.</p>' :
          (b.grafico ? graficoDia(b.grafico) : '') +
          '<div class="dia-kpis">' + b.itens.map((it) => '<div class="kpi"><div class="rot">' + esc(it.rotulo) +
            (it.detalhe ? ' <span class="det">(' + esc(it.detalhe) + ')</span>' : '') + '</div>' +
            '<div class="val" title="' + esc(fmtDia(it.valor, it.formato)) + '">' + esc(fmtDia(it.valor, it.formato, true)) + '</div></div>').join('') + '</div>') + '</div>').join('');
      document.getElementById('d-fonte').textContent = 'Atualizado em ' + d.atualizado + ' · o servidor atualiza a cada 10 min (ou clique em ↻) · vendas pela data do documento; produção pelo lançamento do apontamento.';
    } catch (e) {
      painelDiaCalculando = false;
      if (card.hidden) return;
      document.getElementById('d-fonte').textContent = 'Não foi possível atualizar os números do dia agora.';
    } finally {
      painelDiaEmCurso = Math.max(0, painelDiaEmCurso - 1);
      if (!painelDiaEmCurso && !painelDiaCalculando) { btn.disabled = false; btn.classList.remove('girando'); }
    }
  }
  document.getElementById('d-recarregar').addEventListener('click', () => atualizarPainelDia(true));

  async function buscarPeriodo() {
    const res = document.getElementById('m-res');
    const moeda = document.getElementById('m-moeda').value;
    const de = document.getElementById('m-de').value;
    const ate = document.getElementById('m-ate').value;
    if (!de || !ate) { res.innerHTML = '<p class="msg-erro">Informe as duas datas.</p>'; return; }
    const btn = document.getElementById('m-buscar');
    btn.disabled = true;
    res.innerHTML = '<p>Buscando…</p>';
    try {
      const r = await fetch('/api/cambio?moeda=' + encodeURIComponent(moeda) + '&de=' + encodeURIComponent(de) + '&ate=' + encodeURIComponent(ate),
        { headers: { 'Authorization': 'Bearer ' + token } });
      const d = await r.json();
      if (r.status === 401 && d.sessao === false) { voltarAoPortao(); return; }
      if (!d.ok) { res.innerHTML = '<p class="msg-erro">' + esc(d.mensagem || 'Erro.') + '</p>'; return; }
      if (!d.cotacoes.length) { res.innerHTML = '<p>Sem cotações nesse período (fins de semana e feriados não têm PTAX).</p>'; return; }
      const s = d.resumo;
      const cls = s.variacao > 0 ? 'sobe' : s.variacao < 0 ? 'desce' : '';
      res.innerHTML = '<p><strong>' + esc(d.nome) + '</strong>, ' + dataBr(d.de) + ' a ' + dataBr(d.ate) + ' (' + d.cotacoes.length + ' dias úteis): ' +
        'média R$ ' + num(s.media, 4) + ' · mín. R$ ' + num(s.minimo, 4) + ' · máx. R$ ' + num(s.maximo, 4) +
        ' · variação <span class="' + cls + '">' + (s.variacao > 0 ? '+' : '') + num(s.variacao, 2) + '%</span></p>' +
        '<div class="tabela"><table><tr><th>Data</th><th>Compra</th><th>Venda</th></tr>' +
        d.cotacoes.slice().reverse().map((x) => '<tr><td>' + dataBr(x.data) + '</td><td>' + num(x.compra, 4) + '</td><td>' + num(x.venda, 4) + '</td></tr>').join('') +
        '</table></div>';
    } catch (e) {
      res.innerHTML = '<p class="msg-erro">Não foi possível buscar as cotações agora.</p>';
    } finally {
      btn.disabled = false;
    }
  }
  document.getElementById('m-buscar').addEventListener('click', buscarPeriodo);

  campo.addEventListener('input', () => { ajustarAltura(); atualizarBotao(); });
  campo.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); perguntar(); }
  });
  botao.addEventListener('click', () => perguntar());

