/*@parte tela principal: últimas perguntas, voz, app instalável e tema. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- últimas perguntas do usuário (botão de relógio dentro da caixa de pergunta) ---------- */
  (function () {
    const btnHist = document.getElementById('btn-historico');
    const menuHist = document.getElementById('menu-historico');
    const quando = (dh) => { // '2026-10-11 15:07:33' -> '11/10 15:07'
      const m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})/.exec(String(dh || ''));
      return m ? m[3] + '/' + m[2] + ' ' + m[4] + ':' + m[5] : '';
    };
    const fechar = () => { menuHist.hidden = true; btnHist.setAttribute('aria-expanded', 'false'); };
    async function abrir() {
      menuHist.innerHTML = '<div class="hist-vazio">Carregando…</div>';
      menuHist.hidden = false; btnHist.setAttribute('aria-expanded', 'true');
      try {
        const r = await fetch('/api/historico', { headers: { 'Authorization': 'Bearer ' + token } });
        const d = await r.json();
        if (r.status === 401 && d.sessao === false) { fechar(); voltarAoPortao(); return; }
        const lista = d.perguntas || [];
        menuHist.innerHTML = '';
        if (!lista.length) { menuHist.innerHTML = '<div class="hist-vazio">Você ainda não fez perguntas.</div>'; return; }
        const tit = document.createElement('div');
        tit.className = 'hist-titulo'; tit.textContent = 'Últimas perguntas';
        menuHist.appendChild(tit);
        lista.forEach((p) => {
          const o = document.createElement('button');
          o.type = 'button'; o.setAttribute('role', 'menuitem'); o.title = p.texto;
          o.innerHTML = '<span class="hist-texto">' + esc(p.texto) + '</span><span class="hist-data">' + esc(quando(p.data_hora)) + '</span>';
          // escolher só coloca a pergunta no campo (cursor no fim), para a pessoa completar antes de perguntar
          o.addEventListener('click', () => {
            fechar();
            campo.value = p.texto; ajustarAltura(); atualizarBotao();
            campo.focus();
            campo.setSelectionRange(campo.value.length, campo.value.length);
          });
          menuHist.appendChild(o);
        });
        const primeiro = menuHist.querySelector('button');
        if (primeiro) primeiro.focus();
      } catch (e) {
        menuHist.innerHTML = '<div class="hist-vazio">Não foi possível carregar as últimas perguntas.</div>';
      }
    }
    btnHist.addEventListener('click', (e) => { e.stopPropagation(); if (menuHist.hidden) abrir(); else fechar(); });
    menuHist.addEventListener('keydown', (e) => { if (e.key === 'Escape') { fechar(); btnHist.focus(); } });
    document.addEventListener('click', (e) => { if (!btnHist.parentNode.contains(e.target)) fechar(); });
  })();

  /* ---------- comando de voz: fala a pergunta e o texto vai para o campo (não pesquisa sozinho) ---------- */
  (function () {
    const Reconhecer = window.SpeechRecognition || window.webkitSpeechRecognition;
    const btn = document.getElementById('btn-voz');
    const aviso = document.getElementById('voz-aviso');
    if (!Reconhecer || !window.isSecureContext) return; // navegador sem reconhecimento de fala: o botão não aparece
    btn.hidden = false;
    let rec = null;
    const mostrar = (txt) => { aviso.textContent = txt; aviso.hidden = !txt; };
    const ERROS = {
      'not-allowed': 'Permita o uso do microfone para falar a pergunta (no cadeado ao lado do endereço).',
      'service-not-allowed': 'Permita o uso do microfone para falar a pergunta (no cadeado ao lado do endereço).',
      'no-speech': 'Não ouvi nada. Toque no microfone e fale a pergunta.',
      'audio-capture': 'Nenhum microfone encontrado neste aparelho.',
      'network': 'Sem conexão com o serviço de voz do navegador. Tente de novo.'
    };
    btn.addEventListener('click', () => {
      if (rec) { try { rec.stop(); } catch (e) { /* ignora */ } return; } // tocar de novo encerra
      mostrar('');
      rec = new Reconhecer();
      rec.lang = 'pt-BR';
      rec.interimResults = true; // o texto aparece enquanto a pessoa fala
      rec.continuous = false;
      rec.maxAlternatives = 1;
      const inicio = campo.value.trim() ? campo.value.trim() + ' ' : ''; // complementa o que já estava escrito
      rec.onresult = (e) => {
        let fala = '';
        for (let i = 0; i < e.results.length; i++) fala += e.results[i][0].transcript;
        campo.value = inicio + fala.trim();
        ajustarAltura(); atualizarBotao();
      };
      rec.onerror = (e) => { if (e.error !== 'aborted') mostrar(ERROS[e.error] || 'Não foi possível usar o microfone (' + e.error + ').'); };
      rec.onend = () => {
        rec = null;
        btn.classList.remove('ouvindo'); btn.setAttribute('aria-pressed', 'false'); btn.title = 'Falar a pergunta';
        campo.focus();
        campo.setSelectionRange(campo.value.length, campo.value.length);
      };
      try {
        rec.start();
        btn.classList.add('ouvindo'); btn.setAttribute('aria-pressed', 'true'); btn.title = 'Ouvindo… toque para parar';
      } catch (e) {
        rec = null;
        mostrar('Não foi possível iniciar o microfone.');
      }
    });
  })();

  /* ---------- app instalável (PWA): só o service worker; a instalação é oferecida pelo próprio navegador ---------- */
  if ('serviceWorker' in navigator && window.isSecureContext) {
    navigator.serviceWorker.register('/sw.js').catch(() => { /* sem service worker: o site funciona igual */ });
  }

  /* ---------- tema: automático (segue o sistema), claro ou escuro; fica guardado neste navegador ---------- */
  (function () {
    const botoesTema = document.querySelectorAll('#tema button');
    function aplicarTema(t) {
      if (t !== 'claro' && t !== 'escuro') t = 'auto';
      if (t === 'auto') document.documentElement.removeAttribute('data-tema');
      else document.documentElement.setAttribute('data-tema', t);
      try { if (t === 'auto') localStorage.removeItem('tema'); else localStorage.setItem('tema', t); } catch (e) { /* ignora */ }
      botoesTema.forEach((b) => b.setAttribute('aria-pressed', String(b.dataset.tema === t)));
    }
    let salvo = 'auto';
    try { salvo = localStorage.getItem('tema') || 'auto'; } catch (e) { /* ignora */ }
    aplicarTema(salvo);
    botoesTema.forEach((b) => b.addEventListener('click', () => aplicarTema(b.dataset.tema)));
  })();

