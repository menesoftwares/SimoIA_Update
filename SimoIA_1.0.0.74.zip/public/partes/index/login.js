/*@parte tela principal: login, outro aparelho e esqueci a senha. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  const portao = document.getElementById('portao');
  const app = document.getElementById('app');
  const campoUsuario = document.getElementById('usuario');
  const campoSenha = document.getElementById('senha');
  const entrar = document.getElementById('entrar');
  const quem = document.getElementById('quem');
  const erroPortao = document.getElementById('portao-erro');

  // Usuário e senha são conferidos no servidor; o navegador só guarda o token da sessão.
  // identifica este navegador/aparelho (fica guardado nele): o mesmo aparelho não conta como "outro acesso"
  function idDispositivo() {
    try {
      let d = localStorage.getItem('dispositivo');
      if (!d) {
        d = (Date.now().toString(36) + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2)).slice(0, 40);
        localStorage.setItem('dispositivo', d);
      }
      return d;
    } catch (e) { return ''; }
  }

  // já conectado em outro equipamento: mostra qual e pergunta SIM / NÃO
  function mostrarConflito(d) {
    const s = d.sessao || {};
    document.getElementById('conflito-texto').textContent = 'Conexão aberta: ' + (s.aparelho || 'outro navegador') +
      (s.ip ? ' (IP ' + s.ip + ')' : '') + (s.desde ? ', desde ' + s.desde : '') + (s.ultimo_uso && s.ultimo_uso !== s.desde ? ', último uso ' + s.ultimo_uso : '') + '.';
    document.getElementById('conflito').hidden = false;
    document.getElementById('conflito-sim').focus();
  }
  // login certo (senha ou digital/rosto): guarda o token e abre o app com a tela limpa
  function entrou(d, usuarioTexto) {
    token = d.token;
    try { sessionStorage.setItem('token', token); sessionStorage.setItem('usuario', usuarioTexto || d.usuario || ''); } catch (e) { /* ignora */ }
    // so guarda no aparelho se o servidor aceitou o "manter conectado" (o desenv sempre entra com senha)
    try {
      if (d.manter) { localStorage.setItem('simoia_token', token); localStorage.setItem('simoia_usuario', usuarioTexto || d.usuario || ''); }
      else { localStorage.removeItem('simoia_token'); localStorage.removeItem('simoia_usuario'); }
    } catch (e) { /* ignora */ }
    // usuario so do Simulador ou so do Coletor (tela padrao na Gestao): depois do login vai direto para ele
    if (d.tela_inicial === 'simulador' || d.tela_inicial === 'coletor' || d.tela_inicial === 'coletor_rastro') { location.replace(d.tela_inicial === 'simulador' ? '/simulador' : '/coletor'); return; }
    limparTela(); // novo login sempre começa com a tela limpa
    campoSenha.value = '';
    quem.textContent = 'Olá, ' + (d.nome || '');
    portao.hidden = true;
    app.hidden = false;
    document.getElementById('topo').hidden = false;
    carregarOpcoes();
    // a home abre sempre no começo da página (dono, 02/11/2026): sem foco automático no campo da IA
    window.scrollTo(0, 0);
  }
  let ultimoMetodo = 'senha'; // o "Sim, entrar aqui" do conflito repete o mesmo jeito de entrar

  async function tentarEntrar(ev, confirmar) {
    if (ev) ev.preventDefault();
    ultimoMetodo = 'senha';
    if (!campoUsuario.value.trim() || !campoSenha.value) { erroPortao.textContent = 'Preencha o usuário (ou e-mail) e a senha.'; return; }
    entrar.disabled = true;
    erroPortao.textContent = '';
    document.getElementById('conflito').hidden = true;
    try {
      const r = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ usuario: campoUsuario.value.trim(), senha: campoSenha.value, dispositivo: idDispositivo(), confirmar: !!confirmar, manter: manterMarcado() })
      });
      const d = await r.json();
      if (r.status === 409 && d.conflito) {
        mostrarConflito(d);
        entrar.disabled = false;
        return;
      }
      if (d.ok) {
        entrou(d, campoUsuario.value.trim());
      } else {
        erroPortao.textContent = d.mensagem || 'Usuário (ou e-mail) ou senha incorretos.';
        campoSenha.select();
      }
    } catch (e) {
      erroPortao.textContent = 'Não foi possível falar com o servidor.';
    }
    entrar.disabled = false;
  }

  /* ---------- "Esqueci minha senha" (dono, 13/11/2026) ---------- */
  const secEsqueci = document.getElementById('esqueci'), secNova = document.getElementById('nova-senha');
  function irAoLogin() {
    secEsqueci.hidden = true; secNova.hidden = true; portao.hidden = false;
    campoUsuario.focus();
  }
  document.getElementById('esqueci-abrir').addEventListener('click', () => {
    portao.hidden = true; secEsqueci.hidden = false;
    document.getElementById('esqueci-erro').textContent = ''; document.getElementById('esqueci-ok').textContent = '';
    const campo = document.getElementById('esqueci-login');
    if (!campo.value) campo.value = campoUsuario.value.trim();
    campo.focus();
  });
  document.getElementById('esqueci-voltar').addEventListener('click', irAoLogin);
  document.getElementById('ns-voltar').addEventListener('click', irAoLogin);
  document.getElementById('form-esqueci').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('esqueci-enviar'), erro = document.getElementById('esqueci-erro'), okMsg = document.getElementById('esqueci-ok');
    const login = document.getElementById('esqueci-login').value.trim();
    erro.textContent = ''; okMsg.textContent = '';
    if (!login) { erro.textContent = 'Informe o seu usuário ou e-mail.'; return; }
    btn.disabled = true; btn.textContent = 'Enviando…';
    try {
      const r = await fetch('/api/senha/esqueci', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ login }) });
      const d = await r.json().catch(() => ({}));
      if (d.ok) okMsg.textContent = d.mensagem; else erro.textContent = d.mensagem || 'Não foi possível enviar agora.';
    } catch (er) { erro.textContent = 'Não foi possível falar com o servidor.'; }
    btn.disabled = false; btn.textContent = 'Enviar link';
  });
  // link do e-mail: /#nova-senha=<token>. O token sai do endereco na hora (nao fica no historico do navegador)
  let novaSenhaToken = '';
  { const m = /^#nova-senha=([A-Za-z0-9_-]{20,100})$/.exec(location.hash || ''); if (m) novaSenhaToken = m[1]; }
  if (novaSenhaToken) {
    try { history.replaceState(null, '', location.pathname); } catch (e) { /* ignora */ }
    portao.hidden = true; app.hidden = true; secNova.hidden = false;
    const apoio = document.getElementById('ns-apoio'), form = document.getElementById('form-ns');
    fetch('/api/senha/redefinir', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: novaSenhaToken, conferir: true }) })
      .then((r) => r.json()).then((d) => {
        if (!d.ok) { apoio.textContent = d.mensagem || 'Este link não vale mais.'; return; }
        apoio.textContent = 'Usuário: ' + d.usuario + (d.nome && d.nome !== d.usuario ? ' (' + d.nome + ')' : '') + '. Escolha a nova senha, com pelo menos 4 caracteres.' +
          (d.bloqueado ? ' Ao salvar, o seu usuário também é desbloqueado.' : '');
        document.getElementById('ns-usuario').value = d.usuario;
        form.hidden = false;
        document.getElementById('ns-nova').focus();
      }).catch(() => { apoio.textContent = 'Não foi possível falar com o servidor. Abra o link de novo.'; });
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const nova = document.getElementById('ns-nova').value, rep = document.getElementById('ns-repete').value;
      const erro = document.getElementById('ns-erro'), okMsg = document.getElementById('ns-ok'), btn = document.getElementById('ns-salvar');
      erro.textContent = ''; okMsg.textContent = '';
      if (nova.length < 4) { erro.textContent = 'A nova senha precisa ter pelo menos 4 caracteres.'; return; }
      if (nova !== rep) { erro.textContent = 'As duas senhas não são iguais.'; document.getElementById('ns-repete').focus(); return; }
      btn.disabled = true;
      try {
        const r = await fetch('/api/senha/redefinir', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: novaSenhaToken, senha: nova }) });
        const d = await r.json().catch(() => ({}));
        if (!d.ok) { erro.textContent = d.mensagem || 'Não foi possível salvar.'; if (!d.invalido) btn.disabled = false; return; }
        // as sessoes desse usuario foram encerradas no servidor: este aparelho tambem entra de novo
        try { localStorage.removeItem('simoia_token'); } catch (er) { /* ignora */ }
        token = '';
        form.hidden = true;
        okMsg.textContent = d.mensagem;
        campoUsuario.value = d.usuario || '';
        document.getElementById('ns-voltar').textContent = 'Entrar agora';
        document.getElementById('ns-voltar').focus();
      } catch (er) { erro.textContent = 'Não foi possível falar com o servidor.'; btn.disabled = false; }
    });
  }

  if (token && !novaSenhaToken) { portao.hidden = true; app.hidden = false; document.getElementById('topo').hidden = false; carregarOpcoes(); }

  // olhinho da senha (pedido do dono): NAO e clicavel; mostra a senha enquanto o mouse esta sobre o olho
  // (no celular, enquanto o dedo segura o olho) e esconde ao sair; tambem esconde ao entrar e ao sair do app
  const verSenha = document.getElementById('ver-senha');
  // (function: pode ser chamada pelo voltarAoPortao antes desta linha rodar)
  function iconeOlho(aberto) {
    const OLHO_ABERTO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>';
    const OLHO_FECHADO = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10.6 5.1A10.8 10.8 0 0 1 12 5c6.4 0 10 7 10 7a17.6 17.6 0 0 1-3 3.9M6.6 6.6A17.4 17.4 0 0 0 2 12s3.6 7 10 7a10 10 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/><path d="M3 3l18 18"/></svg>';
    return aberto ? OLHO_ABERTO : OLHO_FECHADO;
  }
  function mostrarSenha(ver) {
    const campoSenha = document.getElementById('senha'), verSenha = document.getElementById('ver-senha');
    campoSenha.type = ver ? 'text' : 'password';
    verSenha.innerHTML = iconeOlho(!ver); // senha escondida = olho aberto; visível = olho riscado
  }
  mostrarSenha(false);
  // mouse: entrou no olho = mostra; saiu = esconde. Toque (celular): segurou = mostra; soltou = esconde.
  verSenha.addEventListener('pointerenter', (e) => { if (e.pointerType === 'mouse') mostrarSenha(true); });
  verSenha.addEventListener('pointerleave', () => mostrarSenha(false));
  verSenha.addEventListener('pointerdown', (e) => {
    e.preventDefault(); // nao e clicavel: o foco e o cursor continuam no campo de senha
    if (e.pointerType !== 'mouse') mostrarSenha(true);
  });
  ['pointerup', 'pointercancel'].forEach((ev) => verSenha.addEventListener(ev, (e) => { if (e.pointerType !== 'mouse') mostrarSenha(false); }));
  verSenha.addEventListener('click', (e) => e.preventDefault()); // o <label> em volta nao reage ao clique no olho
  verSenha.addEventListener('contextmenu', (e) => e.preventDefault()); // segurar o dedo nao abre menu no celular
  document.getElementById('form-login').addEventListener('submit', () => mostrarSenha(false));
  document.getElementById('form-login').addEventListener('submit', tentarEntrar);
  document.getElementById('conflito-sim').addEventListener('click', () => (ultimoMetodo === 'bio' ? entrarComBiometria(true) : tentarEntrar(null, true)));

