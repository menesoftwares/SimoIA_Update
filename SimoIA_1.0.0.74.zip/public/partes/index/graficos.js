/*@parte tela principal: gráficos e mapa das respostas. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  /* ---------- gráficos das respostas (sem bibliotecas externas) ---------- */
  function fmtValor(v, formato) {
    const n = Number(v);
    if (!isFinite(n)) return '-';
    if (formato === 'moeda') return n.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
    if (formato === 'inteiro') return Math.round(n).toLocaleString('pt-BR');
    if (formato === 'percentual') return n.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + '%';
    if (formato === 'percentual2') return n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%';
    if (formato === 'pontos') return (n > 0.004 ? '+' : '') + n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + ' p.p.';
    return n.toLocaleString('pt-BR', { maximumFractionDigits: 3 });
  }
  // valores curtos para o eixo: 1,2 mi / 350 mil
  function fmtCurto(v, formato) {
    const a = Math.abs(v);
    const pre = formato === 'moeda' ? 'R$ ' : '';
    const suf = formato === 'percentual' || formato === 'percentual2' ? '%' : formato === 'pontos' ? ' p.p.' : '';
    if (a >= 1e9) return pre + (v / 1e9).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' bi' + suf;
    if (a >= 1e6) return pre + (v / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mi' + suf;
    if (a >= 1e3) return pre + (v / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil' + suf;
    return pre + v.toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + suf;
  }
  const pctTxt = (v, t) => (t > 0 ? (v / t * 100).toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%' : '');
  const escA = (s) => esc(String(s)).replace(/"/g, '&quot;');

  // balão de dica: qualquer elemento com data-dica dentro de um gráfico
  const dica = document.createElement('div');
  dica.className = 'dica-graf'; dica.hidden = true; document.body.appendChild(dica);
  function mostrarDica(ev) {
    const alvo = ev.target.closest && ev.target.closest('[data-dica]');
    if (!alvo) { dica.hidden = true; return; }
    dica.textContent = alvo.getAttribute('data-dica');
    dica.hidden = false;
    const x = (ev.touches ? ev.touches[0].clientX : ev.clientX);
    const y = (ev.touches ? ev.touches[0].clientY : ev.clientY);
    const w = dica.offsetWidth;
    dica.style.left = Math.max(8, Math.min(x + 14, window.innerWidth - w - 8)) + 'px';
    dica.style.top = (y + 16) + 'px';
  }
  document.addEventListener('mousemove', (ev) => { if (!dica.hidden || (ev.target.closest && ev.target.closest('.grafico'))) mostrarDica(ev); });
  document.addEventListener('touchstart', mostrarDica, { passive: true });
  window.addEventListener('scroll', () => { dica.hidden = true; }, { passive: true });

  function graficoBarras(g) {
    const max = Math.max(...g.itens.map((x) => Math.abs(x.valor)), 0) || 1;
    return '<div class="barras">' + g.itens.map((x) => {
      const d = escA(x.rotulo + ': ' + fmtValor(x.valor, g.formato) + (g.total > 0 ? ' (' + pctTxt(x.valor, g.total) + ' do total)' : ''));
      return '<span class="rot" title="' + escA(x.rotulo) + '">' + esc(x.rotulo) + '</span>' +
        '<span class="trilha" data-dica="' + d + '"><span class="barra' + (x.valor < 0 ? ' neg' : '') + '" style="width:' + (Math.abs(x.valor) / max * 100).toFixed(2) + '%"></span></span>' +
        '<span class="val">' + fmtValor(x.valor, g.formato) + (g.total > 0 ? '<small>' + pctTxt(x.valor, g.total) + '</small>' : '') + '</span>';
    }).join('') + '</div>';
  }

  // comparativo de anos (dono, 27/11/2026): um bloco de barras por medida, com a variação do último ano.
  // serie 1 = último ano, 2 = anos anteriores, 3 = ano anterior no mesmo período (mais clara)
  function graficoComparativo(g) {
    return '<div class="comparativo">' + g.grupos.map((b) => {
      const max = Math.max(...b.itens.map((x) => Math.abs(x.valor)), 0) || 1;
      const v = b.variacao;
      const cls = v == null ? '' : v > 0.04 ? ' sobe' : v < -0.04 ? ' desce' : '';
      return '<div class="comp-bloco"><div class="comp-cab"><span class="comp-titulo">' + esc(b.titulo) + '</span>' +
        '<span class="comp-var' + cls + '">' + (v == null ? '' : (v > 0.04 ? '▲ ' : v < -0.04 ? '▼ ' : '')) + esc(b.texto) + '</span></div>' +
        '<div class="barras">' + b.itens.map((x) => {
          const d = escA(x.rotulo + ': ' + fmtValor(x.valor, b.formato));
          return '<span class="rot" title="' + escA(x.rotulo) + '">' + esc(x.rotulo) + '</span>' +
            '<span class="trilha" data-dica="' + d + '"><span class="barra s' + (x.serie || 1) + '" style="width:' + (Math.abs(x.valor) / max * 100).toFixed(2) + '%"></span></span>' +
            '<span class="val">' + fmtValor(x.valor, b.formato) + '</span>';
        }).join('') + '</div></div>';
    }).join('') + '</div>';
  }

  function graficoPizza(g) {
    const fatias = g.itens.map((x, i) => ({ rotulo: x.rotulo, valor: x.valor, cor: 'var(--serie-' + (i + 1) + ')' }));
    if (g.outros) fatias.push({ rotulo: 'Outros', valor: g.outros, cor: 'var(--outros)' });
    const tot = g.total || fatias.reduce((a, x) => a + x.valor, 0);
    const R = 96, r = 54, C = 100;
    let ang = -Math.PI / 2;
    const ponto = (raio, a) => (C + raio * Math.cos(a)).toFixed(2) + ' ' + (C + raio * Math.sin(a)).toFixed(2);
    const paths = fatias.map((f) => {
      const parte = tot > 0 ? f.valor / tot : 0;
      const a1 = ang, a2 = ang + Math.max(parte, 0) * 2 * Math.PI;
      ang = a2;
      const d = escA(f.rotulo + ': ' + fmtValor(f.valor, g.formato) + ' (' + pctTxt(f.valor, tot) + ')');
      if (parte >= 0.9999) {
        return '<path data-dica="' + d + '" fill="' + f.cor + '" fill-rule="evenodd" d="M' + ponto(R, 0) + ' A' + R + ' ' + R + ' 0 1 1 ' + ponto(R, Math.PI) + ' A' + R + ' ' + R + ' 0 1 1 ' + ponto(R, 0) +
          ' M' + ponto(r, 0) + ' A' + r + ' ' + r + ' 0 1 0 ' + ponto(r, Math.PI) + ' A' + r + ' ' + r + ' 0 1 0 ' + ponto(r, 0) + 'Z"/>';
      }
      const grande = a2 - a1 > Math.PI ? 1 : 0;
      return '<path data-dica="' + d + '" fill="' + f.cor + '" d="M' + ponto(R, a1) + ' A' + R + ' ' + R + ' 0 ' + grande + ' 1 ' + ponto(R, a2) +
        ' L' + ponto(r, a2) + ' A' + r + ' ' + r + ' 0 ' + grande + ' 0 ' + ponto(r, a1) + 'Z"/>';
    }).join('');
    const centro = '<text x="100" y="96" text-anchor="middle" font-size="11" fill="var(--tinta-suave)" font-family="inherit">Total</text>' +
      '<text x="100" y="114" text-anchor="middle" font-size="13" font-weight="600" fill="var(--tinta)" font-family="inherit">' + esc(fmtCurto(tot, g.formato)) + '</text>';
    const leg = '<ul class="legenda">' + fatias.map((f) =>
      '<li data-dica="' + escA(f.rotulo + ': ' + fmtValor(f.valor, g.formato)) + '"><span class="cor" style="background:' + f.cor + '"></span><span class="nome" title="' + escA(f.rotulo) + '">' + esc(f.rotulo) + '</span>' +
      '<span class="v">' + fmtValor(f.valor, g.formato) + '</span><span class="p">' + pctTxt(f.valor, tot) + '</span></li>').join('') + '</ul>';
    return '<div class="pizza"><svg viewBox="0 0 200 200" role="img" aria-label="' + escA(g.titulo) + '">' + paths + centro + '</svg>' + leg + '</div>';
  }

  function graficoLinha(g, largura) {
    const W = Math.max(280, Math.round(largura)), H = 230, mE = 66, mD = 14, mT = 10, mB = 30;
    const vals = g.itens.map((x) => x.valor);
    let min = Math.min(0, ...vals), max = Math.max(...vals, 0);
    if (max === min) max = min + 1;
    // passo "redondo" para 4 linhas de grade
    const bruto = (max - min) / 4, mag = Math.pow(10, Math.floor(Math.log10(bruto)));
    const passo = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((p) => p >= bruto);
    min = Math.floor(min / passo) * passo; max = Math.ceil(max / passo) * passo;
    const X = (i) => mE + (g.itens.length === 1 ? (W - mE - mD) / 2 : i * (W - mE - mD) / (g.itens.length - 1));
    const Y = (v) => mT + (max - v) / (max - min) * (H - mT - mB);
    let s = '';
    for (let v = min; v <= max + passo / 2; v += passo) {
      s += '<line class="' + (Math.abs(v) < passo / 1e6 ? 'base' : 'grade') + '" x1="' + mE + '" x2="' + (W - mD) + '" y1="' + Y(v).toFixed(1) + '" y2="' + Y(v).toFixed(1) + '"/>' +
        '<text class="tick" x="' + (mE - 8) + '" y="' + (Y(v) + 4).toFixed(1) + '" text-anchor="end">' + esc(fmtCurto(v, g.formato)) + '</text>';
    }
    const cabe = Math.max(1, Math.floor((W - mE - mD) / 70));
    const pulo = Math.ceil(g.itens.length / cabe);
    g.itens.forEach((x, i) => {
      if (i % pulo === 0 || i === g.itens.length - 1 && (g.itens.length - 1) % pulo >= pulo / 2) {
        s += '<text class="tick" x="' + X(i).toFixed(1) + '" y="' + (H - 10) + '" text-anchor="middle">' + esc(x.rotulo) + '</text>';
      }
    });
    s += '<polyline class="serie" points="' + g.itens.map((x, i) => X(i).toFixed(1) + ',' + Y(x.valor).toFixed(1)).join(' ') + '"/>';
    g.itens.forEach((x, i) => {
      const d = escA(x.rotulo + ': ' + fmtValor(x.valor, g.formato) + (g.total > 0 ? ' (' + pctTxt(x.valor, g.total) + ' do total)' : ''));
      s += '<circle class="alvo" data-dica="' + d + '" cx="' + X(i).toFixed(1) + '" cy="' + Y(x.valor).toFixed(1) + '" r="14"/>' +
        '<circle class="ponto" cx="' + X(i).toFixed(1) + '" cy="' + Y(x.valor).toFixed(1) + '" r="4"/>';
    });
    return '<div class="linha-graf"><svg width="' + W + '" height="' + H + '" role="img" aria-label="' + escA(g.titulo) + '">' + s + '</svg></div>';
  }

  /* ---------- mapa da resposta (OpenStreetMap + Leaflet; a biblioteca só carrega quando precisa) ---------- */
  let leafletCarregando = null;
  function carregarLeaflet() {
    if (window.L) return Promise.resolve();
    if (leafletCarregando) return leafletCarregando;
    leafletCarregando = new Promise((ok, falha) => {
      const css = document.createElement('link');
      css.rel = 'stylesheet'; css.href = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css';
      document.head.appendChild(css);
      const s = document.createElement('script');
      s.src = 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js';
      s.onload = () => ok();
      s.onerror = () => { leafletCarregando = null; falha(new Error('leaflet')); };
      document.head.appendChild(s);
    });
    return leafletCarregando;
  }
  function inserirMapa(caixa, m) {
    if (!m || !m.pontos || !m.pontos.length) return;
    const box = document.createElement('div');
    box.className = 'mapa-caixa';
    box.innerHTML = '<div class="mapa-titulo">' + esc(m.titulo) + '</div><div class="mapa" role="region" aria-label="Mapa: ' + esc(m.titulo) + '"></div>' +
      '<div class="mapa-nota">' + (m.precisao === 'estado' ? 'Posição pelo estado.' : 'Posição aproximada pela cidade; clientes da mesma cidade ficam juntos no mesmo pino.') +
      ' Clique num pino para ver os detalhes. Pino azul: posição no ranking; laranja (ex.: "(+2)"): mais de um cliente no mesmo lugar. No exterior, pela cidade e o país. Mapa © colaboradores do OpenStreetMap.</div>';
    caixa.insertBefore(box, caixa.querySelector('.tabela') || null);
    const el = box.querySelector('.mapa');
    carregarLeaflet().then(() => desenharMapa(el, m))
      .catch(() => { el.innerHTML = '<p class="mapa-erro">Não foi possível carregar o mapa (este computador está sem acesso à internet?).</p>'; });
  }
  function desenharMapa(el, m) {
    const L = window.L;
    const mapa = L.map(el, { scrollWheelZoom: false });
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 18, attribution: '&copy; OpenStreetMap' }).addTo(mapa);
    // quem cai no mesmo ponto (mesma cidade) fica num pino só, com a lista no balão
    const grupos = new Map();
    m.pontos.forEach((p) => {
      const k = p.lat.toFixed(4) + ',' + p.lon.toFixed(4);
      if (!grupos.has(k)) grupos.set(k, []);
      grupos.get(k).push(p);
    });
    const pct = (v) => (v == null ? '' : ' · ' + v.toLocaleString('pt-BR', { minimumFractionDigits: 1, maximumFractionDigits: 1 }) + '%');
    const limites = [];
    grupos.forEach((ps) => {
      const p0 = ps[0];
      const varios = ps.length > 1;
      // pino com 1 cliente: a posição no ranking (azul); com vários no mesmo lugar: quantos, ex.: "(+2)" (laranja)
      const rotuloPino = varios ? '(+' + ps.length + ')' : String(p0.pos);
      const largPino = Math.max(30, 12 + rotuloPino.length * 8);
      const icone = L.divIcon({ className: 'pino' + (varios ? ' pino-varios' : ''), html: '<span>' + rotuloPino + '</span>',
        iconSize: [largPino, 30], iconAnchor: [largPino / 2, 15], popupAnchor: [0, -14] });
      const local = p0.local || (p0.cidade ? p0.cidade + '/' + p0.uf : p0.uf);
      const html = '<div class="pop"><div class="pop-local">' + esc(local) + (varios ? ' · ' + ps.length + ' na lista' : '') + '</div>' +
        ps.map((p) => '<div class="pop-item"><strong>' + p.pos + '. ' + esc(p.rotulo) + '</strong><br>' + esc(fmtValor(p.valor, m.formato)) + esc(pct(p.pct)) +
          '<br><a href="https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(p.rotulo + ', ' + local) + '" target="_blank" rel="noopener">Abrir no Google Maps</a></div>').join('') +
        '</div>';
      L.marker([p0.lat, p0.lon], { icon: icone, title: varios ? local + ' (' + ps.length + ')' : p0.pos + '. ' + p0.rotulo }).addTo(mapa).bindPopup(html, { maxWidth: 300 });
      limites.push([p0.lat, p0.lon]);
    });
    if (limites.length === 1) mapa.setView(limites[0], 9);
    else mapa.fitBounds(limites, { padding: [36, 36], maxZoom: 10 });
  }

  // coloca o gráfico logo depois do parágrafo "Entendi", acima da tabela
  function inserirGrafico(caixa, g) {
    if (!g || !((g.itens && g.itens.length) || (g.grupos && g.grupos.length))) return;
    const el = document.createElement('div');
    el.className = 'grafico';
    const apos = caixa.querySelector('.tabela') || null;
    caixa.insertBefore(el, apos);
    const largura = el.clientWidth || 600;
    el.innerHTML = '<h3>' + esc(g.titulo) + '</h3>' +
      (g.tipo === 'comparativo' && g.grupos ? graficoComparativo(g) : g.tipo === 'pizza' ? graficoPizza(g) : g.tipo === 'linha' ? graficoLinha(g, largura) : graficoBarras(g)) +
      (g.aviso ? '<p class="aviso">' + esc(g.aviso) + '</p>' : '');
  }

