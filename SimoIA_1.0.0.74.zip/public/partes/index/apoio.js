/*@parte tela principal: ordem dos balões, apoio e texto das respostas. Parte de index.html: roda junto com as outras partes, no mesmo escopo*/
  // ordem dos baloes da pagina inicial (Gestão › Gerais; dono, 16/11/2026). Tempo e Câmbio ficam lado a lado
  // quando um vem logo depois do outro; separados, cada um ocupa a linha inteira. Os desmarcados la (data-ocultos) somem.
  (function ordenarBaloes() {
    const painel = document.getElementById('painel');
    const ordem = String(painel.dataset.ordem || '').split(',').map((x) => x.trim()).filter(Boolean);
    const baloes = Array.from(painel.querySelectorAll(':scope > [data-bloco]'));
    const pos = (b) => { const i = ordem.indexOf(b.dataset.bloco); return i < 0 ? 100 + baloes.indexOf(b) : i; };
    const ocultos = String(painel.dataset.ocultos || '').split(',').map((x) => x.trim()).filter(Boolean);
    baloes.slice().sort((a, b) => pos(a) - pos(b)).forEach((b) => { b.classList.toggle('oculto-gestao', ocultos.includes(b.dataset.bloco)); painel.appendChild(b); });
    const lista = Array.from(painel.querySelectorAll(':scope > [data-bloco]:not(.oculto-gestao)')).map((b) => b.dataset.bloco);
    const juntos = Math.abs(lista.indexOf('tempo') - lista.indexOf('cambio')) === 1;
    ['c-tempo', 'c-cambio'].forEach((id) => document.getElementById(id).classList.toggle('largo', !juntos));
  })();
  const campo = document.getElementById('pergunta');
  const botao = document.getElementById('enviar');
  const secao = document.getElementById('resposta');
  const titulo = document.getElementById('pergunta-feita');
  const resultado = document.getElementById('resultado');

  function ajustarAltura() {
    campo.style.height = 'auto';
    campo.style.height = campo.scrollHeight + 'px';
  }

  function atualizarBotao() {
    botao.disabled = campo.value.trim() === '';
  }

  let token = '';
  try { token = sessionStorage.getItem('token') || ''; } catch (e) { /* sem storage */ }
  // "Manter conectado neste aparelho": o login fica no localStorage (sobrevive a fechar o app); o servidor e quem
  // decide o prazo (7 dias sem uso) e pode encerrar a qualquer momento (Sair, Logoff na Gestao, troca de senha)
  if (!token) {
    try {
      token = localStorage.getItem('simoia_token') || '';
      if (token) { sessionStorage.setItem('token', token); sessionStorage.setItem('usuario', localStorage.getItem('simoia_usuario') || ''); }
    } catch (e) { /* sem storage */ }
  }
  const manterMarcado = () => { const c = document.getElementById('manter'); return !!(c && c.checked); };

  function esc(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function inline(s) {
    return esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  }

  // Mostra o texto da resposta (parágrafos, listas, negrito e tabelas simples) sem permitir HTML.
  function renderizar(md) {
    const caixa = document.createElement('div');
    const linhas = String(md).replace(/\r/g, '').split('\n');
    let html = '';
    let i = 0;
    const ehTabela = (x) => /^\s*\|/.test(x);
    const ehLista = (x) => /^\s*[-*]\s+/.test(x);
    while (i < linhas.length) {
      const l = linhas[i];
      if (l.trim() === '') { i++; continue; }
      if (ehTabela(l)) {
        const bloco = [];
        while (i < linhas.length && ehTabela(linhas[i])) { bloco.push(linhas[i]); i++; }
        const celulas = (x) => x.trim().replace(/^\||\|$/g, '').split('|').map((c) => c.trim());
        const dados = bloco.filter((x) => !/^\s*\|[\s:\-|]+$/.test(x));
        html += '<div class="tabela"><table>';
        dados.forEach((x, k) => {
          const tag = k === 0 ? 'th' : 'td';
          html += '<tr>' + celulas(x).map((c) => '<' + tag + '>' + inline(c) + '</' + tag + '>').join('') + '</tr>';
        });
        html += '</table></div>';
        continue;
      }
      if (ehLista(l)) {
        html += '<ul>';
        while (i < linhas.length && ehLista(linhas[i])) {
          html += '<li>' + inline(linhas[i].replace(/^\s*[-*]\s+/, '')) + '</li>';
          i++;
        }
        html += '</ul>';
        continue;
      }
      const par = [];
      while (i < linhas.length && linhas[i].trim() !== '' && !ehTabela(linhas[i]) && !ehLista(linhas[i])) {
        par.push(inline(linhas[i]));
        i++;
      }
      html += '<p>' + par.join('<br>') + '</p>';
    }
    caixa.innerHTML = html;
    return caixa;
  }

