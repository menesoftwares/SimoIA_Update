/* SimoIA - codigo gerado, nao editar */
"use strict";module.exports=e=>{const r={};return require("./simulador_base")(e,r),require("./simulador_demo")(e,r),require("./simulador_dados")(e,r),require("./simulador_tributos")(e,r),require("./simulador_pedido")(e,r),require("./simulador_documentos")(e,r),require("./simulador_rotas_pedido")(e,r),require("./simulador_rotas")(e,r),r};
