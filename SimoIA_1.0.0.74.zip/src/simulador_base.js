/* SimoIA - codigo gerado, nao editar */
"use strict";const a=require("./db");module.exports=(t,r)=>{const{marcarSql:s}=t;function i(e){return s("Simulador: "+e),a.simSql(e)}const c={SI:"simples",LP:"presumido",LR:"real",IS:"isento"},l=e=>String(e||"").normalize("NFD").replace(new RegExp("\\p{M}","gu"),"").toLowerCase();function u(e){return/^\s*(declare|begin)\b/i.test(e)?`set serveroutput on size unlimited\r
`+e+";":e}function m(e){const n=[];for(let o=0;o<e.length;o+=3e3)n.push("To_Clob('"+e.slice(o,o+3e3).replace(/'/g,"''")+"')");return n.join(`\r
 || `)}Object.assign(r,{simSqlDe:i,SIM_REGIME:c,semAcentoMin:l,comoBloco:u,jsonEmClob:m})};
