/* SimoIA - codigo gerado, nao editar */
"use strict";module.exports=e=>{const r={};return require("./coletor_base")(e,r),require("./coletor_etiqueta")(e,r),require("./coletor_coleta")(e,r),require("./coletor_listas")(e,r),require("./coletor_excluir")(e,r),require("./coletor_demo")(e,r),require("./coletor_rotas_conferencia")(e,r),require("./coletor_rotas")(e,r),r};
