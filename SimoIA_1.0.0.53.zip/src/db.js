/* SimoIA - codigo gerado, nao editar */
"use strict";const p=require("path"),g=require("crypto");let U;try{const e=process.emitWarning;process.emitWarning=function(r,...a){if(!/sqlite/i.test(String(r&&r.message||r)))return e.call(process,r,...a)},{DatabaseSync:U}=require("node:sqlite")}catch{throw new Error("Este Node.js nao tem SQLite embutido. Instale o Node.js 22 LTS (22.13 ou superior) ou 24 LTS em https://nodejs.org e rode de novo.")}const S=p.join(__dirname,"..","dados","agenteia.db"),o=new U(S);o.exec(`
  PRAGMA foreign_keys = ON;
  CREATE TABLE IF NOT EXISTS usuarios (
    usuario     TEXT PRIMARY KEY COLLATE NOCASE,
    nome        TEXT,
    senha_hash  TEXT,
    master      INTEGER NOT NULL DEFAULT 0,
    ativo       INTEGER NOT NULL DEFAULT 1,
    criado_em   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    ultimo_login TEXT
  );
  CREATE TABLE IF NOT EXISTS usuario_bi (
    usuario TEXT NOT NULL COLLATE NOCASE REFERENCES usuarios(usuario) ON DELETE CASCADE ON UPDATE CASCADE,
    w_id    INTEGER NOT NULL,
    PRIMARY KEY (usuario, w_id)
  );
  -- historico de cada pergunta feita no app (sem chave estrangeira: o historico fica mesmo se o usuario for excluido)
  CREATE TABLE IF NOT EXISTS consultas (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    data_hora   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    usuario     TEXT NOT NULL COLLATE NOCASE,
    ip          TEXT,
    origem      TEXT,     -- pergunta | formulario | ia
    texto       TEXT,     -- o que o usuario escreveu (ou o formulario, em JSON)
    assunto     TEXT,     -- Venda, Producao...
    consulta    TEXT,     -- como o app entendeu (JSON)
    sql_texto   TEXT,     -- SQL executado no Oracle
    situacao    TEXT,     -- ok | recusada | erro
    mensagem    TEXT,     -- motivo, quando nao deu certo
    tempo_ms    INTEGER
  );
  CREATE INDEX IF NOT EXISTS ix_consultas_usuario ON consultas (usuario, data_hora);
  -- historico de acessos: entradas, tentativas com senha errada e saidas
  CREATE TABLE IF NOT EXISTS acessos (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    data_hora   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    usuario     TEXT NOT NULL COLLATE NOCASE,
    ip          TEXT,
    evento      TEXT NOT NULL,  -- login | falha | sair | bloqueado (muitas tentativas)
    navegador   TEXT
  );
  CREATE INDEX IF NOT EXISTS ix_acessos_usuario ON acessos (usuario, data_hora);
`),o.prepare("pragma table_info(usuario_bi)").all().some(e=>e.name==="modulo")||o.exec("ALTER TABLE usuario_bi ADD COLUMN modulo TEXT");let E={};try{E=JSON.parse(require("fs").readFileSync(p.join(__dirname,"..","config","config.json"),"utf8")).modulos||{}}catch{}function T(e){return E[String(Number(e))]||null}for(const[e,r]of Object.entries(E))o.prepare("update usuario_bi set modulo = ? where w_id = ? and modulo is not ?").run(r,Number(e),r);o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="email")||o.exec("ALTER TABLE usuarios ADD COLUMN email TEXT"),o.exec("CREATE UNIQUE INDEX IF NOT EXISTS ux_usuarios_email ON usuarios (email COLLATE NOCASE) WHERE email IS NOT NULL"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="celular")||o.exec("ALTER TABLE usuarios ADD COLUMN celular TEXT"),o.exec("CREATE UNIQUE INDEX IF NOT EXISTS ux_usuarios_celular ON usuarios (celular) WHERE celular IS NOT NULL");for(const e of["pode_email","pode_whats"])o.prepare("pragma table_info(usuarios)").all().some(r=>r.name===e)||o.exec("ALTER TABLE usuarios ADD COLUMN "+e+" INTEGER NOT NULL DEFAULT 1");o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_simulador")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_simulador INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_integrar")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_integrar INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="tela_inicial")||o.exec("ALTER TABLE usuarios ADD COLUMN tela_inicial TEXT NOT NULL DEFAULT ''"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_coletor")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_coletor INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_col_manut")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_col_manut INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_sim_manut")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_sim_manut INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_sim_custo")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_sim_custo INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="pode_biometria")||o.exec("ALTER TABLE usuarios ADD COLUMN pode_biometria INTEGER NOT NULL DEFAULT 1");const I=["","simulador","coletor","coletor_rastro"];if(o.exec(`create table if not exists simulador_despesas (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL UNIQUE COLLATE NOCASE,
  ordem INTEGER NOT NULL DEFAULT 0,
  ativo INTEGER NOT NULL DEFAULT 1,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`),o.prepare("pragma table_info(simulador_despesas)").all().some(e=>e.name==="percentual")&&o.exec("ALTER TABLE simulador_despesas DROP COLUMN percentual"),!o.prepare("select count(*) as n from simulador_despesas").get().n){const e=o.prepare("insert into simulador_despesas (nome, ordem, alterado_por) values (?, ?, ?)");["Frete","MKT","IRPJ","Cont. Soc.","Custo ADM","Custo FIN","PPD","Margem","Comiss\xE3o"].forEach((r,a)=>e.run(r,(a+1)*10,"inicial"))}if(o.exec(`create table if not exists simulador_param_uf (
  uf TEXT PRIMARY KEY COLLATE NOCASE,
  frete REAL, mkt REAL, irpj REAL, cont_soc REAL, custo_adm REAL, custo_fin REAL, ppd REAL, margem REAL, comissao REAL,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`),!o.prepare("select count(*) as n from simulador_param_uf").get().n){const e=o.prepare("insert into simulador_param_uf (uf, frete, mkt, irpj, cont_soc, custo_adm, custo_fin, ppd, margem, comissao, alterado_por) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"),r=[["RS",8,13,1.2],["PR",8,13,1.2],["SC",8,13,1.2],["SP",5.5,1,4],["AC",11,1,4],["AL",10,1,4],["AM",13,1,4],["AP",12,1,4],["BA",10,1,4],["CE",10,1,4],["DF",8,1,4],["ES",8,1,4],["GO",8,1,4],["MA",11,1,4],["MT",8,1,4],["MS",8,1,4],["MG",6.5,1,4],["PA",11,1,4],["PB",10,1,4],["PE",10,1,4],["PI",11,1,4],["RN",10,1,4],["RJ",7,1,4],["RO",10,1,4],["RR",15,1,4],["SE",10,1,4],["TO",10,1,4]];for(const[a,t,i,s]of r)e.run(a,t,i,2,1.08,6.92,1.5,1,8,s,"inicial")}o.exec(`create table if not exists sistema_config (
  chave TEXT PRIMARY KEY COLLATE NOCASE,
  valor TEXT,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`),o.exec(`create table if not exists simulador_config (
  chave TEXT PRIMARY KEY COLLATE NOCASE,
  valor TEXT,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`),o.prepare("delete from simulador_config where chave = 'item_inicial'").run(),o.exec(`create table if not exists simulador_ultima (
  usuario TEXT PRIMARY KEY COLLATE NOCASE,
  dados TEXT NOT NULL,
  salvo_em TEXT NOT NULL DEFAULT (datetime('now','localtime'))
)`),o.exec(`create table if not exists coletor_sql (
  chave TEXT PRIMARY KEY COLLATE NOCASE,
  descricao TEXT NOT NULL,
  sql_texto TEXT NOT NULL,
  observacao TEXT,
  ativo INTEGER NOT NULL DEFAULT 1,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`);{const e=o.prepare("insert or ignore into coletor_sql (chave, descricao, sql_texto, observacao, ativo, alterado_por) values (?, ?, ?, ?, ?, 'inicial')"),r="-- aguardando o SQL do dono";e.run("documentos","Documentos a conferir (lista que aparece no coletor)",r,"Inativo at\xE9 receber o SQL.",0),o.prepare("delete from coletor_sql where chave = 'itens' and alterado_por = 'inicial' and sql_texto = ?").run(r);const a=`insert into wonder.simo_conferencia_doctos
  (w_id_transacao, w_id_movitens, sequencia, w_id_produto, cod_item, cod_comercial_item,
   num_lote, bipe_checkout, qtd_checkout, qtd_conferida, observacao, dt_criacao, usuario_criacao)
values
  (#W_ID_TRANSACAO#, #W_ID_MOVITENS#, #SEQUENCIA#, #W_ID_PRODUTO#, #COD_ITEM#, #COD_COMERCIAL_ITEM#,
   #NUM_LOTE#, #BIPE#, #QTD_CHECKOUT#, #QTD_CONFERIDA#, #OBSERVACAO#, sysdate, #USUARIO#)`,t=`insert into wonder.simo_conferencia_doctos
  (w_id_transacao, w_id_movitens, sequencia, w_id_produto, cod_item, cod_comercial_item,
   num_lote, bipe_checkout, qtd_checkout, qtd_conferida, observacao, tipo_coleta, dt_criacao, usuario_criacao)
values
  (#W_ID_TRANSACAO#, #W_ID_MOVITENS#, #SEQUENCIA#, #W_ID_PRODUTO#, #COD_ITEM#, #COD_COMERCIAL_ITEM#,
   #NUM_LOTE#, #BIPE#, #QTD_CHECKOUT#, #QTD_CONFERIDA#, #OBSERVACAO#, #TIPO_COLETA#, sysdate, #USUARIO#)`,i="Grava\xE7\xE3o de uma leitura do coletor (insert em wonder.simo_conferencia_doctos)",s='Um insert por leitura (sem ";" no fim). QTD_CONFERIDA come\xE7a igual \xE0 QTD_CHECKOUT. TIPO_COLETA: C = cega, P = por produto. OBSERVACAO leva o tipo de coleta e se foi digitado.';e.run("gravar",i,t,s,1);const n=`select w_id, w_id_movitens, sequencia, w_id_produto, cod_item, num_lote, bipe_checkout, qtd_checkout, qtd_conferida, observacao,
       to_char(dt_criacao, 'dd/mm/yyyy hh24:mi:ss') dt_criacao, usuario_criacao
  from wonder.simo_conferencia_doctos
 where w_id_transacao = #W_ID_TRANSACAO#
   and cancelado = 'N'
   and eliminado = 'N'
 order by w_id desc`,l=`select w_id, w_id_movitens, sequencia, w_id_produto, cod_item, num_lote, bipe_checkout, qtd_checkout, qtd_conferida, observacao,
       tipo_coleta, to_char(dt_criacao, 'dd/mm/yyyy hh24:mi:ss') dt_criacao, usuario_criacao
  from wonder.simo_conferencia_doctos
 where w_id_transacao = #W_ID_TRANSACAO#
   and cancelado = 'N'
   and eliminado = 'N'
 order by w_id desc`;e.run("conferidos","Leituras ativas de um documento (o que j\xE1 foi conferido)",l,"Mostrado na tela de coleta (totais por item e hist\xF3rico de leituras). TIPO_COLETA define o tipo em que a coleta continua.",1);const u=o.prepare("update coletor_sql set sql_texto = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = ? and alterado_por = 'inicial' and sql_texto = ?");u.run(t,s,"gravar",a),u.run(l,"Mostrado na tela de coleta (totais por item e hist\xF3rico de leituras). TIPO_COLETA define o tipo em que a coleta continua.","conferidos",n),e.run("cancelar","Cancela uma leitura (CANCELADO = S, com data e usu\xE1rio)",`update wonder.simo_conferencia_doctos
   set cancelado = 'S', dt_cancelamento = sysdate, usuario_cancelamento = #USUARIO#,
       dt_alteracao = sysdate, usuario_alteracao = #USUARIO#
 where w_id = #W_ID#
   and w_id_transacao = #W_ID_TRANSACAO#
   and cancelado = 'N'`,'Bot\xE3o "Cancelar" do hist\xF3rico de leituras. O servidor junta num bloco com commit.',1),e.run("cancelar_item","Cancela todas as leituras de um item do documento (excluir item para reconferir)",`update wonder.simo_conferencia_doctos
   set cancelado = 'S', dt_cancelamento = sysdate, usuario_cancelamento = #USUARIO#,
       dt_alteracao = sysdate, usuario_alteracao = #USUARIO#
 where w_id_transacao = #W_ID_TRANSACAO#
   and w_id_movitens = #W_ID_MOVITENS#
   and cancelado = 'N'`,'Bot\xE3o "Excluir" do item na tela de coleta. O servidor junta num bloco com commit.',1),o.prepare("update coletor_sql set sql_texto = ?, ativo = 1, descricao = ?, observacao = ?, alterado_em = datetime('now','localtime') where chave = 'gravar' and alterado_por = 'inicial' and sql_texto = ?").run(t,i,s,r)}o.exec(`create table if not exists coletor_reserva (
  id_transacao TEXT PRIMARY KEY,
  usuario TEXT NOT NULL COLLATE NOCASE,
  dispositivo TEXT NOT NULL,
  aparelho TEXT,
  tipo TEXT,
  nr_docto TEXT,
  cliente TEXT,
  iniciado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  ultimo_uso TEXT NOT NULL DEFAULT (datetime('now','localtime'))
)`),o.prepare("pragma table_info(coletor_reserva)").all().some(e=>e.name==="transportadora")||o.exec("ALTER TABLE coletor_reserva ADD COLUMN transportadora TEXT"),o.exec(`create table if not exists simulador_sql (
  chave TEXT PRIMARY KEY COLLATE NOCASE,
  descricao TEXT NOT NULL,
  sql_texto TEXT NOT NULL,
  observacao TEXT,
  ativo INTEGER NOT NULL DEFAULT 1,
  alterado_em TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  alterado_por TEXT
)`);{const e=o.prepare("insert or ignore into simulador_sql (chave, descricao, sql_texto, observacao, alterado_por) values (?, ?, ?, ?, ?)");e.run("clientes","Clientes ativos (rela\xE7\xE3o C), s\xF3 pessoa jur\xEDdica, com regi\xE3o, cidade/UF/pa\xEDs, classifica\xE7\xE3o ICMS, regime tribut\xE1rio federal, Suframa e vendedores",`select p.codigo, p.nome, p.fantasia, p.ativo, p.cpf_cnpj, p.rg_insc, p.tipo_pessoa, r.descricao regiao1, p.p_cidade, p.p_uf, p.p_pais, p.cod_classif_icms, p.reg_trib_fed, p.suframa,
       listagg(ven.nome, ';') within group (order by ven.nome) as vendedores,
       listagg(ven.codigo, ';') within group (order by ven.nome) as cod_vendedores
  from wonder.pessoas p,
       wonder.regioes r,
       wonder.pessoas_rel prel,
       wonder.relacoes rel,
       wonder.pessoas_ven vrel,
       wonder.pessoas ven
 where p.w_id = prel.w_id_pessoa
   and p.w_id_regiao = r.w_id(+)
   and prel.w_id_relacao = rel.w_id
   and vrel.w_id_pessoa = p.w_id(+)
   and vrel.w_id_vendedor = ven.w_id
   and rel.codigo = 'C'
   and p.ativo = 'S'
   and p.tipo_pessoa = 'JD'
 group by p.codigo, p.nome, p.fantasia, p.ativo, p.cpf_cnpj, p.rg_insc, p.tipo_pessoa, r.descricao, p.p_cidade, p.p_uf, p.p_pais, p.cod_classif_icms, p.reg_trib_fed, p.suframa`,"reg_trib_fed: SI = Simples, LP = Lucro Presumido, LR = Lucro Real, IS = Isento. S\xF3 tipo_pessoa JD (jur\xEDdica); clientes sem vendedor ficam de fora. cod_vendedores (c\xF3digos, mesma ordem dos nomes) vai para a Margem Sistema.","inicial"),o.prepare("update simulador_sql set sql_texto = replace(sql_texto, 'as vendedores', 'as vendedores,' || char(10) || '       listagg(ven.codigo, '';'') within group (order by ven.nome) as cod_vendedores'), observacao = observacao || ' cod_vendedores (c\xF3digos, mesma ordem dos nomes) vai para a Margem Sistema.', alterado_em = datetime('now','localtime') where chave = 'clientes' and alterado_por = 'inicial' and instr(lower(sql_texto), 'cod_vendedores') = 0").run(),e.run("tipos_docto",'Tipos de documento de venda para o campo "Tipo Docto" do Simulador (o c\xF3digo vai no cod_tipo_doc da tributa\xE7\xE3o)',`select td.w_id, td.codigo, td.descricao,
       td.codigo ||'-'|| td.descricao cod_desc_tipo_doc
  from wonder.cml_tiposdoc td
 where td.operacao in ('VE')
   and td.ativo = 'S'
   and td.codigo in (2,38,180,165,169,170,206)`,"Manter as colunas: W_ID, CODIGO (vai no cod_tipo_doc da API de tributos), DESCRICAO e COD_DESC_TIPO_DOC (o texto mostrado no campo).","inicial");try{e.run("tributos","API de tributos (wonder.probus_edi.GetPrecoVendaFormacaoPreco em bloco PL/SQL): s\xF3 os campos usados, com ST, num JSON pequeno",require("fs").readFileSync(p.join(__dirname,"sql","simulador_tributos.sql"),"utf8").replace(/\r/g,"").trim(),"Manter #JSON#. O servidor monta o documento: ENF, emiss\xE3o pr\xF3pria, R$, empresa 1, dt_emissao = hoje, es S, oper_presenca_comprador 9, cenario F, cod_tipo_doc 2; com cliente vai cod_pessoa_filial; uf, num_inscr_suframa, cod_classif_icms e contribuinte_icms v\xEAm do cliente ou da tela (sem cliente vai tamb\xE9m reg_trib_fed do regime); consumidor_final sempre N; itens {cod_produto, vl_bruto = Vl caixa}.","inicial")}catch{}try{e.run("pedidos",'\xDAltimos 5 pedidos de venda do cliente (itens com quantidade digitada, valor digitado e os 3 descontos), para "Usar itens deste pedido" no Simulador',require("fs").readFileSync(p.join(__dirname,"sql","simulador_pedidos.sql"),"utf8").replace(/\r/g,"").trim(),"Manter #COD_PESSOA# (c\xF3digo do cliente) e as colunas: ID_TRANSACAO, COD_ITEM, DESC_ITEM, NUM_PEDIDO, DT_EMISSAO, EMPRESA, SITUACAO, ITEN_BONIFICADO, PERC_DESC_VLUNIT1..3, DESCPED, QTD_DIGITADA, QTD_CANCELADA, VL_DIGITADO, VL_UNT, VL_BRUTO_ITEN.","inicial")}catch{}try{e.run("pedido_numero",'Pedido de venda pelo n\xFAmero (dados do cliente e todos os itens), para o "Carregar pedido" do Simulador',require("fs").readFileSync(p.join(__dirname,"sql","simulador_pedido_numero.sql"),"utf8").replace(/\r/g,"").trim(),"Manter #COD_PEDIDO# (n\xFAmero do pedido, nr_docto) e as colunas: CODIGO, NOME, P_UF, COD_CLASSIF_ICMS, REG_TRIB_FED, SUFRAMA (cliente); ID_TRANSACAO, COD_ITEM, DESC_ITEM, NUM_PEDIDO, DT_EMISSAO, EMPRESA, SITUACAO, PERC_DESC_VLUNIT1..3, DESCPED, QTD_DIGITADA, VL_DIGITADO, VL_BRUTO_ITEN.","inicial")}catch{}try{e.run("condicoes_pagto",'Condi\xE7\xF5es de pagamento ativas com as parcelas (dias e % de amortiza\xE7\xE3o), para o "Integrar" do Simulador',require("fs").readFileSync(p.join(__dirname,"sql","simulador_condicoes_pagto.sql"),"utf8").replace(/\r/g,"").trim(),"Manter as colunas: W_ID, CODIGO (vai como cod_cond_pagto), DESCRICAO, SEQUENCIA, DIAS (vencimento = hoje + dias) e AMORTIZACAO (% do total em cada parcela).","inicial"),e.run("integrar_pedido","Grava o pedido do Simulador no sistema (wonder.probus_edi.Grava_JSON_as_pv_terc) e devolve a resposta com o pedido",require("fs").readFileSync(p.join(__dirname,"sql","simulador_integrar.sql"),"utf8").replace(/\r/g,"").trim(),'Bloco PL/SQL. Manter #JSON# (documento montado pelo servidor), o commit e a sa\xEDda em linhas "#J#".',"inicial"),e.run("integrar_orcamento","Grava o or\xE7amento do Simulador no sistema (wonder.probus_edi.Grava_JSON_as_orc_terc) e devolve a resposta com o or\xE7amento",require("fs").readFileSync(p.join(__dirname,"sql","simulador_integrar.sql"),"utf8").replace(/\r/g,"").trim().replace("Grava_JSON_as_pv_terc","Grava_JSON_as_orc_terc").replace("Integra o pedido do Simulador (dono, 28/10/2026)","Integra o orcamento do Simulador (dono, 29/10/2026)"),'Bloco PL/SQL. Manter #JSON# (documento montado pelo servidor, o mesmo do pedido), o commit e a sa\xEDda em linhas "#J#".',"inicial")}catch{}if(!o.prepare("select 1 from simulador_config where chave = 'mig_tributos_bloco'").get())try{const r=require("fs").readFileSync(p.join(__dirname,"sql","simulador_tributos.sql"),"utf8").replace(/\r/g,"").trim();o.prepare("update simulador_sql set sql_texto = ?, descricao = ?, alterado_em = datetime('now','localtime'), alterado_por = 'inicial' where chave = 'tributos'").run(r,"API de tributos (wonder.probus_edi.GetPrecoVendaFormacaoPreco em bloco PL/SQL): s\xF3 os campos usados, com ST, num JSON pequeno"),o.prepare("insert into simulador_config (chave, valor, alterado_por) values ('mig_tributos_bloco', 'feito', 'inicial')").run()}catch{}if(!o.prepare("select 1 from simulador_config where chave = 'mig_tributos_kit'").get())try{const r=require("fs").readFileSync(p.join(__dirname,"sql","simulador_tributos.sql"),"utf8").replace(/\r/g,"").trim();o.prepare("update simulador_sql set sql_texto = ?, alterado_em = datetime('now','localtime') where chave = 'tributos' and alterado_por = 'inicial'").run(r),o.prepare("insert into simulador_config (chave, valor, alterado_por) values ('mig_tributos_kit', 'feito', 'inicial')").run()}catch{}{const r=a=>`                           and (   r.${a}='CANAL'      and ir.cod_canal = null
                                or r.${a}='COND_PAGTO' and ir.Cod_Condpagto = null
                                or r.${a}='DEPTO'      and ir.cod_depto = ''
                                or r.${a}='DT_DOCTO'   and sysdate between ir.dt_ini and ir.dt_fim
                                or r.${a}='EMPRESA'    and ir.empresa = 1
                                or r.${a}='ESP_DOCTO'  and ir.esp_docto = ''
                                or r.${a}='ID_CIDADE'  and ir.w_id_cidade = null
                                or r.${a}='PESSOA'     and ir.cod_pessoa = #COD_PESSOA#
                                or r.${a}='PRAZOMEDIO' and -1 between ir.przmed_ini and ir.przmed_fim
                                or r.${a}='REGIAO'     and ir.w_id_regiao = null
                                or r.${a}='TIPODOC'    and ir.cod_tipodoc = ''
                                or r.${a}='UF_PESSOA'  and Instr(ir.uf_pessoa, '#UF#') > 0
                                or r.${a}='VENDEDOR'   and ir.Cod_vendedor in (#COD_VENDEDORES#)
                                or r.${a}='CAT_VEND'   and ir.Cod_CatVend = null
                                or r.${a} is null
                               )`;e.run("margem_sistema","Margem Sistema: % m\xEDnimo de resultado da regra comercial (REG_CML_PERC_MIN_RESULT_VDA) para a UF/cliente da simula\xE7\xE3o",`Select to_number(substr(min(to_char(r.prioridade,'FM000')||to_char(ir.percentual)),4,20)) perc_result_minimo
                          from wonder.cml_regras r, wonder.cml_itens_regras ir
                         where r.id_regra = ir.id_regra
                           and r.origem='REG_CML_PERC_MIN_RESULT_VDA'
                           and trunc(sysdate) between r.dt_inicial and r.dt_final
                           and r.empresa_m = 10
${["var1","var2","var3","var4","var5"].map(r).join(`
`)}`,"Marcas: #UF# (UF de venda, 2 letras), #COD_PESSOA# (c\xF3digo do cliente ou null) e #COD_VENDEDORES# (c\xF3digos dos vendedores do cliente, separados por v\xEDrgula, ou null). Sem wonder.pessoas/pessoas_ven (ajuste do dono): canal, cond. pagto, cidade, regi\xE3o e categoria do vendedor ficam null. Sem regra = 0%.","inicial"),o.prepare("update simulador_sql set sql_texto = replace(sql_texto, 'ir.Cod_vendedor = null', 'ir.Cod_vendedor in (#COD_VENDEDORES#)'), alterado_em = datetime('now','localtime') where chave = 'margem_sistema' and alterado_por = 'inicial' and instr(sql_texto, 'ir.Cod_vendedor = null') > 0").run()}e.run("classif_icms","Classifica\xE7\xF5es de ICMS da pessoa (EST_CLASSIF_ICMS), com a indica\xE7\xE3o de contribuinte, para a tela sem cliente",`select codigo, descricao, contrib_icms
  from wonder.est_classif_icms
 order by codigo`,"Manter as colunas CODIGO, DESCRICAO e CONTRIB_ICMS (S/N = contribuinte_icms do JSON da API de tributos).","inicial"),e.run("produtos","Produtos dispon\xEDveis para o vendedor 26349 (MOB_Envio_Prod), categorias 7 e 12, fabricantes 2 e 3, ativos, com pesos, volume, peso do pacote e a estrutura de grupos",`Select prod.codigo, prod.descricao, prod.unmed, prod.Peso_Liquido, prod.Peso_Bruto, prod.Volume_cubico,
       case when prod.UndAlt_Fator_Qtde = 1 then 0 else prod.Peso_Liquido/(prod.UndAlt_Fator_Qtde/1000) end peso_pct,
       prod.catproduto, prod.desc_cat, prod.fabricante, prod.desc_fab, prod.grupo, prod.desc_grupo,
       prod.grupo_1, prod.grupo_2, prod.grupo_3, prod.grupo_4, prod.grupo_5
 From(
      Select pr.codigo, pr.descricao, pr.unmed, pr.Peso_Liquido, pr.Peso_Bruto, pr.Volume_cubico,
             pr.catproduto, pr.fabricante, pr.grupo,
             cat.descricao desc_cat, fab.descricao desc_fab, grp.descricao desc_grupo,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,1) as grupo_1,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,2) as grupo_2,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,3) as grupo_3,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,4) as grupo_4,
             wonder.util.lerinfoestrut('est_grupos','classific','descricao','1=1', 'w_id=' || pr.w_id_grupo,5) as grupo_5,
             Nvl(Decode(UndAlt.Cod_Unidade, pr.UnMed, UndAlt.Cod_UndResult, UndAlt.Cod_Unidade),pr.UnMed) as UndAlt,
             Nvl(Wonder.Probus_Estoque.ObtemQtdEquiv(pr.W_Id, pr.UnMed, 1, Decode(UndAlt.Cod_Unidade, pr.UnMed, UndAlt.Cod_UndResult, UndAlt.Cod_Unidade), 'N'),1) UndAlt_Fator_Qtde,
             Nvl(Wonder.Probus_Estoque.ObtemQtdEquiv(pr.W_Id, Decode(UndAlt.Cod_Unidade, pr.UnMed, UndAlt.Cod_UndResult, UndAlt.Cod_Unidade), 1, pr.UnMed, 'N'),1) UndAlt_Fator_Valores
        From wonder.MOB_Envio_Prod ep, wonder.est_produtos pr,
             wonder.est_catproduto cat, wonder.est_fabricantes fab, wonder.est_grupos grp,
             (Select e.W_Id_Produto,
                     min(e.w_id) w_id,
                     trim(substr( min( to_char(e.w_id,'FM000000000000000')||rpad(e.cod_unidade,5)   ), 16,5)) cod_unidade,
                     trim(substr( min( to_char(e.w_id,'FM000000000000000')||rpad(e.cod_undresult,5) ), 16,5)) cod_undresult
                from Wonder.Est_Prod_Und_Equiv e
               Group by e.w_id_produto
             ) UndAlt
       Where ep.w_id_produto = pr.w_id
         and pr.w_id = UndAlt.w_id_produto(+)
         and pr.w_id_cat_produto = cat.w_id(+)
         and pr.w_id_fabricante = fab.w_id(+)
         and pr.w_id_grupo = grp.w_id(+)
         and ep.w_id_vendedor = (select Max(p.w_id) from wonder.pessoas p where p.codigo = 26349)
         and pr.catproduto in ('7','12')
         and pr.fabricante in ('2','3')
         and pr.codigo not in ('13200')
         and pr.ativo = 'S'
         and ep.disponivel = 'S'
      ) prod
 Order by prod.descricao`,"Manter as colunas CODIGO, DESCRICAO, UNMED, PESO_LIQUIDO, PESO_BRUTO, VOLUME_CUBICO, PESO_PCT, DESC_CAT, DESC_FAB, DESC_GRUPO, GRUPO_1..5. PESO_PCT = gramatura (g por pacote); unidades por caixa = PESO_LIQUIDO x 1000 / PESO_PCT; grupo do simulador = GRUPO_3. O servidor faz select distinct e l\xEA de novo a cada 30 min.","inicial"),e.run("custos","Tabelas de custo de refer\xEAncia (planos) ativas das empresas 1, 6 e 7, com a empresa, para o campo Custo",`Select c.descricao||' - ('||c.codigo||')' desc_cod_plno_ref, c.w_id, emp.empresa
  From Wonder.EST_CustoRef c,
       Wonder.EST_CustoRef_Emp emp
 Where c.w_id = emp.W_Id_CustoRef
   and emp.eliminado = 'N'
   and c.Eliminado = 'N'
   and c.Ativo = 'S'
   and emp.Empresa in (1,6,7)
 order by codigo desc`,"Manter as colunas DESC_COD_PLNO_REF (texto mostrado), W_ID e EMPRESA (a tela guarda os dois). Cada par tabela + empresa \xE9 uma op\xE7\xE3o, na ordem do SQL.","inicial"),e.run("custo_produto","Custo de refer\xEAncia (vl_custo_ref) de cada produto por empresa, para o custo dos itens",`select pr.w_id, pr.codigo, esp.vl_custo_ref, esp.empresa
  from wonder.est_produtos pr,
       wonder.est_espprodemp esp
 Where pr.w_id = esp.w_id_produto
   and pr.catproduto in ('7','12')
   and pr.fabricante in ('2','3')
   and pr.codigo not in ('13200')
   and pr.ativo = 'S'`,'Manter as colunas W_ID, CODIGO, VL_CUSTO_REF e EMPRESA. O servidor l\xEA tudo de uma vez (cerca de 2 mil linhas) e procura por c\xF3digo + empresa da tabela de custo escolhida; custo 0 conta como "sem custo". Custo por caixa (confirmado pelo dono).',"inicial"),e.run("tabelas_preco","Tabelas de pre\xE7o ativas da empresa 10 com pre\xE7os vigentes hoje (menos 56, 350, 357, 370, 375, 377), para o campo Tabela de pre\xE7o",`Select w_id, cod_tabpreco, descricao, ativa, promocao, cod_indice, obs, precos_vigentes, empresas_aut, w_dt_criacao
From (
      Select w_id, cod_tabpreco, descricao, ativa, promocao, cod_indice, obs,
             case when tem_preco_vig + tem_preco_vig_resp_var + tem_preco_vig_grade_cfg > 0 then 'S' else 'N' end precos_vigentes,
             empresas_aut, w_dt_criacao
        From (
               Select tp.w_id, tp.cod_tabpreco, tp.descricao, tp.ativa, tp.promocao, tp.cod_indice, tp.obs, tp.w_dt_criacao,
                      wonder.util.concatdados(Cursor(Select tpe.empresa
                                                       From wonder.cml_tabpreco_emp tpe
                                                       Where tpe.w_id_tabpreco = tp.w_id
                                                    ), ','
                                              )
                      empresas_aut,
                      case when exists (Select 1
                                          From wonder.cml_itenstabpreco itp
                                          Where tp.w_id = itp.w_id_tabpreco
                                          and trunc(sysdate) between itp.dt_inicio and itp.dt_termino
                                          and not exists (Select 1
                                                            From wonder.cml_itenstabpreco_resp_var_cfg cfg, wonder.cml_itenstabpreco_vigencias vig
                                                            Where itp.w_id = cfg.w_id_item_tabpreco
                                                            and cfg.w_id = vig.w_id_itp_resp_var
                                                         )
                                          and not exists (Select 1
                                                            From wonder.cml_itenstabpreco_grade itpg, wonder.cml_itenstabpreco_vigencias vig
                                                            Where itp.w_id = itpg.w_id_item_tabpreco
                                                            and itpg.w_id = vig.w_id_itp_grade
                                                         )
                                        )
                      then 1 else 0 end tem_preco_vig,
                      case when exists (Select 1
                                          From wonder.cml_itenstabpreco itp, wonder.cml_itenstabpreco_resp_var_cfg cfg, wonder.cml_itenstabpreco_vigencias vig
                                          Where tp.w_id = itp.w_id_tabpreco
                                          and itp.w_id = cfg.w_id_item_tabpreco
                                          and cfg.w_id = vig.w_id_itp_resp_var
                                          and trunc(sysdate) between vig.dt_inicio and vig.dt_termino
                                       )
                      then 1 else 0 end tem_preco_vig_resp_var,
                      case when exists (Select 1
                                          From wonder.cml_itenstabpreco itp, wonder.cml_itenstabpreco_grade itpg, wonder.cml_itenstabpreco_vigencias vig
                                          Where tp.w_id = itp.w_id_tabpreco
                                          and itp.w_id = itpg.w_id_item_tabpreco
                                          and itpg.w_id = vig.w_id_itp_grade
                                          and trunc(sysdate) between vig.dt_inicio and vig.dt_termino
                                       )
                      then 1 else 0 end tem_preco_vig_grade_cfg
                 From wonder.cml_tabpreco tp
                Where tp.cod_tabpreco not in (56,350, 370,377, 375,357)
                  and tp.w_id in ((Select tp.w_id From wonder.cml_tabpreco tp Where tp.empresa_m = 10 and tp.ativa = 'S'))
              )
       )
 Where decode(sysdate, null, 'S', precos_vigentes) = 'S'`,'Manter as colunas W_ID, COD_TABPRECO, DESCRICAO (e, se quiser, PROMOCAO, OBS, EMPRESAS_AUT). A tela mostra "descri\xE7\xE3o (c\xF3digo)" em ordem alfab\xE9tica; o valor \xE9 o W_ID.',"inicial"),e.run("precos","Pre\xE7o vigente hoje de cada item em cada tabela de pre\xE7o (pre\xE7o diferente de zero)",`select tb.descricao||' - ('||tb.cod_tabpreco||')' desc_cod_tab_preco, it.preco,
       tb.w_id, it.w_id_produto, it.cod_item
  from wonder.cml_itenstabpreco it, wonder.cml_tabpreco tb
 where tb.cod_tabpreco = it.cod_tabpreco
   and tb.w_id = it.w_id_tabpreco
   and tb.empresa_m = it.empresa_m
   and (nvl(trunc(sysdate),trunc(sysdate)) between it.dt_inicio and it.dt_termino)
   and it.preco <> 0`,"Manter as colunas PRECO, W_ID (da tabela de pre\xE7o) e COD_ITEM (= c\xF3digo do produto; conferido em 27/10/2026: igual em todas as 21.677 linhas, sem repetidos por tabela + produto). O servidor l\xEA tudo de uma vez e procura por tabela + produto.","inicial")}o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="falhas_login")||o.exec("ALTER TABLE usuarios ADD COLUMN falhas_login INTEGER NOT NULL DEFAULT 0"),o.prepare("pragma table_info(usuarios)").all().some(e=>e.name==="bloqueado_em")||o.exec("ALTER TABLE usuarios ADD COLUMN bloqueado_em TEXT"),o.exec(`create table if not exists log_bloqueios (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario TEXT NOT NULL,
  data_hora TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  ip TEXT,
  aparelho TEXT,
  tentativas INTEGER,
  desbloqueado_em TEXT,
  desbloqueado_por TEXT
)`),o.exec(`create table if not exists geo_cache (
  chave TEXT PRIMARY KEY,
  lat REAL,
  lon REAL,
  ok INTEGER NOT NULL,
  atualizado TEXT NOT NULL DEFAULT (datetime('now','localtime'))
)`);function X(e){return o.prepare("select lat, lon, ok from geo_cache where chave = ?").get(String(e))||null}function y(e,r,a,t){o.prepare("insert or replace into geo_cache (chave, lat, lon, ok, atualizado) values (?, ?, ?, ?, datetime('now','localtime'))").run(String(e),t?Number(r):null,t?Number(a):null,t?1:0)}o.exec(`create table if not exists sessoes (
  hash TEXT PRIMARY KEY,
  usuario TEXT NOT NULL,
  nome TEXT,
  master INTEGER NOT NULL DEFAULT 0,
  login_anterior TEXT,
  expira INTEGER NOT NULL
)`);for(const[e,r]of[["criado","INTEGER"],["ip","TEXT"],["aparelho","TEXT"],["dispositivo","TEXT"],["manter","INTEGER"]])o.prepare("pragma table_info(sessoes)").all().some(a=>a.name===e)||o.exec("ALTER TABLE sessoes ADD COLUMN "+e+" "+r);o.exec(`create table if not exists painel_cache (
  chave TEXT PRIMARY KEY,
  dados TEXT NOT NULL,
  quando INTEGER NOT NULL
)`);function F(){const e=o.prepare("select chave, dados, quando from painel_cache order by quando desc limit 1").get();if(!e)return null;try{return{chave:e.chave,quando:Number(e.quando),dados:JSON.parse(e.dados)}}catch{return null}}function G(e,r,a){o.prepare("insert or replace into painel_cache (chave, dados, quando) values (?, ?, ?)").run(String(e),JSON.stringify(r),Math.round(Number(a))),o.prepare("delete from painel_cache where chave <> ?").run(String(e))}o.exec(`create table if not exists perfil_uso (
  usuario TEXT NOT NULL COLLATE NOCASE,
  assunto TEXT NOT NULL,
  tipo TEXT NOT NULL,
  valor TEXT NOT NULL,
  peso REAL NOT NULL DEFAULT 0,
  vezes INTEGER NOT NULL DEFAULT 0,
  sugerida INTEGER NOT NULL DEFAULT 0,
  aceita INTEGER NOT NULL DEFAULT 0,
  ultimo TEXT,
  PRIMARY KEY (usuario, assunto, tipo, valor)
)`),o.exec(`create table if not exists termos_aprendidos (
  usuario TEXT NOT NULL COLLATE NOCASE,
  termo TEXT NOT NULL,
  assunto TEXT NOT NULL,
  peso REAL NOT NULL DEFAULT 0,
  vezes INTEGER NOT NULL DEFAULT 0,
  ultimo TEXT,
  PRIMARY KEY (usuario, termo, assunto)
)`);const B=.93;function j(e,r,a){const t=String(e).trim(),i=[...new Set(a.map(n=>n.tipo))],s=o.prepare("insert into perfil_uso (usuario, assunto, tipo, valor, peso, vezes, ultimo) values (?, ?, ?, ?, 1, 1, datetime('now','localtime')) on conflict (usuario, assunto, tipo, valor) do update set peso = peso + 1, vezes = vezes + 1, ultimo = excluded.ultimo");o.exec("BEGIN");try{o.prepare("update perfil_uso set peso = peso * ? where usuario = ? and assunto = ?").run(B,t,r);for(const n of a)s.run(t,r,n.tipo,String(n.valor));for(const n of i)s.run(t,r,n,"*");o.exec("COMMIT")}catch(n){throw o.exec("ROLLBACK"),n}}function Y(e,r){return r?o.prepare("select assunto, tipo, valor, peso, vezes, sugerida, aceita, ultimo from perfil_uso where usuario = ? and assunto = ?").all(String(e).trim(),r):o.prepare("select assunto, tipo, valor, peso, vezes, sugerida, aceita, ultimo from perfil_uso where usuario = ? order by assunto, tipo, peso desc").all(String(e).trim())}function W(e,r,a,t,i){i!=="sugerida"&&i!=="aceita"||o.prepare("update perfil_uso set "+i+" = "+i+" + 1 where usuario = ? and assunto = ? and tipo = ? and valor = ?").run(String(e).trim(),r,a,String(t))}function V(e,r,a,t){const i=o.prepare("insert into termos_aprendidos (usuario, termo, assunto, peso, vezes, ultimo) values (?, ?, ?, ?, 1, datetime('now','localtime')) on conflict (usuario, termo, assunto) do update set peso = peso + excluded.peso, vezes = vezes + 1, ultimo = excluded.ultimo");for(const s of a)i.run(String(e).trim(),String(s),r,Number(t)||1)}function k(e,r){return r.length?o.prepare("select termo, assunto, peso, vezes from termos_aprendidos where usuario = ? and termo in ("+r.map(()=>"?").join(",")+")").all(String(e).trim(),...r.map(String)):[]}function z(e){return o.prepare("select termo, assunto, peso, vezes, ultimo from termos_aprendidos where usuario = ? order by peso desc limit 200").all(String(e).trim())}o.exec(`create table if not exists ultimo_resultado (
  usuario TEXT PRIMARY KEY COLLATE NOCASE,
  consulta TEXT NOT NULL,
  linhas TEXT NOT NULL,
  pergunta TEXT,
  texto TEXT,
  quando INTEGER NOT NULL
)`),o.prepare("pragma table_info(ultimo_resultado)").all().some(e=>e.name==="interacao")||o.exec("ALTER TABLE ultimo_resultado ADD COLUMN interacao INTEGER");function Q(e,r){o.prepare("update ultimo_resultado set interacao = ? where usuario = ?").run(Math.round(Number(r)||Date.now()),String(e).trim())}function K(e,r){const a=Math.round(Number(r.quando)||Date.now());o.prepare("insert or replace into ultimo_resultado (usuario, consulta, linhas, pergunta, texto, quando, interacao) values (?, ?, ?, ?, ?, ?, ?)").run(String(e).trim(),JSON.stringify(r.consulta),JSON.stringify(r.linhas),r.pergunta||null,r.texto||null,a,a)}function J(e){const r=o.prepare("select consulta, linhas, pergunta, texto, quando, interacao from ultimo_resultado where usuario = ?").get(String(e).trim());if(!r)return null;try{return{consulta:JSON.parse(r.consulta),linhas:JSON.parse(r.linhas),pergunta:r.pergunta,texto:r.texto,quando:Number(r.quando),interacao:Number(r.interacao)||Number(r.quando)}}catch{return null}}o.exec(`create table if not exists biometria (
  id TEXT PRIMARY KEY,
  usuario TEXT NOT NULL COLLATE NOCASE,
  chave TEXT NOT NULL,
  alg INTEGER NOT NULL,
  contador INTEGER NOT NULL DEFAULT 0,
  aparelho TEXT,
  dispositivo TEXT,
  criado TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  ultimo_uso TEXT
)`);function $(e){o.prepare("insert or replace into biometria (id, usuario, chave, alg, contador, aparelho, dispositivo) values (?, ?, ?, ?, ?, ?, ?)").run(String(e.id),String(e.usuario).trim(),String(e.chave),Number(e.alg),Number(e.contador)||0,e.aparelho||null,e.dispositivo||null)}function H(e){return o.prepare("select id, usuario, chave, alg, contador, aparelho, dispositivo, criado, ultimo_uso from biometria where id = ?").get(String(e))||null}function Z(e){return o.prepare("select id, usuario, alg, aparelho, dispositivo, criado, ultimo_uso from biometria where usuario = ? order by criado").all(String(e).trim())}function ee(e,r){o.prepare("update biometria set contador = ?, ultimo_uso = datetime('now','localtime') where id = ?").run(Number(r)||0,String(e))}function re(e,r){const a=r?o.prepare("delete from biometria where usuario = ? and id = ?").run(String(e).trim(),String(r)):o.prepare("delete from biometria where usuario = ?").run(String(e).trim());return Number(a.changes)||0}function oe(e){const r=d(e);return!r||!r.ativo?null:(o.prepare("update usuarios set ultimo_login = datetime('now','localtime'), falhas_login = 0 where usuario = ?").run(r.usuario),{usuario:r.usuario,nome:r.nome||r.usuario,master:!!r.master,login_anterior:r.ultimo_login||null})}o.exec(`create table if not exists cliente_compras (
  codigo TEXT PRIMARY KEY,
  primeira TEXT NOT NULL,
  ultima TEXT NOT NULL,
  exterior INTEGER NOT NULL DEFAULT 0,
  atualizado TEXT NOT NULL DEFAULT (datetime('now','localtime'))
)`),o.exec("create index if not exists ix_cliente_compras_primeira on cliente_compras (primeira)"),o.exec(`create table if not exists cache_info (
  chave TEXT PRIMARY KEY,
  valor TEXT
)`);function ae(e){const r=o.prepare("select valor from cache_info where chave = ?").get(String(e));return r?r.valor:null}function te(e,r){o.prepare("insert or replace into cache_info (chave, valor) values (?, ?)").run(String(e),r==null?null:String(r))}function ie(e,r){const a=o.prepare("insert into cliente_compras (codigo, primeira, ultima, exterior, atualizado) values (?, ?, ?, ?, datetime('now','localtime')) on conflict (codigo) do update set primeira = min(primeira, excluded.primeira), ultima = max(ultima, excluded.ultima), exterior = max(exterior, excluded.exterior), atualizado = excluded.atualizado");o.exec("BEGIN");try{r&&o.exec("delete from cliente_compras");for(const t of e)a.run(String(t.codigo),t.primeira,t.ultima,t.exterior?1:0);o.exec("COMMIT")}catch(t){throw o.exec("ROLLBACK"),t}}function se(e,r,a){const t=a==="brasil"?" and exterior = 0":a==="exterior"?" and exterior = 1":"";return o.prepare("select codigo from cliente_compras where primeira between ? and ?"+t+" order by codigo").all(String(e),String(r)).map(i=>i.codigo)}function ne(e){const r=new Map,a=(e||[]).map(String);for(let t=0;t<a.length;t+=500){const i=a.slice(t,t+500);for(const s of o.prepare("select codigo, primeira, ultima, exterior from cliente_compras where codigo in ("+i.map(()=>"?").join(",")+")").all(...i))r.set(s.codigo,{primeira:s.primeira,ultima:s.ultima,exterior:!!s.exterior})}return r}function ue(){const e=R();return o.exec("delete from cliente_compras"),e}function le(){return o.prepare("select min(atualizado) as d, max(atualizado) as u from cliente_compras").get()||{}}function R(){return Number(o.prepare("select count(*) as n from cliente_compras").get().n)||0}function D(e){o.prepare("delete from perfil_uso where usuario = ?").run(String(e).trim()),o.prepare("delete from termos_aprendidos where usuario = ?").run(String(e).trim())}function de(){return!o.prepare("select 1 from perfil_uso limit 1").get()&&!o.prepare("select 1 from termos_aprendidos limit 1").get()}function ce(){return o.prepare("select usuario, origem, texto, assunto, consulta from consultas where situacao = 'ok' and origem in ('pergunta', 'formulario', 'sugestao') and assunto is not null and consulta is not null order by id").all()}function me(e,r){const a=Math.max(1,Math.min(Number(r)||4,10));return o.prepare("select texto, count(*) as vezes, max(id) as id from consultas where usuario = ? and origem = 'pergunta' and situacao = 'ok' and texto is not null and trim(texto) <> '' and data_hora >= datetime('now', 'localtime', '-90 days') "+M+" group by lower(trim(texto)) having count(*) >= 2 order by vezes desc, id desc limit "+a).all(String(e).trim()).map(t=>({texto:t.texto,vezes:Number(t.vezes)}))}o.exec(`create table if not exists sessoes_encerradas (
  hash TEXT PRIMARY KEY,
  mensagem TEXT NOT NULL,
  quando INTEGER NOT NULL
)`);function pe(e,r){o.prepare("insert or replace into sessoes_encerradas (hash, mensagem, quando) values (?, ?, ?)").run(String(e),String(r),Date.now())}function _e(e){o.prepare("delete from sessoes_encerradas where quando < ?").run(Date.now()-7*24*3600*1e3);const r=o.prepare("select mensagem from sessoes_encerradas where hash = ?").get(String(e));return r?r.mensagem:null}function fe(e,r){o.prepare("insert or replace into sessoes (hash, usuario, nome, master, login_anterior, expira, criado, ip, aparelho, dispositivo, manter) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").run(String(e),String(r.usuario),r.nome||null,r.master?1:0,r.login_anterior||null,Math.round(Number(r.expira)),r.criado?Math.round(Number(r.criado)):null,r.ip||null,r.aparelho||null,r.dispositivo||null,r.manter?1:0)}function ge(e,r){o.prepare("update sessoes set expira = ? where hash = ?").run(Math.round(Number(r)),String(e))}function Ee(e){o.prepare("delete from sessoes where hash = ?").run(String(e))}function Te(){return o.prepare("delete from sessoes where expira < ?").run(Date.now()),o.prepare("select hash, usuario, nome, master, login_anterior, expira, criado, ip, aparelho, dispositivo, manter from sessoes").all()}function _(e){const r=g.randomBytes(16),a=g.scryptSync(String(e),r,64);return"scrypt$"+r.toString("hex")+"$"+a.toString("hex")}function L(e,r){const a=String(r||"").split("$");if(a.length!==3||a[0]!=="scrypt")return!1;const t=g.scryptSync(String(e),Buffer.from(a[1],"hex"),64),i=Buffer.from(a[2],"hex");return i.length===t.length&&g.timingSafeEqual(i,t)}function d(e){return o.prepare("select usuario, nome, email, senha_hash, master, ativo, ultimo_login from usuarios where usuario = ?").get(String(e||"").trim())||null}function f(e){const r=String(e||"").trim();return r.includes("@")?o.prepare("select usuario, nome, email, senha_hash, master, ativo, ultimo_login from usuarios where email = ? collate nocase").get(r)||null:d(r)}function he(e){const r=f(e);return r?r.usuario:String(e||"").trim()}function ve(e,r){const a=f(e);return!a||!a.ativo||!a.senha_hash?(_("x"),null):L(r,a.senha_hash)?(o.prepare("update usuarios set ultimo_login = datetime('now','localtime'), falhas_login = 0 where usuario = ?").run(a.usuario),{usuario:a.usuario,nome:a.nome||a.usuario,master:!!a.master,login_anterior:a.ultimo_login||null}):null}function we(e,r){const a=f(e);return!a||!a.ativo||!a.senha_hash?(_("x"),null):L(r,a.senha_hash)?{usuario:a.usuario,master:!!a.master}:null}function Se(e){const r=f(e);if(!r)return null;const a=o.prepare("select ativo, falhas_login, bloqueado_em, master from usuarios where usuario = ?").get(r.usuario);return{usuario:r.usuario,ativo:!!a.ativo,falhas:a.falhas_login||0,bloqueado_em:a.bloqueado_em||null,master:!!a.master}}function Le(e,r,a,t){const i=f(e);if(!i||!i.ativo)return null;r=Math.max(1,Number(r)||5),o.prepare("update usuarios set falhas_login = falhas_login + 1 where usuario = ?").run(i.usuario);const s=o.prepare("select falhas_login from usuarios where usuario = ?").get(i.usuario).falhas_login;let n=!1;return s>=r&&!i.master&&(o.prepare("update usuarios set ativo = 0, bloqueado_em = datetime('now','localtime') where usuario = ?").run(i.usuario),o.prepare("insert into log_bloqueios (usuario, ip, aparelho, tentativas) values (?, ?, ?, ?)").run(i.usuario,a||null,t||null,s),n=!0),{usuario:i.usuario,falhas:s,limite:r,inativado:n,master:!!i.master}}function N(e,r){const a=d(e);a&&(o.prepare("update usuarios set falhas_login = 0, bloqueado_em = null where usuario = ?").run(a.usuario),o.prepare("update log_bloqueios set desbloqueado_em = datetime('now','localtime'), desbloqueado_por = ? where usuario = ? and desbloqueado_em is null").run(String(r||"terminal"),a.usuario))}function Ne(e,r){const a=Math.max(1,Math.min(Number(r)||50,1e3)),t="select id, usuario, data_hora, ip, aparelho, tentativas, desbloqueado_em, desbloqueado_por from log_bloqueios"+(e?" where usuario = ?":"")+" order by data_hora desc, id desc limit "+a;return e?o.prepare(t).all(String(e).trim()):o.prepare(t).all()}function Ae(e,r){const a=r?Object.values(E):o.prepare("select distinct modulo from usuario_bi where usuario = ? and modulo is not null").all(String(e).trim()).map(t=>t.modulo);return Array.from(new Set(a)).sort((t,i)=>t.localeCompare(i,"pt-BR"))}function Oe(e){const r=d(e);if(!r||!r.ativo)return null;const a=o.prepare("select w_id from usuario_bi where usuario = ?").all(r.usuario).map(n=>Number(n.w_id)),t=o.prepare("select pode_email, pode_whats, pode_simulador, pode_integrar, pode_coletor, pode_col_manut, pode_col_etiq, pode_col_rastro, pode_sim_manut, pode_sim_custo, tela_inicial from usuarios where usuario = ?").get(r.usuario)||{},i=A(r.usuario),s=!i&&!r.master&&I.includes(t.tela_inicial)&&t.tela_inicial||"";return{usuario:r.usuario,nome:r.nome||r.usuario,master:!!r.master,tudo:i,wids:a,pode_email:i||t.pode_email!==0,pode_whats:i||t.pode_whats!==0,pode_simulador:i||t.pode_simulador===1||s==="simulador",pode_integrar:i||t.pode_integrar===1,pode_coletor:i||t.pode_coletor===1||s==="coletor",tela_inicial:s,pode_col_rastro:i||t.pode_col_rastro===1||s==="coletor_rastro",pode_col_manut:i||t.pode_col_manut===1,pode_col_etiq:i||t.pode_col_etiq===1,pode_sim_manut:i||t.pode_sim_manut===1&&(t.pode_simulador===1||s==="simulador"),pode_sim_custo:i||t.pode_sim_custo===1&&(t.pode_simulador===1||s==="simulador")}}const be=new Set(["desenv"]);function A(e){return be.has(String(e||"").toLowerCase())}function Ce(e){return o.prepare("select dados, salvo_em from simulador_ultima where usuario = ?").get(String(e))||null}function Ue(e,r){if(r==null){o.prepare("delete from simulador_ultima where usuario = ?").run(String(e));return}o.prepare("insert into simulador_ultima (usuario, dados) values (?, ?) on conflict (usuario) do update set dados = excluded.dados, salvo_em = datetime('now','localtime')").run(String(e),String(r))}function Ie(e){return o.prepare("select id, nome, salvo_em from simulador_salvas where usuario = ? order by salvo_em desc, id desc").all(String(e))}function Re(e,r){return o.prepare("select id, nome, dados, salvo_em from simulador_salvas where usuario = ? and id = ?").get(String(e),Number(r))||null}function De(e,r){return!!o.prepare("select 1 from simulador_salvas where usuario = ? and nome = ?").get(String(e),String(r))}function xe(e,r,a){o.prepare("insert into simulador_salvas (usuario, nome, dados) values (?, ?, ?) on conflict (usuario, nome) do update set nome = excluded.nome, dados = excluded.dados, salvo_em = datetime('now','localtime')").run(String(e),String(r),String(a))}function qe(e,r){return o.prepare("delete from simulador_salvas where usuario = ? and id = ?").run(String(e),Number(r)).changes>0}function Me(e){const r=o.prepare("select valor from sistema_config where chave = ?").get(String(e));return r?r.valor:null}function Pe(e){return o.prepare("select chave, valor, alterado_em, alterado_por from sistema_config where chave = ?").get(String(e))||null}function Xe(e,r,a){o.prepare("insert into sistema_config (chave, valor, alterado_por) values (?, ?, ?) on conflict (chave) do update set valor = excluded.valor, alterado_em = datetime('now','localtime'), alterado_por = excluded.alterado_por").run(String(e),r==null?null:String(r),a||null)}function ye(){return o.prepare("select chave, largura, altura, length(png) bytes, descricao, alterado_em, alterado_por from sistema_logo").all()}function Fe(e){const r=o.prepare("select png from sistema_logo where chave = ?").get(String(e));return r&&r.png?Buffer.from(r.png):null}function Ge(e,r){o.exec("BEGIN");try{o.prepare("delete from sistema_logo").run();const a=o.prepare("insert into sistema_logo (chave, largura, altura, png, descricao, alterado_por) values (?, ?, ?, ?, ?, ?)");for(const t of e)a.run(t.chave,t.largura,t.altura,t.png,t.descricao||null,r||null);o.exec("COMMIT")}catch(a){try{o.exec("ROLLBACK")}catch{}throw a}}function Be(e){const r=o.prepare("select valor from simulador_config where chave = ?").get(String(e));return r?r.valor:null}function je(e,r,a){o.prepare("insert into simulador_config (chave, valor, alterado_por) values (?, ?, ?) on conflict (chave) do update set valor = excluded.valor, alterado_em = datetime('now','localtime'), alterado_por = excluded.alterado_por").run(String(e),r==null?null:String(r),a||null)}const x=["frete","mkt","irpj","cont_soc","custo_adm","custo_fin","ppd","margem","comissao"];function Ye(e,r){if(!e||typeof e!="object")throw new Error("Tabela de par\xE2metros inv\xE1lida.");const a=o.prepare("pragma table_info(simulador_param_uf)").all().map(t=>t.name).filter(t=>x.includes(t));o.exec("BEGIN");try{for(const[t,i]of Object.entries(e)){const s=String(t).toUpperCase();if(!/^[A-Z]{2}$/.test(s))throw new Error("UF inv\xE1lida: "+t);const n=a.map(l=>{const u=i&&i[l];if(u===""||u==null)return null;const c=Number(String(u).replace(",","."));if(!isFinite(c)||c<0||c>100)throw new Error("Valor inv\xE1lido em "+s+" / "+l+" (use de 0 a 100).");return c});o.prepare("insert into simulador_param_uf (uf, "+a.join(", ")+", alterado_por) values (?, "+a.map(()=>"?").join(", ")+", ?) on conflict (uf) do update set "+a.map(l=>l+" = excluded."+l).join(", ")+", alterado_em = datetime('now','localtime'), alterado_por = excluded.alterado_por").run(s,...n,r||null)}o.exec("COMMIT")}catch(t){throw o.exec("ROLLBACK"),t}}function We(){const e={};for(const r of o.prepare("select * from simulador_param_uf").all()){const{uf:a,alterado_em:t,alterado_por:i,...s}=r;e[String(a).toUpperCase()]=s}return e}function Ve(e){return o.prepare("select id, nome, ordem, ativo, alterado_em, alterado_por from simulador_despesas"+(e?"":" where ativo = 1")+" order by ordem, nome").all()}function q(e){return{sql(r){const a=o.prepare("select sql_texto from "+e+" where chave = ? and ativo = 1").get(String(r||""));return a?a.sql_texto:null},lista(){return o.prepare("select chave, descricao, observacao, ativo, alterado_em, alterado_por from "+e+" order by chave").all()},ler(r){return o.prepare("select chave, descricao, sql_texto, observacao, ativo, alterado_em, alterado_por from "+e+" where chave = ?").get(String(r||""))||null},gravar(r,a,t,i){return o.prepare("update "+e+" set sql_texto = ?, ativo = ?, alterado_em = datetime('now','localtime'), alterado_por = ? where chave = ?").run(String(a),t?1:0,String(i||""),String(r||"")).changes>0}}}function ke(e){const r=o.prepare("select pode_biometria from usuarios where usuario = ?").get(String(e||"").trim());return!!r&&r.pode_biometria!==0}function ze(e){return o.prepare("select * from coletor_reserva where id_transacao = ?").get(String(e))||null}function Qe(e){o.prepare("insert into coletor_reserva (id_transacao, usuario, dispositivo, aparelho, tipo, nr_docto, cliente, transportadora) values (?, ?, ?, ?, ?, ?, ?, ?) on conflict (id_transacao) do update set tipo = coalesce(excluded.tipo, coletor_reserva.tipo), nr_docto = coalesce(excluded.nr_docto, coletor_reserva.nr_docto), cliente = coalesce(excluded.cliente, coletor_reserva.cliente), transportadora = coalesce(excluded.transportadora, coletor_reserva.transportadora), aparelho = excluded.aparelho, ultimo_uso = datetime('now','localtime')").run(String(e.id_transacao),String(e.usuario),String(e.dispositivo),e.aparelho||null,e.tipo||null,e.nr_docto||null,e.cliente||null,e.transportadora||null)}function Ke(e){o.prepare("update coletor_reserva set ultimo_uso = datetime('now','localtime') where id_transacao = ?").run(String(e))}function Je(e){return o.prepare("delete from coletor_reserva where id_transacao = ?").run(String(e)).changes>0}function $e(e){return e?o.prepare("select * from coletor_reserva where usuario = ? order by ultimo_uso desc").all(String(e)):o.prepare("select * from coletor_reserva order by ultimo_uso desc").all()}const h=q("simulador_sql"),v=q("coletor_sql"),He=h.sql,Ze=h.lista,er=h.ler,rr=h.gravar,or=v.sql,ar=v.lista,tr=v.ler,ir=v.gravar;function sr(e,r,a){a=a||{};const t=O(e,a);o.prepare("insert into usuarios (usuario, nome, senha_hash, master, email, celular, pode_email, pode_whats, pode_biometria) values (?, ?, ?, ?, ?, ?, 0, 0, 0)").run(t.usuario,a.nome||t.usuario,r?_(r):null,a.master?1:0,t.email,t.celular)}function O(e,r){if(r=r||{},e=String(e||"").trim(),!/^[A-Za-z0-9._-]{2,40}$/.test(e))throw new Error("Usuario invalido (use letras, numeros, ponto, traco; 2 a 40 caracteres).");if(d(e))throw new Error("Usuario ja existe: "+d(e).usuario);const a=r.email?b(r.email,null):null,t=r.celular?C(r.celular,null):null;return{usuario:e,email:a,celular:t}}const nr=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;function b(e,r){const a=String(e||"").trim().toLowerCase();if(a.length>120||!nr.test(a))throw new Error("E-mail invalido: "+e);const t=o.prepare("select usuario from usuarios where email = ? collate nocase and usuario <> ?").get(a,r||"");if(t)throw new Error("Este e-mail ja esta cadastrado no usuario "+t.usuario+".");return a}function C(e,r){let a=String(e||"").replace(/\D/g,"");if((a.length===10||a.length===11)&&(a="55"+a),!/^55\d{10,11}$/.test(a))throw new Error("Celular invalido: "+e+" (use DDD + numero, ex.: 54999998888).");const t=o.prepare("select usuario from usuarios where celular = ? and usuario <> ?").get(a,r||"");if(t)throw new Error("Este celular ja esta cadastrado no usuario "+t.usuario+".");return a}function ur(e){const r=String(e||"").match(/^55(\d{2})(\d{4,5})(\d{4})$/);return r?"+55 ("+r[1]+") "+r[2]+"-"+r[3]:e||""}function lr(e,r){const a=d(e);if(!a)throw new Error("Usuario nao encontrado: "+e);const t=String(r||"").trim(),i=t==="-"||t===""?null:b(t,a.usuario);return o.prepare("update usuarios set email = ? where usuario = ?").run(i,a.usuario),i}function dr(e,r){const a=d(e);if(!a)throw new Error("Usuario nao encontrado: "+e);const t=String(r||"").trim(),i=t==="-"||t===""?null:C(t,a.usuario);return o.prepare("update usuarios set celular = ? where usuario = ?").run(i,a.usuario),i}function cr(e){const r=d(e);return r&&r.email?r.email:null}function mr(e,r){if(!d(e))throw new Error("Usuario nao encontrado: "+e);o.prepare("update usuarios set senha_hash = ? where usuario = ?").run(_(r),String(e).trim())}function pr(e,r,a){const t=d(e);return!t||!t.ativo||!t.senha_hash?{ok:!1,motivo:"atual",mensagem:"Senha atual incorreta."}:L(r,t.senha_hash)?(a=String(a||""),a.length<4?{ok:!1,motivo:"regra",mensagem:"A nova senha precisa ter pelo menos 4 caracteres."}:a.length>200?{ok:!1,motivo:"regra",mensagem:"A nova senha pode ter no maximo 200 caracteres."}:a===String(r)?{ok:!1,motivo:"regra",mensagem:"A nova senha precisa ser diferente da atual."}:(o.prepare("update usuarios set senha_hash = ? where usuario = ?").run(_(a),t.usuario),{ok:!0})):{ok:!1,motivo:"atual",mensagem:"Senha atual incorreta."}}function _r(e,r,a){if(!["ativo","master","nome","pode_email","pode_whats","pode_simulador","pode_integrar","pode_coletor","pode_col_manut","pode_col_etiq","pode_col_rastro","pode_sim_manut","pode_sim_custo","pode_biometria"].includes(r))throw new Error("Campo invalido.");if(!d(e))throw new Error("Usuario nao encontrado: "+e);o.prepare("update usuarios set "+r+" = ? where usuario = ?").run(a,String(e).trim()),r==="ativo"&&Number(a)===1&&N(e,"terminal")}function fr(e,r){if(!d(e))throw new Error("Usuario nao encontrado: "+e);o.prepare("insert into usuario_bi (usuario, w_id, modulo) values (?, ?, ?) on conflict (usuario, w_id) do update set modulo = excluded.modulo").run(String(e).trim(),Number(r),T(r))}function gr(e,r){o.prepare("delete from usuario_bi where usuario = ? and w_id = ?").run(String(e).trim(),Number(r))}function Er(e){o.prepare("delete from usuarios where usuario = ?").run(String(e).trim()),D(e),o.prepare("delete from ultimo_resultado where usuario = ?").run(String(e).trim()),o.prepare("delete from biometria where usuario = ?").run(String(e).trim()),o.prepare("delete from simulador_ultima where usuario = ?").run(String(e).trim()),o.prepare("delete from simulador_salvas where usuario = ?").run(String(e).trim()),o.prepare("delete from coletor_reserva where usuario = ?").run(String(e).trim())}function Tr(e,r){e=e||{};const a=e.senha==null?"":String(e.senha);if(r&&!a)throw new Error("Informe a senha do novo usu\xE1rio.");if(a&&(a.length<4||a.length>200))throw new Error("A senha precisa ter de 4 a 200 caracteres.");const t=String(e.email||"").trim(),i=String(e.celular||"").trim(),s=String(e.nome||"").trim().slice(0,80);let n;o.exec("BEGIN");try{if(r){const u=O(e.usuario,{email:t||null,celular:i||null});o.prepare("insert into usuarios (usuario, nome, senha_hash, email, celular) values (?, ?, ?, ?, ?)").run(u.usuario,s||u.usuario,_(a),u.email,u.celular),n=u.usuario}else{const u=d(e.usuario);if(!u)throw new Error("Usu\xE1rio n\xE3o encontrado: "+e.usuario);n=u.usuario,o.prepare("update usuarios set email = ?, celular = ? where usuario = ?").run(t?b(t,n):null,i?C(i,n):null,n),a&&o.prepare("update usuarios set senha_hash = ? where usuario = ?").run(_(a),n)}const l=!e.master&&!A(n)&&I.includes(String(e.tela_inicial||""))?String(e.tela_inicial||""):"";if(o.prepare("update usuarios set nome = ?, master = ?, ativo = ?, pode_email = ?, pode_whats = ?, pode_simulador = ?, pode_integrar = ?, pode_coletor = ?, pode_col_manut = ?, pode_col_etiq = ?, pode_col_rastro = ?, pode_sim_manut = ?, pode_sim_custo = ?, pode_biometria = ?, tela_inicial = ? where usuario = ?").run(s||n,e.master?1:0,e.ativo===!1?0:1,e.pode_email===!1?0:1,e.pode_whats===!1?0:1,e.pode_simulador||l==="simulador"?1:0,e.pode_integrar?1:0,e.pode_coletor||l==="coletor"?1:0,e.pode_col_manut?1:0,e.pode_col_etiq?1:0,e.pode_col_rastro||l==="coletor_rastro"?1:0,e.pode_sim_manut&&(e.pode_simulador||l==="simulador")?1:0,e.pode_sim_custo&&(e.pode_simulador||l==="simulador")?1:0,e.pode_biometria===!1?0:1,l,n),e.ativo!==!1){const u=o.prepare("select bloqueado_em, falhas_login from usuarios where usuario = ?").get(n);u&&(u.bloqueado_em||u.falhas_login)&&N(n,e.por||"gestao")}if(Array.isArray(e.bis)){o.prepare("delete from usuario_bi where usuario = ?").run(n);const u=o.prepare("insert into usuario_bi (usuario, w_id, modulo) values (?, ?, ?)");for(const c of new Set(e.bis.map(Number)))T(c)&&u.run(n,c,T(c))}o.exec("COMMIT")}catch(l){throw o.exec("ROLLBACK"),l}return n}function hr(e){o.prepare("insert into consultas (usuario, ip, origem, texto, assunto, consulta, sql_texto, situacao, mensagem, tempo_ms) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)").run(e.usuario,e.ip||null,e.origem||null,e.texto||null,e.assunto||null,e.consulta||null,e.sql||null,e.situacao||null,e.mensagem||null,e.tempo_ms==null?null:Number(e.tempo_ms))}const M=` and (consulta is null or consulta not like '%"continuou":true%')`;function vr(e,r){const a=Math.max(1,Math.min(Number(r)||10,50));return o.prepare("select texto, data_hora, max(id) as id from consultas where usuario = ? and origem = 'pergunta' and situacao = 'ok' and texto is not null and trim(texto) <> '' "+M+" group by lower(trim(texto)) order by id desc limit "+a).all(String(e).trim()).map(t=>({texto:t.texto,data_hora:t.data_hora}))}function P(e){const r=(e||[]).map(a=>String(a).toLowerCase()).filter(Boolean);return{sql:r.length?" and lower(usuario) not in ("+r.map(()=>"?").join(",")+")":"",args:r}}function wr(e,r){const a=Math.max(0,Math.round(Number(e)||0)),t=P(r),i="select assunto, count(*) as total, count(distinct usuario) as usuarios, max(data_hora) as ultimo from consultas where origem in ('pergunta', 'formulario', 'ia', 'sugestao') and situacao = 'ok' and assunto is not null and assunto <> ''"+(a?" and data_hora >= datetime('now', 'localtime', ?)":"")+t.sql+" group by assunto order by total desc";return o.prepare(i).all(...a?["-"+a+" days"]:[],...t.args)}function Sr(e,r){const a=Math.max(0,Math.round(Number(e)||0)),t=P(r),i=(a?" and data_hora >= datetime('now', 'localtime', ?)":"")+t.sql,s=(a?["-"+a+" days"]:[]).concat(t.args),n=o.prepare("select usuario, count(*) as pesquisas, count(distinct assunto) as relatorios, max(data_hora) as ultima from consultas where origem in ('pergunta', 'formulario', 'ia', 'sugestao') and situacao = 'ok'"+i+" group by usuario").all(...s),l=o.prepare("select usuario, count(*) as entradas, max(data_hora) as ultima from acessos where evento in ('login', 'login_biometria')"+i+" group by usuario").all(...s),u=new Map,c=m=>{const w=String(m).toLowerCase();return u.has(w)||u.set(w,{usuario:m,pesquisas:0,relatorios:0,entradas:0,ultima_pesquisa:null,ultima_entrada:null}),u.get(w)};for(const m of n)Object.assign(c(m.usuario),{pesquisas:Number(m.pesquisas),relatorios:Number(m.relatorios),ultima_pesquisa:m.ultima});for(const m of l)Object.assign(c(m.usuario),{entradas:Number(m.entradas),ultima_entrada:m.ultima});return[...u.values()]}function Lr(e,r){const a=Math.max(1,Math.min(Number(r)||20,1e3)),t="select id, data_hora, usuario, origem, texto, situacao, tempo_ms from consultas"+(e?" where usuario = ?":"")+" order by id desc limit "+a;return e?o.prepare(t).all(String(e).trim()):o.prepare(t).all()}function Nr(e){o.prepare("insert into acessos (usuario, ip, evento, navegador) values (?, ?, ?, ?)").run(String(e.usuario||"").slice(0,60),e.ip||null,e.evento,e.navegador?String(e.navegador).slice(0,300):null)}function Ar(e,r){const a=Math.max(1,Math.min(Number(r)||20,1e3)),t="select id, data_hora, usuario, ip, evento, navegador from acessos"+(e?" where usuario = ?":"")+" order by data_hora desc, id desc limit "+a;return e?o.prepare(t).all(String(e).trim()):o.prepare(t).all()}function Or(){const e=o.prepare("select usuario, nome, email, celular, master, ativo, pode_email, pode_whats, pode_simulador, pode_integrar, pode_coletor, pode_col_manut, pode_col_etiq, pode_col_rastro, pode_sim_manut, pode_sim_custo, pode_biometria, tela_inicial, falhas_login, bloqueado_em, senha_hash is not null as tem_senha, ultimo_login, criado_em from usuarios order by usuario").all();for(const r of e)r.bis=o.prepare("select w_id from usuario_bi where usuario = ? order by w_id").all(r.usuario).map(a=>a.w_id);return e}function br(e,r){const a=String(e||"").trim();if(!a||a==="?")return null;const t=o.prepare("select versao from versoes_instaladas order by id desc limit 1").get();return t&&t.versao===a?null:(o.prepare("insert into versoes_instaladas (versao, anterior, por) values (?, ?, ?)").run(a,t?t.versao:null,r||null),{versao:a,anterior:t?t.versao:null,por:r||null})}function Cr(){const e={};for(const r of o.prepare("select versao, min(instalada_em) instalada_em from versoes_instaladas group by versao").all())e[r.versao]=r.instalada_em;return e}function Ur(){return o.prepare("select versao, anterior, instalada_em, por from versoes_instaladas order by id").all()}function Ir(e){const r=f(e);if(!r||!r.email)return null;const a=o.prepare("select ativo, bloqueado_em from usuarios where usuario = ?").get(r.usuario);return!a.ativo&&!a.bloqueado_em?null:{usuario:r.usuario,nome:r.nome||r.usuario,email:r.email,bloqueado:!a.ativo}}function Rr(e,r,a,t){o.prepare("update senha_redefinir set usado_em = 'substituido' where usuario = ? and usado_em is null").run(String(e)),o.prepare("insert into senha_redefinir (usuario, token_hash, expira_em, ip) values (?, ?, datetime('now','localtime', ?), ?)").run(String(e),String(r),"+"+Math.round(a)+" minutes",t||null),o.prepare("delete from senha_redefinir where criado_em < datetime('now','localtime','-30 days')").run()}function Dr(e){const r=o.prepare("select (julianday('now','localtime') - julianday(criado_em)) * 86400 seg from senha_redefinir where usuario = ? order by id desc limit 1").get(String(e));return r?r.seg:null}function xr(e){const r=o.prepare("select id, usuario from senha_redefinir where token_hash = ? and usado_em is null and expira_em > datetime('now','localtime')").get(String(e));if(!r)return null;const a=o.prepare("select usuario, nome, ativo, bloqueado_em from usuarios where usuario = ?").get(r.usuario);return!a||!a.ativo&&!a.bloqueado_em?null:{id:r.id,usuario:a.usuario,nome:a.nome||a.usuario,bloqueado:!a.ativo}}function qr(e,r,a){o.exec("BEGIN");try{if(!o.prepare("update senha_redefinir set usado_em = datetime('now','localtime') where id = ? and usado_em is null").run(Number(e)).changes)throw new Error("link j\xE1 usado");const i=o.prepare("select ativo, bloqueado_em from usuarios where usuario = ?").get(String(r));o.prepare("update usuarios set senha_hash = ?, falhas_login = 0 where usuario = ?").run(_(a),String(r));let s=!1;return i&&!i.ativo&&i.bloqueado_em&&(o.prepare("update usuarios set ativo = 1, bloqueado_em = null where usuario = ?").run(String(r)),o.prepare("update log_bloqueios set desbloqueado_em = datetime('now','localtime'), desbloqueado_por = 'nova senha por e-mail' where usuario = ? and desbloqueado_em is null").run(String(r)),s=!0),o.exec("COMMIT"),{desbloqueou:s}}catch(t){try{o.exec("ROLLBACK")}catch{}throw t}}require("./migracoes").aplicar(o,S),module.exports={ARQUIVO:S,autenticar:ve,conferirLogin:we,situacaoLogin:Se,registrarFalhaLogin:Le,desbloquearPorSenha:N,logBloqueios:Ne,nomeDoLogin:he,emailDe:cr,permissoes:Oe,criarUsuario:sr,conferirNovoUsuario:O,definirEmail:lr,definirCelular:dr,formatarCelular:ur,trocarSenha:mr,trocarSenhaPropria:pr,definir:_r,salvarUsuarioAdmin:Tr,liberarBi:fr,removerBi:gr,excluirUsuario:Er,listar:Or,registrarConsulta:hr,ultimasConsultas:Lr,usoPorAssunto:wr,usoPorUsuario:Sr,ultimasPerguntas:vr,registrarAcesso:Nr,ultimosAcessos:Ar,modulosDoUsuario:Ae,moduloDe:T,geoLer:X,geoGravar:y,sessaoGravar:fe,sessaoRenovar:ge,sessaoApagar:Ee,sessoesValidas:Te,encerradaGravar:pe,encerradaLer:_e,painelCacheLer:F,painelCacheGravar:G,perfilRegistrar:j,perfilLer:Y,perfilMarcar:W,termosRegistrar:V,termosLer:k,termosDoUsuario:z,aprendizadoApagar:D,aprendizadoVazio:de,consultasParaAprender:ce,perguntasFrequentes:me,resultadoGravar:K,resultadoLer:J,resultadoInteracao:Q,biometriaGravar:$,biometriaLer:H,biometriaDoUsuario:Z,biometriaUso:ee,biometriaApagar:re,entrarSemSenha:oe,cacheInfo:ae,cacheInfoGravar:te,clienteComprasGravar:ie,clientesPrimeiraCompra:se,clienteComprasLer:ne,clienteComprasContar:R,clienteComprasLimpar:ue,clienteComprasDesde:le,sistemaConfig:Me,sistemaConfigLer:Pe,sistemaConfigGravar:Xe,sempreTudo:A,logoVariantes:ye,logoPng:Fe,logoGravar:Ge,simDespesas:Ve,simSql:He,simSqlLista:Ze,simSqlLer:er,simSqlGravar:rr,colSql:or,colSqlLista:ar,colSqlLer:tr,colSqlGravar:ir,colReservaLer:ze,colReservaGravar:Qe,colReservaTocar:Ke,colReservaApagar:Je,colReservas:$e,podeBiometria:ke,simParamUf:We,simParamUfSalvar:Ye,simConfig:Be,simConfigGravar:je,SIM_PARAM_COLS:x,simUltimaLer:Ce,simUltimaGravar:Ue,simSalvasListar:Ie,simSalvaLer:Re,simSalvaExiste:De,simSalvaGravar:xe,simSalvaExcluir:qe,versaoInstaladaRegistrar:br,versoesInstaladas:Cr,versoesInstaladasLista:Ur,redefinirAlvo:Ir,redefinirCriar:Rr,redefinirUltimo:Dr,redefinirBuscar:xr,redefinirAplicar:qr};
