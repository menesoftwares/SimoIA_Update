# Novidades do SimoIA

Texto mostrado na guia "Atualizações" da Gestão, escrito para quem usa o sistema.
Os detalhes técnicos de cada versão ficam em `docs/VERSOES.md`.

---

## 1.0.0.50 — 13/11/2026

### Simulador: Excel personalizado
- Na **Gestão › Simulador**, novo quadro **Excel personalizado** (acima dos SQLs, para qualquer usuário master): monte as colunas da planilha, com o nome de cada cabeçalho e o campo do produto que vai nela (código, descrição, preços, descontos, impostos, totais, margens e outros). Dá para mudar a ordem e remover colunas.
- No Simulador, **Opções Simulação › Gerar Excel Personalizado** baixa a planilha nessa ordem, uma linha por produto, com os valores da tela. As colunas de margem só saem quando você escolhe "Com margens".

### Conf. interna: limpar o log de e-mails
- Botão **Limpar log** na lista dos últimos e-mails enviados.

---

## 1.0.0.49 — 13/11/2026

### Avisos do sistema por e-mail
- Nova guia **Conf. interna** na Gestão (só para o administrador do sistema): cadastro do e-mail que o sistema usa para enviar mensagens e da lista de quem recebe os avisos.
- Avisos possíveis: banco de dados fora do ar (Pesquisas, Simulador ou Coletor) e quando volta, atualização concluída, erro na atualização, versão nova disponível, usuário bloqueado por senha errada, serviço iniciado e erro interno do servidor.

### Gestão: conexões com o banco para todos os master
- Na **Gestão › Dados do banco**, qualquer usuário master pode trocar as conexões com o banco (Pesquisas, Simulador e Coletor) pelo botão **Testar e aplicar**.

### Gestão: cadastro de usuário reorganizado
- No quadro **Acesso**, a opção **Entrar com digital/rosto** fica ao lado da senha, e **Ativo** e **Master** ficam abaixo da senha, na mesma linha.

---

## 1.0.0.48 — 12/11/2026

### Gestão: confirmações na própria tela
- Todas as perguntas de confirmação da Gestão (excluir usuário, fazer logoff, reiniciar o serviço, limpar cache, trocar conexão, trocar o logo e as demais) abrem uma janela da própria tela, no lugar do aviso do navegador.

---

## 1.0.0.47 — 12/11/2026

### Gestão: confirmação do "Atualizar agora" na própria tela
- Ao clicar em **Atualizar agora** (guia Atualizações), a confirmação abre uma janela da própria tela, no lugar do aviso do navegador.

### Simulador: sem zoom no celular
- No celular, abrir o **Carregar pedido** (botão **Pedidos**) não amplia mais a tela.

---

## 1.0.0.46 — 12/11/2026

### Atualização automática do sistema
- Na **Gestão › Gerais**, nova opção **Atualizar Sistema Automaticamente**: marque, informe a hora e salve.
- Todo dia nessa hora o sistema procura uma versão nova e, se houver, se atualiza sozinho (fica fora do ar por cerca de 1 minuto). Escolha um horário sem uso, como de madrugada.
- A tela mostra o resultado da última verificação automática.

---

## 1.0.0.45 — 11/11/2026

### Simulador: imprimir relatório e gerar Excel
- No botão **Opções Simulação**, duas opções novas: **Imprimir relatório** (o mesmo PDF do Compartilhar, direto para a impressora) e **Gerar Excel** (planilha com os dados da simulação e os itens linha a linha).
- As duas perguntam se vão **com margens** ou **sem margens (para o cliente)**. O custo nunca vai.

### Simulador: só com a margem calculada
- **Compartilhar**, **Imprimir relatório** e **Gerar Excel** só liberam depois de calcular os tributos (com a **Margem geral** aparecendo).

### Simulador: confirmações na própria tela
- As perguntas de confirmação (Limpar Simulação, tirar todos os itens, salvar por cima, excluir ou carregar simulação salva) abrem uma janela da própria tela, no lugar do aviso do navegador.

---

## 1.0.0.44 — 11/11/2026

### Simulador: imposto IS
- Novo imposto **IS** (Imposto Seletivo), calculado como o IBS/CBS: chave Sim/Não e % geral no quadro **Tributos**, e o % de cada produto na linha **(+)**.
- A coluna dos itens agora é **Vl IBS/CBS/IS**, e o quadro **Impostos** e o PDF mostram **IBS + CBS + IS**.

### Simulador: salvar e carregar simulações
- Novo botão **Opções Simulação**: **Salvar** guarda a simulação com um nome, e **Carregar** mostra as suas simulações salvas para abrir ou excluir. Cada usuário vê só as suas.

### Simulador: botão Pedidos
- **Carregar pedido** e **Últimos 5 pedidos** agora ficam dentro do botão **Pedidos**. A linha do topo ficou com 6 botões (no celular, 2 linhas de 3).
- **Carregar pedido** fica sempre liberado: o cliente vem do pedido e, se estiverem vazios, o **Tipo Docto** e a **tabela de preço** também. O custo fica o primeiro da lista.

### Simulador: margem só com os tributos calculados
- Enquanto algum item estiver sem tributos, a **Margem geral** não aparece, e o botão **Calcular tributos** fica amarelo. Depois de calcular, a margem volta.

### Simulador: ajustes na tela
- Os botões ▶ da **Tabela de preço** e dos **Descontos padrão** ficaram mais baixos, com o mesmo símbolo.

---

## 1.0.0.43 — 10/11/2026

### Usuários: permissão para selecionar o custo no Simulador
- Nova caixa **Simulador de preços (permite selecionar custo)** no cadastro de usuários. Sem ela, o campo **Custo** do Simulador mostra todos os custos, mas só o primeiro da lista pode ser escolhido. Começa desmarcada para todos.
- **Integrar pedidos (simulador)** agora se chama **Simulador de preços (integrar pedidos)**, e as caixas foram reorganizadas em linhas: Simulador, depois custo e integrar pedidos, depois Coletor.

### Simulador: tabela de preço por código
- O campo **Tabela de preço** mostra cada tabela como **código - descrição**, em ordem de código.

### Gestão › Atualizações
- A versão nova aparece em até 1 minuto depois de publicada (antes podia levar até 5 minutos).

---

## 1.0.0.42 — 10/11/2026

### Simulador: ICMS como desconto só quando dispensado
- O **ICMS** só é abatido do total do pedido quando o sistema informa um **valor de ICMS dispensado** (desconto do tipo de documento). Nos demais casos, o ICMS volta a ser calculado normalmente, incluso no preço.

---

## 1.0.0.41 — 10/11/2026

### Simulador: margem sem os tributos descontados
- Quando o **ICMS** ou o **PIS/COFINS** vem como desconto do total do pedido, esse valor **não entra mais no cálculo da margem**. Só o imposto incluso continua sendo descontado do resultado.

---

## 1.0.0.40 — 10/11/2026

### Simulador: atualizar os itens
- Novo botão **↻** ao lado de **Limpar itens**: atualiza os produtos da simulação com os dados mais recentes (preços, custos e impostos), sem perder quantidades, descontos e valores digitados.

---

## 1.0.0.39 — 09/11/2026

### Gestão › Atualizações: atualizar pelo sistema
- No topo da guia **Atualizações** aparece se há uma **versão nova** disponível, com as novidades dela.
- O botão **Atualizar agora** (só para master) baixa e instala a versão sozinho: o sistema fica fora do ar por cerca de 1 minuto e volta já atualizado, e a página recarrega sozinha. O banco e as configurações não mudam, e o código anterior fica guardado.
- **Verificar de novo** consulta na hora se saiu versão nova.

---

## 1.0.0.38 — 09/11/2026

### Simulador: tributos como desconto
- Quando o sistema manda o **ICMS** ou o **PIS/COFINS** como desconto (ex.: Zona Franca), o imposto é calculado normalmente, mas o valor é **abatido do total do pedido**.
- No quadro **Pedido**, nova linha **Valor tributos desconto**. No quadro **Impostos**, novas linhas **ICMS (descontado)** e **PIS/COFINS (descontado)**.

### Simulador: campo Cidade
- Novo campo **Cidade** nas Configurações, ao lado da UF de venda. Com cliente, vem do cadastro dele; sem cliente, escolha entre as cidades da UF. A cidade entra no cálculo dos impostos.
- A UF ficou mais estreita e a Cidade mais larga, aproveitando o espaço que sobrava depois do Suframa.

### Simulador: simulação anterior com impostos
- Ao abrir a **simulação anterior**, os impostos são buscados mesmo com a chave **Online** em **Não**.

---

## 1.0.0.37 — 07/11/2026

### Gestão › Gerais: site da empresa
- Novo campo **Site da empresa**: o link do rodapé da tela inicial agora pode ser trocado por ali. Deixando o campo vazio, o rodapé fica sem link.

---

## 1.0.0.36 — 07/11/2026

### Celular: botão Voltar ao lado do título
- No celular, o botão **Voltar** não fica mais abaixo do título: na **Manutenção do Coletor**, na **Rastreabilidade**, em **Gerar etiqueta**, no **Documento**, na **Gestão do sistema** e em **Notícias**, ele aparece na mesma linha.

### Coletor: Imprimir e Compartilhar na Rastreabilidade
- Os botões **Imprimir** e **Compartilhar** da **Rastreabilidade** ficam agora num balão próprio, logo abaixo do título. Eles liberam quando a pesquisa traz resultado.

---

## 1.0.0.35 — 07/11/2026

### Gestão: nova guia Gerais
- **Logo principal:** troque o logo do sistema enviando uma imagem (PNG, JPG, WebP ou SVG). Ele é ajustado sozinho aos tamanhos de cada tela, sem distorcer, e vale na tela inicial, no ícone do app instalado (Android e iPhone), no ícone da aba do navegador, no Coletor, no Simulador e nos PDFs.
- Dá para escolher a **cor de fundo** dos ícones do iPhone e do Android e **voltar ao logo do projeto** quando quiser.
- **Título da página:** o nome do sistema (hoje "SimoIA") pode ser trocado. Ele aparece na aba do navegador, nos cabeçalhos, no app instalado, nos PDFs, nos e-mails, nas mensagens de WhatsApp e nos arquivos baixados.

### Botão Voltar ao Home
- Os botões **Voltar ao SimoIA** agora se chamam **Voltar ao Home**.

### Cadastro de usuário: tela padrão do Coletor
- Em **Depois do login, abrir**, a opção **Coletor** agora se chama **Coletor (conf)**, e há a nova **Coletor (rast)**, que entra direto na **Rastreabilidade**.
- Escolher uma opção do Coletor desmarca as caixas do Simulador, e escolher Simulador desmarca as do Coletor.

### Coletor: datas da Manutenção no celular
- Os filtros de data da **Manutenção do Coletor** não ficam mais sobrepostos no celular.

---

## 1.0.0.34 — 06/11/2026

### Coletor: mais filtros na Manutenção
- A pesquisa da **Manutenção do Coletor** ganhou **Coleta inicial**, **Coleta final** e **Status** (Todos, Em Conferência, A conferir e Conferidas). As datas que já existiam agora se chamam **Emissão inicial** e **Emissão final**.
- Novo balão **Conferidas**, com as notas finalizadas: emissão, período da coleta, data da finalização e quem finalizou.
- Nota **A conferir** ainda não tem coleta, então não aparece em pesquisa por data de coleta.

---

## 1.0.0.33 — 06/11/2026

### Coletor: nova tela inicial
- A tela do Coletor agora se chama **Sistema de Coleta** e abre com os balões **Manutenção**, **Gerar etiqueta** e **Coletor**. Cada um tem um botão com ícone à direita.
- O balão **Coletor** abre a conferência das notas. Ao finalizar ou sair de uma coleta, o conferente continua na tela de Documento.
- Cada balão só aparece para quem tem a liberação dele. Quem tem um único acesso abre direto nele.
- O botão **Voltar** dentro dos balões retorna à tela inicial e ficou mais baixo.

### Coletor: vírgula na quantidade conforme o produto
- Mesmo com **Permitir quantidade com vírgula** ligado, o produto com **Qtd múltipla** inteira só aceita quantidade inteira. Qtd múltipla zero ou fracionada aceita vírgula.

### Coletor: Rastreabilidade
- Novo botão **Rastreabilidade** no Sistema de Coleta, para quem tem a liberação **Coletor (rastro)** no cadastro. Ela vem desmarcada para todos, inclusive master.
- O botão só fica habilitado com **Exigir lote produto na conferência** ou **Exigir lote kit na conferência** ligado em **Gestão › Coletor**.
- Informe o **produto** e o **lote** e toque em **Pesquisar**. O botão só libera com os dois preenchidos.
- O resultado mostra o **número do documento**, a **pessoa**, a **cidade**, o **estado** e a **quantidade com a unidade**, uma nota por linha, com o produto, o lote e a validade no cabeçalho. A pesquisa usa só as conferências finalizadas no Coletor.
- Use **Imprimir** para sair o relatório, ou **Compartilhar** para enviá-lo em PDF por e-mail ou WhatsApp, conforme as liberações do seu usuário.

### Coletor: pesquisa na Manutenção
- A tela **Manutenção do Coletor** agora abre sem carregar as notas. Informe a **data inicial**, a **data final** ou o **número da NF-e** e toque em **Pesquisar**. O botão **Atualizar** saiu: para ler de novo, toque em Pesquisar.
- As datas são da emissão da nota. Com os campos em branco, aparecem as notas em conferência e as a conferir desde a data dos ajustes.

### Coletor: correção nas telas de espera
- As janelas de espera, como **Liberando nota** e **Pesquisando**, voltam a aparecer sem botões. Antes, mostravam botões da pergunta anterior, que não faziam nada.

### Coletor: pesquisa geral em Gerar etiqueta
- Nos campos **Produto** e **Kit**, digitar **3 espaços** lista todos os itens, em ordem de nome.

### Celular: botões mais organizados
- No **Simulador**, os botões do topo ficam em 3 por linha, todos do mesmo tamanho.
- O botão do Simulador passa a se chamar **Limpar Simulação**.

---

## 1.0.0.32 — 05/11/2026

### Coletor: etiqueta do tamanho exato do rolo
- Em **Gestão › Coletor › Ajustes**, a largura e a altura agora são da **linha de etiquetas, em milímetros**. Exemplo: 100 x 20 mm com 2 por linha gera etiquetas de 50 x 20 mm.
- Cada linha de etiquetas sai em uma página do tamanho exato da linha, sem folha em volta.
- Em etiquetas baixas e largas, o QR code fica à esquerda e o texto à direita, para ficar legível.
- Na impressora térmica, configure no driver um papel do mesmo tamanho da linha e imprima em escala de 100%.

### Coletor: leitura pela câmera
- Novo ajuste **Permitir usar câmera** em **Gestão › Coletor › Ajustes**, que vem desligado.
- Ligado, aparece um pequeno botão de câmera dentro dos campos da nota e do bipe.
- No campo da nota, a câmera lê o código de barras ou o QR code do DANFE. No campo de bipe, lê o QR code da etiqueta.
- A câmera só funciona pelo endereço seguro do sistema (https), e o navegador pede autorização na primeira vez.

---

## 1.0.0.31 — 05/11/2026

### Coletor: etiqueta de produto com escolha do item
- Se o produto tiver 2 ou mais itens na composição, a tela **Gerar etiqueta** pergunta qual deles usar, com o código e a descrição de cada um.
- O campo **Lote** carrega os lotes do item escolhido.
- A etiqueta continua saindo com o código do produto principal: o item serve só para definir o lote.

### Coletor: só lotes dentro da validade
- Em **Gerar etiqueta**, de produto e de kit, os lotes vencidos deixam de aparecer na lista.

### Simulador: pacotes por caixa vêm do cadastro
- A quantidade de pacotes por caixa agora vem direto do cadastro do produto. Os produtos com pacote continuam com o mesmo número.
- Os produtos a granel, que antes mostravam "—", agora podem ser simulados: nesse caso, o "pacote" é a caixa inteira, então informe o valor da caixa.

---

## 1.0.0.30 — 04/11/2026

### Coletor: gerar etiqueta de produto
- Novo botão **Gerar etiqueta** no Coletor, para quem tem a liberação **Coletor (etiquetas)** no cadastro.
- **Produtos:** escolha o produto, o lote e a quantidade. Cada etiqueta sai com o QR code da coleta, o código do produto e o número do lote.
- **Kit:** escolha o kit e o lote de cada componente. Um único QR code leva todos os componentes, com as quantidades do kit.
- O tamanho da etiqueta e quantas saem por linha são definidos em **Gestão › Coletor**.

### Coletor: lote exigido separado para produto e kit
- Em **Gestão › Coletor**, dá para exigir o lote separadamente para produto e para kit, tanto na conferência quanto na etiqueta.
- Na etiqueta, se o lote não for exigido, o campo oferece **Sem lote**.

---

## 1.0.0.29 — 04/11/2026

### Simulador: Tipo Docto conforme o plano de compra e venda
- O campo **Tipo Docto** passa a mostrar apenas tipos de documento ligados a um plano de compra e venda.

### Simulador: pedido carregado usa a tabela de preço do pedido
- Ao usar um pedido na simulação, cada item fica com a tabela de preço que tem no pedido.
- Se essa tabela não estiver mais disponível (por exemplo, um pedido antigo com tabela inativa), o item fica sem valor de tabela e a mensagem mostra quais itens ficaram assim.
- Para esses itens, escolha outra tabela no botão **>** ao lado do Vl tabela.

### Simulador: escolha o que fazer com os itens ao usar um pedido
- Se já houver itens na simulação, o sistema pergunta o que fazer ao usar um pedido.
- **Apagar os itens existentes:** a simulação fica só com os itens do pedido.
- **Só incrementar:** os itens continuam na simulação. Os que também estão no pedido são substituídos pelos dados do pedido, sem duplicar.
- No **Carregar pedido**, o cliente passa a ser o do pedido nos dois casos.

---

## 1.0.0.28 — 03/11/2026

### Simulador: % dos tributos digitado no topo aparece nos itens
- O % digitado no quadro **Tributos** agora aparece no **(+)** de cada item que não tem % próprio.
- O item usa, nesta ordem: o % digitado nele, o % digitado no topo e o % que veio da tributação.
- Com a chave do imposto em **Não**, esse imposto não é usado.

### Coletor: nota só sai de "em conferência" quando é finalizada
- Ao tocar em **Finalizar**, a nota fica marcada no banco como finalizada, com a data e quem finalizou.
- A nota não finalizada não some mais da tela. Se ela tiver leituras e ninguém estiver com ela, aparece em **Coletas em andamento › Não finalizadas, sem conferente**. Tocar nela continua a conferência.
- Abrir uma nota já finalizada mostra quem finalizou e quando, e pergunta se quer **Reabrir**. Reabrir volta a nota para "em conferência".
- Excluir ou cancelar uma leitura, abandonar ou liberar a nota também tira a marcação de finalizada.
- Na Manutenção, as notas sem conferente aparecem como "sem conferente" e também podem ser liberadas.

### Coletor: notas conforme o plano de compra e venda
- O Coletor passa a mostrar apenas notas de tipos de documento ligados a um plano de compra e venda.

---

## 1.0.0.27 — 02/11/2026

### Tela de trocar senha mais limpa
- Ao trocar a senha, a tela mostra só os campos da senha. Os botões Simulador, Coletor, Gestão do sistema, Digital/rosto e Sair voltam ao terminar ou cancelar.

### Usuários: master segue as liberações
- O usuário **master** acessa a Gestão e gerencia usuários, mas agora só vê os relatórios e as ferramentas (Simulador, Coletor) marcados no cadastro dele, como os demais usuários.
- Ao atualizar, confira o cadastro de cada master e marque o que ele deve ver.

### Simulador: parâmetros por UF no próprio Simulador
- No cadastro de usuário (Gestão) há a nova opção **Simulador de preços (manutenção)**. Ela vem desmarcada para todos, inclusive master, e precisa ser liberada usuário por usuário.
- Quem tem a opção vê, no Simulador, o botão **Manutenção**, antes do "Carregar pedido". Ele abre a tabela de parâmetros por UF para alterar e salvar. A simulação aberta já passa a usar os valores novos.
- A tabela saiu da Gestão › Simulador, que ficou só com os SQLs.
- "Simulador de preços (manutenção)" só pode ser marcada junto com "Simulador de preços".

### Coletor: página de manutenção
- No cadastro de usuário (Gestão) há a nova opção **Coletor (manutenção)**. Ela vem desmarcada para todos, inclusive master, e precisa ser liberada usuário por usuário.
- Quem tem a opção vê, na tela inicial do Coletor, o balão **Manutenção**. Ele abre uma página com as notas **em conferência** (de todos os conferentes, com quem está conferindo e desde quando) e as notas **a conferir** a partir da data definida em Gestão › Coletor › Ajustes.
- Quem tem só "Coletor (manutenção)", sem a conferência, também vê o botão **Coletor** no SimoIA. Ele abre direto a página de manutenção.
- Cada nota em conferência mostra quanto já foi bipado (por exemplo, "Bipados: 30 de 50") e tem o botão **Liberar**. Liberar cancela todos os bipes da nota e a deixa livre para outro conferente começar do zero. Não dá para liberar enquanto o conferente está dentro da coleta: a nota aparece como "coletando agora", e o botão só libera depois que ele sair.
- A página de manutenção é só de consulta: tocar numa nota não abre a conferência.
- A lista de coletas em andamento e o botão **Liberar** saíram da Gestão › Coletor. Agora ficam só na Manutenção do Coletor.

---

## 1.0.0.26 — 02/11/2026

### Coletor: exclusões e abandono mais seguros
- Se você tocar em **Voltar** com exclusões em andamento, elas continuam até terminar. Não precisa esperar na tela da nota.
- Ao **Abandonar** uma coleta, o sistema espera terminar o que estava sendo gravado ou excluído e então cancela tudo. Nenhum bipe fica gravado depois do abandono.

### Coletor: aviso em vermelho enquanto ainda está gravando
- Com todos os itens conferidos, mas com leituras ainda sendo gravadas, o "Gravando… leituras" e o texto embaixo do botão **Finalizar** ficam vermelhos. Assim fica claro por que o botão ainda não liberou. Quando tudo é gravado, ele volta ao normal.

### Coletor: excluir e já bipar de novo
- Corrigido: ao excluir as leituras de um item e bipar o mesmo item logo em seguida, as leituras antigas voltavam a ser somadas. Agora a contagem recomeça do zero, sem precisar esperar. Também não some mais o bipe feito enquanto a exclusão está em andamento. Ao excluir vários itens seguidos, todos saem na hora: o sistema exclui um de cada vez, sem precisar esperar.

### Coletor: etiqueta com vários produtos em qualquer ordem
- Na conferência por produto, uma etiqueta com vários produtos é aceita mesmo que eles estejam fora da ordem da nota, desde que um deles seja o item atual.

### Coletor: aviso de produto errado na hora
- Na conferência por produto, se você bipar um produto diferente do item atual (ou que não está na nota), o aviso aparece na hora, sem pedir o lote antes. Menos toques para seguir a conferência.

### Gestão: data em que cada versão foi instalada
- Na guia **Atualizações**, cada versão mostra quando foi instalada neste servidor (a partir desta versão).

---

## 1.0.0.25 — 02/11/2026

### Coletor: nova ordem dos itens na conferência por produto
- Primeiro aparecem os itens que têm localização no depósito, na ordem da localização.
- Depois vêm os itens sem localização, na ordem em que estão na nota (sequência) e, empatando, em ordem alfabética.

### Coletor: Gestão decide se dá para informar a quantidade
- Em **Gestão › Coletor › Ajustes** há a opção **Permitir ligar "Informar quantidade"**.
- Desmarcada, a chave "Informar quantidade" continua aparecendo no Coletor, mas fica desligada e não pode ser mudada: cada bipe vale 1. A quantidade que vem no QR code da etiqueta continua valendo.

### Gestão: liberar uma nota do Coletor zera a conferência
- Ao clicar em **Liberar** numa coleta em andamento (Gestão › Coletor), todos os bipes já feitos naquela nota são cancelados. Quem pegar a nota depois começa a conferência do zero.

### Coletor: suas coletas primeiro e a lista de notas a conferir
- Na tela inicial, as **suas coletas** aparecem sempre primeiro, começando pelas que você pode abrir neste aparelho. Depois vêm as dos outros conferentes.
- Logo abaixo, a nova lista **Notas a conferir** mostra as notas que ainda ninguém começou a conferir. Toque numa nota para abri-la.
- Na **Gestão › Coletor › Ajustes** dá para ligar ou desligar essa lista e escolher **a partir de qual data** as notas aparecem.

### Simulador: botão "Atualizar" também para os dados do cliente
- Logo depois de o sistema ser reiniciado, os dados do cliente (UF, Suframa, regime e classificação de ICMS) às vezes demoram para carregar. Agora, se isso acontecer, aparece o botão **Atualizar** nas Configurações, como já acontecia com a tabela de preço, o custo e o Tipo Docto. Um clique recarrega tudo sem sair da página.
- Corrigido: quando a classificação de ICMS chegava atrasada, o botão de adicionar produtos ficava travado mesmo com tudo preenchido.

### Simulador: cada produto pode ter a sua tabela de preço
- Ao lado do **Vl tabela** de cada item há um botão **>**. Clique nele para ver as tabelas de preço que têm aquele produto e escolher uma. O item passa a usar o preço dessa tabela, e o botão fica destacado.
- Ao **Integrar**, cada produto vai para o pedido com a tabela escolhida para ele.
- O botão **>** ao lado da **Tabela de preço**, nas Configurações, aplica essa tabela em todos os itens de novo. Produto que não tem preço nela fica sem preço.
- Trocar a Tabela de preço nas Configurações muda só os itens que não têm tabela própria.

---

## 1.0.0.24 — 02/11/2026

### Coletor: etiqueta com a quantidade dentro do QR code
- A etiqueta agora pode informar a quantidade, por exemplo: `cod_item:4555|num_lote:123|qtde:2`. Ao bipar, o Coletor já lança 2 unidades daquele item e lote, sem perguntar nada.
- Etiqueta só com o código do item lança 1 unidade. Se o produto exige lote, o Coletor pede o lote no teclado (antes dava erro).
- Etiqueta com código e lote, sem quantidade, lança 1 unidade.
- Se a quantidade da etiqueta estiver errada (ou com vírgula num produto que não aceita), a leitura é recusada e aparece um aviso.
- Continua valendo: o sistema não deixa lançar produto que não é da nota nem passar da quantidade da nota.

### Coletor: botão "Teclado"
- O botão para lançar sem bipar agora se chama **Teclado**, nas duas formas de conferência (por produto e cega).
- Com **"Informar quantidade" desligada**, cada lançamento vale 1 unidade: o Teclado lança 1 direto e o atalho "2*código" não é aceito.
- Com **"Informar quantidade" ligada**, o Teclado pergunta a quantidade, como antes.

### Coletor: aviso de "Não gravou" some quando a leitura é gravada
- Se a internet ou o servidor falhar por um instante, aparece "Não gravou… tentando de novo". Agora, assim que a leitura é gravada, o aviso troca para **"✓ Leituras pendentes gravadas."**, para você saber que está tudo certo.

### Gestão: escolher o tipo de conferência do Coletor
- Em **Gestão › Coletor › Ajustes** há a opção **Padrão de conferência**:
  - **Todas:** o conferente escolhe entre conferência cega e por produto (como era antes).
  - **Por produto** ou **Cega:** a nota já abre direto nesse tipo, sem a tela de escolha.
- Notas que já foram começadas continuam no tipo em que começaram.

### Gestão: nova guia "Atualizações"
- Esta guia, onde você acompanha as novidades de cada versão do sistema. A versão mais nova aparece em cima.

### Tela principal
- Depois de entrar no sistema, a página abre sempre no topo.
- Novo botão redondo no canto de baixo da tela para **voltar ao topo** rapidamente.
- Aviso sobre o uso de cookies, que só servem para o sistema funcionar (manter o login, o tema e o aparelho). Basta clicar em **"Aceitar e fechar"** uma vez.

---

## 1.0.0.23 — 01/11/2026

Primeira versão numerada do sistema.

### Número da versão à vista
- A versão em uso aparece no rodapé da tela principal e na Gestão, para saber qual versão está rodando.

### Melhorias internas
- Ajustes nas conexões com o banco de dados e no cálculo de tributos do Simulador de preços, sem mudança no jeito de usar.
- Atualização do sistema no servidor da empresa ficou mais rápida e segura, mantendo os dados e as configurações de vocês.
